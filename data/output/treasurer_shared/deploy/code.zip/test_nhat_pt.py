# -*- coding: utf-8 -*-
"""test_nhat_pt.py — TEST live code AUTO-NHẶT (op54→op56 toàn bộ) + AUTO-VÀO-TỔ-ĐỘI (op79→op92), độc lập
với cài đặt profile (user TẮT nhặt/pt trong auto để thử). Char cứ để autoplay đánh; script lo nhặt + accept party.
Dùng: (char đang cày)  venv/bin/python -u test_nhat_pt.py [secs] [device]
"""
import sys, time, os
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot
from core.equip_matcher import split_frames

_a = sys.argv[1:]
SECS = next((int(x) for x in _a if x.isdigit() and int(x) > 30), 600)
DEV = next((x for x in _a if (":" in x or x.startswith("emulator"))), "127.0.0.1:26624")
LOG = "data/output/test_nhat_pt.log"
os.makedirs("data/output", exist_ok=True)
_lf = open(LOG, "w", encoding="utf-8")
def emit(s): print(s, flush=True); _lf.write(s+"\n"); _lf.flush()


def _vint(b, i):
    v = 0; sh = 0
    while i < len(b):
        c = b[i]; i += 1; v |= (c & 0x7f) << sh; sh += 7
        if not c & 0x80: break
    return v, i


def op54_objid(hx):
    try:
        b = bytes.fromhex(hx)[6:]
        if len(b) >= 2 and b[0] == 0x0a:
            ln = b[1]; return b[2:2+ln].decode('utf-8', 'ignore')
    except Exception:
        pass
    return None


def op79_teamid(hx):
    """PartyData field4 = teamId."""
    try: b = bytes.fromhex(hx)[6:]
    except Exception: return None
    i = 0
    while i < len(b):
        tag = b[i]; i += 1; f = tag >> 3; w = tag & 7
        if w == 2:
            ln = b[i]; i += 1; sub = b[i:i+ln]; i += ln
            if f == 1:
                j = 0
                while j < len(sub):
                    t2 = sub[j]; j += 1; f2 = t2 >> 3; w2 = t2 & 7
                    if w2 == 0:
                        v, j = _vint(sub, j)
                        if f2 == 4: return v
                    elif w2 == 2:
                        l2 = sub[j]; j += 1; j += l2
                    else: break
        elif w == 0:
            _, i = _vint(b, i)
        else: break
    return None


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect():
        emit("connect FAIL (UI Auto giữ Frida? tắt Auto cửa sổ đó)"); return
    for _ in range(5):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.3)
    try: bot.redetect_fd_by_traffic()
    except Exception: pass
    pi = bot.rpc.get_player_info() or {}
    emit(f"[*] TEST nhặt+pt {SECS}s | {DEV} char={pi.get('name')!r}. TẮT nhặt/pt trong profile + để char cày. log={LOG}\n")
    picked = set(); joined_team = None; npick = naccept = n48 = 0
    t0 = time.time()
    while time.time() - t0 < SECS:
        try: pk = bot.poll_recv() or []
        except Exception: pk = []
        for p in pk:
            for op, hx in (split_frames(p.get('hex', '')) or [(p.get('opcode'), p.get('hex', ''))]):
                if op == 54:                      # đồ rơi -> nhặt op56
                    oid = op54_objid(hx)
                    if oid and oid not in picked:
                        picked.add(oid); bot.pickup(str(oid)); npick += 1
                        emit(f"  t+{int(time.time()-t0)}s 🫳 nhặt op56 id={oid}")
                elif op == 79:                    # mời tổ đội -> accept op92
                    tid = op79_teamid(hx)
                    if tid and tid != joined_team:
                        bot.accept_party(tid); joined_team = tid; naccept += 1
                        emit(f"  t+{int(time.time()-t0)}s 🤝 tự vào tổ đội teamId={tid}")
                elif op == 77:
                    joined_team = None            # mình rời -> cho vào lại
                elif op == 48:
                    n48 += 1                       # xác nhận nhặt (đồ-chí/bạc/đồ)
        time.sleep(0.05)
    emit(f"\n[xong] {SECS}s | đã bắn op56={npick} | op48(nhặt xác nhận)={n48} | accept party={naccept}")


if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: emit("\n[*] Dừng.")
    finally: _lf.close()
