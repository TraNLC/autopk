# -*- coding: utf-8 -*-
"""test_attack_all_near.py — PROVE "bắn op239 cho MỌI con near mỗi tick" (con trong tầm chết, con xa server bỏ).

Verify 2026-06-16: op239(skill,nid) GÂY DAME khi con TRONG TẦM (không cần lock). Vì RPC không có toạ độ để
lọc tầm → bắn HẾT con near mỗi vòng; server tự bỏ con ngoài tầm. Test này đo: bao nhiêu con chết + nhịp gói.

Pha HỌC: đánh chiêu tay 1 con vài lần → học skillId. Rồi DỪNG tay → script tự bắn MỌI con near mỗi ~0.8s.

Dùng: TẮT UI cửa sổ → venv/bin/python -u test_attack_all_near.py [device] [secs] [skillId]
"""
import sys, time
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

_a = sys.argv[1:]
DEV = next((x for x in _a if (":" in x or x.startswith("emulator"))), "127.0.0.1:26624")
_nums = [int(x) for x in _a if x.isdigit()]
SECS = next((n for n in _nums if 10 <= n <= 300), 40)
SKILL = next((n for n in _nums if n > 300), None)   # skillId >300 (vd 362) → bỏ pha học; không truyền → học


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect():
        print("connect FAIL (UI bot còn attach? tắt rồi chạy lại)"); return
    bot.capture_sent = True
    for _ in range(6):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.3)
    try: bot.redetect_fd_by_traffic()
    except Exception as e: print(f"redetect: {e}")
    try:
        p = bot.rpc.ping(); pi = bot.rpc.get_player_info() or {}
        print(f"gameFd={p.get('gameFd')} recvAny={p.get('recvAny')} CHAR={pi.get('name')!r}")
    except Exception as e: print(f"ping/char: {e}")

    def snap():
        try: r = bot.rpc.get_near_npcs_detail() or {}
        except Exception: return {}
        return {str(n.get("id")): {"name": n.get("name") or "?", "hp": n.get("hp")}
                for n in (r.get("npcs") or []) if (n.get("hpMax", 0) or 0) > 0}

    skill = SKILL
    # ---- PHA HỌC skillId (nếu chưa truyền) ----
    if skill is None:
        print("\n==> PHA HỌC (≤25s): đánh chiêu tay 1 con vài lần để học skillId. Học xong tôi báo DỪNG tay.\n")
        bot.sent_buffer = []; t0 = time.time()
        while time.time() - t0 < 25 and skill is None:
            try: bot.poll_recv()
            except: pass
            for pp in list(getattr(bot, "sent_buffer", [])):
                if pp.get("opcode") == 239:
                    try:
                        b = bytes.fromhex(pp.get("hex", ""))[6:]
                        if b and b[0] == 0x08:
                            v = 0; s = 0; i = 1
                            while i < len(b):
                                c = b[i]; i += 1; v |= (c & 0x7F) << s; s += 7
                                if not c & 0x80: break
                            skill = v
                    except Exception: pass
                    if skill: break
            bot.sent_buffer = []; time.sleep(0.05)
        if skill is None:
            print("❌ Không học được skillId (chưa đánh tay đúng lúc). Chạy lại + đánh chiêu tay liên tục."); return
        print(f">>> HỌC ĐƯỢC skillId={skill}. 🛑 DỪNG ĐÁNH TAY — bắt đầu auto-bắn-mọi-con sau 2s.")
        time.sleep(2.0)

    # ---- KIỂM CHỨNG CHỐNG NHIỄM 5s: KHÔNG gửi gói. Con nào tụt HP = autoplay/đòn khác đang đánh → test HỎNG ----
    print("\n==> KIỂM CHỨNG 5s (KHÔNG gửi gói) — mọi con phải ĐỨNG YÊN nếu autoplay đã tắt hẳn:")
    s0 = snap()
    for s in range(5):
        t1 = time.time()
        while time.time() - t1 < 1.0:
            try: bot.poll_recv()
            except: pass
            time.sleep(0.05)
    s1 = snap()
    drifted = [k for k in s0 if (k not in s1) or (s0[k]["hp"] is not None and s1.get(k, {}).get("hp") is not None and s1[k]["hp"] < s0[k]["hp"])]
    if drifted:
        print(f"⚠️⚠️ {len(drifted)} con TỰ TỤT/CHẾT khi tôi gửi 0 gói (vd {drifted[:3]}) → AUTOPLAY CÒN BẬT → test HỎNG. Tắt hẳn auto rồi chạy lại."); return
    print(f"   ✓ {len(s1)} con đứng yên suốt 5s = SẠCH (không gì khác đánh). Giờ mới spam.")

    before = snap()
    if not before:
        print("❌ Không thấy con quái nào quanh (ra bãi quái rồi chạy lại)."); return
    print(f"\n==> AUTO bắn skill {skill} vào MỌI con near, {SECS}s. ĐỨNG YÊN, ĐỪNG đánh tay.")
    print(f"   [BASELINE] {len(before)} con: " + ", ".join(f"{v['name']}#{k}={v['hp']}" for k, v in before.items()))

    t0 = time.time(); ticks = 0; sent = 0; killed = set()
    while time.time() - t0 < SECS:
        cur = snap()
        nids = list(cur.keys())
        for nid in nids:                       # bắn MỌI con near — server tự bỏ con ngoài tầm
            bot.send_gs('eDoSkillTargetNpc', skillid=int(skill), nid=str(nid)); sent += 1
        ticks += 1
        # con biến mất so với baseline = chết
        for k in before:
            if k not in cur: killed.add(k)
        t1 = time.time()
        while time.time() - t1 < 0.8:
            try: bot.poll_recv()
            except: pass
            time.sleep(0.05)
        if ticks % 5 == 0:
            print(f"   tick {ticks}: {len(nids)} con near | đã bắn {sent} gói | chết tới giờ: {len(killed)}")

    after = snap()
    print(f"\n=== KẾT QUẢ sau {SECS}s ({ticks} tick, {sent} gói op239, ~{sent/max(SECS,1):.1f} gói/s) ===")
    dead = 0
    for k, v in before.items():
        gone = k not in after
        ha = after.get(k, {}).get("hp")
        drop = (v["hp"] is not None and ha is not None and ha < v["hp"])
        if gone: dead += 1
        tail = "  ☠️ CHẾT" if gone else ("  💥 tụt" if drop else "  (không đổi=ngoài tầm?)")
        print(f"   {v['name']}#{k}: {v['hp']} → {('mất' if gone else ha)}{tail}")
    print(f"\n----- {dead}/{len(before)} con CHẾT. " +
          ("✅ 'bắn mọi con near' giết được con trong tầm → wire vào bot được." if dead else
           "❌ 0 con chết — kiểm tra đứng trong bãi quái + skill đúng."))


if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: print("\n[*] Dừng.")
