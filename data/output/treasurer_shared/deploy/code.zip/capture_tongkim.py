# -*- coding: utf-8 -*-
"""capture_tongkim.py — GHI GÓI flow Tống Kim để code auto (báo danh → máu → ra trận → auto → chết-lặp).

Cách Tống Kim hoạt động: chưa có trong code → PHẢI bắt gói khi chơi TAY 1 lần. Probe này:
  - TỰ NGHE thông báo server (op133/247/118...) chứa "tống kim"/"báo danh"/"khai chiến"/"quân nhu" → IN ĐẬM
    "⚔️ TỐNG KIM MỞ — CHƠI NGAY" (khỏi canh giờ tay).
  - GHI MỌI gói OUT (client GỬI) — quan trọng nhất: eNpcDialogue(op33, npcId), eNpcSelect(selectIndex),
    eSendStorageMoney (rút tiền), op140 (autoplay), eGotoPosition/goto (ra vị trí). Kèm giải mã npcId/selectIndex.
  - GHI map đổi (vào doanh trại / ra chiến trường) + vị trí, để biết "đang ở đâu".
  - Lọc gói ồn (di chuyển/sync) cho timeline sạch.

DÙNG (TẮT UI cửa sổ đó):  venv/bin/python -u capture_tongkim.py [secs] [device]
  vd:  venv/bin/python -u capture_tongkim.py 2400 127.0.0.1:26624     (chạy nền 40 phút, canh qua 1 trận)
Khi thấy "⚔️ TỐNG KIM MỞ" → tới Quân Nhu Quan báo danh → vào trại → NPC máu → NPC chiến đấu chọn vị trí →
bật Auto → đánh tới chết. Làm THẬT CHẬM, RÕ từng bước. Xong copy log gửi lại (data/output/capture_tongkim.log).
"""
import sys, time, os
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

_a = sys.argv[1:]
SECS = next((int(x) for x in _a if x.isdigit() and int(x) > 60), 2400)
DEV = next((x for x in _a if (":" in x or x.startswith("emulator"))), "127.0.0.1:26624")
# Từ khoá thông báo Tống Kim (chuẩn hoá không dấu để khớp text server)
TK_KW = ["tong kim", "tống kim", "bao danh", "báo danh", "khai chien", "khai chiến", "quan nhu", "quân nhu"]
# Gói ồn (di chuyển/đồng bộ) — bỏ khỏi timeline để thấy gói tương tác.
NOISE = {7, 8, 9, 16, 17, 18, 19, 20, 23, 40, 54, 63, 66, 68, 69, 70, 83, 87, 90, 94, 117, 120, 251}
LOG = "data/output/capture_tongkim.log"
os.makedirs("data/output", exist_ok=True)
_lf = open(LOG, "w", encoding="utf-8")
def emit(s): print(s, flush=True); _lf.write(s + "\n"); _lf.flush()


def _vi(b, o):
    """đọc varint protobuf từ bytes b tại offset o -> (value, new_offset)."""
    r = sh = 0
    while o < len(b):
        x = b[o]; o += 1; r |= (x & 0x7F) << sh
        if not x & 0x80:
            break
        sh += 7
    return r, o


def _first_varint_field1(body):
    """gói eNpcDialogue/eNpcSelect: field1 (tag 0x08) = npcId / selectIndex. Trả int hoặc None."""
    try:
        if body and body[0] == 0x08:
            v, _ = _vi(body, 1)
            return v
    except Exception:
        pass
    return None


def _text(hexs):
    """rút chuỗi UTF-8 in được từ hex (để đọc thông báo/menu)."""
    try:
        raw = bytes.fromhex(hexs)
    except Exception:
        return ""
    out = bytearray()
    for c in raw:
        if 32 <= c < 127 or c >= 0xC2:
            out.append(c)
    try:
        s = out.decode("utf-8", "ignore")
    except Exception:
        s = ""
    return "".join(ch for ch in s if ch.isprintable()).strip()


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect():
        emit("connect FAIL (UI bot còn attach? tắt rồi chạy lại)"); return
    bot.capture_sent = True
    for _ in range(6):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.3)
    try: bot.redetect_fd_by_traffic()
    except Exception as e: emit(f"redetect: {e}")
    try: emit(f"recvAny={bot.rpc.ping().get('recvAny')} (phải >0)")
    except Exception as e: emit(f"ping: {e}")

    def pos():
        try:
            r = bot.rpc.get_player_info() or {}
            return r.get("mapId"), r.get("mapX"), r.get("mapY"), r.get("name")
        except Exception:
            return None, None, None, None

    mid0, x0, y0, nm = pos()
    emit(f"[*] GHI GÓI TỐNG KIM {SECS}s | {DEV} | char={nm} map={mid0} ({x0},{y0}). log={LOG}")
    emit("    → Khi thấy '⚔️ TỐNG KIM MỞ' thì làm TAY từng bước CHẬM: Quân Nhu Quan→báo danh→vào trại→NPC máu→NPC chiến đấu→Auto.\n")
    t0 = time.time(); seen_sent = 0; last_map = mid0; last_beat = 0.0; alerted = False
    try: bot.recv_buffer = []
    except Exception: pass
    seen_recv = 0

    while time.time() - t0 < SECS:
        try: bot.poll_recv()
        except: pass
        now = time.time(); el = now - t0

        # OUT (client gửi) — quan trọng nhất
        sb = list(getattr(bot, "sent_buffer", []))
        for p in sb[seen_sent:]:
            op = p.get("opcode"); nme = p.get("name") or "?"; hx = p.get("hex") or ""
            if op in NOISE:
                continue
            body = b""
            try: body = bytes.fromhex(hx)[6:]
            except Exception: pass
            extra = ""
            if op == 33 or "NpcDialogue" in nme:
                v = _first_varint_field1(body); extra = f"  npcId={v}" if v is not None else ""
            elif "NpcSelect" in nme:
                v = _first_varint_field1(body); extra = f"  selectIndex={v}" if v is not None else "  (select rỗng)"
            elif "StorageMoney" in nme:
                extra = "  (rút/cất bạc)"
            elif op == 140:
                extra = "  (autoplay profile)"
            emit(f"  t+{el:6.1f}s →OUT op{op} ({nme}){extra}  {hx[:120]}")
        seen_sent = len(sb)

        # IN (server) — thông báo + menu NPC (34/124) + text
        rb = list(getattr(bot, "recv_buffer", []))
        for p in rb[seen_recv:]:
            op = p.get("opcode"); nme = p.get("name") or "?"; hx = p.get("hex") or ""
            txt = _text(hx)
            low = txt.lower()
            if any(k in low for k in TK_KW):
                if not alerted:
                    emit("\n" + "=" * 60)
                    emit(f"  ⚔️⚔️ TỐNG KIM MỞ (t+{el:.0f}s) — CHƠI NGAY, làm tay từng bước CHẬM!")
                    emit("=" * 60 + "\n")
                    alerted = True
                emit(f"  t+{el:6.1f}s ←IN op{op} ({nme}) [TK] {txt[:140]}")
            elif op in (34, 124, 166, 167, 245, 247, 148):    # menu NPC / thưởng / thông báo riêng / shop
                emit(f"  t+{el:6.1f}s ←IN op{op} ({nme}) {txt[:120]}  {hx[:80]}")
        seen_recv = len(rb)
        if len(rb) > 4000:
            bot.recv_buffer = rb[-1000:]; seen_recv = len(bot.recv_buffer)

        # MAP đổi = vào trại / ra chiến trường
        mid, x, y, _ = pos()
        if mid is not None and mid != last_map:
            emit(f"  t+{el:6.1f}s 🗺️ ĐỔI MAP {last_map} → {mid}  (vị trí {x},{y})")
            last_map = mid

        if now - last_beat > 30:
            last_beat = now
            emit(f"  --- t+{el:.0f}s: map {mid} ({x},{y}) | đang nghe… ---")
        time.sleep(0.15)

    emit(f"\n[xong] {SECS}s. Gửi tôi toàn bộ {LOG} (nhất là các dòng →OUT op33/NpcSelect + 🗺️ ĐỔI MAP).")


if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: emit("\n[*] Dừng.")
    finally: _lf.close()
