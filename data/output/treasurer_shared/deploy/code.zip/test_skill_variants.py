# -*- coding: utf-8 -*-
"""test_skill_variants.py — THỬ LIÊN TIẾP nhiều biến thể gói skill vào 1 con, đo HP sau mỗi biến thể.
Tìm gói khiến caster (skill 362) THỰC SỰ trừ máu (hand-cast có dame, replay op239 thì không).
CHỈ tính DAME khi HP% GIẢM (KHÔNG tính 'mất khỏi list' = có thể đi lạc/despawn).
⚠️ TẮT autoplay + KHÔNG đánh tay. Có pre-check 5s chống nhiễm.
Dùng: venv/bin/python -u test_skill_variants.py [device] [skillId]
"""
import sys, time
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

_a = sys.argv[1:]
DEV = next((x for x in _a if (":" in x or x.startswith("emulator"))), "127.0.0.1:26624")
SKILL = next((int(x) for x in _a if x.isdigit() and int(x) > 50), 362)


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect():
        print("connect FAIL"); return
    bot.capture_sent = True
    for _ in range(6):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.3)
    try: bot.redetect_fd_by_traffic()
    except Exception as e: print("redetect:", e)
    pi = {}
    try:
        p = bot.rpc.ping(); pi = bot.rpc.get_player_info() or {}
        print(f"gameFd={p.get('gameFd')} recvAny={p.get('recvAny')} CHAR={pi.get('name')!r} cid={pi.get('cid')!r} pos=({pi.get('mapX')},{pi.get('mapY')})")
    except Exception as e: print("ping/char:", e)
    mycid = str(pi.get('cid') or "")
    myx = int(pi.get('mapX') or 0); myy = int(pi.get('mapY') or 0)

    def snap():
        try: r = bot.rpc.get_near_npcs_detail() or {}
        except Exception: return {}
        return {str(n.get("id")): {"name": n.get("name") or "?", "hp": n.get("hp")}
                for n in (r.get("npcs") or []) if (n.get("hpMax", 0) or 0) > 0}

    s0 = snap()
    if not s0:
        print("❌ Không thấy con quái nào. Đứng sát quái rồi chạy lại."); return
    # chọn target = con HP cao nhất (đầy máu, dễ thấy tụt)
    target = sorted(s0.items(), key=lambda kv: -(kv[1]["hp"] or 0))[0][0]
    tname = s0[target]["name"]
    print(f"\nTARGET = {tname}#{target} (HP {s0[target]['hp']}%). Mọi con: " + ", ".join(f"{v['name']}#{k}={v['hp']}" for k,v in s0.items()))

    # PRE-CHECK 5s chống nhiễm
    print("\n[pre-check 5s, gửi 0 gói] HP target phải đứng yên:")
    h_a = (snap().get(target,{}) or {}).get("hp")
    time.sleep(5)
    h_b = (snap().get(target,{}) or {}).get("hp")
    if target not in snap() or (h_a is not None and h_b is not None and h_b < h_a):
        print(f"⚠️ HP tự đổi {h_a}->{h_b} (hoặc mất) khi gửi 0 gói → AUTOPLAY còn bật → tắt hẳn rồi chạy lại."); return
    print(f"   ✓ HP đứng yên {h_b}% = sạch.\n")

    def hp():
        return (snap().get(target,{}) or {}).get("hp")

    # ---- DANH SÁCH BIẾN THỂ: mỗi cái bắn 10 phát ~0.4s, đo HP trước/sau ----
    variants = [
        ("V1 op239(skill,nid) [baseline]",      lambda: bot.send_gs('eDoSkillTargetNpc', skillid=SKILL, nid=target)),
        ("V2 op40 eCastSkill targetType=1",     lambda: bot.send_gs('eCastSkill', launchType=1, launchId=mycid, targetType=1, targetId=target, skillId=SKILL, skillLevel=1, isNoAction=False)),
        ("V3 op40 eCastSkill targetType=2",     lambda: bot.send_gs('eCastSkill', launchType=1, launchId=mycid, targetType=2, targetId=target, skillId=SKILL, skillLevel=1, isNoAction=False)),
        ("V4 op40 eCastSkill targetType=0",     lambda: bot.send_gs('eCastSkill', launchType=0, launchId=mycid, targetType=0, targetId=target, skillId=SKILL, skillLevel=1, isNoAction=False)),
        ("V5 op40 launchType=2 tType=1",        lambda: bot.send_gs('eCastSkill', launchType=2, launchId=mycid, targetType=1, targetId=target, skillId=SKILL, skillLevel=1, isNoAction=False)),
        ("V6 op239 skillLevel? thử skill+0",    lambda: bot.send_gs('eDoSkillTargetNpc', skillid=SKILL, nid=target)),
    ]
    for label, fire in variants:
        if target not in snap():
            print(f"target {target} mất giữa chừng — dừng."); break
        before = hp()
        for _ in range(10):
            try: fire()
            except Exception as e: print(f"   ({label} gửi lỗi: {e})"); break
            t1=time.time()
            while time.time()-t1 < 0.4:
                try: bot.poll_recv()
                except: pass
                time.sleep(0.04)
        after = hp()
        gone = target not in snap()
        verdict = "💥 HP GIẢM = CÓ DAME!" if (before is not None and after is not None and after < before) else ("(mất khỏi list — KHÔNG chắc chết)" if gone else "không đổi")
        print(f"   {label}: HP {before} -> {('mất' if gone else after)}   {verdict}")

    print("\n→ Biến thể nào báo '💥 HP GIẢM' = đúng gói gây dame. Nếu tất cả 'không đổi' = chưa trúng, đào tiếp hướng facing/op9.")


if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: print("\n[*] Dừng.")
