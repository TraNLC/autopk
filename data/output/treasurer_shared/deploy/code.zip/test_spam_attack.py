# -*- coding: utf-8 -*-
"""test_spam_attack.py — Bắn gói đánh (eDoSkillTargetNpc skill=1) LIÊN TỤC vào mọi quái trong tầm,
trong lúc người chơi CHẠY VÒNG VÒNG sát quái. Xem có gây dame/giết được không (auto-đánh bằng packet).

Dùng: (TẮT UI) venv/bin/python -u test_spam_attack.py [secs] [device]
"""
import sys, time
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

SECS = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 40
DEV = next((a for a in sys.argv[1:] if not a.isdigit()), "127.0.0.1:26624")


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect():
        print("connect FAIL"); return
    for _ in range(8):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.4)
    bot.redetect_fd_by_traffic()
    p = bot.rpc.ping()
    print(f"gameFd={p.get('gameFd')} recvAny={p.get('recvAny')}")
    if not p.get("recvAny"):
        print("recvAny=0 — chưa vào thế giới."); return

    def mobs():
        try:
            r = bot.rpc.get_near_npcs_detail() or {}
        except Exception:
            return {}
        return {str(n['id']): n for n in (r.get('npcs') or []) if (n.get('hpMax', 0) or 0) > 0}

    print(f"\n==> BẮN ĐÁNH LIÊN TỤC {SECS}s — BẠN CHẠY VÒNG VÒNG SÁT QUÁI NGAY!\n")
    seen = {}          # id -> hp% cao nhất từng thấy
    dmg = set()        # id từng tụt máu do mình
    killed = set()     # id biến mất sau khi đang có máu (nghi chết)
    sent = 0
    t0 = time.time(); last = 0.0
    while time.time() - t0 < SECS:
        cur = mobs()
        for i, n in cur.items():
            bot.send_gs('eDoSkillTargetNpc', skillid=1, nid=i); sent += 1
            hp = n.get('hp')
            if i in seen and isinstance(hp, int) and hp < seen[i]:
                if i not in dmg:
                    print(f"  💥 trúng id={i} {n.get('name')!r}: {seen[i]}→{hp}")
                dmg.add(i)
            seen[i] = max(seen.get(i, 0), hp or 0) if i not in dmg else hp
        # phát hiện chết: id từng thấy (máu>0) giờ biến mất
        for i in list(seen):
            if i not in cur and seen[i] and i not in killed:
                # chỉ tính nếu nó từng bị mình đánh tụt (tránh kết luận nhầm do ra tầm)
                if i in dmg:
                    print(f"  ☠️ id={i} CHẾT (biến mất sau khi tụt máu)")
                    killed.add(i)
        if time.time() - last > 5:
            last = time.time()
            print(f"  --- t+{int(time.time()-t0)}s | quái trong tầm={len(cur)} | đã gửi={sent} | "
                  f"con bị mình đánh tụt={len(dmg)} | nghi chết={len(killed)} ---")
        time.sleep(0.35)
    print(f"\n=== KẾT QUẢ {SECS}s: gửi {sent} gói đánh | {len(dmg)} con TỤT MÁU do mình | {len(killed)} con CHẾT ===")
    if dmg:
        print("✅ Vừa CHẠY vừa bắn gói đánh VẪN gây dame (con vào tầm là trúng) -> auto-đánh-bằng-packet KHẢ THI.")
    else:
        print("❌ Không con nào tụt -> cần đứng yên / bị chặn khi đang di chuyển.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[*] Dừng.")
