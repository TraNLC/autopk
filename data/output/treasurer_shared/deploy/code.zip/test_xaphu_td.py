# -*- coding: utf-8 -*-
"""Test xaphu_to_city_by_name (đọc-live, chọn theo tên). Ca lỗi: Biện Kinh → Tương Dương."""
import sys, time
sys.path.insert(0, '.')
from core.adb_helper import ADB_PATH
from core.device_discovery import discover_devices
from features.bot.game_bot import VLTK1Bot

dev = discover_devices(ADB_PATH, package="vn.perfingame.jx1mobile")[0]
bot = VLTK1Bot(device_id=dev); bot.connect(); time.sleep(2)
def mid():
    try: return (bot.rpc.get_player_info() or {}).get('mapId')
    except: return None
NAMES = {37:'Biện Kinh', 78:'Tương Dương', 80:'Dương Châu', 1:'Phượng Tường', 11:'Thành Đô', 176:'Lâm An', 162:'Đại Lý'}
def show(m): return f"{m} ({NAMES.get(m,'?')})"

print("map ĐẦU:", show(mid()))
# 1) về Biện Kinh trước (để test đúng ca BK→TD)
print(">>> đi Biện Kinh…")
print("  xaphu_to_city_by_name('Biện Kinh') =", bot.xaphu_to_city_by_name("Biện Kinh"))
time.sleep(2); print("  map giờ:", show(mid()))
# 2) BIỆN KINH → TƯƠNG DƯƠNG (ca bị lỗi cũ)
print(">>> đi Tương Dương (từ Biện Kinh — ca lỗi cũ)…")
ok = bot.xaphu_to_city_by_name("Tương Dương")
time.sleep(3); m = mid()
print("="*50)
print(f"KẾT QUẢ: trả {ok} | map SAU = {show(m)}")
print("  → 78 = ĐÚNG Tương Dương ✅✅ | 80 = vẫn Dương Châu ❌")
print("="*50)
