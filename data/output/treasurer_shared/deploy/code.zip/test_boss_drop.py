"""
test_boss_drop.py — BẮT gói server khi BOSS thả MẬT CHÍ (bot không nhặt được → nghi không phải op54).
Mục đích: tìm CHÍNH XÁC opcode + cấu trúc gói "thả mật chí" của boss để bot nhặt đúng.

DÙNG:
  1. TẮT Auto cửa sổ test (Frida attach 1 lần/PID). Đứng cạnh chỗ sắp đánh boss.
  2. venv/bin/python test_boss_drop.py 127.0.0.1:26624
  3. Khi probe báo "ĐANG BẮT", đánh boss cho rơi mật chí. Probe sẽ:
       - in MỌI opcode nhận được (đếm), và
       - in NGAY gói nào chứa chữ 'mật chí' / 'thần bí' / 'chí' (kèm opcode + hex) — đây là gói thả mật chí.
  4. Copy các dòng [HIT] gửi lại.
"""
import sys, time, re
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

KWS = ('mật chí', 'mật tịch', 'thần bí', 'chí')


def decode(hx):
    try:
        raw = bytes.fromhex(hx)[6:]
        return re.sub(r'<[^>]*>', '', raw.decode('utf-8', 'ignore'))
    except Exception:
        return ''


def main():
    dev = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1:26624"
    print(f"[*] Attach {dev}…", flush=True)
    bot = VLTK1Bot(device_id=dev)
    if not bot.connect():
        print("[-] Attach FAIL (còn bật Auto? game chưa vào?).", flush=True)
        return
    for _ in range(5):
        try: bot.poll_recv()
        except Exception: pass
        time.sleep(0.3)
    print("=" * 56, flush=True)
    print("👉 ĐANG BẮT (90s) — ĐÁNH BOSS cho rơi MẬT CHÍ…", flush=True)
    print("=" * 56, flush=True)
    t0 = time.time()
    op_count = {}
    hits = 0
    seen_hit = set()
    while time.time() - t0 < 90:
        try:
            pkts = bot.poll_recv() or []
        except Exception:
            pkts = []
        for p in pkts:
            op = p.get('opcode'); hx = p.get('hex', '') or ''
            op_count[op] = op_count.get(op, 0) + 1
            txt = decode(hx).lower()
            if any(k in txt for k in KWS):
                key = (op, hx[:60])
                if key in seen_hit:
                    continue
                seen_hit.add(key)
                hits += 1
                snippet = decode(hx)[:80].strip()
                print(f"[HIT] op={op} name={p.get('name','?')} text={snippet!r}", flush=True)
                print(f"      hex={hx}", flush=True)
        time.sleep(0.3)
    print("-" * 56, flush=True)
    print(f"[*] Xong. {hits} gói chứa từ khoá. Tần suất opcode:", flush=True)
    for op, c in sorted(op_count.items(), key=lambda x: -x[1])[:25]:
        print(f"    op={op}: {c}", flush=True)
    try: bot.close()
    except Exception: pass


if __name__ == "__main__":
    main()
