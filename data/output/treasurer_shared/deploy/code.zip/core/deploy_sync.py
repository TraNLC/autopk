# -*- coding: utf-8 -*-
"""core/deploy_sync.py — TỰ DEPLOY code giữa các máy qua Syncthing (folder treasurer_shared/deploy).

Luồng: MÁY NGUỒN (vinh) build xong -> publish(version) gom code -> `treasurer_shared/deploy/code.zip` +
`version.json` (kèm publisher=hostname). Syncthing đồng bộ folder đó sang MÁY KIA (linhdl). UI máy kia canh
định kỳ: thấy version MỚI (khác máy mình + khác bản đang chạy + chưa áp) -> giải nén code đè -> ghi cờ resume
(các cửa sổ đang chạy) -> re-exec app. Sau re-exec, UI tự bật Auto lại các cửa sổ đó.

KHÔNG sync venv/data/binaries (mỗi máy riêng). code.zip ~1MB (chỉ .py/.js). Máy NGUỒN không tự áp gói của
chính nó (publisher==hostname) -> tránh vòng lặp.
"""
import os
import json
import time
import socket
import zipfile

try:
    from core.paths import BASE as _ROOT
except Exception:
    _ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DEPLOY_DIR = os.path.join(_ROOT, "data", "output", "treasurer_shared", "deploy")
VERSION_FILE = os.path.join(DEPLOY_DIR, "version.json")
CODE_ZIP = os.path.join(DEPLOY_DIR, "code.zip")
APPLIED_FILE = os.path.join(_ROOT, "data", "output", ".deploy_applied.txt")   # local mỗi máy
RESUME_FILE = os.path.join(_ROOT, "data", "output", ".deploy_resume.json")    # local mỗi máy

# Thư mục source đưa vào gói deploy (KHÔNG venv/data/platform-tools/frida-server).
_CODE_DIRS = ["features", "core", "proto", "vendor", "database", "gui"]
_EXCLUDE_DIR = {"__pycache__"}
_EXCLUDE_SUFFIX = (".pyc", ".pyo")


def machine_id():
    h = socket.gethostname() or "may"
    return "".join(c if (c.isalnum() or c in "-_") else "_" for c in h)[:40] or "may"


def own_version():
    try:
        return open(os.path.join(_ROOT, "BUILD_VERSION.txt"), encoding="utf-8").read().strip()
    except Exception:
        return ""


def _read_remote():
    try:
        return json.load(open(VERSION_FILE, encoding="utf-8"))
    except Exception:
        return None


def last_applied():
    try:
        return open(APPLIED_FILE, encoding="utf-8").read().strip()
    except Exception:
        return ""


def mark_applied(version):
    try:
        os.makedirs(os.path.dirname(APPLIED_FILE), exist_ok=True)
        with open(APPLIED_FILE, "w", encoding="utf-8") as f:
            f.write(version or "")
    except Exception:
        pass


def has_new_deploy():
    """Trả (version, publisher) nếu có gói deploy MỚI từ máy KHÁC cần áp; ngược lại None."""
    rm = _read_remote()
    if not rm:
        return None
    ver = str(rm.get("version") or "").strip()
    pub = str(rm.get("publisher") or "").strip()
    if not ver:
        return None
    if pub == machine_id():       # gói do CHÍNH máy này phát -> bỏ
        return None
    if ver == own_version():      # đang chạy đúng bản đó rồi
        return None
    if ver == last_applied():     # đã áp (chờ/đã re-exec) rồi
        return None
    if not os.path.isfile(CODE_ZIP):
        return None
    return (ver, pub)


def apply_code_zip():
    """Giải nén code.zip đè lên _ROOT. Kiểm tra zip toàn vẹn trước (tránh áp gói đang sync dở). True nếu OK.
    SAU khi giải nén: XOÁ mọi __pycache__ để ép Python BIÊN DỊCH LẠI .pyc — nếu không, có máy giữ .pyc CŨ
    (mtime/size trùng khớp ngẫu nhiên) → re-exec vẫn chạy CODE CŨ dù file .py đã mới (đã từng làm LinhDL ẩn)."""
    try:
        with zipfile.ZipFile(CODE_ZIP) as z:
            if z.testzip() is not None:   # file lỗi -> zip chưa sync xong
                return False
            z.extractall(_ROOT)
        # dọn bytecode cũ → buộc dùng .py mới
        for root, dirs, files in os.walk(_ROOT):
            if os.path.basename(root) == "__pycache__":
                for fn in files:
                    try: os.remove(os.path.join(root, fn))
                    except Exception: pass
        return True
    except Exception:
        return False


def save_resume(devices):
    try:
        os.makedirs(os.path.dirname(RESUME_FILE), exist_ok=True)
        json.dump({"devices": list(devices), "ts": time.time()},
                  open(RESUME_FILE, "w", encoding="utf-8"))
    except Exception:
        pass


def pop_resume(max_age=900):
    """Đọc + XOÁ cờ resume. Trả list device nếu còn mới (< max_age giây), else []."""
    try:
        d = json.load(open(RESUME_FILE, encoding="utf-8"))
    except Exception:
        return []
    try:
        os.remove(RESUME_FILE)
    except Exception:
        pass
    try:
        if time.time() - float(d.get("ts", 0)) <= max_age:
            return list(d.get("devices") or [])
    except Exception:
        pass
    return []


def publish(version):
    """(MÁY NGUỒN) gom code -> code.zip + ghi version.json (publisher=máy này). Trả True nếu OK.
    Ghi code.zip TRƯỚC rồi version.json sau (atomic replace) để máy kia không thấy version mới khi zip chưa đủ."""
    try:
        os.makedirs(DEPLOY_DIR, exist_ok=True)
        tmp = CODE_ZIP + ".tmp"
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
            # file lẻ ở gốc
            for f in os.listdir(_ROOT):
                full = os.path.join(_ROOT, f)
                if os.path.isfile(full) and (f.endswith(".py") or f == "BUILD_VERSION.txt"):
                    z.write(full, f)
            # các thư mục code
            for d in _CODE_DIRS:
                base = os.path.join(_ROOT, d)
                if not os.path.isdir(base):
                    continue
                for root, dirs, files in os.walk(base):
                    dirs[:] = [x for x in dirs if x not in _EXCLUDE_DIR]
                    for fn in files:
                        if fn.endswith(_EXCLUDE_SUFFIX):
                            continue
                        full = os.path.join(root, fn)
                        z.write(full, os.path.relpath(full, _ROOT))
        os.replace(tmp, CODE_ZIP)   # atomic
        with open(VERSION_FILE, "w", encoding="utf-8") as f:
            json.dump({"version": version, "publisher": machine_id(), "ts": time.time()}, f)
        return True
    except Exception as e:
        print(f"[deploy publish] lỗi: {e}")
        return False
