"""
core/item_db.py — Học toàn bộ item của game từ file gốc data/game_raw/settings/item/*.txt.

Mỗi file item là TSV UTF-16LE. Cột (đã xác định bằng món tham chiếu thật):
  col0 = tên, col1 = genre, col2 = detail, col3 = particular, col11 = "cấp" (tier).
  (Vd Mặc Ngọc Ngọc Bội = genre0,detail9,particular1,cấp8 -> khớp đồ thật trong rương.)

Dùng để: tra cứu (genre,detail,particular,level)->tên, và tìm món theo TÊN + CẤP
từ câu nhiệm vụ (vd "Ngọc Bội cấp 8 hệ Kim" -> Mặc Ngọc = (0,9,1,8)).
Không cần click từng món để bắt hệ/cấp nữa.
"""
import os
import glob
import logging

logger = logging.getLogger("item_db")

ITEM_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "data", "game_raw", "settings", "item")

# Cột (xác định từ dữ liệu thật)
C_NAME, C_GENRE, C_DETAIL, C_PARTICULAR, C_LEVEL = 0, 1, 2, 3, 11
C_GENDER = 37   # 0 = nam, 1 = nữ (Mặc Ngọc nam=0; Hạng Liên nữ=1)


def _read_utf16(path):
    raw = open(path, "rb").read()
    for enc in ("utf-16", "utf-16-le", "utf-8-sig", "utf-8"):
        try:
            return raw.decode(enc)
        except Exception:
            pass
    return raw.decode("latin-1", "ignore")


def _to_int(s):
    try:
        return int(str(s).strip())
    except Exception:
        return None


class ItemDB:
    def __init__(self, item_dir=ITEM_DIR):
        self.entries = []          # list of dict {name, genre, detail, particular, level, source}
        self.by_gdpl = {}          # (genre,detail,particular,level) -> name
        # (genre,detail,particular) -> [tên theo THỨ TỰ MODEL trong FILE] (giữ list DÀI NHẤT 1 file).
        # Dùng cho gói shop: field9 = số model (1-based) -> tên (vd belt: 4 = Mãng Bì Yêu Đái).
        self.by_gdp_model = {}
        self._load(item_dir)

    def _load(self, item_dir):
        files = glob.glob(os.path.join(item_dir, "*.txt"))
        for fp in files:
            src = os.path.splitext(os.path.basename(fp))[0]
            try:
                text = _read_utf16(fp)
            except Exception as e:
                logger.error(f"[item_db] đọc {fp}: {e}")
                continue
            lines = [l for l in text.replace("\r", "").split("\n") if l.strip()]
            # Shop NPC bán đồ THƯỜNG -> KHÔNG dùng goldequip (Hoàng Kim) cho model-order (nó dài hơn,
            # sẽ chiếm chỗ belt.txt -> sai). Bỏ qua goldequip khi dựng by_gdp_model.
            skip_model = (src == "goldequip")
            file_grp = {}   # (g,d,p) -> [tên theo thứ tự dòng trong CHÍNH file này]
            for ln in lines[1:]:
                c = ln.split("\t")
                if len(c) <= C_LEVEL:
                    continue
                name = c[C_NAME].strip()
                if not name:
                    continue
                g = _to_int(c[C_GENRE]); d = _to_int(c[C_DETAIL])
                p = _to_int(c[C_PARTICULAR]); lv = _to_int(c[C_LEVEL])
                if None in (g, d, p, lv):
                    continue
                gender = _to_int(c[C_GENDER]) if len(c) > C_GENDER else None
                e = {"name": name, "genre": g, "detail": d, "particular": p, "level": lv,
                     "gender": gender, "source": src}
                self.entries.append(e)
                self.by_gdpl[(g, d, p, lv)] = name
                if not skip_model:
                    file_grp.setdefault((g, d, p), []).append(name)
            # Giữ list model DÀI NHẤT cho mỗi (g,d,p) — file "chủ" của loại đó (vd belt.txt cho đai).
            for k, lst in file_grp.items():
                if len(lst) > len(self.by_gdp_model.get(k, [])):
                    self.by_gdp_model[k] = lst
        logger.info(f"[item_db] Đã học {len(self.entries)} item từ {len(files)} file.")

    def name_of(self, genre, detail, particular, level):
        return self.by_gdpl.get((genre, detail, particular, level))

    def name_by_model(self, genre, detail, particular, model):
        """Tên món theo SỐ MODEL (field9 gói shop, 1-based) trong nhóm (g,d,p). Phân biệt được
        các món cùng (g,d,p) khác model (vd Mãng Bì vs Thiên Tàm Yêu Đái). None nếu ngoài phạm vi."""
        lst = self.by_gdp_model.get((genre, detail, particular))
        if lst and isinstance(model, int) and 1 <= model <= len(lst):
            return lst[model - 1]
        return None

    def search(self, name_contains=None, level=None, detail=None, gender=None, include_gold=False):
        """Tìm item theo tên (chứa) + cấp + detail + giới tính (0 nam/1 nữ). Trả list entries.
        Mặc định LOẠI đồ HOÀNG KIM (source 'goldequip', vd 'An Bang... Hoàng Thạch') — quest Dã Tẩu
        cần đồ THƯỜNG. include_gold=True để lấy cả hoàng kim."""
        kw = (name_contains or "").lower().strip()
        out = []
        for e in self.entries:
            if not include_gold and e.get("source") == "goldequip":
                continue
            if kw and kw not in e["name"].lower():
                continue
            if level is not None and e["level"] != level:
                continue
            if detail is not None and e["detail"] != detail:
                continue
            if gender is not None and e.get("gender") != gender:
                continue
            out.append(e)
        return out


_DB = None


def get_item_db():
    global _DB
    if _DB is None:
        _DB = ItemDB()
    return _DB
