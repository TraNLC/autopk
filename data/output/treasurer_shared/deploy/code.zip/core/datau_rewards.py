"""
core/datau_rewards.py — Học danh sách PHẦN THƯỞNG Dã Tẩu mà bot bắt được từ gói 245.

Mỗi lần parse được bảng thưởng (eAwardSelectionAsk), gọi record_options(options) để
gom các lựa chọn vào 1 file JSON. Sau này dùng list này để người chơi tự đặt độ ưu tiên.

Lưu tại data/output/datau_rewards.json:
  { "name": {"count": n, "first": "ISO", "last": "ISO", "priority": int|null} }
priority = None nghĩa là chưa người chơi đặt -> dùng logic mặc định (pick_reward_index).
"""
import os
import json
import threading
from datetime import datetime

_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                    "data", "output")
_PATH = os.path.join(_DIR, "datau_rewards.json")
_LOCK = threading.Lock()


def _load_raw():
    try:
        with open(_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def record_options(options):
    """Ghi nhận các lựa chọn thưởng vừa thấy. Trả về số mục MỚI thêm."""
    if not options:
        return 0
    now = datetime.now().isoformat(timespec="seconds")
    new = 0
    with _LOCK:
        data = _load_raw()
        for opt in options:
            name = (opt or "").strip()
            if not name:
                continue
            if name in data:
                data[name]["count"] = data[name].get("count", 0) + 1
                data[name]["last"] = now
            else:
                data[name] = {"count": 1, "first": now, "last": now, "priority": None}
                new += 1
        try:
            os.makedirs(_DIR, exist_ok=True)
            with open(_PATH, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass
    return new


def load_all():
    """Trả list dict đã sắp xếp: nhiều lần thấy nhất trước.
    [{name, count, first, last, priority}]"""
    data = _load_raw()
    rows = []
    for name, v in data.items():
        rows.append({"name": name, "count": v.get("count", 0),
                     "first": v.get("first", ""), "last": v.get("last", ""),
                     "priority": v.get("priority")})
    rows.sort(key=lambda r: (-r["count"], r["name"]))
    return rows


def set_priority(name, priority):
    """Đặt độ ưu tiên cho 1 phần thưởng (số nhỏ = ưu tiên cao). priority=None để xoá."""
    with _LOCK:
        data = _load_raw()
        if name in data:
            data[name]["priority"] = priority
            try:
                with open(_PATH, "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
            except Exception:
                pass


def save_order(ordered_names):
    """Lưu THỨ TỰ ưu tiên (drag-drop): tên ở TRÊN = ưu tiên CAO = priority NHỎ (0,1,2...).
    Tên không nằm trong list -> priority=None (dùng logic mặc định)."""
    with _LOCK:
        data = _load_raw()
        rank = {n: i for i, n in enumerate(ordered_names)}
        for name in data:
            data[name]["priority"] = rank.get(name)
        try:
            os.makedirs(_DIR, exist_ok=True)
            with open(_PATH, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass


def priority_order():
    """List TÊN thưởng theo ưu tiên người chơi (priority nhỏ trước). Chỉ mục ĐÃ đặt priority."""
    data = _load_raw()
    ranked = [(v.get("priority"), name) for name, v in data.items()
              if isinstance(v.get("priority"), int)]
    ranked.sort(key=lambda x: x[0])
    return [name for _, name in ranked]


def load_ordered():
    """load_all nhưng SẮP theo ưu tiên người chơi TRƯỚC (priority asc), mục chưa đặt theo count."""
    rows = load_all()
    rows.sort(key=lambda r: (0, r["priority"]) if isinstance(r.get("priority"), int)
              else (1, -r.get("count", 0)))
    return rows
