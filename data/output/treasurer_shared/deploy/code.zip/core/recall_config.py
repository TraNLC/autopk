# -*- coding: utf-8 -*-
"""core/recall_config.py — Cách VỀ THÀNH khi xong nhiệm vụ Dã Tẩu.

  "tdp"   = Thổ Địa Phù (túi) — MẶC ĐỊNH (baseline cũ, an toàn).
  "xaphu" = Xa Phu về Biện Kinh (giờ Xa Phu gọi được TẠI ĐỘNG). Fallback TĐP nếu Xa Phu không về được.

Toàn cục (mọi cửa sổ dùng chung). Chọn ở tab Dã tẩu.
"""
import json
import os

_PATH = "data/output/recall_config.json"
_VALID = ("tdp", "xaphu")
XAPHU_CITY = "Biện Kinh"   # thành trả NV khi đi Xa Phu


def get_method() -> str:
    try:
        m = json.load(open(_PATH, encoding="utf-8")).get("method")
        return m if m in _VALID else "tdp"
    except Exception:
        return "tdp"   # MẶC ĐỊNH: LUÔN Thổ Địa Phù (user chốt). _recall_to_town fallback Xa Phu→THP nếu TĐP fail.


def set_method(method: str):
    method = method if method in _VALID else "tdp"
    try:
        os.makedirs(os.path.dirname(_PATH), exist_ok=True)
        json.dump({"method": method}, open(_PATH, "w", encoding="utf-8"),
                  ensure_ascii=False, indent=2)
    except Exception:
        pass
