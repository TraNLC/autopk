"""
core/npc_shop.py — Suy shopkey NPC theo THÀNH/THÔN trong nhiệm vụ + tra itemindex từ shop_index.json.

Dùng cho NV "tới <thành/thôn> mua/tìm <item>" -> remote-buy (eShopBuyItem), KHÔNG quét sạp người chơi.
Bảng town->index verified 2026-06 (xem memory shop-index-town-mapping). Mọi shop CÙNG LOẠI dùng chung
danh sách item -> itemindex giống nhau giữa các thành -> có thể tra index từ bất kỳ shop cùng loại.
"""
import os
import json

SHOP_INDEX_PATH = "data/output/shop_index.json"
LEARNED_PATH = "data/output/shop_item_index.json"   # học từ mua tay: {tên_lower: {shopkey, itemindex}}

# Tên thành/thôn (chuỗi con đặc trưng, lowercase) -> (loc_type, index)
TOWN_INDEX = {
    # THÀNH THỊ
    "phượng tường": ("thanh.thi", 1),
    "thành đô":     ("thanh.thi", 2),
    "đại lý":       ("thanh.thi", 3),
    "biện kinh":    ("thanh.thi", 4),
    "tương dương":  ("thanh.thi", 5),
    "dương châu":   ("thanh.thi", 6),
    "lâm an":       ("thanh.thi", 7),
    # THÔN TRẤN
    "ba lăng":      ("thon.tran", 1),
    "giang tân":    ("thon.tran", 2),
    "long môn":     ("thon.tran", 3),
    "long tuyền":   ("thon.tran", 4),
    "đạo hương":    ("thon.tran", 5),
    "vĩnh lạc":     ("thon.tran", 6),
    "chu tiên":     ("thon.tran", 7),
    "thạch cổ":     ("thon.tran", 8),   # tên đúng trong game (map 153 "Thạch Cổ trấn")
    "thạch cù":     ("thon.tran", 8),   # alias (feed OCR cũ ghi nhầm "Thạch Cù trẹn")
}

SHOP_TYPE_KW = {
    "thợ rèn":   "tho.ren",
    "tạp hóa":   "tap.hoa",
    "tạp hoá":   "tap.hoa",
    "dược điếm": "hieu.thuoc",
    "hiệu thuốc": "hieu.thuoc",
    "trại ngựa": "trai.ngua",
    "trại ngua": "trai.ngua",
    "tàu ngựa":  "trai.ngua",
    "bán ngựa":  "trai.ngua",
    "bán ngua":  "trai.ngua",
}

# Suy loại shop từ tên vật phẩm khi quest không ghi rõ
_WEAPON_KW = ["kiếm", "đao", "côn", "thương", "chùy", "bổng", "cung", "phủ", "kích", "phi đao", "thиết"]


def find_town(text):
    """Trả (name, loc_type, index) nếu quest có nêu tên thành/thôn, else None."""
    t = (text or "").lower()
    for name, (loc, idx) in TOWN_INDEX.items():
        if name in t:
            return name, loc, idx
    return None


def find_shop_slug(text, item_name=""):
    t = (text or "").lower()
    for kw, slug in SHOP_TYPE_KW.items():
        if kw in t:
            return slug
    n = (item_name or "").lower()
    # Tên ngựa thường có "ngựa" hoặc kết thúc bằng "mã" (Liệt Thanh Mã, Tích Lịch Mã, Bôn Tiêu...).
    if "ngựa" in n or "ngua" in n or n.endswith("mã") or " mã" in n:
        return "trai.ngua"            # NV mua ngựa -> trại/bán ngựa
    if any(w in n for w in _WEAPON_KW):
        return "tho.ren"
    return "tap.hoa"   # mặc định tạp hóa


def is_npc_shop_quest(text, item_name=""):
    """NV thuộc loại mua shop NPC? = có tên thành/thôn, HOẶC có từ khóa loại shop."""
    t = (text or "").lower()
    if any(kw in t for kw in SHOP_TYPE_KW):
        return True
    if find_town(text) and ("mua" in t or "tìm" in t or "tới" in t or "đến" in t):
        return True
    return False


def resolve_shopkey(quest_text, item_name=""):
    """Suy shopkey '<slug>.<loc>.<idx>'. Cần biết thành/thôn; nếu không có tên thành -> None."""
    town = find_town(quest_text)
    slug = find_shop_slug(quest_text, item_name)
    if not town:
        return None
    _, loc, idx = town
    # Trại ngựa dùng format 'trai.ngua.<idx>' (không có loc thanh.thi/thon.tran như tạp hóa/thợ rèn).
    if slug == "trai.ngua":
        return f"trai.ngua.{idx}"
    return f"{slug}.{loc}.{idx}"


def load_shop_index():
    try:
        return json.load(open(SHOP_INDEX_PATH, encoding="utf-8"))
    except Exception:
        return {}


def _match_item(shop, item_name):
    nl = (item_name or "").lower().strip()
    if not nl:
        return None
    for it in shop.get("items", []):
        nm = (it.get("name") or "").lower().strip()
        if nm and (nl in nm or nm in nl):
            return it
    return None


def load_learned():
    try:
        return json.load(open(LEARNED_PATH, encoding="utf-8"))
    except Exception:
        return {}


LIVE_DICT_PATH = "features/bot/shop_dict.json"   # shop_dict do frida parse LIVE (eOpenShop -> 119)
SHOP_CTX_PATH = "data/output/shop_npc_context.json"   # {shopkey: "2|x|y|.." } để mở shop từ xa


def save_shop_context(shopkey, ctx):
    """Học context mở shop NPC (gói eStringData "2|x|y|..") theo shopkey -> để replay mở từ xa."""
    if not shopkey or not ctx:
        return
    try:
        d = json.load(open(SHOP_CTX_PATH, encoding="utf-8"))
    except Exception:
        d = {}
    if d.get(shopkey) == ctx:
        return
    d[shopkey] = ctx
    try:
        os.makedirs(os.path.dirname(SHOP_CTX_PATH), exist_ok=True)
        json.dump(d, open(SHOP_CTX_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    except Exception:
        pass


def load_shop_context(shopkey):
    """Trả context "2|x|y|.." đã học cho ĐÚNG shopkey (toạ độ NPC theo map -> không dùng chéo shop), else None."""
    try:
        d = json.load(open(SHOP_CTX_PATH, encoding="utf-8"))
    except Exception:
        return None
    return d.get(shopkey)


def find_in_live_dict(item_name, prefer_shopkey=""):
    """Tra (shopkey, itemindex) theo TÊN trong shop_dict.json (parse LIVE từ eOpenShop).
    Khớp tên gần đúng (substring 2 chiều). Ưu tiên prefer_shopkey nếu khớp. Trả (shopkey, idx) hoặc None."""
    nl = (item_name or "").lower().strip()
    if not nl:
        return None
    try:
        d = json.load(open(LIVE_DICT_PATH, encoding="utf-8"))
    except Exception:
        return None
    hits = []
    for sk, items in (d or {}).items():
        for nm, idx in (items or {}).items():
            n2 = (nm or "").lower().strip()
            if n2 and (nl in n2 or n2 in nl):
                hits.append((sk, idx))
    if not hits:
        return None
    # ưu tiên shopkey mong muốn (cùng shop quest chỉ định)
    for sk, idx in hits:
        if prefer_shopkey and sk == prefer_shopkey:
            return sk, idx
    return hits[0]


def last_itemindex(shopkey):
    """Manh mối: NV Dã Tẩu thường mua MÓN CUỐI CÙNG trong shop. Trả (itemindex_max, tên) của shopkey.
    Ưu tiên shop_dict.json (LIVE phiên này); nếu shop chưa mở live -> FALLBACK shop_index.json (catalog
    đã quét đủ — vd Thành Đô tap.hoa.thanh.thi.2). None nếu cả 2 đều không có shopkey này."""
    # 1) LIVE dict: {shopkey: {tên: idx}}
    try:
        d = json.load(open(LIVE_DICT_PATH, encoding="utf-8"))
        items = d.get(shopkey) or {}
        if items:
            nm, idx = max(items.items(), key=lambda kv: kv[1])
            return idx, nm
    except Exception:
        pass
    # 2) FALLBACK catalog shop_index.json: {shopkey: {items:[{itemindex, name}]}}
    try:
        idxd = load_shop_index()
        sh = idxd.get(shopkey) or {}
        its = [it for it in sh.get("items", []) if (it.get("name") or "").strip()]
        if its:
            best = max(its, key=lambda it: it.get("itemindex", 0))
            return best.get("itemindex"), (best.get("name") or "").strip()
    except Exception:
        pass
    return None


def first_itemindex(shopkey):
    """NV mua NGỰA = mua con ĐẦU/RẺ NHẤT (idx nhỏ nhất) trong trại ngựa. Trả (idx_min, tên) hoặc None.
    Nếu shopkey đúng chưa quét -> fallback sang BẤT KỲ shop cùng slug (vd trai.ngua.*) đã quét."""
    try:
        d = json.load(open(LIVE_DICT_PATH, encoding="utf-8"))
    except Exception:
        return None
    items = d.get(shopkey)
    if not items:
        slug = ".".join(shopkey.split(".")[:2])   # vd 'trai.ngua'
        for sk, it in d.items():
            if sk.startswith(slug + ".") and it:
                items = it
                break
    if not items:
        return None
    nm, idx = min(items.items(), key=lambda kv: kv[1])   # idx nhỏ nhất = món đầu
    return idx, nm


def save_learned(item_name, shopkey, itemindex, element=""):
    """Ghi nhớ (name,HỆ)->(shopkey,itemindex). Key gồm HỆ vì vũ khí cùng tên khác hệ = idx KHÁC
    (vd 'Cang Kiếm hệ Thổ' vs 'hệ Kim'). Không hệ -> key chỉ tên."""
    nl = (item_name or "").lower().strip()
    if not nl or itemindex is None:
        return
    el = (element or "").lower().strip()
    key = f"{nl}|{el}" if el else nl
    m = load_learned()
    m[key] = {"shopkey": shopkey, "itemindex": itemindex, "element": el, "name": nl}
    try:
        os.makedirs(os.path.dirname(LEARNED_PATH), exist_ok=True)
        json.dump(m, open(LEARNED_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    except Exception:
        pass


# ===== Suy ứng viên itemindex theo CẤU TRÚC (loại vũ khí) — để bot tự thử, khỏi mua tay =====
_MELEE_DB = None


def _load_melee():
    """name(lower) -> {particular(=loại), model(field11), tier(field7), level}. Vũ khí cận chiến."""
    global _MELEE_DB
    if _MELEE_DB is not None:
        return _MELEE_DB
    _MELEE_DB = {}
    for fp in ("data/output/json/item_meleeweapon.json", "data/output/json/item_rangeweapon.json"):
        try:
            arr = json.load(open(fp, encoding="utf-8"))
            for a in arr:
                name = a.get("﻿0", a.get("0", ""))
                if name:
                    _MELEE_DB[name.lower().strip()] = {
                        "particular": a.get("3"), "model": a.get("11"),
                        "tier": a.get("7"), "level": a.get("35"),
                    }
        except Exception:
            pass
    return _MELEE_DB


def weapon_spec(item_name):
    db = _load_melee()
    nl = (item_name or "").lower().strip()
    if nl in db:
        return db[nl]
    for n, s in db.items():
        if nl and (nl in n or n in nl):
            return s
    return None


def _shop_item_fields(it):
    """Giải mã (particular=f8, f9, f10) từ item_hex của 1 shop item."""
    try:
        from features.bot.shop_parser import _decode_protobuf
        f = _decode_protobuf(bytes.fromhex(it.get("item_hex", "")))
        return (f.get(8, 0) or 0), f.get(9), f.get(10)
    except Exception:
        return 0, None, None


def _shop_for(shopkey):
    """Trả shop CÙNG HẠNG có NHIỀU MÓN NHẤT (bản đầy đủ nhất — tránh bản bị cắt thiếu item).
    Các shop cùng hạng (thành/thôn) dùng chung danh sách + itemindex giống nhau."""
    db = load_shop_index()
    klass = ".".join(shopkey.split(".")[:4])   # vd tho.ren.thanh.thi
    best, best_n = None, -1
    for k, s in db.items():
        if ".".join(k.split(".")[:4]) == klass:
            n = len(s.get("items", []))
            if n > best_n:
                best, best_n = s, n
    if best is not None:
        return best
    return db.get(shopkey)


def candidate_itemindexes(shopkey, item_name, limit=6):
    """Ứng viên itemindex (cùng LOẠI vũ khí với quest), xếp ưu tiên model#≈f9 rồi giá rẻ trước.
    Dùng cho bot TỰ THỬ (mua->nộp->verify->học). Trả [] nếu không phải vũ khí cận/viễn."""
    spec = weapon_spec(item_name)
    shop = _shop_for(shopkey)
    if not spec or not shop:
        return []
    part = spec.get("particular")
    model = spec.get("model") or 0
    items = shop.get("items", [])
    nbase = len(items)
    # (a) SLOT CHÈN theo quest: itemindex cao + có f10 (biến thể hệ) -> nhiều khả năng = món quest hiện tại.
    inject = []
    for it in items:
        p, f9, f10 = _shop_item_fields(it)
        idx = it.get("itemindex", 0)
        if f10 is not None and f10 >= 2 and idx >= nbase - 2:   # món cuối có gắn hệ
            inject.append((idx, it.get("itemindex")))
    inject.sort(reverse=True)
    inject_idx = [x[1] for x in inject]
    # (b) Ứng viên cùng LOẠI vũ khí, xếp theo model#≈f9 rồi giá rẻ.
    cands = []
    for it in items:
        p, f9, f10 = _shop_item_fields(it)
        if p == part:
            cands.append((abs((f9 or 0) - model), it.get("cost", 0), it.get("itemindex")))
    cands.sort()
    same = [c[2] for c in cands]
    # Thử SLOT CHÈN trước (đúng nhất nếu shop chèn món quest), rồi tới cùng-loại.
    out = []
    for x in inject_idx + same:
        if x not in out:
            out.append(x)
    return out[:limit]


def _match_live(shopkey, item_name):
    """Tra itemindex theo TÊN trong shop_dict.json (LIVE, parser MỚI — tên ĐÚNG).
    shop_index.json tên SAI hết (parser cũ) nên PHẢI ưu tiên nguồn live này. Trả (idx, item_dict) hoặc None."""
    nl = (item_name or "").lower().strip()
    if not nl:
        return None
    try:
        d = json.load(open(LIVE_DICT_PATH, encoding="utf-8"))
    except Exception:
        return None
    # ưu tiên đúng shopkey, rồi shop cùng HẠNG (thành↔thành / thôn↔thôn), rồi cùng loại (slug)
    klass = ".".join(shopkey.split(".")[:4]) if shopkey else ""
    slug = ".".join(shopkey.split(".")[:2]) if shopkey else ""
    def order(sk):
        if sk == shopkey: return 0
        if klass and ".".join(sk.split(".")[:4]) == klass: return 1
        if slug and sk.startswith(slug + "."): return 2
        return 3
    for sk in sorted(d.keys(), key=order):
        for nm, idx in (d.get(sk) or {}).items():
            n2 = (nm or "").lower().strip()
            if n2 and (nl in n2 or n2 in nl):
                return idx, {"name": nm, "live": True, "shopkey": sk}
    return None


def find_itemindex(shopkey, item_name, element=""):
    """Tra itemindex của item trong shopkey. element để khớp vũ khí có 'hệ X' (đã học theo tên|hệ).
    1) Map ĐÃ HỌC từ mua tay (shop_item_index.json) — chuẩn nhất, xử lý cả 'hệ X'.
    2) shop_dict.json LIVE theo tên (tên ĐÚNG — parser mới).
    3) shop_index.json theo tên (tên SAI parser cũ — chỉ dùng làm chốt chặn cuối).
    Trả (itemindex, item_dict) hoặc None."""
    nl = (item_name or "").lower().strip()
    elem = (element or "").lower().strip()
    parts = shopkey.split(".") if shopkey else []
    slug = ".".join(parts[:2])          # vd tho.ren
    klass = ".".join(parts[:4])         # vd tho.ren.thanh.thi (THÀNH và THÔN khác danh sách)
    learned = load_learned()

    def _scan(pred):
        for key, info in learned.items():
            lname = info.get("name") or key.split("|")[0]
            lel = (info.get("element") or "").lower().strip()
            lsk = info.get("shopkey", "")
            # tên khớp + (hệ trùng HOẶC mục học không có hệ) — chặn nhầm hệ khác.
            if nl and lname in nl and (not lel or lel == elem) and pred(lsk):
                return info.get("itemindex"), {"name": lname, "learned": True, "shopkey": lsk}
        return None

    # CÙNG HẠNG (thành↔thành / thôn↔thôn) — itemindex chắc chắn giống nhau.
    hit = _scan(lambda lsk: klass and ".".join(lsk.split(".")[:4]) == klass)
    if hit:
        return hit
    # Chỉ fallback cùng-loại (slug) khi KHÔNG xác định được hạng (shopkey lạ) -> tránh áp nhầm thành↔thôn.
    if not klass:
        hit = _scan(lambda lsk: (not slug) or lsk.startswith(slug))
        if hit:
            return hit
    # 2) shop_dict.json LIVE — TÊN ĐÚNG (vd 'Cát Ngoa' ở tap.hoa.thanh.thi.2 idx 11).
    live = _match_live(shopkey, item_name)
    if live:
        return live
    # 3) shop_index.json (tên sai — gần như vô dụng cho tạp hóa, giữ làm chốt cuối)
    db = load_shop_index()
    shop = db.get(shopkey)
    if shop:
        it = _match_item(shop, item_name)
        if it is not None:
            return it.get("itemindex"), it
    # fallback: shop cùng loại (tho.ren.* / tap.hoa.*)
    slug = ".".join(shopkey.split(".")[:2]) if shopkey else ""
    for k, s in db.items():
        if slug and not k.startswith(slug):
            continue
        it = _match_item(s, item_name)
        if it is not None:
            return it.get("itemindex"), it
    return None
