# -*- coding: utf-8 -*-
"""core/webbridge.py — KÊNH FILE (qua Syncthing) giữa WEB UI tập trung và AGENT mỗi máy.

Bot (Frida) chạy LOCAL mỗi máy → web không điều khiển trực tiếp. Thay vào đó:
  • AGENT (ui_bot_app mỗi máy) PUBLISH trạng thái cửa sổ -> treasurer_shared/web/status/<machine>.json
  • WEB đọc gộp mọi status/*.json -> hiện cây Máy→Cửa sổ; bấm nút -> PUSH lệnh vào
    treasurer_shared/web/commands/<machine>.jsonl
  • AGENT poll commands/<machine>.jsonl -> thực thi lệnh CHƯA áp (theo id) -> đánh dấu đã-áp (local).

AN TOÀN (sau review đối kháng):
  - machine_id PHẢI khớp [0-9A-Za-z_]{1,24} (chống path traversal vào file ngoài thư mục).
  - applied = {id: ts} prune THEO TUỔI (KHÔNG list(set)[-N:] = evict bừa → replay lệnh = phá bot).
  - lệnh CŨ hơn CMD_MAX_AGE = ÔI, KHÔNG thực thi (chống burst khi máy offline lâu rồi bật lại).
  - seed_applied_from_jsonl(): agent khởi động đánh dấu MỌI lệnh đang có = đã-áp → chỉ lệnh MỚI mới chạy.
  - bỏ qua file .sync-conflict-* của Syncthing.
"""
import os
import re
import json
import time
import uuid
import glob
import tempfile
import threading

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WEB_DIR = os.path.join(_ROOT, "data", "output", "treasurer_shared", "web")
STATUS_DIR = os.path.join(WEB_DIR, "status")     # <machine>.json (agent ghi, web đọc)
CMD_DIR = os.path.join(WEB_DIR, "commands")      # <machine>.jsonl (web ghi, agent đọc)
APPLIED_PATH = os.path.join(_ROOT, "data", "output", ".web_cmd_applied.json")   # LOCAL mỗi máy (không sync)
STALE_SEC = 60          # status cũ hơn ngần này = máy có thể offline (web vẫn hiện, gắn cờ)
CMD_MAX_AGE = 120       # lệnh cũ hơn = ÔI, agent bỏ (không replay khi bật lại sau lâu)
APPLIED_TTL = 7200      # giữ id đã-áp 2h rồi prune (đủ lâu để KHÔNG bao giờ replay lệnh còn trong jsonl)

_LOCK = threading.Lock()
_MID_RE = re.compile(r"^[0-9A-Za-z_]{1,24}$")


def _valid_mid(mid):
    return bool(mid) and bool(_MID_RE.match(str(mid)))


def web_machine_id():
    """ID MÁY cho kênh web — theo HOSTNAME sanitize (duy nhất mỗi máy). KHÔNG đọc core/machine_id.txt: file đó
    có thể bị Syncthing sync / copy giữa máy → trùng id → 2 máy publish ĐÈ cùng file status → bão sync-conflict
    + máy kia không hiện trên web. Hostname luôn khác nhau giữa máy (log đã chứng minh)."""
    import socket
    h = socket.gethostname() or "may"
    return re.sub(r"[^0-9A-Za-z_]", "", h)[:24] or "may"


def _atomic_write(path, text):
    d = os.path.dirname(path) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp, path)
    except Exception:
        try: os.remove(tmp)      # dọn .tmp khi lỗi (không để rác)
        except Exception: pass
        raise


# ---------------- AGENT: publish status ----------------
def publish_status(machine_id, status):
    """Agent ghi trạng thái máy mình. status = {windows:[...], count, ...}. Tự thêm machine + ts."""
    if not _valid_mid(machine_id):
        return False
    try:
        data = dict(status or {})
        data["machine"] = machine_id
        data["ts"] = time.time()
        _atomic_write(os.path.join(STATUS_DIR, f"{machine_id}.json"), json.dumps(data, ensure_ascii=False))
        return True
    except Exception:
        return False


# ---------------- WEB: đọc gộp status mọi máy ----------------
def read_all_status():
    """Web đọc gộp -> {machine_id: status_dict} (kèm 'stale'). Bỏ qua file .sync-conflict của Syncthing
    + machine_id không hợp lệ (chống nhiễm key lạ)."""
    out = {}
    try:
        now = time.time()
        for fp in glob.glob(os.path.join(STATUS_DIR, "*.json")):
            base = os.path.basename(fp)
            if ".sync-conflict" in base:      # file xung đột Syncthing -> bỏ
                continue
            try:
                with open(fp, encoding="utf-8") as f:
                    d = json.load(f)
                mid = d.get("machine") or os.path.splitext(base)[0]
                if not _valid_mid(mid):
                    continue
                d["stale"] = (now - float(d.get("ts", 0))) > STALE_SEC
                d["age_sec"] = round(now - float(d.get("ts", 0)), 1)
                out[mid] = d
            except Exception:
                continue
    except Exception:
        pass
    return out


# ---------------- WEB: đẩy lệnh ----------------
_VALID_ACTIONS = {"rescan", "start", "stop", "resume", "pause", "unpause",
                  "restart", "scan_stalls", "set_label", "set_config", "set_threshold",
                  "set_treasurer", "unset_treasurer", "set_accounts"}   # set_threshold: ngưỡng mua; set/unset_treasurer: thủ quỹ; set_accounts: danh sách tài khoản


def push_command(machine_id, action, device=None, args=None):
    """Web ghi 1 lệnh vào commands/<machine>.jsonl (append + trim 300 dòng). Trả id lệnh hoặc None.
    Validate machine_id (chống path traversal) + action (whitelist)."""
    if not _valid_mid(machine_id) or action not in _VALID_ACTIONS:
        return None
    try:
        with _LOCK:
            os.makedirs(CMD_DIR, exist_ok=True)
            path = os.path.join(CMD_DIR, f"{machine_id}.jsonl")
            cmd = {"id": uuid.uuid4().hex[:12], "ts": time.time(),
                   "machine": machine_id, "device": device, "action": action, "args": args or {}}
            lines = []
            if os.path.exists(path):
                try:
                    with open(path, encoding="utf-8") as f:
                        lines = [ln for ln in f.read().splitlines() if ln.strip()]
                except Exception:
                    lines = []
            lines.append(json.dumps(cmd, ensure_ascii=False))
            _atomic_write(path, "\n".join(lines[-300:]) + "\n")
            return cmd["id"]
    except Exception:
        return None


# ---------------- AGENT: applied = {id: ts} (prune THEO TUỔI) ----------------
def _load_applied():
    try:
        with open(APPLIED_PATH, encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save_applied(applied):
    try:
        now = time.time()
        pruned = {k: v for k, v in applied.items() if now - float(v or 0) <= APPLIED_TTL}
        _atomic_write(APPLIED_PATH, json.dumps(pruned))
    except Exception:
        pass


def seed_applied_from_jsonl(machine_id):
    """Agent KHỞI ĐỘNG: đánh dấu MỌI lệnh hiện có trong jsonl = đã-áp → chỉ lệnh GỬI SAU khi agent chạy mới
    thực thi. Chống replay (mất applied-file / restart / clean data) làm start/stop/restart chạy lại = phá bot."""
    if not _valid_mid(machine_id):
        return
    path = os.path.join(CMD_DIR, f"{machine_id}.jsonl")
    if not os.path.exists(path):
        return
    applied = _load_applied()
    now = time.time()
    try:
        with open(path, encoding="utf-8") as f:
            for ln in f:
                ln = ln.strip()
                if not ln:
                    continue
                try:
                    c = json.loads(ln)
                except Exception:
                    continue
                if c.get("id"):
                    applied[c["id"]] = now
    except Exception:
        pass
    _save_applied(applied)


def read_pending_commands(machine_id, max_age_sec=CMD_MAX_AGE):
    """Agent đọc lệnh CHƯA áp + còn MỚI (≤ max_age_sec) cho máy mình. Lệnh ôi -> đánh dấu áp (bỏ, không chạy)."""
    if not _valid_mid(machine_id):
        return []
    path = os.path.join(CMD_DIR, f"{machine_id}.jsonl")
    if not os.path.exists(path):
        return []
    applied = _load_applied()
    now = time.time()
    out = []
    changed = False
    try:
        with open(path, encoding="utf-8") as f:
            for ln in f:
                ln = ln.strip()
                if not ln:
                    continue
                try:
                    c = json.loads(ln)
                except Exception:
                    continue
                cid = c.get("id")
                if not cid or cid in applied:
                    continue
                if now - float(c.get("ts", 0)) > max_age_sec:   # lệnh ôi -> bỏ (đánh dấu áp)
                    applied[cid] = now; changed = True
                    continue
                out.append(c)
    except Exception:
        return []
    if changed:
        _save_applied(applied)
    return out


def mark_applied(cmd_ids):
    """Agent đánh dấu các id đã thực thi (kèm ts để prune theo tuổi)."""
    if not cmd_ids:
        return
    applied = _load_applied()
    now = time.time()
    for i in cmd_ids:
        if i:
            applied[i] = now
    _save_applied(applied)
