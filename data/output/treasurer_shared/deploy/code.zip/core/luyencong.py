# -*- coding: utf-8 -*-
"""core/luyencong.py — Cờ "cửa sổ Luyện Công" theo device (per-window).

Cửa sổ được đánh dấu Luyện Công = nhân vật chỉ đi luyện công, KHÔNG chạy Dã Tẩu.
UI: chuột phải tên cửa sổ -> "Luyện Công" (giống pattern Thủ Quỹ). Bot đọc is_luyencong_device(dev)
để biết bỏ qua flow Dã Tẩu. Mặc định: KHÔNG có trong list = chế độ Dã Tẩu.
"""
import json
import os

_PATH = "data/output/luyencong_devices.json"


def _load():
    try:
        return set(str(x) for x in (json.load(open(_PATH, encoding="utf-8")) or []))
    except Exception:
        return set()


def is_luyencong_device(dev) -> bool:
    """True nếu cửa sổ (device_id) đang ở chế độ Luyện Công."""
    return bool(dev) and str(dev) in _load()


def set_luyencong(dev, on: bool = True):
    """BẬT/TẮT chế độ Luyện Công cho 1 cửa sổ. Lưu xuống file (sống qua restart UI)."""
    if not dev:
        return
    s = _load()
    if on:
        s.add(str(dev))
    else:
        s.discard(str(dev))
    try:
        os.makedirs(os.path.dirname(_PATH), exist_ok=True)
        json.dump(sorted(s), open(_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    except Exception:
        pass


def all_luyencong_devices():
    return _load()
