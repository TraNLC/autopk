# -*- coding: utf-8 -*-
"""Thông báo ra Zalo (qua zlapi — KHÔNG chính thức) cho bot Dã Tẩu.

⚠️ zlapi RE web Zalo cá nhân: VI PHẠM điều khoản Zalo + có RỦI RO bị khoá nick. User đã chủ động chọn.
TRIẾT LÝ AN TOÀN: mọi lỗi (chưa cài lib / chưa cấu hình / login fail / mạng) đều NUỐT — KHÔNG bao giờ
làm sập bot. Gửi tin chạy trong luồng nền (daemon) để không chặn UI/watchdog.

Cấu hình: data/output/notify_config.json
{
  "enabled": true,
  "zalo": {
    "phone": "0901234567",            # SĐT đăng nhập (có thể để rỗng nếu dùng cookies)
    "password": "******",            # mật khẩu (có thể để rỗng nếu dùng cookies)
    "imei": "....",                  # imei thiết bị Zalo (lấy từ trình duyệt)
    "cookies": null,                  # dict cookie HOẶC đường dẫn file cookies.json (KHUYÊN DÙNG: ổn định, ít OTP)
    "user_agent": "Mozilla/5.0 ...",
    "thread_id": "<uid_của_bạn_hoặc_group>",   # NƠI NHẬN thông báo (uid bản thân, hoặc id group)
    "thread_type": "USER"            # "USER" | "GROUP"
  },
  "events": {"stuck": true, "stats_daily": true},
  "stats_hour": 21                    # giờ (0-23) gửi thống kê cuối ngày tự động
}
"""
import os
import json
import time
import threading

CONFIG_PATH = "data/output/notify_config.json"
TREASURER_STATS_DIR = "data/output/treasurer_stats"

_client = None              # ZaloAPI singleton (lazy)
_client_lock = threading.Lock()
_client_failed_at = 0.0     # mốc lần login fail gần nhất (cooldown, không spam login lỗi)
_LOGIN_RETRY_COOLDOWN = 300 # login fail -> 5 phút sau mới thử lại
_dedup = {}                 # {key: ts} chống spam cùng 1 sự kiện
_dedup_lock = threading.Lock()

# NGHE LỆNH ZALO (2 chiều): UI đăng ký handler; listener chạy 1 lần.
_cmd_handler = None         # fn(message:str, author_id:str, thread_id:str) do UI set
_listening = False          # đang nghe (tránh start 2 lần)


def _today():
    return time.strftime("%Y-%m-%d")


def load_config():
    """Đọc config; None nếu chưa có / lỗi / tắt."""
    try:
        if not os.path.exists(CONFIG_PATH):
            return None
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cfg = json.load(f)
        if not cfg.get("enabled"):
            return None
        return cfg
    except Exception:
        return None


def is_enabled():
    return load_config() is not None


def _normalize_cookies(raw):
    """Chuẩn hoá MỌI định dạng cookies về dict {tên: giá_trị} mà zlapi cần.
    Nhận: dict {tên:giá_trị}; list [{name,value,...}] (Cookie-Editor/EditThisCookie/J2TEAM);
    hoặc object có khoá 'cookies'. Trả None nếu không dựng được."""
    if not raw:
        return None
    # object bọc {"cookies": [...]} (vài tiện ích xuất kiểu này)
    if isinstance(raw, dict) and "cookies" in raw and isinstance(raw["cookies"], (list, dict)):
        raw = raw["cookies"]
    if isinstance(raw, dict):
        # đã là {tên: giá_trị}? (giá trị là chuỗi/số)
        if all(isinstance(v, (str, int, float)) for v in raw.values()):
            return {str(k): str(v) for k, v in raw.items()}
        return None
    if isinstance(raw, list):
        out = {}
        for it in raw:
            if isinstance(it, dict) and "name" in it and "value" in it:
                out[str(it["name"])] = str(it["value"])
        return out or None
    return None


def _resolve_cookies(zcfg):
    """cookies có thể là dict/list trực tiếp trong config, hoặc đường dẫn tới file json (mọi định dạng)."""
    c = zcfg.get("cookies")
    if isinstance(c, str) and c:
        if not os.path.exists(c):
            return None
        try:
            with open(c, encoding="utf-8") as f:
                c = json.load(f)
        except Exception:
            return None
    return _normalize_cookies(c)


def _get_client(zcfg):
    """Tạo (1 lần) ZaloAPI client. Trả None nếu lib chưa cài / login fail (có cooldown)."""
    global _client, _client_failed_at
    if _client is not None:
        return _client
    with _client_lock:
        if _client is not None:
            return _client
        if time.time() - _client_failed_at < _LOGIN_RETRY_COOLDOWN:
            return None    # vừa fail -> đừng thử login lại liên tục
        try:
            from zlapi import ZaloAPI
        except Exception as e:
            print(f"[notifier] zlapi chưa cài ({e}) — chạy: venv/bin/pip install zlapi")
            _client_failed_at = time.time()
            return None
        try:
            _client = _make_cmd_class(ZaloAPI)(   # subclass: override onMessage để NGHE LỆNH (dùng chung cho gửi+nghe)
                phone=zcfg.get("phone") or None,
                password=zcfg.get("password") or None,
                imei=zcfg.get("imei") or None,
                cookies=_resolve_cookies(zcfg),
                user_agent=zcfg.get("user_agent") or None,
            )
            print("[notifier] Đăng nhập Zalo OK.")
            return _client
        except Exception as e:
            print(f"[notifier] Đăng nhập Zalo FAIL: {e} — thử lại sau {_LOGIN_RETRY_COOLDOWN}s.")
            _client = None
            _client_failed_at = time.time()
            return None


def _send_blocking(text):
    """Gửi 1 tin (chặn). Nuốt mọi lỗi. Trả True nếu gửi được."""
    cfg = load_config()
    if not cfg:
        return False
    zcfg = cfg.get("zalo") or {}
    thread_id = zcfg.get("thread_id")
    if not thread_id:
        print("[notifier] thiếu thread_id (nơi nhận) trong config.")
        return False
    client = _get_client(zcfg)
    if client is None:
        return False
    try:
        from zlapi.models import Message, ThreadType
        tt = ThreadType.GROUP if str(zcfg.get("thread_type", "USER")).upper() == "GROUP" else ThreadType.USER
        client.send(Message(text=text), thread_id=str(thread_id), thread_type=tt)
        return True
    except Exception as e:
        # Lỗi gửi (token hết hạn / mạng / API đổi) -> reset client để lần sau login lại; KHÔNG sập bot.
        global _client, _client_failed_at
        print(f"[notifier] gửi Zalo lỗi: {e}")
        _client = None
        _client_failed_at = time.time()
        return False


def send(text, dedup_key=None, dedup_sec=0):
    """Gửi thông báo (KHÔNG chặn — chạy luồng nền). dedup_key+dedup_sec: bỏ qua nếu vừa gửi key này.
    An toàn gọi từ bất cứ đâu (UI thread/watchdog/bot thread) — không bao giờ ném lỗi ra ngoài."""
    try:
        if not is_enabled():
            return
        if dedup_key and dedup_sec > 0:
            now = time.time()
            with _dedup_lock:
                if now - _dedup.get(dedup_key, 0) < dedup_sec:
                    return
                _dedup[dedup_key] = now
        threading.Thread(target=_send_blocking, args=(text,), daemon=True).start()
    except Exception:
        pass


# ---------------- NGHE LỆNH ZALO (2 chiều) ----------------

def set_command_handler(fn):
    """UI đăng ký callback xử lý lệnh nhận từ Zalo: fn(message:str, author_id:str, thread_id:str).
    fn PHẢI tự đẩy thao tác Tk về main thread (root.after) — onMessage chạy ở luồng listener."""
    global _cmd_handler
    _cmd_handler = fn


def _authorized(author_id, thread_id, zcfg):
    """CHỈ nhận lệnh từ người được phép (chống người lạ điều khiển bot):
    - cmd_authors (list uid) trong config nếu có → author_id phải thuộc danh sách.
    - không cấu hình → mặc định CHỈ chấp nhận author_id == thread_id nhận-thông-báo (case USER = chính bạn)."""
    allowed = zcfg.get("cmd_authors") or []
    if allowed:
        return str(author_id) in {str(a) for a in allowed}
    return bool(author_id) and str(author_id) == str(zcfg.get("thread_id") or "")


def _make_cmd_class(ZaloAPI):
    """Tạo subclass ZaloAPI override onMessage → chuyển lệnh (đã lọc người gửi) cho _cmd_handler. Nuốt mọi lỗi."""
    class _CmdZalo(ZaloAPI):
        def onMessage(self, mid=None, author_id=None, message=None, message_object=None,
                      thread_id=None, thread_type=None):
            try:
                if _cmd_handler is None:
                    return
                msg = (message or "").strip()
                if not msg:
                    return
                zcfg = (load_config() or {}).get("zalo") or {}
                if not _authorized(author_id, thread_id, zcfg):
                    return   # KHÔNG phải người được phép → bỏ qua (im lặng)
                _cmd_handler(msg, str(author_id), str(thread_id))
            except Exception as e:
                print(f"[notifier] onMessage lỗi (bỏ qua): {e}")
    return _CmdZalo


def start_listener():
    """Bật NGHE LỆNH Zalo (1 lần, luồng nền daemon). An toàn: nuốt mọi lỗi, KHÔNG sập bot.
    Tôn trọng toggle events.commands (mặc định bật khi notify bật)."""
    global _listening
    if _listening:
        return
    cfg = load_config()
    if not cfg:
        return
    if not (cfg.get("events") or {}).get("commands", True):
        return
    zcfg = cfg.get("zalo") or {}

    def _run():
        global _listening
        client = _get_client(zcfg)      # subclass _CmdZalo (đã override onMessage) — dùng CHUNG cho gửi
        if client is None:
            return
        _listening = True
        print("[notifier] Đang NGHE lệnh Zalo… (trả lời: resume <tên> | resume all | tt)")
        try:
            client.listen(thread=False, reconnect=5)   # CHẶN trong luồng nền này; tự reconnect khi rớt
        except Exception as e:
            print(f"[notifier] listener dừng: {e}")
        finally:
            _listening = False

    try:
        threading.Thread(target=_run, daemon=True).start()
    except Exception:
        pass


def reply(text, thread_id, thread_type="USER"):
    """Trả lời lại Zalo (vd xác nhận đã resume / danh sách PENDING). Dùng client đang nghe. Nuốt lỗi."""
    try:
        client = _client
        if client is None:
            return False
        from zlapi.models import Message, ThreadType
        tt = ThreadType.GROUP if str(thread_type).upper() == "GROUP" else ThreadType.USER
        client.send(Message(text=text), thread_id=str(thread_id), thread_type=tt)
        return True
    except Exception as e:
        print(f"[notifier] reply lỗi: {e}")
        return False


# ---------------- Nội dung thông báo ----------------

def _who(device_id, char):
    """Dòng định danh cửa sổ: ưu tiên TÊN NHÂN VẬT, kèm device cho rõ."""
    char = (char or "").strip()
    return f"{char} ({device_id})" if char else str(device_id)


def notify_pending(device_id, reason, char=""):
    """Cửa sổ vào PENDING (cần bạn xử lý — KHÔNG tự hồi, vd hết NV ngày / thiếu đồ / không về thành được).
    Dedup 10 phút/cửa sổ. Tôn trọng toggle events.pending."""
    cfg = load_config()
    if cfg and not (cfg.get("events") or {}).get("pending", True):
        return
    _name = (char or device_id)
    txt = (f"🆘 CỬA SỔ CẦN TRỢ GIÚP (PENDING)\n"
           f"• Nhân vật: {_who(device_id, char)}\n"
           f"• Lý do: {reason}\n"
           f"• Lúc: {time.strftime('%H:%M:%S %d/%m')}\n"
           f"↩️ Xử lý xong, trả lời: resume {_name}  (hoặc: resume all | tt)")
    send(txt, dedup_key=f"pending:{device_id}", dedup_sec=600)


def notify_stuck(device_id, reason, char=""):
    """Cửa sổ treo/chết -> watchdog đã tự restart. Dedup 5 phút/cửa sổ (tránh spam khi flapping).
    Tôn trọng toggle events.stuck (tắt stuck trong config -> KHÔNG gửi loại này)."""
    cfg = load_config()
    if cfg and not (cfg.get("events") or {}).get("stuck", True):
        return
    txt = (f"🐕 BOT TREO — đã tự khởi động lại\n"
           f"• Nhân vật: {_who(device_id, char)}\n"
           f"• Lý do: {reason}\n"
           f"• Lúc: {time.strftime('%H:%M:%S %d/%m')}")
    send(txt, dedup_key=f"stuck:{device_id}", dedup_sec=300)


def build_stats_summary(day=None):
    """Gom treasurer_stats/<day>.jsonl -> text thống kê (ngân lượng + từng vật phẩm). '' nếu không có dữ liệu."""
    day = day or _today()
    path = os.path.join(TREASURER_STATS_DIR, f"{day}.jsonl")
    if not os.path.exists(path):
        return ""
    money_van = 0
    items = {}
    n_tx = 0
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    r = json.loads(line)
                except Exception:
                    continue
                n_tx += 1
                money_van += int(r.get("money_van", 0) or 0)
                for nm, c in (r.get("received") or {}).items():
                    items[nm] = items.get(nm, 0) + int(c or 0)
    except Exception:
        return ""
    if n_tx == 0:
        return ""

    def _vn(n):
        return f"{int(n):,}".replace(",", ".")

    lines = [f"📊 THỐNG KÊ THỦ QUỸ — {day}",
             f"💰 Ngân lượng đã cấp: {_vn(money_van)} vạn"]
    if items:
        lines.append("📦 Vật phẩm đã nhận:")
        for nm, c in sorted(items.items(), key=lambda kv: -kv[1]):
            lines.append(f"   • {nm}: {_vn(c)}")
    else:
        lines.append("📦 Chưa nhận vật phẩm nào.")
    lines.append(f"({n_tx} giao dịch · tất cả cửa sổ)")
    return "\n".join(lines)


def send_stats(day=None):
    """Gửi thống kê ngày. Trả True nếu CÓ dữ liệu để gửi (đã đẩy luồng nền)."""
    txt = build_stats_summary(day)
    if not txt:
        return False
    send(txt)
    return True
