# -*- coding: utf-8 -*-
"""core/luyencong_accounts.py — Hàng đợi account LUYỆN CÔNG theo cửa sổ (device).

Mỗi dòng: taikhoan:matkhau:tennhanvat  (vd duatop09:11111111:LC09).
Lưu data/output/luyencong_queue.json {device_id: [{acc,pwd,name}]}.
Tiến độ (đã xử acc nào) data/output/luyencong_progress.json {device_id: {date, done:[acc...]}}.
"""
import json
import os

QUEUE_PATH = "data/output/luyencong_queue.json"
PROGRESS_PATH = "data/output/luyencong_progress.json"


def parse_lines(text):
    """Parse textarea -> list [{acc,pwd,name}]. Bỏ dòng trống/sai định dạng."""
    out = []
    for ln in (text or "").splitlines():
        ln = ln.strip()
        if not ln or ln.startswith("#"):
            continue
        parts = ln.split(":")
        if len(parts) < 3:
            continue
        acc, pwd, name = parts[0].strip(), parts[1].strip(), ":".join(parts[2:]).strip()
        if acc and pwd and name:
            out.append({"acc": acc, "pwd": pwd, "name": name})
    return out


def _load(path):
    try:
        return json.load(open(path, encoding="utf-8"))
    except Exception:
        return {}


def _save(path, data):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        json.dump(data, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    except Exception:
        pass


def save_queue(device_id, accounts):
    q = _load(QUEUE_PATH)
    q[str(device_id)] = accounts
    _save(QUEUE_PATH, q)


def load_queue(device_id):
    return _load(QUEUE_PATH).get(str(device_id), [])


def queue_text(device_id):
    return "\n".join(f"{a['acc']}:{a['pwd']}:{a['name']}" for a in load_queue(device_id))


def mark_done(device_id, acc, today):
    p = _load(PROGRESS_PATH)
    rec = p.get(str(device_id)) or {}
    if rec.get("date") != today:
        rec = {"date": today, "done": []}
    if acc not in rec["done"]:
        rec["done"].append(acc)
    p[str(device_id)] = rec
    _save(PROGRESS_PATH, p)


def done_set(device_id, today):
    rec = _load(PROGRESS_PATH).get(str(device_id)) or {}
    return set(rec.get("done", [])) if rec.get("date") == today else set()
