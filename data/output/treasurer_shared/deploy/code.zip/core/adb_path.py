"""core/adb_path.py — Dò đường dẫn ADB đa nền tảng (Windows + MEmu / macOS + MuMu / Linux).

Thứ tự ưu tiên:
  1. Biến môi trường  GST_ADB
  2. config.json  (khóa "adb_path")  ở thư mục gốc repo
  3. 'adb' trong PATH (shutil.which)
  4. Vị trí phổ biến theo HỆ ĐIỀU HÀNH (MEmu bundled adb, C:\\platform-tools, ~/Library/Android...)
  5. fallback "adb"/"adb.exe" (hy vọng có trong PATH)

Nhờ vậy NGƯỜI DÙNG KHỎI SỬA CODE: chỉ cần adb có trong PATH, hoặc đặt "adb_path" trong config.json,
hoặc đặt biến môi trường GST_ADB.
"""
import os
import json
import shutil
import platform

try:
    from core.paths import BASE as _ROOT          # thư mục chứa exe khi đóng gói, hoặc gốc repo
except Exception:
    _ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

_CACHE = None


def _from_config():
    try:
        with open(os.path.join(_ROOT, "config.json"), encoding="utf-8") as f:
            p = (json.load(f) or {}).get("adb_path")
            if p and os.path.exists(p):
                return p
    except Exception:
        pass
    return None


def resolve_adb():
    """Trả đường dẫn adb dùng được (đã tồn tại), hoặc 'adb'/'adb.exe' nếu trông cậy PATH."""
    global _CACHE
    if _CACHE:
        return _CACHE

    cands = []
    env = os.environ.get("GST_ADB")
    if env:
        cands.append(env)
    cfg = _from_config()
    if cfg:
        cands.append(cfg)
    # adb ĐÓNG GÓI cạnh exe (bản .exe one-click) — ưu tiên cao để khỏi cần cài gì.
    cands.append(os.path.join(_ROOT, "adb.exe"))
    cands.append(os.path.join(_ROOT, "platform-tools", "adb.exe"))
    cands.append(os.path.join(_ROOT, "adb"))
    which = shutil.which("adb") or shutil.which("adb.exe")
    if which:
        cands.append(which)

    if platform.system() == "Windows":
        cands += [
            r"C:\platform-tools\adb.exe",
            r"C:\Program Files\Microvirt\MEmu\adb.exe",
            r"C:\Program Files (x86)\Microvirt\MEmu\adb.exe",
            r"C:\Program Files\Microvirt\MEmuHyperv\adb.exe",
            r"C:\Program Files (x86)\Microvirt\MEmuHyperv\adb.exe",
            os.path.join(_ROOT, "platform-tools", "adb.exe"),
        ]
    else:
        cands += [
            os.path.expanduser("~/Library/Android/sdk/platform-tools/adb"),
            "/usr/local/bin/adb",
            "/opt/homebrew/bin/adb",
            os.path.join(_ROOT, "platform-tools", "adb"),
        ]

    for c in cands:
        try:
            # PHẢI là FILE (không phải thư mục) — os.path.exists() cũng True cho thư mục,
            # khiến candidate trỏ vào thư mục gốc lọt qua rồi bị shell chạy như lệnh
            # ("/bin/sh: .../GSTAuto_mac: is a directory"). Chỉ nhận file thật.
            if c and os.path.isfile(c):
                _CACHE = c
                return c
        except Exception:
            continue

    _CACHE = "adb.exe" if platform.system() == "Windows" else "adb"
    return _CACHE


# Tiện dùng như hằng: `from core.adb_path import ADB`
ADB = resolve_adb()
