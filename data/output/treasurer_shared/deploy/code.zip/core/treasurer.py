"""
core/treasurer.py — Hạ tầng tính năng "Thủ Quỹ" (treasurer).

- Map TÊN phần thưởng Dã Tẩu -> `particular` của item (qua data/output/json/item_magicscript.json,
  có chuẩn hoá tên vì datau_rewards ghi "X (Tống Kim)" còn magicscript ghi "Tống Kim X").
- Config: cửa sổ nào là thủ quỹ + danh sách TÊN thưởng "giao thủ quỹ".
- File phối hợp giữa các cửa sổ (mỗi cửa sổ = 1 thread, chia sẻ qua file + lock):
    treasurer_config.json  : {"device": "<id>", "give_names": [...]}
    treasurer_info.json    : {"cid","name","mapId","mapX","mapY","ts"}  (thủ quỹ ghi định kỳ)
    treasurer_requests.json: {"<worker_cid>": {"type":"money"|"deposit","status":"pending|trading|done","ts":..}}
    reward_item_sigs.json  : {"<tên>": {"genre","detail","particular","series"}}  (HỌC khi nhận thưởng — bổ sung map tĩnh)
"""
import os
import re
import json
import time
import glob
import shutil
import socket
import threading

_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "output")
# THƯ MỤC CHIA SẺ CROSS-MÁY: dùng 1 thủ quỹ cho NHIỀU MÁY → Syncthing đồng bộ ĐÚNG thư mục này giữa các máy
# (config/info/requests). KHÔNG sync mấy file riêng-máy (account_queue, autoplay_profile, deposits, machine_id...).
_SHARED_DIR = os.path.join(_DIR, "treasurer_shared")
_MS_PATH = os.path.join(_DIR, "json", "item_magicscript.json")
CONFIG_PATH = os.path.join(_SHARED_DIR, "treasurer_config.json")   # SHARED (thủ quỹ ghi, mọi máy đọc)
INFO_PATH = os.path.join(_SHARED_DIR, "treasurer_info.json")       # SHARED (thủ quỹ ghi, mọi máy đọc)
SIGS_PATH = os.path.join(_SHARED_DIR, "reward_item_sigs.json")     # SHARED (sig item reward)
DEPOSITS_PATH = os.path.join(_DIR, "treasurer_deposits.json")      # LOCAL từng máy (cột 'đã nộp' — không sync)
_MACHINE_ID_PATH = os.path.join(_DIR, "machine_id.txt")            # LOCAL — KHÔNG sync (định danh máy)

_LOCK = threading.RLock()
INFO_TTL = 30.0          # thủ quỹ "online" nếu info ghi trong 30s gần đây


def _machine_id():
    """ID ổn định của MÁY NÀY (để mỗi máy ghi file requests RIÊNG → không đè nhau cross-máy)."""
    try:
        if os.path.exists(_MACHINE_ID_PATH):
            v = open(_MACHINE_ID_PATH, encoding="utf-8").read().strip()
            if v:
                return v
    except Exception:
        pass
    v = re.sub(r"[^0-9a-zA-Z_]", "", (socket.gethostname() or "may"))[:24] or "may"
    try:
        os.makedirs(_DIR, exist_ok=True)
        open(_MACHINE_ID_PATH, "w", encoding="utf-8").write(v)
    except Exception:
        pass
    return v


def _req_path(machine_id=None):
    """File requests RIÊNG của 1 máy (trong shared). Mỗi máy chỉ GHI file của mình → tránh va chạm cross-máy."""
    return os.path.join(_SHARED_DIR, f"requests_{machine_id or _machine_id()}.json")


def _migrate_shared():
    """1 lần: chuyển file thủ quỹ CŨ (data/output) → treasurer_shared (giữ config/pos/give đã cấu hình)."""
    try:
        os.makedirs(_SHARED_DIR, exist_ok=True)
        for fn in ("treasurer_config.json", "treasurer_info.json", "reward_item_sigs.json"):
            old, new = os.path.join(_DIR, fn), os.path.join(_SHARED_DIR, fn)
            if os.path.exists(old) and not os.path.exists(new):
                shutil.copy2(old, new)
        oldreq, newreq = os.path.join(_DIR, "treasurer_requests.json"), _req_path()
        if os.path.exists(oldreq) and not os.path.exists(newreq):
            shutil.copy2(oldreq, newreq)
    except Exception:
        pass


_migrate_shared()


# ---------------- name -> particular (map tĩnh từ item_magicscript) ----------------
def _norm(s):
    """Chuẩn hoá tên để khớp datau_rewards <-> magicscript: bỏ 'tống kim'/'(tống kim)', ký tự lạ, gộp space."""
    s = (s or "").lower()
    s = re.sub(r"\(\s*t[ốô]ng kim\s*\)|t[ốô]ng kim", " ", s)
    s = re.sub(r"[^0-9a-zà-ỹ ]", " ", s)
    return " ".join(s.split())


_MSMAP = None   # {name_norm: particular}


def _load_msmap():
    global _MSMAP
    if _MSMAP is not None:
        return _MSMAP
    m = {}
    try:
        data = json.load(open(_MS_PATH, encoding="utf-8"))
        for it in (data if isinstance(data, list) else []):
            name = (it.get("name") or it.get("﻿name") or "").strip()
            p = it.get("particular")
            if name and isinstance(p, int):
                m.setdefault(_norm(name), p)
    except Exception:
        pass
    _MSMAP = m
    return m


def name_to_particular(name):
    """TÊN thưởng -> particular (int) hoặc None. Ưu tiên map tĩnh; fallback map đã HỌC (reward_item_sigs)."""
    p = _load_msmap().get(_norm(name))
    if p is not None:
        return p
    learned = _read_json(SIGS_PATH).get(name)
    if learned and isinstance(learned.get("particular"), int):
        return learned["particular"]
    return None


_P2NAME = None


def particular_to_name(p):
    """particular -> TÊN item (map ngược từ item_magicscript) để log 'nhận vật phẩm X'. None -> 'item #p'."""
    global _P2NAME
    if _P2NAME is None:
        _P2NAME = {}
        try:
            data = json.load(open(_MS_PATH, encoding="utf-8"))
            for it in (data if isinstance(data, list) else []):
                name = (it.get("name") or it.get("﻿name") or "").strip()
                pp = it.get("particular")
                if name and isinstance(pp, int):
                    _P2NAME.setdefault(pp, name)
        except Exception:
            pass
    return _P2NAME.get(p) or f"item #{p}"


def candidate_give_names():
    """TÊN thưởng LÀ ITEM TÚI (map được particular) — để UI liệt kê cho chọn giao/không-giao.
    Tự LOẠI Ngân lượng / Điểm kinh nghiệm / Ngẫu nhiên... (không phải item, không giao dịch được)."""
    names = []
    try:
        rj = _read_json(os.path.join(_DIR, "datau_rewards.json"))
        for nm in rj.keys():
            if name_to_particular(nm) is not None:
                names.append(nm)
    except Exception:
        pass
    return sorted(names)


def candidate_give_groups():
    """Trả [(label, [member_names])] để UI hiện GỌN: gộp HẾT item '(Tống Kim)' thành 1 nhóm 'Lắc Tống Kim';
    các item khác (Thiết La Hán, thuốc...) mỗi cái 1 nhóm riêng. Tick nhóm = giao toàn bộ member của nhóm."""
    names = candidate_give_names()
    tongkim = [n for n in names if "tống kim" in n.lower() or "tong kim" in n.lower()]
    others = [n for n in names if n not in tongkim]
    groups = []
    if tongkim:
        groups.append(("Lắc Tống Kim", tongkim))
    for n in others:
        groups.append((n, [n]))
    return groups


def give_particulars(give_names):
    """Tập particular của các tên được chọn 'giao' (bỏ tên không map được = Ngân lượng/Điểm KN/Ngẫu nhiên)."""
    out = set()
    for nm in (give_names or []):
        p = name_to_particular(nm)
        if p is not None:
            out.add(p)
    return out


def is_giveable(item, particulars):
    """Item trong TÚI (location==2), KHÔNG bị KHOÁ (lockstate==0), có particular thuộc danh sách giao?
    (vàng/exp không phải item nên tự loại; đồ khoá -> không giao dịch theo yêu cầu.)"""
    try:
        if item.get("lockstate"):          # != 0/None -> đang khoá -> KHÔNG giao
            return False
        # CHỈ giao vật phẩm tích luỹ (genre 6 = Thiết La Hán / Tống Kim / thuốc...). TUYỆT ĐỐI không giao
        # TRANG BỊ (genre 0): trang bị rác đôi khi TRÙNG 'particular' với give-set → lọt nếu chỉ lọc particular.
        if item.get("genre") != 6:
            return False
        return item.get("location") == 2 and item.get("particular") in particulars
    except Exception:
        return False


# ---------------- file JSON an toàn (lock + atomic) ----------------
def _read_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f) or {}
    except Exception:
        return {}


def _write_json(path, data):
    with _LOCK:
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            tmp = f"{path}.tmp.{os.getpid()}.{threading.get_ident()}"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, path)
        except Exception:
            pass


# ---------------- config (cửa sổ thủ quỹ + give list) ----------------
DEFAULT_GIVE_MONEY = 20000    # 2 vạn = mặc định cấp/lần

# mapId -> tên thành (cho Xa Phu) — worker tự suy điểm đến từ mapId, KHÔNG cần nhập tên thành.
MAPID_TO_TOWN = {1: "Phượng Tường", 11: "Thành Đô", 162: "Đại Lý", 37: "Biện Kinh",
                 78: "Tương Dương", 80: "Dương Châu", 176: "Lâm An",
                 53: "Ba Lăng Huyện", 20: "Giang Tân Thôn", 121: "Long Môn Trấn", 174: "Long Tuyền Thôn",
                 101: "Đạo Hương Thôn", 99: "Vĩnh Lạc Trấn", 100: "Chu Tiên Trấn", 153: "Thạch Cổ Trấn"}


def town_for_map(map_id):
    """Tên thành (cho Xa Phu) suy từ mapId. None nếu không biết."""
    try:
        return MAPID_TO_TOWN.get(int(map_id))
    except Exception:
        return None


def load_config():
    c = _read_json(CONFIG_PATH)
    return {"device": c.get("device") or "", "give_names": c.get("give_names") or [],
            "pos": c.get("pos") or None, "machine": c.get("machine") or "",
            "give_money": int(c.get("give_money") or DEFAULT_GIVE_MONEY)}


def save_config(device, give_names, pos=None, give_money=None):
    """pos = {"map_id":int, "town":"<tên thành cho Xa Phu>", "gx":int, "gy":int} (toạ độ MINIMAP nơi thủ quỹ đứng).
    give_money = ngân lượng cấp cho worker MỖI LẦN xin tiền (lượng, 1 vạn=10000). Giữ giá trị cũ nếu None.
    Ghi luôn 'machine' = máy đặt thủ quỹ → cross-máy phân biệt đúng (device_id 127.0.0.1:port KHÔNG unique giữa máy)."""
    cur = load_config()
    out = {"device": device or "", "give_names": list(give_names or []), "machine": _machine_id()}
    if pos is None:
        pos = cur.get("pos")             # giữ pos cũ nếu không truyền
    if pos:
        out["pos"] = pos
    out["give_money"] = int(give_money if give_money is not None else cur.get("give_money") or DEFAULT_GIVE_MONEY)
    _write_json(CONFIG_PATH, out)


def give_money():
    """Ngân lượng cấp cho worker mỗi lần xin tiền (lượng)."""
    return int(load_config().get("give_money") or DEFAULT_GIVE_MONEY)


def treasurer_pos():
    """(map_id, gx, gy) toạ độ MINIMAP cố định của thủ quỹ, hoặc None nếu chưa cấu hình.
    KHÔNG còn 'town' — worker tự suy tên thành từ mapId qua town_for_map()."""
    p = load_config().get("pos")
    if p and p.get("gx") is not None and p.get("gy") is not None:
        return p.get("map_id"), int(p["gx"]), int(p["gy"])
    return None


def treasurer_device():
    return load_config().get("device") or ""


def is_treasurer_device(device_id):
    # CROSS-MÁY: device_id (127.0.0.1:port) KHÔNG unique giữa máy → phải khớp CẢ machine. Thủ quỹ chỉ-là-thủ-quỹ
    # TRÊN ĐÚNG MÁY đã đặt; máy khác (dù trùng port) KHÔNG nhận là thủ quỹ. (config cũ thiếu 'machine' → coi như
    # khớp máy hiện tại để giữ tương thích 1-máy.)
    if not device_id:
        return False
    c = load_config()
    if c.get("device") != device_id:
        return False
    cm = c.get("machine") or ""
    return (not cm) or (cm == _machine_id())


# ---------------- info (thủ quỹ công bố vị trí/cid) ----------------
def write_info(cid, name, map_id, x, y):
    _write_json(INFO_PATH, {"cid": str(cid), "name": name or "", "mapId": map_id,
                            "mapX": x, "mapY": y, "ts": time.time()})


def read_info():
    """Trả info thủ quỹ nếu còn 'online' (ghi trong INFO_TTL giây), else None."""
    info = _read_json(INFO_PATH)
    if not info or not info.get("cid"):
        return None
    if time.time() - float(info.get("ts", 0)) > INFO_TTL:
        return None
    return info


# ---------------- requests (worker <-> thủ quỹ) ----------------
def add_request(worker_cid, req_type):
    # Ghi vào file requests CỦA MÁY NÀY (worker thuộc máy nào ghi máy đó) → cross-máy KHÔNG đè nhau.
    with _LOCK:
        p = _req_path()
        d = _read_json(p)
        d[str(worker_cid)] = {"type": req_type, "status": "pending", "ts": time.time()}
        _write_json(p, d)


def _all_requests():
    """Gộp requests TỪ MỌI MÁY (mỗi máy 1 file requests_<id>.json trong treasurer_shared). Thủ quỹ đọc cái này
    để biết nhu cầu của worker dù worker ở máy khác. Trùng cid (hiếm) → giữ bản ts mới nhất."""
    merged = {}
    try:
        for fp in glob.glob(os.path.join(_SHARED_DIR, "requests_*.json")):
            for cid, r in (_read_json(fp) or {}).items():
                if cid not in merged or (r or {}).get("ts", 0) > merged[cid].get("ts", 0):
                    merged[cid] = r
    except Exception:
        pass
    return merged


def get_request(worker_cid):
    return _all_requests().get(str(worker_cid))


def set_request_status(worker_cid, status):
    # CHỈ ghi vào file MÁY NÀY (worker của chính máy thủ quỹ). Worker MÁY KHÁC: KHÔNG ghi-ngược file của họ
    # (tránh va chạm cross-máy) — chống phục vụ lặp đã do thủ quỹ tự quản (_treasurer_served 60s).
    with _LOCK:
        p = _req_path()
        d = _read_json(p)
        if str(worker_cid) in d:
            d[str(worker_cid)]["status"] = status
            d[str(worker_cid)]["ts"] = time.time()
            _write_json(p, d)


def clear_request(worker_cid):
    with _LOCK:
        p = _req_path()
        d = _read_json(p)
        if d.pop(str(worker_cid), None) is not None:
            _write_json(p, d)


# ---------------- trạng thái ĐÃ NỘP thủ quỹ theo account (cho cột tab Tài khoản) ----------------
def mark_deposited(device, account):
    """Đánh dấu account (trên device) ĐÃ nộp đồ cho thủ quỹ hôm nay."""
    if not device or not account:
        return
    import datetime
    today = datetime.date.today().isoformat()
    with _LOCK:
        d = _read_json(DEPOSITS_PATH)
        e = d.get(device)
        if not e or e.get("date") != today:
            e = {"date": today, "done": []}
        if account not in e["done"]:
            e["done"].append(account)
        d[device] = e
        _write_json(DEPOSITS_PATH, d)


def deposited_today(device):
    """Set các account (trên device) đã nộp thủ quỹ HÔM NAY."""
    import datetime
    e = _read_json(DEPOSITS_PATH).get(device) or {}
    if e.get("date") == datetime.date.today().isoformat():
        return set(e.get("done") or [])
    return set()


# ---------------- learn name -> signature khi nhận thưởng (bổ sung map tĩnh) ----------------
def record_learned_sig(name, item):
    """Ghi map TÊN thưởng -> chữ ký item thật (gọi khi bot nhận đúng 1 item ứng với thưởng đã chọn)."""
    if not name or not item:
        return
    with _LOCK:
        d = _read_json(SIGS_PATH)
        d[name] = {"genre": item.get("genre"), "detail": item.get("detail"),
                   "particular": item.get("particular"), "series": item.get("series")}
        _write_json(SIGS_PATH, d)
