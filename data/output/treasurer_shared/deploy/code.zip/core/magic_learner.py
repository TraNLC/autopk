"""
magic_learner.py — Học map {attribId(số) -> tên_thuộc_tính(chuỗi)} MIỄN PHÍ.

Cơ chế: 1 món ở sạp mang `magic` = [value*1000 + attribId, ...] (chỉ id SỐ).
Sau khi MUA, món vào túi và bag reader đọc được thuộc tính dạng CHUỖI
(attribs=[{type, value:[...]}]). Đối chiếu magic(số) ↔ attribs(chuỗi) của CÙNG 1 món
=> học id->tên, ghi dồn vào data/output/magic_id_map.json. Không tốn thêm xu.

An toàn: chỉ học khi chắc chắn (ghép theo CHỈ SỐ khi số lượng + giá trị khớp đồng loạt,
hoặc ghép theo giá trị duy nhất). Bỏ qua trường hợp nhập nhằng — KHÔNG bịa.
"""
import json
import os

MAP_PATH = "data/output/magic_id_map.json"


def decode_magic(magic_ints):
    """[value*1000+attribId,...] -> [(attribId, value), ...]."""
    out = []
    for mi in magic_ints or []:
        try:
            out.append((mi % 1000, mi // 1000))
        except Exception:
            pass
    return out


def load_map():
    try:
        with open(MAP_PATH, encoding="utf-8") as f:
            return {int(k): v for k, v in json.load(f).items()}
    except Exception:
        return {}


def save_map(id_map):
    try:
        os.makedirs(os.path.dirname(MAP_PATH), exist_ok=True)
        with open(MAP_PATH, "w", encoding="utf-8") as f:
            json.dump({str(k): v for k, v in sorted(id_map.items())},
                      f, ensure_ascii=False, indent=1)
        return True
    except Exception:
        return False


def _attr_value(attr):
    vals = attr.get("value") or []
    return max(vals) if vals else None


def learn(stall_magic_ints, bag_attribs, id_map=None, save=True):
    """Đối chiếu magic(số) của món ở sạp với attribs(chuỗi) của chính món đó trong túi.
    Trả (id_map đã cập nhật, dict id->tên VỪA học lần này). Chỉ học khi chắc chắn.

    Chiến lược AN TOÀN: chỉ học cặp có GIÁ TRỊ DUY NHẤT — 1 magic value chỉ khớp đúng 1 attrib
    (và attrib đó cũng chỉ có 1 value khớp). Trùng value -> bỏ qua (học ở món sau). KHÔNG đoán
    theo thứ tự vì thứ tự magic(protobuf) chưa chắc trùng thứ tự attribs(runtime).
    """
    if id_map is None:
        id_map = load_map()
    learned = {}
    dec = decode_magic(stall_magic_ints)            # [(id, value), ...]
    attrs = [a for a in (bag_attribs or []) if a.get("type")]
    if not dec or not attrs:
        return id_map, learned

    def _record(aid, name):
        if not name:
            return
        if aid in id_map and id_map[aid] != name:
            return  # xung đột với cái đã học -> bỏ, không ghi đè
        if id_map.get(aid) != name:
            id_map[aid] = name
            learned[aid] = name

    for aid, val in dec:
        cands = [a for a in attrs if _attr_value(a) == val]
        # chỉ học khi 1-1: đúng 1 attrib mang value này VÀ value chỉ xuất hiện 1 lần trong magic
        if len(cands) == 1 and sum(1 for _, v in dec if v == val) == 1:
            _record(aid, cands[0].get("type"))
    if learned and save:
        save_map(id_map)
    return id_map, learned
