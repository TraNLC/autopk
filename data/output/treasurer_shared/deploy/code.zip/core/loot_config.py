# -*- coding: utf-8 -*-
"""core/loot_config.py — Cờ "dọn túi khi về thành".

BẬT (tab Dã tẩu): khi về tới thành (sau Xa Phu), bot BÁN đồ nhặt genre0 không-thuộc-tính & không-trang-sức,
CẤT KHO trang sức (nhẫn/dây chuyền) + đồ CÓ thuộc tính (đồ NV 'xem xong trả lại'). KHÔNG đụng thuốc/lệnh (gen6).
Mặc định TẮT (bán không hoàn tác — opt-in). Toàn cục (mọi cửa sổ dùng chung).
"""
import json
import os

_PATH = "data/output/loot_config.json"


def is_enabled() -> bool:
    try:
        return bool(json.load(open(_PATH, encoding="utf-8")).get("sell_loot", True))
    except Exception:
        return True   # MẶC ĐỊNH BẬT (không còn UI; dọn túi luôn chạy khi về thành)


def set_enabled(on: bool):
    try:
        os.makedirs(os.path.dirname(_PATH), exist_ok=True)
        json.dump({"sell_loot": bool(on)}, open(_PATH, "w", encoding="utf-8"),
                  ensure_ascii=False, indent=2)
    except Exception:
        pass
