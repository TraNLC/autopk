"""core/money.py — Format đơn vị bạc VLTK cho log/UI.

Quy ước (user): >= 10000 -> 'vạn' (60000 = '6 vạn', 65000 = '6 vạn 5000 lượng');
                < 10000 -> 'lượng' (6555 = '6555 lượng').
1 vạn = 10000 lượng.
"""


def fmt_money(n):
    try:
        n = int(n)
    except Exception:
        return str(n)
    neg = n < 0
    n = abs(n)
    if n >= 10000:
        van, le = divmod(n, 10000)
        s = f"{van} vạn" + (f" {le} lượng" if le else "")
    else:
        s = f"{n} lượng"
    return ("-" + s) if neg else s
