"""
core/stall_shopper.py — Tìm & mua đồ nhiệm vụ từ sạp người chơi (bày bán).

Cơ chế (đã RE + test thật):
  - Mở sạp: ePlayerStallOpenRequest(stallKey="salesman.<cid>.0") -> ePlayerStallOpenResponse (205).
  - Item sạp đóng gói: detailAndGenre = detail*10000 + genre ; particularAndLevel = level*10000 + particular.
  - Mua: ePlayerStallBuyItemRequest(stallCid, itemIndex, itemMoney). KHÔNG check khoảng cách.
  - getNearPlayers -> cid người chơi quanh mình (để biết sạp nào).

Map nhiệm vụ -> (genre, detail, particular, level): seed từ món tham chiếu thật, mở rộng dần.
  Ngọc Bội cấp 8 hệ Kim (Mặc Ngọc) = (genre=0, detail=9, particular=1, level=8).
"""
import os
import re
import time
import logging
import threading

logger = logging.getLogger("stall_shopper")

# Khoá ghi catalog dùng chung (nhiều cửa sổ/acc cùng process quét đồng thời -> read-modify-write atomic,
# tránh lost-update + trùng item). RLock vì cùng thread có thể gọi lồng (merge trong vòng quét).
_CATALOG_LOCK = threading.RLock()

# Từ khóa LOẠI trang bị (slot) -> detail. Tra theo SLOT vì NAM/NỮ cùng slot nhưng TÊN KHÁC NHAU
# (vd "Ngọc Bội" cấp 8: nam = "Mặc Ngọc Ngọc Bội", nữ = "Tiên Xạ Hương Nang" — tên hoàn toàn khác!).
SLOT_DETAIL = {
    # LOẠI đồ (slot) -> detail. Tên item THẬT trong group này khác hẳn (vd nhẫn = "Giới Chỉ",
    # KHÔNG chứa chữ "nhẫn"), nên PHẢI khớp theo detail+hệ, KHÔNG match tên. Đã verify qua item_db.
    "ngọc bội": 9, "ngọc bôi": 9, "hương nang": 9,        # bội/pendant (detail 9)
    "dây chuyền": 4, "hạng liên": 4, "hộ thân phù": 4,    # dây chuyền/necklace (detail 4)
    "nhẫn": 3, "giới chỉ": 3,                              # nhẫn/ring (detail 3 = "Giới Chỉ")
    "hộ uyển": 8, "thủ trạc": 8,                           # vòng tay/bracelet (detail 8)
    "giới cô": 7, "mão": 7, "nón": 7,                      # mão/head (detail 7 = "Giới Cô")
    "yêu đái": 6, "thắt lưng": 6,                          # đai/belt (detail 6 = "Yêu Đái")
    "giày": 5, "ngoa": 5,                                  # giày/boots (detail 5 = "Ngoa")
    "áo giáp": 2, "y phục": 2, "chiến bào": 2,            # áo/armor (detail 2)
}
ELEMENT_WORDS = {"kim": "kim", "mộc": "mộc", "moc": "mộc", "thủy": "thủy", "thuỷ": "thủy",
                 "thuy": "thủy", "hỏa": "hỏa", "hoả": "hỏa", "thổ": "thổ", "tho": "thổ"}


# Ngũ hành (series): xác nhận từ item_magicattrib (Kim m_nSeries=0, Thủy=2) + chuẩn VLTK.
SERIES_ELEMENT = {0: "kim", 1: "mộc", 2: "thủy", 3: "hỏa", 4: "thổ"}
ELEMENT_SERIES = {v: k for k, v in SERIES_ELEMENT.items()}


def decode_stall_item(dg: int, pl: int, sas: int = 0) -> dict:
    """Giải mã field item ở gói sạp (đã xác minh bằng món thật):
      field3 detailAndGenre = detail*10000 + genre
      field4 particularAndLevel = particular*10000 + level
      field5 stackAndSeries: series = sas % 10000 (ngũ hành 0-4)
    """
    return {
        "genre": dg % 10000,
        "detail": dg // 10000,
        "particular": pl // 10000,
        "level": pl % 10000,
        "series": sas % 10000,
    }


def resolve_quest_target(quest_text: str):
    """Quest text -> {'genre','detail','particular','level','name','desc'} hoặc None.

    Tra trực tiếp item DB của game (core.item_db) theo TÊN + CẤP.
    Vd: 'Hãy đi tìm cho ta 1 cái Ngọc Bội [Cấp 8] hệ Kim' -> Mặc Ngọc = (0,9,1,8).
    (Với Ngọc Bội, 'cấp' phân biệt từng ngọc = từng hệ nên hệ tự đúng theo cấp.)
    """
    if not quest_text:
        return None
    t = quest_text.lower()

    # cấp
    m = re.search(r"cấp\s*(\d+)", t)
    level = int(m.group(1)) if m else None

    # giới tính
    gender = None
    if re.search(r"\bnữ\b", t):
        gender = 1
    elif re.search(r"\bnam\b", t):
        gender = 0

    # hệ (giữ lại để lọc theo thuộc tính magic về sau)
    elem = None
    em = re.search(r"hệ\s+([^\s,\.\]]+)", t)
    if em:
        elem = ELEMENT_WORDS.get(em.group(1), em.group(1))

    try:
        from core.item_db import get_item_db
        db = get_item_db()
    except Exception as e:
        logger.error(f"[stall] item_db lỗi: {e}")
        return None

    # 1) Nếu quest dùng TÊN SLOT (dây chuyền, ngọc bội...) -> tra theo detail + cấp + giới tính
    detail = None
    slot_kw = ""
    for kw, d in SLOT_DETAIL.items():
        if kw in t:
            detail = d; slot_kw = kw; break

    # NV kiểu "tìm <slot> hệ <X>" KHÔNG nêu cấp -> khớp LOẠI(detail) + HỆ(series), BỎ QUA cấp.
    # (user: "dây chuyền hệ thủy" = bất kỳ dây chuyền hệ Thủy nào, không cần cấp độ.)
    if detail is not None and elem is not None and level is None:
        series = ELEMENT_SERIES.get(elem)
        return {"genre": None, "detail": detail, "particular": None, "level": None,
                "gender": gender, "element": elem, "series": series,
                "match_mode": "type_series",
                "name": f"{slot_kw} hệ {elem}",
                "desc": f"{slot_kw} hệ {elem} (mọi cấp)"}

    # NV "tìm 1 cái <slot>" KHÔNG nêu cấp, KHÔNG nêu hệ -> khớp BẤT KỲ món cùng SLOT (detail).
    # (vd "Hãy đi tìm cho ta 1 cái Nhẫn" = nhẫn bất kỳ; TRÁNH name-match vớ nhầm "Ngư Nhẫn y" cụ thể.)
    if detail is not None and elem is None and level is None:
        return {"genre": None, "detail": detail, "particular": None, "level": None,
                "gender": gender, "element": None, "series": None,
                "match_mode": "type_any",
                "name": slot_kw,
                "desc": f"{slot_kw} (bất kỳ cấp/hệ)"}

    cands = []
    gender_honored = True
    if detail is not None and level is not None:
        # Tra theo SLOT (detail) + cấp + GIỚI TÍNH -> bắt đúng bản nam/nữ dù tên khác nhau.
        cands = db.search(detail=detail, level=level, gender=gender)
        if not cands:   # không có đúng giới tính -> lấy đồ thường cùng slot+cấp (đừng vơ hoàng kim)
            cands = db.search(detail=detail, level=level)
            if cands:
                gender_honored = False

    # 2) Nếu chưa ra, thử theo TÊN item (cụm chữ trong quest)
    if not cands:
        pm = re.search(
            r"(?:tìm|mua|kiếm|gom)[^0-9\[]*?(?:\d+\s*)?(?:cái|thanh|cây|bộ|chiếc|viên|quyển|cuốn|đôi|cục|mảnh)?\s*"
            r"([^\[\.,;]+?)\s*(?:\[?\s*cấp|\s+hệ\b|[\.,;\]]|$)", t)
        phrase = pm.group(1).strip() if pm else ""
        if not phrase:
            # fallback: bỏ tiền tố "nhiệm vụ thứ N." rồi lấy cụm trước [cấp/hệ
            t2 = re.sub(r"nhiệm vụ thứ\s*\d+\.?", " ", t)
            pm2 = re.search(r"([\wà-ỹ ]+?)\s*(?:\[?\s*cấp|\s+hệ\b|[\.,;\]]|$)", t2.strip())
            phrase = pm2.group(1).strip() if pm2 else ""
        phrase = re.sub(r"\([^)]*\)", " ", phrase)   # bỏ "(Nữ)/(Nam)" dính sau tên (vd "Ngọc Bội(Nữ)")
        phrase = re.sub(r"\b(một|1|cái|thanh|cây|bộ|chiếc|cho|ta|giúp|nam|nữ|hãy|đi)\b", " ", phrase).strip()
        phrase = re.sub(r"\s+", " ", phrase)
        def _by_name(ph):
            """Tìm theo tên+cấp (đồ THƯỜNG, đã loại hoàng kim). Trả (cands, gender_honored):
            - Có đồ đúng giới tính -> dùng, honor gender.
            - Không -> lấy đồ thường CÙNG CẤP bất kể giới tính (vd ngọc bội cấp 8 chỉ có 1 bản),
              KHÔNG honor gender (để khớp được ở rương/sạp)."""
            c = db.search(name_contains=ph, level=level, gender=gender)
            if c:
                return c, True
            c = db.search(name_contains=ph, level=level)   # đồ thường cùng cấp, mọi giới tính
            return c, False

        gender_honored = True
        if phrase:
            cands, gender_honored = _by_name(phrase)
            if not cands and " " in phrase:
                cands, gender_honored = _by_name(" ".join(phrase.split()[-2:]))

    if not cands:
        logger.warning(f"[stall] Không tra được item DB: detail={detail} cấp={level} gender={gender}")
        return None

    e = cands[0]
    # spec.gender: honor giới tính NẾU tìm được đồ đúng giới tính; nếu phải fallback đồ thường (chỉ 1 bản,
    # vd ngọc bội cấp 8) thì = None để KHỚP được ở rương/sạp (đồ thường có gender riêng).
    spec_gender = gender if gender_honored else None
    gtxt = {0: "nam", 1: "nữ"}.get(spec_gender, "")
    series = ELEMENT_SERIES.get(elem) if elem else None
    return {"genre": e["genre"], "detail": e["detail"], "particular": e["particular"],
            "level": e["level"], "gender": spec_gender, "element": elem, "series": series,
            "name": e["name"].strip(),
            "desc": f"{e['name'].strip()} (cấp {e['level']}{', ' + gtxt if gtxt else ''}{', hệ ' + elem if elem else ''})"}


def item_matches_spec(item: dict, spec: dict) -> bool:
    # Chế độ LOẠI BẤT KỲ (chỉ detail) — cho NV "tìm 1 cái <slot>" KHÔNG cấp KHÔNG hệ (vd "1 cái Nhẫn").
    if spec.get("match_mode") == "type_any":
        if spec.get("detail") is not None and item.get("detail") != spec["detail"]:
            return False
        wg = spec.get("gender"); ig = item.get("gender")
        if wg is not None and ig is not None and ig != wg:
            return False
        return True
    # Chế độ LOẠI + HỆ (bỏ qua cấp/genre/particular) — cho NV "tìm <slot> hệ <X>".
    if spec.get("match_mode") == "type_series":
        if spec.get("detail") is not None and item.get("detail") != spec["detail"]:
            return False
        want = spec.get("series")
        if want is not None and item.get("series") is not None and item.get("series") != want:
            return False
        return True
    # Chế độ KHỚP CHÍNH XÁC (mặc định): genre/detail/particular/level.
    if not (item.get("genre") == spec["genre"] and item.get("detail") == spec["detail"]
            and item.get("particular") == spec["particular"] and item.get("level") == spec["level"]):
        return False
    want = spec.get("series")
    if want is not None and item.get("series") is not None and item.get("series") != want:
        return False
    # HONOR GIỚI TÍNH: NV Nữ(1)/Nam(0) -> loại đồ giới tính NGƯỢC; chấp đồ unisex (gender None).
    wg = spec.get("gender")
    ig = item.get("gender")
    if wg is not None and ig is not None and ig != wg:
        return False
    return True


def find_in_bag(bag_items, spec):
    """Tìm trong rương (túi location==2 hoặc đang mặc==1) món khớp spec. Trả (slot, item) hoặc (-1, None)."""
    cand = []
    for it in bag_items or []:
        if it.get("location") not in (None, 1, 2):
            continue
        if item_matches_spec(it, spec):
            cand.append(it)
    if not cand:
        return -1, None
    cand.sort(key=lambda it: 0 if it.get("location") == 2 else 1)  # ưu tiên đồ trong túi
    return cand[0].get("slot"), cand[0]


# ---- Quét sạp (cần bot đã connect) ----

def _parse_stall_packet(body: bytes):
    """Gói 205 -> [{itemIndex, genre, detail, particular, level, price, magic:[ints]}]."""
    def vi(d, o):
        r = s = 0
        while o < len(d):
            x = d[o]; o += 1; r |= (x & 0x7F) << s
            if not x & 0x80:
                break
            s += 7
        return r, o
    out = []; o = 0
    while o < len(body):
        try: tag, o = vi(body, o)
        except Exception: break
        f, w = tag >> 3, tag & 7
        if w == 0: _, o = vi(body, o)
        elif w == 2:
            ln, o = vi(body, o); raw = body[o:o + ln]; o += ln
            if f == 3:
                # ĐÚNG field protobuf Item: f3=detailAndGenre, f4=particularAndLevel, f5=stackAndSeries, f11=magic
                idx = None; price = 0; money_type = 0; dg = 0; pl = 0; sas = 0; mg = []; oo = 0
                while oo < len(raw):
                    t, oo = vi(raw, oo); ff, ww = t >> 3, t & 7
                    if ww == 0:
                        v, oo = vi(raw, oo)
                        if ff == 1: idx = v
                    elif ww == 2:
                        l2, oo = vi(raw, oo); ent = raw[oo:oo + l2]; oo += l2
                        p = 0
                        while p < len(ent):
                            t2, p = vi(ent, p); f2, w2 = t2 >> 3, t2 & 7
                            if w2 == 0:
                                v2, p = vi(ent, p)
                                if f2 == 2: price = v2
                                elif f2 == 3: money_type = v2   # 0=vạn/lượng, khác=KNB (kim nguyên bảo)
                            elif w2 == 2:
                                l3, p = vi(ent, p); itm = ent[p:p + l3]; p += l3
                                if f2 == 1:
                                    pp = 0
                                    while pp < len(itm):
                                        t3, pp = vi(itm, pp); f3, w3 = t3 >> 3, t3 & 7
                                        if w3 == 0:
                                            v3, pp = vi(itm, pp)
                                            if f3 == 3: dg = v3
                                            elif f3 == 4: pl = v3
                                            elif f3 == 5: sas = v3
                                        elif w3 == 2:
                                            l4, pp = vi(itm, pp); sub = itm[pp:pp + l4]; pp += l4
                                            if f3 == 11:
                                                q = 0
                                                while q < len(sub):
                                                    mvv, q = vi(sub, q); mg.append(mvv)
                                        elif w3 == 1: pp += 8
                                        elif w3 == 5: pp += 4
                                        else: break
                            elif w2 == 1: p += 8
                            elif w2 == 5: p += 4
                            else: break
                    elif ww == 1: oo += 8
                    elif ww == 5: oo += 4
                    else: break
                if idx is not None:
                    d = decode_stall_item(dg, pl, sas)
                    d.update(itemIndex=idx, price=price, money_type=money_type, magic=mg)
                    out.append(d)
        elif w == 1: o += 8
        elif w == 5: o += 4
        else: break
    return out


_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CATALOG_PATH = os.path.join(_ROOT, "stall_catalog.json")   # cache CID theo PHIÊN (cid là tạm thời)
HOTSPOT_PATH = os.path.join(_ROOT, "vendor_hotspots.json")  # TOẠ ĐỘ khu chợ (CỐ ĐỊNH, server-agnostic)

# ---- BLACKLIST "DEAD ENTRY" (LOCAL mỗi máy, KHÔNG sync) ----
# remove_item chỉ xoá được catalog LOCAL; entry đến từ SHARED (máy khác quét) không dập được → vòng lặp
# "mua hụt sạp 10491 mãi". Giải: ghi (cid:itemIndex) đã-mua-hụt vào dead-list LOCAL có TTL; load_catalog_merged
# LỌC chúng ra → entry shared cũng bị bỏ qua. TTL hết → cho thử lại (sạp có thể niêm yết lại).
DEAD_PATH = os.path.join(_ROOT, "data", "output", ".stall_dead.json")
DEAD_TTL = 1800   # 30 phút: đủ lâu để khỏi spam sạp đã đóng; hết hạn cho thử lại phòng sạp relist


def _dead_key(cid, item_index):
    return f"{cid}:{item_index}"


def _load_dead():
    try:
        import json
        with open(DEAD_PATH, "r", encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save_dead(dead):
    import json
    try:
        now = time.time()
        pruned = {k: v for k, v in dead.items() if now - float(v or 0) <= DEAD_TTL}   # prune hết-hạn
        os.makedirs(os.path.dirname(DEAD_PATH), exist_ok=True)
        with open(DEAD_PATH, "w", encoding="utf-8") as f:
            json.dump(pruned, f)
    except Exception as e:
        logger.error(f"[stall] _save_dead: {e}")


def mark_dead(cid, item_index):
    """Đánh dấu (cid,itemIndex) mua-hụt → load_catalog_merged bỏ qua trong DEAD_TTL (kể cả entry từ shared)."""
    with _CATALOG_LOCK:
        dead = _load_dead()
        dead[_dead_key(cid, item_index)] = time.time()
        _save_dead(dead)


def _dead_set():
    """Tập key (cid:itemIndex) còn trong TTL → cần lọc khỏi thư viện gộp."""
    now = time.time()
    return {k for k, v in _load_dead().items() if now - float(v or 0) <= DEAD_TTL}


def load_hotspots(path=HOTSPOT_PATH):
    try:
        import json
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def save_hotspot(map_id, x, y, label="", path=HOTSPOT_PATH):
    """Lưu toạ độ 1 khu chợ. Gộp nếu trùng (cùng map + cách < 5 ô). Trả tổng số hotspot."""
    import json
    spots = load_hotspots(path)
    for s in spots:
        if s.get("map_id") == map_id and abs(s.get("x", 0) - x) < 5 and abs(s.get("y", 0) - y) < 5:
            s["x"], s["y"] = x, y
            if label:
                s["label"] = label
            try:
                json.dump(spots, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
            except Exception:
                pass
            return len(spots)
    spots.append({"map_id": map_id, "x": x, "y": y, "label": label})
    try:
        json.dump(spots, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    except Exception as e:
        logger.error(f"[stall] save_hotspot: {e}")
    return len(spots)


def load_catalog(path=CATALOG_PATH):
    try:
        import json
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_catalog(catalog, path=CATALOG_PATH):
    try:
        import json
        with open(path, "w", encoding="utf-8") as f:
            json.dump(catalog, f, ensure_ascii=False)
    except Exception as e:
        logger.error(f"[stall] save_catalog: {e}")


def _atomic_write_catalog(catalog, path=CATALOG_PATH):
    """Ghi nguyên tử: viết file tạm rồi os.replace (tránh đọc phải file ghi dở khi nhiều acc đua)."""
    import json, tempfile
    try:
        d = os.path.dirname(path) or "."
        fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(catalog, f, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception as e:
        logger.error(f"[stall] atomic write catalog: {e}")


def catalog_counts(catalog):
    """(số_vật_phẩm, số_sạp) trong catalog."""
    stalls = len(catalog or {})
    items = sum(len(v or []) for v in (catalog or {}).values())
    return items, stalls


def _dedup_items_by_index(items):
    """Trong 1 sạp: gộp các lần SWEEP/rảo, giữ itemIndex DUY NHẤT (lần sau ghi đè lần trước).
    LỌC KNB: chỉ giữ vật phẩm bán bằng VẠN/LƯỢNG (money_type 0/None). Đồ định giá bằng KNB (money_type != 0)
    KHÔNG đưa vào thư viện (mua bằng vạn sẽ hụt + nhiễu thư viện)."""
    seen = {}
    for it in items or []:
        idx = it.get("itemIndex")
        if idx is None:
            continue
        if it.get("money_type", 0) not in (0, None):   # KNB -> bỏ, không lưu
            continue
        seen[idx] = it
    return list(seen.values())


def merge_catalog(new_catalog, path=CATALOG_PATH):
    """Gộp kết quả quét MỚI vào catalog chung — CÓ KHOÁ (load->gộp->ghi trong 1 critical section) để
    3 acc quét cùng lúc không đạp/làm trùng nhau. REPLACE theo cid (scan mới = trạng thái HIỆN TẠI của
    sạp đó), dedup itemIndex. Trả (số_vật_phẩm, số_sạp) sau gộp."""
    with _CATALOG_LOCK:
        lib = load_catalog(path)
        for cid, items in (new_catalog or {}).items():
            deduped = _dedup_items_by_index(items)
            if deduped:
                lib[str(cid)] = deduped        # chỉ đụng cid mình quét -> giữ nguyên cid acc khác vừa thêm
        _atomic_write_catalog(lib, path)
        return catalog_counts(lib)


# ---------------- THƯ VIỆN CHIA SẺ ĐA MÁY (qua Syncthing treasurer_shared) ----------------
# Máy QUÉT (vd vinh) publish catalog của mình ra treasurer_shared/stall_catalog/<machine_id>.json (Syncthing
# sync) → máy ĐỌC (vd LinhDL) gộp local + mọi file shared khi MUA → KHỎI tự đi quét. cid là server-wide nên
# dùng chung được (cùng server). Mỗi máy 1 file → không đạp nhau (giống requests_<id>.json của thủ quỹ).
SHARED_CATALOG_DIR = os.path.join(_ROOT, "data", "output", "treasurer_shared", "stall_catalog")


def _this_machine_id():
    try:
        from core.treasurer import _machine_id
        return _machine_id()
    except Exception:
        return "unknown"


def publish_catalog(path=CATALOG_PATH):
    """Đẩy catalog LOCAL hiện tại ra file shared <machine_id>.json (atomic) cho máy khác đọc qua Syncthing.
    Trả (items, stalls) đã publish."""
    import json, tempfile
    lib = load_catalog(path)
    try:
        os.makedirs(SHARED_CATALOG_DIR, exist_ok=True)
        out = os.path.join(SHARED_CATALOG_DIR, f"{_this_machine_id()}.json")
        fd, tmp = tempfile.mkstemp(dir=SHARED_CATALOG_DIR, suffix=".tmp")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(lib, f, ensure_ascii=False)
        os.replace(tmp, out)
    except Exception as e:
        logger.error(f"[stall] publish_catalog: {e}")
    return catalog_counts(lib)


def load_catalog_merged(path=CATALOG_PATH):
    """ĐỌC THƯ VIỆN GỘP cho luồng MUA: catalog LOCAL + MỌI file shared stall_catalog/*.json (máy khác quét).
    Để máy chỉ-đọc (LinhDL) xài đồ máy khác (vinh) quét mà KHỎI tự đi. Gộp theo cid (file sau đè trùng cid —
    chấp nhận, cùng server). CHỈ ĐỌC, không ghi gì."""
    import json, glob
    lib = dict(load_catalog(path))
    try:
        for fp in glob.glob(os.path.join(SHARED_CATALOG_DIR, "*.json")):
            try:
                with open(fp, "r", encoding="utf-8") as f:
                    other = json.load(f) or {}
                for cid, items in other.items():
                    if items:
                        lib[str(cid)] = items
            except Exception:
                continue
    except Exception as e:
        logger.error(f"[stall] load_catalog_merged: {e}")
    # LỌC dead-entry (đã mua-hụt trong TTL) — kể cả entry đến từ shared → chống vòng lặp mua hụt 1 sạp mãi.
    dead = _dead_set()
    if dead:
        cleaned = {}
        for cid, items in lib.items():
            kept = [it for it in (items or []) if _dead_key(cid, it.get("itemIndex")) not in dead]
            if kept:
                cleaned[cid] = kept
        lib = cleaned
    return lib


def sanitize_catalog(path=CATALOG_PATH):
    """DỌN thư viện hiện có: bỏ MỌI vật phẩm KNB (money_type != 0) — chỉ giữ đồ bán bằng VẠN/LƯỢNG.
    Idempotent (chạy lại không hại). Gọi 1 lần lúc khởi động để làm sạch dữ liệu cũ tích trước khi có filter.
    Trả (số_món_bỏ, số_món_còn)."""
    with _CATALOG_LOCK:
        lib = load_catalog(path)
        removed = 0
        clean = {}
        for cid, items in (lib or {}).items():
            kept = [it for it in (items or []) if it.get("money_type", 0) in (0, None)]
            removed += len(items or []) - len(kept)
            if kept:
                clean[cid] = kept
        if removed:
            _atomic_write_catalog(clean, path)
        items_left, _ = catalog_counts(clean)
        return removed, items_left


def remove_item(cid, item_index, path=CATALOG_PATH):
    """Xoá 1 món (cid,itemIndex) khỏi catalog — CÓ KHOÁ. Gọi sau MỖI lần mua (dù thành/bại) để acc khác
    khỏi duyệt lại. cid hết món thì xoá luôn cid. Trả (số_vật_phẩm, số_sạp) sau xoá."""
    with _CATALOG_LOCK:
        lib = load_catalog(path)
        cid = str(cid)
        if cid in lib:
            lib[cid] = [it for it in lib[cid] if it.get("itemIndex") != item_index]
            if not lib[cid]:
                del lib[cid]
            _atomic_write_catalog(lib, path)
        # CŨNG đánh dấu dead → load_catalog_merged bỏ qua entry này DÙ nó nằm ở shared (máy khác quét).
        # Đây là chỗ trước đây bị bug: remove chỉ đụng local, entry shared sống mãi → vòng lặp mua hụt.
        mark_dead(cid, item_index)
        return catalog_counts(load_catalog_merged(path))


def _parse_stall_cid(body: bytes):
    """Lấy stallCid (field 1, string) từ gói 205."""
    try:
        if len(body) >= 2 and body[0] == 0x0A:  # tag field1, wire2
            ln = body[1]
            return body[2:2 + ln].decode("utf-8", "ignore")
    except Exception:
        pass
    return None


def scan_stalls(game_bot, max_players=80, merge=False, log=None, early_stop=None):
    """Quét sạp người chơi quanh mình. GỬI HẾT lệnh mở rồi GOM mọi gói 205, phân loại theo cid
    trong chính gói (tránh đua/ăn nhầm phản hồi). Trả {cid: [items...]}.
    log: callback in chẩn đoán (vd UI). Mặc định ghi vào logger (auto_flow.log).
    early_stop: GIỮ tham số cho tương thích NHƯNG ĐÃ VÔ HIỆU (revert 2026-06-14 — user báo regression;
    memory dặn đừng đụng luồng quét sạp). Quét gom HẾT như baseline rồi để handler tìm."""
    _log = log or logger.info
    catalog = {}
    # SẠP nằm ở CharManager.salesmans (KHÔNG phải GetNearPlayers = người thường). Đọc salesmans trước;
    # nếu rỗng/lỗi mới quay về players (phòng khi RPC chưa sẵn).
    src = "salesmans"
    npres = None
    try:
        npres = game_bot.rpc.get_near_salesmans()
    except Exception as e:
        logger.error(f"[stall] get_near_salesmans: {e}")
    sale = npres.get("players", []) if isinstance(npres, dict) and npres.get("ok") else []
    if not sale:
        # Vì sao salesmans rỗng? in ra để soi (ok/error/diag) — gốc rễ "ít sạp".
        _log(f"[stall] salesmans rỗng -> fallback. RPC trả: ok={isinstance(npres,dict) and npres.get('ok')} "
             f"err={isinstance(npres,dict) and npres.get('error')} diag={isinstance(npres,dict) and npres.get('diag')}")
        src = "players(fallback)"
        try:
            npres = game_bot.rpc.get_near_players()
        except Exception as e:
            logger.error(f"[stall] get_near_players: {e}")
            npres = None
        sale = npres.get("players", []) if isinstance(npres, dict) else []
    cids = [str(p.get("id")) if isinstance(p, dict) else str(p) for p in sale]
    cids = [c for c in cids if c][:max_players]

    if hasattr(game_bot, "recv_buffer"):
        game_bot.recv_buffer = []
    game_bot.poll_recv()
    # 1) gửi TẤT CẢ lệnh mở sạp (không chờ từng cái).
    #    cid từ salesmans ĐÃ là stallKey đầy đủ ('salesman.117435.0') -> dùng THẲNG.
    #    cid từ players là số thuần ('135037') -> bọc thành 'salesman.{cid}.0'.
    for cid in cids:
        key = cid if str(cid).startswith("salesman.") else f"salesman.{cid}.0"
        try:
            game_bot.send_gs("ePlayerStallOpenRequest", stallKey=key)
        except Exception:
            pass
        time.sleep(0.03)
    # 2) gom mọi gói 205 trong vài giây, phân loại theo cid trong gói
    # ĐẾM CHẨN ĐOÁN: bao nhiêu gói 205 nhận được, bao nhiêu sạp có hàng / rỗng / parse hỏng.
    n_resp = 0; n_empty = 0; n_err = 0; resp_cids = set()
    deadline = time.time() + max(4.0, len(cids) * 0.3)
    last_new = time.time()   # mốc nhận gói 205 mới gần nhất (để DỪNG SỚM khi hết phản hồi)
    while time.time() < deadline:
        pkts = game_bot.poll_recv() or []
        for p in pkts:
            if p.get("opcode") == 205 or p.get("name") == "ePlayerStallOpenResponse":
                n_resp += 1
                last_new = time.time()
                try:
                    body = bytes.fromhex(p["hex"])[6:]
                    cid = _parse_stall_cid(body)
                    items = _parse_stall_packet(body)
                    if cid:
                        resp_cids.add(cid)
                    if cid and items:
                        # CHỈ giữ đồ bán bằng VẠN/LƯỢNG (money_type 0/None); BỎ đồ bán bằng KNB (money_type!=0)
                        # — lọc ngay tại GỐC nên mọi đường (quét toàn-map + find_equip) đều sạch KNB.
                        items = [it for it in items if it.get("money_type", 0) in (0, None)]
                    if cid and items:
                        catalog[cid] = items
                    else:
                        n_empty += 1
                except Exception:
                    n_err += 1
        if len(resp_cids) >= len(cids):
            break
        # TĂNG TỐC: đã nhận ≥1 phản hồi mà IM quá 1.5s = các sạp còn lại (ngoài tầm/đã đóng) sẽ KHÔNG trả
        # -> dừng chờ NGAY thay vì đợi hết deadline (~17s với 57 sạp mà thường chỉ ~17 sạp trả lời).
        if resp_cids and (time.time() - last_new) > 1.5:
            break
        time.sleep(0.15)
    _log(f"[CHẨN ĐOÁN QUÉT] nguồn={src}: {len(cids)} sạp gần | gửi {len(cids)} lệnh mở | "
         f"nhận {n_resp} gói trả lời (từ {len(resp_cids)} sạp) | {len(catalog)} sạp CÓ hàng | "
         f"{n_empty} sạp rỗng | {n_err} lỗi parse")
    if merge:
        lib = load_catalog()
        lib.update(catalog)   # cid mới/cập nhật ghi đè; cid cũ ở nơi khác giữ nguyên
        save_catalog(lib)
        return lib
    return catalog


def scan_stalls_roam(game_bot, log=logger.info, stop_when=None, spec=None, max_price=10_000_000):
    """Quét TƯƠI: remote tới các toạ độ chợ CỐ ĐỊNH (vendor_hotspots.json) CÙNG MAP nhân vật.
    spec (tuỳ chọn): món cần tìm -> log chi tiết từng điểm (thấy mấy món, có khớp không, vì sao không),
    và DỪNG ngay khi thấy món khớp giá ≤ max_price.
    stop_when(catalog)->bool: cách cũ (vẫn hỗ trợ). Trả (catalog_tươi, mid_cuối, số_điểm_đã_quét)."""
    fresh = {}
    cx, cy, mid = _read_pos(game_bot)
    # mapId CHẮC CHẮN: _read_pos có thể trả None (đọc mapX hụt) -> đọc lại RIÊNG mapId (không cần mapX>0)
    # nếu không có mid thì KHÔNG roam được tới hotspot -> bỏ lỡ cụm sạp (đúng bug đang gặp).
    if mid is None:
        for _ in range(6):
            try:
                r = game_bot.rpc.get_player_info()
                if r and r.get("ok") and r.get("mapId"):
                    mid = r.get("mapId"); break
            except Exception:
                pass
            time.sleep(0.4)
    try:
        from database.db_manager import db as _db
        def _mname(m):
            try: return _db.get_map_name(m) if m else "?"
            except Exception: return "?"
    except Exception:
        def _mname(m): return "?"

    # CHỈ quét toạ độ chợ CÙNG MAP với nhân vật (user chọn: chỉ quét thành đang đứng, KHÔNG đi liên
    # thành). Muốn farm thành khác -> tự đưa nhân vật sang thành đó rồi bật Auto.
    spots = sorted([s for s in load_hotspots() if s.get("map_id") == mid], key=lambda s: s.get("x") or 0)

    def _nmon(cat):
        return sum(len(v) for v in cat.values())

    if not spots:
        log(f"[QUÉT SẠP] {_mname(mid)} (map {mid}) CHƯA có toạ độ chợ → quét QUANH chỗ đứng. "
            "Dùng '📍 Lưu điểm chợ tại đây' để thêm điểm cho thành này.")
        fresh.update(scan_stalls(game_bot, merge=False))
        return fresh, mid, 0

    tname = _mname(mid)
    log(f"🔎 Bắt đầu quét sạp ở {tname} (map {mid}): {len(spots)} điểm chợ. Cần tìm: "
        + (spec.get('desc') if spec else 'theo NV'))
    # get_near_players chỉ trả ~24 người/lần -> 1 chỗ đứng KHÔNG thấy hết khu chợ.
    # Mỗi điểm: tới nơi rồi QUÉT NHIỀU VỊ TRÍ (tâm + vòng offset) để phủ rộng cụm sạp.
    SWEEP = [(0, 0), (900, 0), (-900, 0), (0, 900), (0, -900), (900, 900), (-900, -900)]
    for i, s in enumerate(spots):
        x0, y0, _ = _read_pos(game_bot, retries=2)
        arrived = _goto_wait(game_bot, s["x"], s["y"], timeout=16.0, near=700, want_map=mid)
        x1, y1, _ = _read_pos(game_bot, retries=2)
        moved = (x0 is not None and x1 is not None and (abs(x1 - x0) + abs(y1 - y0)) > 50)
        log(f"   ↪ tới hotspot ({s['x']},{s['y']}): vị trí {x0},{y0} → {x1},{y1} "
            f"({'có dịch chuyển' if moved else 'KHÔNG dịch chuyển'}), cách đích "
            f"{abs((x1 or 0)-s['x'])+abs((y1 or 0)-s['y'])} đơn vị.")
        spot_cat = {}
        for k, (ox, oy) in enumerate(SWEEP):
            if k > 0:   # nudge nhỏ quanh tâm để thấy thêm người (mỗi lần ~24)
                _goto_wait(game_bot, s["x"] + ox, s["y"] + oy, timeout=6.0, near=500, want_map=mid)
            time.sleep(0.8)
            spot_cat.update(scan_stalls(game_bot, merge=False))
        fresh.update(spot_cat)
        nstall = len(spot_cat); nitem = _nmon(spot_cat)
        log(f"📍 Điểm chợ {i+1}/{len(spots)} ở {tname} {'(đã tới)' if arrived else '(chưa áp sát)'}: "
            f"quét {len(SWEEP)} vị trí, gom {nstall} sạp / {nitem} món.")
        # CHI TIẾT MATCH: vì sao khớp / không khớp -> để người chơi thấy logic.
        if spec is not None:
            same = []   # món CÙNG LOẠI (detail) với món cần -> để soi p/lv/giá
            for items in spot_cat.values():
                for it in items:
                    if it.get("detail") == spec.get("detail"):
                        same.append(it)
            found = find_in_stalls(spot_cat, spec, max_price=max_price)
            if found:
                _cid, _idx, _price, _it = found
                log(f"   ✅ CÓ MÓN PHÙ HỢP ở sạp {_cid}, giá {fmt_money(_price)} → DỪNG quét, đi mua.")
                return fresh, mid, i + 1
            if same:
                sd = [f"(p{it.get('particular')},lv{it.get('level')},{fmt_money(it.get('price'))})" for it in same[:6]]
                log(f"   ↳ có {len(same)} món cùng loại nhưng KHÔNG khớp "
                    f"(cần p{spec.get('particular')},lv{spec.get('level')},giá≤{fmt_money(max_price)}): {', '.join(sd)}")
            else:
                log(f"   ↳ không có món cùng loại (cần detail={spec.get('detail')}).")
            log(f"   → chưa thấy món phù hợp, quét tiếp điểm kế tiếp...")
        elif stop_when is not None:
            try:
                if stop_when(fresh):
                    log(f"   ✅ Đã thấy món cần ở điểm {i+1}/{len(spots)} → DỪNG quét, đi mua.")
                    return fresh, mid, i + 1
            except Exception:
                pass
    log(f"❌ Đã quét hết {len(spots)} điểm chợ ở {tname} — KHÔNG thấy món phù hợp.")
    return fresh, mid, len(spots)


def _read_pos(game_bot, retries=8):
    """Đọc vị trí, poll tới khi hợp lệ (≠0,0) — ngay sau connect thường (0,0)."""
    for _ in range(retries):
        try:
            r = game_bot.rpc.get_player_info()
            if r and r.get("ok") and (r.get("mapX") or 0) > 0:
                return r.get("mapX"), r.get("mapY"), r.get("mapId")
        except Exception:
            pass
        time.sleep(0.5)
    return None, None, None


def _goto_wait(game_bot, tx, ty, timeout=8.0, near=260, want_map=None):
    """REMOTE auto-route tới (tx,ty) bằng GotoFindingPath (đi được QUA MAP - auto travel của game).
    want_map: nếu toạ độ ở map khác, chờ tới khi mapId == want_map RỒI mới tính áp sát.
    Bot là remote nên cứ auto-route tới toạ độ cố định, mặc kệ đang đứng map nào.
    Trả True nếu tới nơi (đúng map + áp sát)."""
    def _send():
        # ĐI BỘ THẬT = invoke GotoFindingPath TRÊN MAIN THREAD (walk_to_world). goto_path_native là invoke
        # OFF-THREAD → Unity gameplay KHÔNG chạy → nhân vật gần như đứng im (đúng triệu chứng "không thấy di
        # chuyển"). tx,ty đã là WORLD coords (từ _read_pos mapX/mapY) → truyền thẳng walk_to_world.
        ok = False
        try:
            ok = game_bot.walk_to_world(tx, ty)
        except Exception:
            ok = False
        if not ok:                                   # fallback (hiếm) — native/op248 thường vô tác dụng
            try: ok = game_bot.goto_path_native(tx, ty)
            except Exception: pass
        if not ok:
            try: game_bot.move_to(tx, ty)
            except Exception: pass
        return ok
    _send()
    t0 = time.time(); last = None; stuck = 0; resent = 0
    while time.time() - t0 < timeout:
        time.sleep(0.6)
        x, y, m = _read_pos(game_bot, retries=2)
        if x is None:
            continue
        on_map = (want_map is None) or (m == want_map)
        if on_map and abs(x - tx) <= near and abs(y - ty) <= near:
            return True
        # đang đi qua map (sai map) -> KHÔNG coi là kẹt, cứ chờ + thỉnh thoảng bắn lại.
        if last and abs(x - last[0]) < 15 and abs(y - last[1]) < 15:
            stuck += 1
            if stuck % 4 == 0 and resent < 4:   # kẹt thật -> bắn lại lệnh auto-route
                _send(); resent += 1
        else:
            stuck = 0
        last = (x, y)
    return False


def sweep_scan(game_bot, ring=550, log=logger.info):
    """Quét RẢO quanh khu chợ: pathfind tới nhiều điểm offset, CHỜ tới nơi, quét gom mỗi điểm."""
    cx, cy, mid = _read_pos(game_bot)
    if not cx:
        log("[sweep] không đọc được toạ độ -> quét tại chỗ")
        return scan_stalls(game_bot, merge=True)
    save_hotspot(mid, cx, cy)
    log(f"[sweep] tâm map {mid} ({cx},{cy}), ring={ring}")
    offsets = [(0, 0), (ring, 0), (-ring, 0), (0, ring), (0, -ring),
               (ring, ring), (-ring, -ring), (ring, -ring), (-ring, ring),
               (2 * ring, 0), (-2 * ring, 0), (0, 2 * ring), (0, -2 * ring)]
    lib = load_catalog()
    for i, (ox, oy) in enumerate(offsets):
        if ox or oy:
            _goto_wait(game_bot, cx + ox, cy + oy)
        else:
            time.sleep(0.5)
        before = len(lib)
        lib = scan_stalls(game_bot, merge=True)
        px, py, _ = _read_pos(game_bot, retries=1)
        log(f"[sweep {i+1}/{len(offsets)}] target({cx+ox},{cy+oy}) @({px},{py}) -> {len(lib)} sạp (+{len(lib)-before})")
    _goto_wait(game_bot, cx, cy, timeout=4.0)
    return lib


def grid_sweep(game_bot, radius=2400, step=600, log=logger.info, goto_timeout=12.0, near=260):
    """Quét TOÀN khu vực: đi theo lưới (snake) phủ bán kính `radius` quanh vị trí hiện tại,
    mỗi điểm quét + gom thư viện. Dùng để 'quét hết thành'. Trả thư viện đã gom.
    goto_timeout cao hơn để thật sự ĐI TỚI điểm xa (điểm xa cần đi lâu)."""
    cx, cy, mid = _read_pos(game_bot)
    if not cx:
        log("[grid] không đọc được toạ độ -> quét tại chỗ")
        return scan_stalls(game_bot, merge=True)
    save_hotspot(mid, cx, cy)
    axis = list(range(-radius, radius + 1, step))
    pts = []
    for iy, oy in enumerate(axis):
        row = [(ox, oy) for ox in axis]
        if iy % 2:
            row = row[::-1]          # đi zigzag cho đỡ tốn đường
        pts += row
    log(f"[grid] tâm map {mid} ({cx},{cy}); {len(pts)} điểm, bán kính {radius}, bước {step}, timeout {goto_timeout}s")
    lib = load_catalog()
    for i, (ox, oy) in enumerate(pts):
        arrived = _goto_wait(game_bot, cx + ox, cy + oy, timeout=goto_timeout, near=near)
        before = len(lib)
        lib = scan_stalls(game_bot, merge=True)
        if len(lib) > before or (i % 6 == 0):
            px, py, _ = _read_pos(game_bot, retries=1)
            tag = "" if arrived else " (kẹt)"
            nmon = sum(len(v or []) for v in lib.values())
            log(f"[grid {i+1}/{len(pts)}] @({px},{py}){tag} FILE: {len(lib)} sạp / {nmon} món (+{len(lib)-before} sạp)")
    _goto_wait(game_bot, cx, cy, timeout=goto_timeout)
    log(f"[grid] XONG — FILE hiện có: {len(lib)} sạp / {sum(len(v or []) for v in lib.values())} món")
    return lib


def goto_dense_stalls(game_bot, log=logger.info, max_hops=4, near=400):
    """HOMING TỚI TÂM CỤM SẠP (thay quét lưới mù): đọc TOẠ ĐỘ các sạp gần (get_near_salesmans có x,y world) →
    tính TÂM (centroid) → walk_to_world tới đó; lặp tới khi tâm ≈ chỗ đứng (đã ở giữa cụm) hoặc hết hop.
    Mỗi hop quét gom luôn (scan_stalls merge). Trả số sạp THẤY ở bước cuối. Hơn hẳn grid vì chạy THẲNG tới đám đông sạp."""
    last_n = 0
    for hop in range(max_hops):
        try:
            r = game_bot.rpc.get_near_salesmans() or {}
            sellers = [s for s in (r.get("players") or [])
                       if isinstance(s.get("x"), (int, float)) and isinstance(s.get("y"), (int, float))]
        except Exception:
            sellers = []
        scan_stalls(game_bot, merge=True)          # gom sạp tại chỗ đứng hiện tại
        if not sellers:
            log(f"[dense] hop {hop}: không đọc được toạ độ sạp nào quanh đây → dừng homing (quét tại chỗ).")
            break
        cx = sum(s["x"] for s in sellers) / len(sellers)
        cy = sum(s["y"] for s in sellers) / len(sellers)
        px, py, _ = _read_pos(game_bot, retries=2)
        last_n = len(sellers)
        if px is not None and abs(px - cx) <= near and abs(py - cy) <= near:
            log(f"[dense] hop {hop}: đã ở GIỮA cụm {len(sellers)} sạp (tâm {int(cx)},{int(cy)}) → quét kỹ tại đây.")
            break
        log(f"[dense] hop {hop}: {len(sellers)} sạp, tâm ({int(cx)},{int(cy)}), mình ({px},{py}) → chạy tới tâm cụm.")
        _goto_wait(game_bot, int(cx), int(cy), timeout=10.0, near=near)
    return last_n


def auto_roam_scan(game_bot, log=logger.info, spec=None, max_price=10_000_000,
                   radius=1200, step=400, goto_timeout=8.0, should_stop=None, matcher=None, max_points=20,
                   report_fn=None):
    """TỰ RẢO: đi lưới (snake) quanh VỊ TRÍ HIỆN TẠI, mỗi điểm quét TƯƠI rồi gom.
    KHÔNG cần hotspot cố định — tự bò khắp khu để gặp các cụm sạp (client chỉ thấy ~10-24 người/chỗ).
    Có spec: log chi tiết + DỪNG ngay khi thấy món khớp giá ≤ max_price. Trả (catalog, mid, số_điểm_đã_quét)."""
    cx, cy, mid = _read_pos(game_bot)
    if cx is None:
        log("[TỰ RẢO] không đọc được vị trí → quét tại chỗ.")
        return scan_stalls(game_bot, merge=False), mid, 0
    try:
        from database.db_manager import db as _db
        tname = _db.get_map_name(mid) or "?"
    except Exception:
        tname = "?"
    axis = list(range(-radius, radius + 1, step))
    pts = []
    for iy, oy in enumerate(axis):
        row = [(ox, oy) for ox in axis]
        if iy % 2:
            row = row[::-1]            # zigzag đỡ tốn đường
        pts += row
    # GIỚI HẠN số điểm rảo (user: chỉ ~20 điểm). Ưu tiên điểm GẦN tâm (chỗ đang đứng = trung tâm sạp đông) trước.
    if max_points and len(pts) > max_points:
        pts.sort(key=lambda p: p[0] * p[0] + p[1] * p[1])   # gần tâm → xa
        pts = pts[:max_points]
    want = spec.get('desc') if spec else 'món theo NV'
    log(f"🧭 Bắt đầu tự rảo tìm '{want}' ở {tname}: sẽ đi qua {len(pts)} điểm quanh chỗ đang đứng.")
    fresh = {}
    dry = 0   # số điểm LIÊN TIẾP không thêm sạp mới (diminishing returns → dừng sớm cho nhanh)
    for i, (ox, oy) in enumerate(pts):
        if should_stop and should_stop():          # tắt Auto giữa chừng → DỪNG rảo ngay (không chờ hết lưới)
            log("[TỰ RẢO] dừng theo yêu cầu (tắt Auto).")
            return fresh, mid, i
        tx, ty = cx + ox, cy + oy
        arrived = _goto_wait(game_bot, tx, ty, timeout=goto_timeout, near=1500, want_map=mid)
        time.sleep(0.7)
        px, py, _ = _read_pos(game_bot, retries=1)
        spot = scan_stalls(game_bot, merge=False)
        nstall = len(spot); nitem = sum(len(v) for v in spot.values())
        # ĐƯA VÀO THƯ VIỆN ngay từng điểm (merge_catalog tự lọc KNB) + đếm số món VẠN lưu được điểm này.
        _lib_add = sum(1 for items in spot.values() for it in items if it.get("money_type", 0) in (0, None))
        try:
            _lib_tot, _ = merge_catalog(spot)
        except Exception:
            _lib_tot = None
        before = len(fresh)
        fresh.update(spot)
        new_stalls = len(fresh) - before
        dry = dry + 1 if new_stalls == 0 else 0
        # MATCHER tuỳ ý (vd khớp THEO THUỘC TÍNH cho NV submit_equip) → thấy là DỪNG rảo ngay (early-stop).
        if matcher is not None:
            try:
                if matcher(spot):
                    log(f"🚶 Điểm {i+1}/{len(pts)}: thấy {nstall} sạp → ✅ CÓ món cần (matcher) → dừng rảo.")
                    return fresh, mid, i + 1
            except Exception:
                pass
        # Câu log kiểu người đọc: di chuyển tới đâu, thấy mấy sạp, quét mấy món, có món cần không.
        # Toạ độ hiển thị = minimap (world-coord ÷ 256, khớp số trên minimap trong game).
        def _mm(v):
            try: return int(v) // 256
            except Exception: return v
        _libtxt = f" | +{_lib_add} vào thư viện" + (f" (thư viện: {_lib_tot} món)" if _lib_tot is not None else "")
        head = (f"🚶 Điểm {i+1}/{len(pts)}: đi tới ({_mm(tx)},{_mm(ty)}) → đang ở ({_mm(px)},{_mm(py)}). "
                f"Thấy {nstall} sạp, quét {nitem} món{_libtxt}")
        if spec is not None:
            found = find_in_stalls(spot, spec, max_price=max_price)
            if found:
                log(head + f" → ✅ CÓ '{want}' (sạp {found[0]}, giá {fmt_money(found[2])}) → mua luôn!")
                return fresh, mid, i + 1
            same = sum(1 for items in spot.values() for it in items if it.get("detail") == spec.get("detail"))
            log(head + f" → KHÔNG có '{want}' ({same} món cùng loại nhưng sai cấp/hệ/giá). "
                f"[Tổng đã quét: {len(fresh)} sạp, +{new_stalls} sạp mới]")
        else:
            # report_fn (vd NV thuộc tính): báo NGAY điểm này có mấy món khớp loại nhưng sai giá-trị/giá.
            extra = ""
            if report_fn:
                try: extra = report_fn(spot) or ""
                except Exception: extra = ""
            log(head + (f" → {extra}" if extra else "") + f". [Tổng: {len(fresh)} sạp, +{new_stalls} mới]")
        # #2 DỪNG SỚM: đã đi ≥6 điểm mà 3 điểm LIÊN TIẾP +0 sạp mới = đã quét hết cụm quanh đây → khỏi đi nốt.
        if i >= 5 and dry >= 3:
            log(f"🧭 {dry} điểm liên tiếp KHÔNG có sạp mới → coi như hết khu, dừng sớm ở điểm {i+1}/{len(pts)}.")
            return fresh, mid, i + 1
    log(f"🧭 Đã rảo hết {len(pts)} điểm ở {tname}: tổng {len(fresh)} sạp — chưa thấy '{want}'.")
    return fresh, mid, len(pts)


MIN_LUONG = 100   # giá < ngần này (lượng) coi như bán KNB/đơn vị khác -> BỎ (chỉ mua bằng vạn)


def buyable_in_luong(it):
    """Chỉ mua đồ bán bằng VẠN/LƯỢNG. Bỏ đồ bán KNB (money_type != 0) hoặc giá quá thấp
    (price < MIN_LUONG -> dấu hiệu bán nguyên bảo, mua bằng vạn sẽ hụt)."""
    if it.get("money_type", 0) not in (0, None):
        return False
    pr = it.get("price", 0)
    return isinstance(pr, int) and pr >= MIN_LUONG


def find_in_stalls(catalog, spec, max_price=10_000_000):
    """Tìm món khớp spec rẻ nhất trong catalog (chỉ đồ bán bằng vạn). Trả (cid, itemIndex, price, item) hoặc None."""
    best = None
    for cid, items in (catalog or {}).items():
        for it in items:
            if not buyable_in_luong(it) or it["price"] > max_price:
                continue
            if item_matches_spec(it, spec):
                if best is None or it["price"] < best[2]:
                    best = (cid, it["itemIndex"], it["price"], it)
    return best


# ===== Khớp theo THUỘC TÍNH (magic) ở sạp =====
import os as _os
from core.money import fmt_money
MAGIC_MAP_PATH = "data/output/magic_id_map.json"


def load_magic_id_map():
    """Đọc map {attribId(int): tên_thuộc_tính} đã học. Rỗng nếu chưa học id nào."""
    import json
    try:
        with open(MAGIC_MAP_PATH, encoding="utf-8") as f:
            return {int(k): v for k, v in json.load(f).items()}
    except Exception:
        return {}


def decode_magic(magic_ints):
    """[value*1000+attribId, ...] -> [(attribId, value), ...]."""
    out = []
    for mi in magic_ints or []:
        try:
            out.append((mi % 1000, mi // 1000))
        except Exception:
            pass
    return out


def _norm_attr(s):
    import unicodedata
    s = (s or "").lower().strip().replace(" ", "_")
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def attr_name_match(attr_key, name):
    """Khớp tên thuộc tính: chuỗi con HOẶC đủ TẤT CẢ token (chịu đảo thứ tự + đuôi thừa).
    Vd 'hồi phục thể lực' khớp 'phục hồi thể lực mỗi nửa giây' (đảo 'hồi phục'/'phục hồi')."""
    want = _norm_attr(attr_key)
    have = _norm_attr(name or "")
    if not want or not have:
        return False
    if want in have:
        return True
    toks = [t for t in want.split("_") if t]
    return bool(toks) and all(t in have for t in toks)


def stall_item_attr_value(item, attr_key, id_map):
    """Giá trị lớn nhất của thuộc tính attr_key trên 1 món sạp (qua magic_id_map), hoặc None nếu
    món không mang id nào map ra attr_key (gồm cả trường hợp id chưa học)."""
    best = None
    for aid, val in decode_magic(item.get("magic")):
        name = id_map.get(aid)
        if name and attr_name_match(attr_key, name):
            best = val if best is None else max(best, val)
    return best


def find_in_stalls_by_attr(catalog, attr_key, min_value, id_map, max_price=10_000_000):
    """Tìm món sạp RẺ NHẤT có thuộc tính attr_key >= min_value. Trả (cid, itemIndex, price, item, value) hoặc None."""
    cands = find_all_in_stalls_by_attr(catalog, attr_key, min_value, id_map, max_price)
    return cands[0] if cands else None


def find_all_in_stalls_by_attr(catalog, attr_key, min_value, id_map, max_price=10_000_000, min_price=1):
    """DANH SÁCH món sạp có thuộc tính attr_key >= min_value, SẮP theo giá tăng dần.
    Mỗi phần tử: (cid, itemIndex, price, item, value). min_price: bỏ giá quá thấp (vd 1 = nghi tiền
    nguyên bảo/khác đơn vị, mua bằng vạn sẽ hụt) — mặc định bỏ giá < 1 thì giữ; chỉ lọc <=0."""
    out = []
    for cid, items in (catalog or {}).items():
        for it in items:
            pr = it.get("price", 0)
            if not buyable_in_luong(it) or pr > max_price or pr < min_price:
                continue   # chỉ đồ bán bằng vạn (bỏ KNB)
            v = stall_item_attr_value(it, attr_key, id_map)
            if v is not None and v >= min_value:
                out.append((cid, it.get("itemIndex"), pr, it, v))
    out.sort(key=lambda x: x[2])
    return out
