"""core/paths.py — Thư mục gốc dùng chung, chạy đúng cả khi ĐÓNG GÓI (PyInstaller .exe).

- Khi chạy code thường: BASE = thư mục gốc repo.
- Khi đóng gói (.exe, sys.frozen): BASE = thư mục chứa GSTAuto.exe (nơi đặt adb.exe, frida-server,
  thư mục data/, features/...). App sẽ os.chdir(BASE) lúc khởi động để mọi đường dẫn tương đối đúng.
"""
import os
import sys


def base_dir():
    if getattr(sys, "frozen", False):           # đang chạy trong .exe PyInstaller
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


BASE = base_dir()
