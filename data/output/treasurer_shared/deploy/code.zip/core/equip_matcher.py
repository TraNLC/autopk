"""
core/equip_matcher.py — Khớp nhiệm vụ Dã Tẩu "nộp trang bị theo thuộc tính".

Luồng: đọc text nhiệm vụ -> trích yêu cầu (thuộc tính + giá trị tối thiểu)
       -> quét danh sách item trong rương (dump từ frida_bot.dumpBagItems)
       -> trả về slot của trang bị khớp đầu tiên.

Thuộc tính trong game lưu dạng chuỗi có dấu + gạch dưới, vd:
  'kháng_băng_phần_trăm', 'kháng_hỏa_phần_trăm', 'sinh_lực_tối_đa', 'nội_lực_tối_đa'...
Text nhiệm vụ dùng khoảng trắng, vd "tăng kháng băng", nên ta chuẩn hoá space->'_' rồi so khớp chuỗi con.
"""
import re
import unicodedata


def _norm(s: str) -> str:
    """Chuẩn hoá: thường hoá, gộp khoảng trắng -> '_', bỏ dấu câu thừa. GIỮ dấu tiếng Việt."""
    if not s:
        return ""
    s = s.lower().strip()
    s = s.replace("%", " phần trăm ")
    # bỏ ký tự không phải chữ/số/khoảng trắng (giữ chữ có dấu)
    s = re.sub(r"[^\w\s]", " ", s, flags=re.UNICODE)
    s = re.sub(r"\s+", "_", s.strip())
    return s


# Bản đồ cụm từ nhiệm vụ -> khóa con khớp trong Attrib.type.
# Chỉ cần khóa con vì sẽ dùng substring match (vd 'kháng_băng' khớp 'kháng_băng_phần_trăm').
ATTR_ALIASES = {
    "kháng băng": "kháng_băng",
    "kháng hỏa": "kháng_hỏa",
    "kháng hoả": "kháng_hỏa",
    "kháng lôi": "kháng_lôi",
    "kháng độc": "kháng_độc",
    "kháng tất cả": "kháng_tất_cả",
    "sinh lực": "sinh_lực",
    "nội lực": "nội_lực",
    "thể lực": "thể_lực",
    "thân pháp": "thân_pháp",
    "độ chính xác": "độ_chính_xác",
    "né tránh": "né_tránh",
    "phản đòn": "phản_đòn",
}


def parse_equip_requirement(quest_text: str):
    """Từ text nhiệm vụ -> {'attr_key': <chuỗi con khớp>, 'min_value': int, 'phrase': <cụm gốc>} hoặc None.

    Ví dụ: "...thuộc tính tăng kháng băng, nhỏ nhất 1 điểm, xem xong ta sẽ trả lại ngươi"
        -> {'attr_key': 'kháng_băng', 'min_value': 1, 'phrase': 'kháng băng'}
    """
    if not quest_text:
        return None
    text = quest_text.lower()

    # 1. Giá trị tối thiểu: "nhỏ nhất N", "tối thiểu N", hoặc "N điểm"
    min_value = 1
    m = re.search(r"(?:nhỏ nhất|tối thiểu|ít nhất)\s*(\d+)", text)
    if not m:
        m = re.search(r"(\d+)\s*điểm", text)
    if m:
        try:
            min_value = int(m.group(1))
        except ValueError:
            min_value = 1

    # 2. Cụm thuộc tính: lấy đoạn sau "thuộc tính" (và bỏ "tăng"/"thêm") tới dấu phẩy/chấm.
    phrase = ""
    mt = re.search(r"thuộc tính\s+(.+?)\s*(?:,|\.|;|$)", text)
    if mt:
        phrase = mt.group(1)
        # Bỏ TỪ CHỈ HƯỚNG (tăng/giảm...) vì tên thuộc tính trong game là TRUNG TÍNH
        # ("thời_gian_choáng_phần_trăm", "kháng_băng_phần_trăm") — chiều tăng/giảm nằm ở GIÁ TRỊ.
        # Vd "giảm thời gian choáng" -> "thời gian choáng" (khớp id88 'thời_gian_choáng_phần_trăm').
        phrase = re.sub(r"\b(tăng|thêm|cộng|về|giảm|thiểu|rút|ngắn)\b", " ", phrase).strip()
        phrase = re.sub(r"\s+", " ", phrase)

    # 3. Suy ra attr_key:
    #    - CÓ cụm sau "thuộc tính" -> dùng NGUYÊN cụm (chính xác: "hồi phục thể lực" KHÁC "thể lực"/"tăng thể lực").
    #    - KHÔNG có cụm -> dò alias trong toàn text.
    attr_key = ""
    if phrase:
        attr_key = _norm(phrase)        # giữ đủ "hồi_phục_thể_lực", không rút gọn về "thể_lực"
    else:
        for alias, key in ATTR_ALIASES.items():
            if alias in text:
                attr_key = key
                break

    if not attr_key:
        return None
    return {"attr_key": attr_key, "min_value": min_value, "phrase": phrase or attr_key}


def item_matches(item: dict, attr_key: str, min_value: int) -> bool:
    """item: dict {slot, genre, detail, attribs:[{type, value:[...]}]}. Khớp nếu có attrib
    type chứa attr_key và giá trị (max trong value[]) >= min_value."""
    # Khớp khi attr_key là chuỗi con, HOẶC đủ TẤT CẢ token (chịu đảo thứ tự: 'hồi phục' ~ 'phục hồi').
    # Token-subset đòi đủ {hồi,phục,thể,lực} -> món 'tăng thể lực' (thiếu hồi/phục) KHÔNG khớp.
    key_tokens = [tok for tok in (attr_key or "").split("_") if tok]
    for a in item.get("attribs", []) or []:
        t = _norm(a.get("type", ""))
        if not attr_key:
            continue
        if (attr_key in t) or (key_tokens and all(tok in t for tok in key_tokens)):
            vals = a.get("value") or []
            v = max(vals) if vals else 0
            if v >= min_value:
                return True
    return False


# location: 1=đang mặc (equip), 2=hành trang (bagarate), 3=kho. Chỉ nộp được đồ trong HÀNH TRANG.
LOC_BAGARATE = 2


LOC_EQUIP = 1


def find_matching_slot(bag_items, attr_key: str, min_value: int, bag_only: bool = True,
                       allow_equipped: bool = False, allow_gold: bool = False):
    """Trả về (slot, item) của trang bị khớp, hoặc (-1, None).

    AN TOÀN ĐỒ QUÝ (user chốt 2026-06-17, sửa 2026-06-18):
    - NV 'xem xong TRẢ LẠI' (allow_gold=allow_equipped=True): giao đồ HOÀNG KIM + đồ ĐANG MẶC ĐỀU ĐƯỢC
      (server trả lại sau khi xem). NV KHÔNG trả lại (mặc định False): KHÔNG giao hoàng kim/đồ mặc (mất luôn).
    - Dù được phép, vẫn ƯU TIÊN: đồ TÚI thường (loc2, không hoàng kim) trước; chỉ dùng hoàng kim/đồ-mặc khi
      KHÔNG có món thường khớp → giảm rủi ro lỡ mất đồ quý.
    """
    # BẢO VỆ HOÀNG KIM (tái bật 2026-06-19 — isGold tin cậy: check nội dung goldequip). FAIL-SAFE chống tái phát:
    # hoàng kim CHỈ là genre 0; nếu món genre≠0 bị flag gold = isGold hỏng → BỎ loại-trừ (đừng loại sạch = chết auto).
    gold_protect = not any(it.get("isGold") and it.get("genre") != 0 for it in (bag_items or []))
    cand = []
    for it in bag_items or []:
        loc = it.get("location")
        if gold_protect and it.get("isGold") and not allow_gold:   # hoàng kim: chỉ giao khi NV trả-lại
            continue
        allowed_locs = (None, LOC_BAGARATE) + ((LOC_EQUIP,) if allow_equipped else ())
        if loc not in allowed_locs:                # bỏ kho (3), đồ đang mặc (1, trừ khi cho phép), vị trí lạ
            continue
        if item_matches(it, attr_key, min_value) and isinstance(it.get("slot"), int):
            cand.append(it)
    if not cand:
        return -1, None
    # sort ưu tiên: đồ TÚI (loc2) trước MẶC (loc1); đồ THƯỜNG trước HOÀNG KIM; rồi thuộc tính cao.
    cand.sort(key=lambda it: (0 if it.get("location") == LOC_BAGARATE else 1,
                              1 if it.get("isGold") else 0,
                              -_best_attr_value(it, attr_key)))
    best = cand[0]
    return best.get("slot"), best


def _best_attr_value(item: dict, attr_key: str) -> int:
    m = 0
    for a in item.get("attribs", []) or []:
        if attr_key in _norm(a.get("type", "")):
            vals = a.get("value") or []
            if vals:
                m = max(m, max(vals))
    return m


# Thuộc tính Dã Tẩu "xem xong trả lại" HAY HỎI — giữ 1 món/mỗi loại trong kho (dư thì bán).
# 5 loại user nêu + các loại trong ATTR_ALIASES. Khớp SUBSTRING trên attrib type đã chuẩn-hoá.
# (vd 'thời_gian_trúng_độc' khớp 'thời_gian_trúng_độc_phần_trăm').
# ⚠️ user chốt 2026-06-13: "đóng băng" = THỜI GIAN LÀM CHẬM (thời_gian_làm_chậm, KHÔNG phải 'đóng_băng');
# SINH KHÍ ≠ SINH LỰC (2 thuộc tính RIÊNG, giữ cả hai).
DA_TAU_ATTR_KEYS = [
    "thời_gian_trúng_độc", "thời_gian_làm_chậm", "sức_mạnh", "sinh_khí", "thân_pháp",
    "kháng_băng", "kháng_hỏa", "kháng_lôi", "kháng_độc",
    "sinh_lực", "nội_lực", "thể_lực", "độ_chính_xác", "né_tránh", "phản_đòn",
]


def matched_attr_keys(item: dict, keys=None) -> set:
    """Trả SET các key (trong DA_TAU_ATTR_KEYS) mà item CÓ (khớp substring trên attrib type chuẩn-hoá)."""
    keys = keys if keys is not None else DA_TAU_ATTR_KEYS
    out = set()
    for a in (item.get("attribs") or []):
        t = _norm(a.get("type", ""))
        if not t:
            continue
        for k in keys:
            if k in t:
                out.add(k)
    return out


# ===================== CHỌN PHẦN THƯỞNG (eAwardSelectionAsk 245) =====================

# Đồ giá trị ưu tiên số 1 (có thể bổ sung). So khớp substring (đã thường hoá).
REWARD_VALUABLE = [
    "võ lâm mật tịch", "mật tịch", "tẩy tủy kinh", "tẩy tuỷ kinh", "thiết la hán",
    "thủy tinh", "thuỷ tinh", "tinh hồng bảo thạch", "bảo thạch", "huyền tinh",
    "kim cương", "bí kíp", "mảnh", "trân", "vô danh", "ngũ hành ấn",
]
REWARD_MONEY = ["ngân lượng", "tiền vạn", "vạn", "bạc"]
REWARD_RANDOM = ["ngẫu nhiên", "random", "tất cả phần thưởng"]
REWARD_EXP = ["kinh nghiệm", "exp", "điểm kinh"]
# Ưu tiên THẤP NHẤT (gần như không chọn trừ khi là lựa chọn duy nhất): hoàn Tống Kim...
REWARD_LOWEST = ["tống kim", "tổng kim"]


def _reward_score(label: str) -> int:
    t = (label or "").lower()
    if any(k in t for k in REWARD_LOWEST):
        return 5     # Tống Kim -> thấp nhất (dưới cả kinh nghiệm)
    if any(k in t for k in REWARD_VALUABLE):
        return 100   # đồ giá trị
    if any(k in t for k in REWARD_MONEY):
        return 80    # tiền vạn
    if any(k in t for k in REWARD_RANDOM):
        return 40    # ngẫu nhiên
    if any(k in t for k in REWARD_EXP):
        return 20    # kinh nghiệm (fallback)
    return 60        # đồ khác không phân loại: trên random, dưới tiền


def pick_reward_index(options, priority_names=None) -> int:
    """Chọn index phần thưởng.
    - Nếu có `priority_names` (list TÊN người chơi xếp, trên=cao): chọn option khớp tên có HẠNG cao nhất.
      Option không nằm trong list -> hạng thấp hơn mọi option có trong list (rồi mới dùng score mặc định).
    - Không có priority: dùng score mặc định (đồ giá trị > tiền > đồ khác > random > kinh nghiệm)."""
    if not options:
        return -1

    def _norm(s):
        return (s or "").strip().lower()

    # ƯU TIÊN TUYỆT ĐỐI (hardcode, trên MỌI cấu hình + priority người chơi): "Tiên Thảo Lộ Đặc Biệt" — phần
    # thưởng HIẾM, CHƯA từng xuất hiện nên KHÔNG có trong danh sách ưu tiên; nếu lỡ ra PHẢI chọn ngay kẻo miss.
    FORCE_TOP = ("tiên thảo lộ đặc biệt",)
    for i, opt in enumerate(options):
        o = _norm(opt)
        if any(k in o for k in FORCE_TOP):
            return i

    if priority_names:
        rank = {}
        for i, nm in enumerate(priority_names):
            rank.setdefault(_norm(nm), i)
        best, best_key = -1, None
        for i, opt in enumerate(options):
            o = _norm(opt)
            r = rank.get(o)
            if r is None:   # khớp lỏng: tên ưu tiên là chuỗi con của option hoặc ngược lại
                for nm, ri in rank.items():
                    if nm and (nm in o or o in nm):
                        r = ri; break
            # key: (đã-xếp? , hạng ưu tiên, -score mặc định) — nhỏ hơn = tốt hơn
            key = (0, r, -_reward_score(opt)) if r is not None else (1, 0, -_reward_score(opt))
            if best_key is None or key < best_key:
                best_key, best = key, i
        return best

    best, best_score = -1, -1
    for i, opt in enumerate(options):
        s = _reward_score(opt)
        if s > best_score:
            best_score, best = s, i
    return best


def split_frames(hx):
    """Tách 1 buffer recv (có thể DÍNH nhiều gói) thành từng frame [len4 LE][op2 LE][body].
    Trả list (opcode:int, frame_hex:str) — frame_hex GỒM cả header 6 byte.
    Lý do: server hay gộp eQuestInfo(124) + eAwardSelectionAsk(245) trong 1 lần recv;
    nếu chỉ đọc opcode đầu sẽ bỏ sót bảng thưởng 245."""
    if not hx:
        return []
    try:
        b = bytes.fromhex(hx)
    except Exception:
        return []
    out, pos = [], 0
    while pos + 6 <= len(b):
        ln = int.from_bytes(b[pos:pos + 4], "little")
        op = int.from_bytes(b[pos + 4:pos + 6], "little")
        end = pos + 6 + ln
        if ln < 0 or end > len(b):
            break
        out.append((op, b[pos:end].hex()))
        pos = end
    return out


def parse_award_ask(body: bytes):
    """Parse body gói eAwardSelectionAsk (opcode 245).
    field1=id(int), field2=description(string, các lựa chọn tách bằng '\\n', dòng đầu là lời dẫn).
    Trả {'id':int, 'prompt':str, 'options':[str,...]}."""
    def _vi(d, o):
        r = 0; s = 0
        while o < len(d):
            x = d[o]; o += 1; r |= (x & 0x7F) << s
            if not x & 0x80:
                break
            s += 7
        return r, o

    aid, desc = 0, ""
    o = 0
    while o < len(body):
        try:
            tag, o = _vi(body, o)
        except Exception:
            break
        f, w = tag >> 3, tag & 7
        if w == 0:
            v, o = _vi(body, o)
            if f == 1:
                aid = v
        elif w == 2:
            ln, o = _vi(body, o)
            raw = body[o:o + ln]; o += ln
            if f == 2:
                try:
                    desc = raw.decode("utf-8")
                except Exception:
                    desc = ""
        elif w == 1:
            o += 8
        elif w == 5:
            o += 4
        else:
            break

    clean = re.sub(r"<[^>]+>", "", desc)
    lines = [l.strip() for l in clean.split("\n") if l.strip()]
    options = lines[1:] if len(lines) > 1 else []
    return {"id": aid, "prompt": lines[0] if lines else "", "options": options}


def quest_returns_item(quest_text: str) -> bool:
    """NV có TRẢ LẠI đồ sau khi xem không? ('xem xong'/'trả lại'/'ta sẽ trả' = trả lại → đồ đang mặc dùng tạm OK).
    Không chắc → coi như KHÔNG trả (an toàn: chỉ dùng đồ trong túi)."""
    t = _norm(quest_text or "")        # _norm GIỮ dấu tiếng Việt -> token phải có dấu
    return ("trả_lại" in t) or ("xem_xong" in t) or ("sẽ_trả" in t) or ("hoàn_trả" in t)


def find_slot_for_quest(quest_text: str, bag_items, allow_equipped=None):
    """Tiện ích: parse yêu cầu rồi tìm slot. Trả về dict kết quả để log rõ ràng.
    NV 'xem xong TRẢ LẠI' → cho phép giao CẢ đồ đang mặc LẪN Hoàng Kim (server trả lại). NV không-trả-lại →
    chỉ đồ thường trong túi (giữ an toàn). allow_equipped truyền tay thì ưu tiên giá trị đó cho đồ-mặc."""
    req = parse_equip_requirement(quest_text)
    if not req:
        return {"ok": False, "reason": "Không trích được yêu cầu thuộc tính từ nhiệm vụ", "req": None}
    returns = quest_returns_item(quest_text)
    if allow_equipped is None:
        allow_equipped = returns
    slot, item = find_matching_slot(bag_items, req["attr_key"], req["min_value"],
                                    allow_equipped=allow_equipped, allow_gold=returns)
    if slot is None or slot < 0:
        return {"ok": False, "reason": f"Không tìm thấy trang bị có '{req['phrase']}' >= {req['min_value']}", "req": req}
    return {"ok": True, "slot": slot, "item": item, "req": req}
