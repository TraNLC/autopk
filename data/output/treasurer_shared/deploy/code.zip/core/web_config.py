# -*- coding: utf-8 -*-
"""core/web_config.py — REGISTRY config cho WEB UI: đọc/ghi an toàn các file cấu hình (whitelist).

Web sửa option/config cho cả dàn máy. Cơ chế:
  • scope 'shared'  : file nằm trong treasurer_shared (Syncthing) → WEB ghi THẲNG, mọi máy đọc.
  • scope 'machine' : file LOCAL mỗi máy → web ĐẨY lệnh set_config tới agent máy đó (agent ghi file của nó).
  • sensitive=True  : chứa BÍ MẬT (mật khẩu/cookies) → KHÔNG publish nội dung ra status (tránh rò qua Syncthing);
                      web chỉ GHI (write-only), không đọc-về-qua-shared.

Chỉ name trong REGISTRY mới ghi được (chống path traversal / ghi file bậy)."""
import os
import json
import tempfile

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# name -> {path (tương đối _ROOT), scope, label, sensitive}
REGISTRY = {
    "quest_actions": {"path": "data/output/quest_actions.json",      "scope": "machine", "label": "Loại NV → Hành động", "sensitive": False},
    "potion_buy":    {"path": "data/output/potion_buy_config.json",  "scope": "machine", "label": "Mua thuốc",          "sensitive": False},
    "buff":          {"path": "data/output/buff_config.json",        "scope": "machine", "label": "Buff Tân Thủ",       "sensitive": False},
    "loot":          {"path": "data/output/loot_config.json",        "scope": "machine", "label": "Nhặt/bán đồ",        "sensitive": False},
    "recall":        {"path": "data/output/recall_config.json",      "scope": "machine", "label": "Phù về thành",       "sensitive": False},
    "device_labels": {"path": "data/output/device_labels.json",      "scope": "machine", "label": "Tên cửa sổ",         "sensitive": False},
    "treasurer":     {"path": "data/output/treasurer_shared/treasurer_config.json", "scope": "shared", "label": "Thủ quỹ (chung cả dàn)", "sensitive": False},
    # NHẠY CẢM — chỉ GHI từ web, KHÔNG publish nội dung (mật khẩu/cookies):
    "account_queue": {"path": "data/output/account_queue.json",      "scope": "machine", "label": "Danh sách tài khoản (mật khẩu)", "sensitive": True},
    "notify":        {"path": "data/output/notify_config.json",      "scope": "machine", "label": "Thông báo Zalo (cookies)",       "sensitive": True},
}


def _abs(name):
    e = REGISTRY.get(name)
    return os.path.join(_ROOT, e["path"]) if e else None


def list_configs():
    """Danh sách config cho web (KHÔNG kèm nội dung)."""
    return {k: {"label": v["label"], "scope": v["scope"], "sensitive": v["sensitive"]} for k, v in REGISTRY.items()}


def read_config(name):
    """Đọc 1 config (dict/list). None nếu name lạ / lỗi. (Web dùng cho scope shared; agent dùng cho snapshot.)"""
    if name not in REGISTRY:
        return None
    p = _abs(name)
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def write_config(name, content):
    """Ghi 1 config (atomic). CHỈ name trong REGISTRY. content = dict/list (JSON-serializable). Trả True/False."""
    if name not in REGISTRY:
        return False
    p = _abs(name)
    try:
        d = os.path.dirname(p) or "."
        os.makedirs(d, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(content, f, ensure_ascii=False, indent=2)
        os.replace(tmp, p)
        return True
    except Exception:
        try: os.remove(tmp)
        except Exception: pass
        return False


def snapshot_machine_configs():
    """{name: content} cho agent PUBLISH — CHỈ scope 'machine' + KHÔNG sensitive (tránh rò mật khẩu/cookies
    qua status.json synced). Web đọc cái này để hiện form sửa config per-máy."""
    out = {}
    for name, e in REGISTRY.items():
        if e["scope"] == "machine" and not e["sensitive"]:
            c = read_config(name)
            if c is not None:
                out[name] = c
    return out
