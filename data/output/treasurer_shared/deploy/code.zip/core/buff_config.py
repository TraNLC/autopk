# -*- coding: utf-8 -*-
"""core/buff_config.py — Cờ "nhận buff Tân Thủ từ xa".

BẬT (tick ở tab Dã tẩu / Luyện công): nhân vật <cấp 79 sẽ remote-call Lễ Quan cùng vùng nhận buff
"Hồi phục Tân Thủ" NGAY + lặp lại mỗi 1 giờ. Nhân vật >=79: bot tự bỏ qua (không làm gì).
Toàn cục (mọi cửa sổ dùng chung cờ; level-gate tự lọc char cao cấp).
"""
import json
import os

_PATH = "data/output/buff_config.json"


def is_enabled() -> bool:
    try:
        return bool(json.load(open(_PATH, encoding="utf-8")).get("remote_buff", False))
    except Exception:
        return False


def set_enabled(on: bool):
    try:
        os.makedirs(os.path.dirname(_PATH), exist_ok=True)
        json.dump({"remote_buff": bool(on)}, open(_PATH, "w", encoding="utf-8"),
                  ensure_ascii=False, indent=2)
    except Exception:
        pass
