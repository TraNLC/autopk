"""
core/quest_actions.py — Phân loại nhiệm vụ Dã Tẩu + cấu hình hành động theo NHÓM.

Người dùng gộp NV thành 3 NHÓM (cấu hình 1 hành động / nhóm):
    mua_trang_bi   : Mua đồ NPC + Tìm trang bị cụ thể + Nộp trang bị theo thuộc tính
    do_chi_combat  : Mật chí / đồ chí + Đánh quái (tiêu diệt)
    do_hiem        : Đồ hiếm (Hoàng Kim/Phúc Duyên) + Nâng cấp (danh vọng/may mắn/sức mạnh) + nộp điểm
    (Giao thư / đưa đồ: hiện KHÔNG có loại NV này -> bỏ.)

Mỗi nhóm chọn 1 trong 4 hành động:
    auto        : Bot tự làm theo flow tương ứng từng NV con
    huy_do_chi  : Hủy bằng 100 tấm đồ chí (gửi gói hủy đặc biệt)
    huy         : Hủy thường
    tu_lam      : Bỏ qua, bot đứng chờ người chơi tự làm

Bên trong, classify_quest vẫn trả NV CON (buy/find_equip/...) để state machine
điều hướng đúng handler; GROUP_OF map NV con -> nhóm để tra cấu hình.

Cấu hình lưu data/output/quest_actions.json: { "<group_key>": "<action_key>", ... }
"""
import os
import json

CONFIG_PATH = "data/output/quest_actions.json"

# (key nhóm, nhãn) — thứ tự hiển thị trên UI. UI cấu hình theo NHÓM này.
QUEST_TYPES = [
    ("mua_npc",        "Mua đồ ở NPC"),
    ("tim_do",         "Tìm đồ"),
    ("do_chi_combat",  "Mật chí Đồ chí"),
    ("tongkim_points", "Tích luỹ TK"),
    ("nang_thuoc_tinh", "Nâng điểm thuộc tính"),
    ("do_hiem",        "Đồ hiếm"),
]
GROUP_KEYS = {g for g, _ in QUEST_TYPES}

# Map NV CON (classify_quest trả) -> NHÓM cấu hình.
GROUP_OF = {
    "buy":           "mua_npc",     # mua tạp hóa/thợ rèn thành-thôn (remote theo shop_index)
    "find_equip":    "tim_do",      # tìm trang bị cụ thể (NPC shop / sạp người chơi)
    "submit_equip":  "tim_do",      # nộp trang bị theo thuộc tính
    "find_item":     "do_chi_combat",
    "combat":        "do_chi_combat",
    "rare":          "do_hiem",
    "submit_points": "do_hiem",
    "tongkim_points": "tongkim_points",   # nhóm RIÊNG (tách khỏi đồ hiếm) — dùng Phiếu Tích Lũy Tống Kim
    "nang_attr":      "nang_thuoc_tinh",  # nhóm RIÊNG — auto cộng điểm tiềm năng (eAddPropField) rồi trả NV
}

ACTIONS = [
    ("auto",        "Auto làm"),
    ("dung_riu",    "Dùng rìu hoàn thành nhanh"),
    ("huy_do_chi",  "Hủy 100 tấm đồ chí"),
    ("huy",         "Hủy"),
    ("tu_lam",      "Tự làm"),
]
ACTION_KEYS = {a for a, _ in ACTIONS}

# Mặc định: mua NPC + tìm đồ -> tự làm; đồ chí/đánh quái -> hủy 100 tấm; đồ hiếm/nâng cấp -> hủy.
DEFAULTS = {
    "mua_npc":        "auto",
    "tim_do":         "auto",
    "do_chi_combat":  "huy_do_chi",
    "tongkim_points": "auto",     # mặc định TỰ LÀM = dùng phiếu (lấy túi/thủ quỹ) rồi trả NV
    "nang_thuoc_tinh": "auto",    # mặc định AUTO = tự cộng (+M) điểm tiềm năng vào đúng stat rồi trả NV
    "do_hiem":        "huy",
}


def load_config():
    """Đọc cấu hình hành động/nhóm; thiếu key nào lấy DEFAULTS."""
    cfg = dict(DEFAULTS)
    try:
        if os.path.exists(CONFIG_PATH):
            data = json.load(open(CONFIG_PATH, encoding="utf-8"))
            for k, v in (data or {}).items():
                if k in DEFAULTS and v in ACTION_KEYS:
                    cfg[k] = v
    except Exception:
        pass
    return cfg


def save_config(cfg):
    try:
        os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
        clean = {k: v for k, v in cfg.items() if k in DEFAULTS and v in ACTION_KEYS}
        json.dump(clean, open(CONFIG_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False


def get_action(type_key, cfg=None):
    """type_key có thể là NV con hoặc key nhóm; quy về nhóm rồi tra cấu hình."""
    cfg = cfg or load_config()
    group = GROUP_OF.get(type_key, type_key)
    return cfg.get(group, DEFAULTS.get(group, "auto"))


def classify_quest(quest):
    """Suy ra NV CON (1 trong GROUP_OF key) từ nội dung quest.
    Bám sát routing trong da_tau_state_machine._handle_evaluate để 'auto' chạy y như cũ."""
    if quest is None:
        return "find_equip"
    name = (getattr(quest, "item_name", "") or "").lower()
    text = (getattr(quest, "clean_text", "") or getattr(quest, "raw_text", "") or name).lower()

    # NHÓM MUA / TÌM TRANG BỊ — TÌM TRANG BỊ THEO THUỘC TÍNH (ưu tiên CAO NHẤT):
    # "tìm món TRANG BỊ có THUỘC TÍNH <x>, ... xem xong/trả lại" = đồ THƯỜNG, BẤT KỂ thuộc tính
    # là gì (kể cả 'tăng sức mạnh'). Phải xét TRƯỚC nhánh đồ-hiếm/nâng-chỉ-số để không hủy nhầm.
    # (Đồ hiếm thật = "tăng sức mạnh cho BẢN THÂN", KHÔNG nhắc tới 'trang bị'.)
    if ("trả lại" in text or "xem xong" in text or "trang bị" in text) and \
       ("trang bị" in text or "thuộc tính" in text or "kháng" in text):
        return "submit_equip"

    # NÂNG ĐIỂM TÍCH LUỸ TỐNG KIM: hoàn thành bằng cách DÙNG "Phiếu Tích Lũy Tống Kim" (g6/d1/p89, +3500đ/cái)
    # -> tách RIÊNG (xét TRƯỚC nhóm submit_points để không bị gộp + hủy oan). Bot tự làm: lấy phiếu (túi/thủ quỹ)
    # -> dùng 1 phiếu -> trả NV.
    if ("tích lũy" in text or "tích luỹ" in text) and ("tống kim" in text or "tong kim" in text):
        return "tongkim_points"

    # NÂNG ĐIỂM THUỘC TÍNH: "Hãy nâng cấp điểm <sức mạnh/sinh khí/nội công/thân pháp> ... lên ít nhất N điểm(+M)"
    # -> bot tự cộng điểm tiềm năng (eAddPropField) rồi trả NV. Tách RIÊNG (xét TRƯỚC submit_points để không bị
    # gộp vào 'đồ hiếm' + hủy oan).
    if "nâng cấp điểm" in text and "ít nhất" in text and \
            any(s in text for s in ["sức mạnh", "thân pháp", "sinh khí", "nội công"]):
        return "nang_attr"

    # NHÓM ĐỒ HIẾM / NÂNG CẤP: hoàng kim, phúc duyên, danh vọng, may mắn, nâng cấp chỉ số BẢN THÂN.
    if any(k in name or k in text for k in ["hoàng kim", "phúc duyên", "danh vọng", "may mắn"]):
        return "rare"
    # Nâng cấp chỉ số bản thân (sức mạnh/thân pháp/sinh khí/...) -> đồ hiếm/nâng cấp.
    if ("điểm" in text or "nâng cấp" in text or "nâng" in text) and any(k in text for k in
            ["nộp", "tích lũy", "nâng cấp", "nâng", "sức mạnh", "thân pháp",
             "sinh khí", "nội công", "ngoại công", "tiềm năng", "thể chất"]):
        return "submit_points"

    # NHÓM ĐỒ CHÍ / ĐÁNH QUÁI.
    if any(k in text for k in ["mật chỉ", "mật chí", "đồ chỉ", "đồ chí",
                                "thần bí", "phục ma", "bản đồ", "lệnh bài", "trục cuốn"]):
        return "find_item"
    if any(k in text for k in ["tiêu diệt", "đánh bại", "hạ gục", "quái"]):
        return "combat"

    # MUA SHOP NPC: quest nêu thành/thôn hoặc loại shop -> remote-buy.
    try:
        from core import npc_shop
        if npc_shop.is_npc_shop_quest(text, name):
            return "buy"
    except Exception:
        if any(k in text for k in ["thợ rèn", "tạp hóa", "tạp hoá", "dược điếm", "hiệu thuốc"]):
            return "buy"
    # Mặc định: tìm trang bị cụ thể (quét rương/sạp).
    return "find_equip"


def type_label(type_key):
    """Nhãn NHÓM (nhận NV con hoặc key nhóm)."""
    group = GROUP_OF.get(type_key, type_key)
    return dict(QUEST_TYPES).get(group, group)


def display_label(type_key, quest=None):
    """Nhãn HIỂN THỊ (UI) TINH hơn type_label: tách Tìm Đồ Chí / Tìm Mật Chí / Mua đồ NPC / Tìm đồ
    dựa nội dung quest (find_item/combat dùng chung 1 type cho cả đồ chí lẫn mật chí)."""
    t = ""
    try:
        t = (getattr(quest, "clean_text", "") or getattr(quest, "raw_text", "")
             or getattr(quest, "item_name", "") or "").lower()
    except Exception:
        t = ""
    if type_key in ("find_item", "combat", "do_chi_combat"):
        # PHÂN BIỆT theo chữ "mật/đồ", KHÔNG dùng "thần bí" (cả 2 đều có: "Thần bí ĐỒ chí" vs "Thần bí MẬT chí").
        if "mật chí" in t or "mật chỉ" in t:
            return "Tìm Mật Chí"
        if "đồ chí" in t or "đồ chỉ" in t:
            return "Tìm Đồ Chí"
        return "Đánh quái" if type_key == "combat" else "Đồ chí / Mật chí"
    if type_key in ("buy", "mua_npc"):
        return "Mua đồ NPC"
    if type_key in ("submit_equip", "find_equip", "tim_do"):
        return "Tìm đồ"
    if type_key == "rare":
        return "Đồ hiếm"
    if type_key in ("nang_attr", "submit_points", "nang_thuoc_tinh"):
        return "Nâng thuộc tính"
    if type_key == "tongkim_points":
        return "Tích luỹ Tống Kim"
    return type_label(type_key)


def action_label(action_key):
    return dict(ACTIONS).get(action_key, action_key)
