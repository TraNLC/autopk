"""
core/tracker.py — Ghi MỌI sự kiện Dã Tẩu + vật phẩm nhận ra file log theo NGÀY (JSONL).

Triết lý: bot GHI event ra đĩa; UI ĐỌC LẠI từ đĩa (không bắt thông tin trực tiếp từ game).
=> dữ liệu không mất khi tắt app, xem lại được theo từng ngày.

Cấu trúc file: data/output/tracking/<YYYY-MM-DD>.jsonl
Mỗi dòng 1 record JSON:
    {"ts": "2026-06-06 14:03:21", "device": "<id>", "type": "<loại>", ...payload}

Các loại (type):
    log              msg                         — mọi dòng _chat/thông báo
    quest_received   qno,item,text,remaining     — vừa nhận 1 nhiệm vụ
    quest_completed  qno                          — vừa hoàn thành 1 nhiệm vụ
    reward           qno,options,chosen_idx,chosen — bảng chọn thưởng Dã Tẩu
    item_received    name,source,slot,price       — nhận/được 1 vật phẩm (thưởng/mua/tìm)
"""
import os
import json
import time
import threading
from datetime import datetime

TRACK_DIR = "data/output/tracking"
_lock = threading.Lock()


def today():
    return datetime.now().strftime("%Y-%m-%d")


def day_file(day=None):
    return os.path.join(TRACK_DIR, f"{day or today()}.jsonl")


def record(device_id, etype, **data):
    """Ghi 1 event vào file của NGÀY HÔM NAY (thread-safe, không bao giờ raise)."""
    rec = {"ts": time.strftime("%Y-%m-%d %H:%M:%S"),
           "device": device_id or "SYSTEM", "type": etype}
    rec.update(data)
    try:
        with _lock:
            os.makedirs(TRACK_DIR, exist_ok=True)
            with open(day_file(), "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass
    return rec


def list_days():
    """Danh sách ngày có dữ liệu (mới nhất trước)."""
    try:
        days = [f[:-6] for f in os.listdir(TRACK_DIR) if f.endswith(".jsonl")]
        return sorted(days, reverse=True)
    except Exception:
        return []


def load_day(day=None):
    """Đọc toàn bộ record của 1 ngày -> list[dict] (giữ thứ tự ghi)."""
    recs = []
    fp = day_file(day)
    if not os.path.exists(fp):
        return recs
    try:
        with open(fp, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    recs.append(json.loads(line))
                except Exception:
                    pass
    except Exception:
        pass
    return recs


def devices_in_day(day=None):
    """Các device có dữ liệu trong ngày (bỏ SYSTEM)."""
    out = []
    for r in load_day(day):
        d = r.get("device")
        if d and d != "SYSTEM" and d not in out:
            out.append(d)
    return out
