# -*- coding: utf-8 -*-
"""core/map_region.py — Gom map theo VÙNG (đại lục) từ maplist.json + tra node Dã Tẩu của vùng.

Phát hiện sống (2026-06-12): remote NPC-call (talk_npc) hoạt động trong TOÀN VÙNG — gọi NPC của vùng từ
BẤT KỲ map nào trong vùng (kể cả động) đều được; khác vùng thì fail. "Vùng" = nhóm map cùng PREFIX path
(folder đầu) trong maplist.json.

→ Từ 1 động, muốn mở Dã Tẩu NHANH: dùng node Dã Tẩu của THÀNH cùng vùng (gọi 1 phát trúng), thay vì duyệt
mù qua node các thành vùng khác (mỗi node sai timeout ~3s).
"""
import os
import json

_MAPLIST = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "data", "output", "json", "maplist.json")

# Thành -> node Dã Tẩu (VERIFIED — datau_town_nodes note). mapId thành: 1 PT, 11 Thành Đô, 37 Biện Kinh,
# 78 Tương Dương, 80 Dương Châu. (Thêm thành khác khi học/verify được node của nó.)
_TOWN_NODE = {1: "588", 11: "1049", 37: "1723", 78: "1425", 80: "1192"}

_region_of = None     # {mapId(int): region_prefix(str)}
_region_node = None    # {region_prefix: node}


def _load():
    global _region_of, _region_node
    if _region_of is not None:
        return
    _region_of, _region_node = {}, {}
    try:
        data = json.load(open(_MAPLIST, encoding="utf-8"))
        for m in (data if isinstance(data, list) else []):
            mid = m.get("id")
            if mid is None:
                continue
            _region_of[int(mid)] = (m.get("path", "") or "").split("\\")[0]
        # Gom node theo vùng. ⚠️ maplist-prefix CÓ THỂ gộp 2 thành KHÁC call-region (vd Tương Dương 78 +
        # Dương Châu 80 cùng prefix nhưng call-region khác: từ vùng TĐ gọi node DC FAIL). → vùng nào có >1
        # anchor cho ra node KHÁC NHAU = NHẬP NHẰNG → BỎ (None) để rơi về tự-học per-map (an toàn, không hint sai).
        reg_nodes = {}
        for town_mid, node in _TOWN_NODE.items():
            reg = _region_of.get(town_mid)
            if reg:
                reg_nodes.setdefault(reg, set()).add(node)
        _region_node = {reg: next(iter(nodes)) for reg, nodes in reg_nodes.items() if len(nodes) == 1}
    except Exception:
        pass


def region_of(map_id):
    """Prefix vùng của map_id (str) hoặc None."""
    try:
        _load()
        return _region_of.get(int(map_id))
    except Exception:
        return None


def datau_node_for_map(map_id):
    """Node Dã Tẩu của THÀNH cùng VÙNG với map_id — gọi 1 phát trúng từ động trong vùng.
    None nếu vùng chưa biết node thành (rơi về duyệt list như cũ)."""
    try:
        _load()
        return _region_node.get(_region_of.get(int(map_id)))
    except Exception:
        return None


# ---------------- RESOLVER CHUNG: map -> THÀNH -> npc của TỪNG loại (dã tẩu / xa phu / lễ quan) ----------------
# datau-node (đã học per-map, định danh THÀNH duy nhất) -> mapId THÀNH.
_DATAU_NODE_TO_TOWN = {"588": 1, "1049": 11, "1723": 37, "1425": 78, "1192": 80, "4099": 162, "3447": 176}
# THÀNH (mapId) -> npc theo loại. Bổ sung khi học thêm (Lễ Quan các thành khác CHƯA biết — chỉ PT 673).
_TOWN_NPCS = {
    1:   {"datau": "588",  "xaphu": "879",  "lequan": "673"},   # Phượng Tường
    11:  {"datau": "1049", "xaphu": "1058", "lequan": None},     # Thành Đô
    37:  {"datau": "1723", "xaphu": "1386", "lequan": None},     # Biện Kinh
    78:  {"datau": "1425", "xaphu": "1222", "lequan": None},     # Tương Dương
    80:  {"datau": "1192", "xaphu": "1312", "lequan": None},     # Dương Châu
    162: {"datau": "4099", "xaphu": "4159", "lequan": None},     # Đại Lý
    176: {"datau": "3447", "xaphu": "3363", "lequan": None},     # Lâm An
}
_DATAU_NODES_PATH = os.path.join(os.path.dirname(_MAPLIST), "..", "datau_nodes.json")


def town_of_map(map_id):
    """THÀNH (mapId) mà map_id thuộc về. map THÀNH → chính nó; ĐỘNG → suy từ datau-node ĐÃ HỌC (datau_nodes.json),
    fallback node-vùng maplist. None nếu chưa biết."""
    try:
        mid = int(map_id)
    except Exception:
        return None
    if mid in _TOWN_NPCS:
        return mid
    # 1) datau-node đã học cho map này (đáng tin nhất — learner điền dần)
    try:
        nodes = json.load(open(_DATAU_NODES_PATH, encoding="utf-8"))
        t = _DATAU_NODE_TO_TOWN.get(str(nodes.get(str(mid))))
        if t:
            return t
    except Exception:
        pass
    # 2) fallback: node-vùng maplist (chỉ vùng 1-anchor chắc chắn)
    return _DATAU_NODE_TO_TOWN.get(str(datau_node_for_map(mid)))


def npc_for_map(map_id, kind):
    """Node NPC của THÀNH cùng vùng map_id, theo kind ('datau'|'xaphu'|'lequan'). None nếu chưa biết.
    → gọi NPC 1 phát trúng từ động/bất kỳ map nào trong vùng (remote same-region)."""
    t = town_of_map(map_id)
    return _TOWN_NPCS.get(t, {}).get(kind) if t else None
