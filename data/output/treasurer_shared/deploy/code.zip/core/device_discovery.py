"""
core/device_discovery.py — DÒ GIẢ LẬP ĐỘNG (không hardcode cổng).

Tự tìm cổng adb của MỌI giả lập đang chạy (MuMu nhiều cửa sổ, LDPlayer, Nox, BlueStacks...,
trên mac/linux/windows) bằng cách quét tiến trình đang LẮNG NGHE TCP rồi `adb connect`.
=> Mở bao nhiêu cửa sổ / đổi sang LDPlayer / đổi máy đều tự bắt, khỏi sửa code.
"""
import subprocess
import platform
import re

# Từ khóa tên tiến trình giả lập (lowercase) — nhận diện cổng adb của chúng.
_EMU_KW = ("mumu", "nemu", "ldplayer", "dnplayer", "ld9box", "nox", "memu",
           "bluestacks", "hd-player", "emulator", "qemu", "genymotion", "headless", "player")

# Fallback nhẹ phòng khi không quét được tiến trình (vẫn có lớp động ở trên).
_FALLBACK_PORTS = list(range(26624, 26645)) + [16384, 16416, 5555, 5557, 7555, 21503, 62001, 62025]


def _listening_ports():
    """Cổng TCP đang LẮNG NGHE của tiến trình GIẢ LẬP (động)."""
    ports = set()
    sysname = platform.system()
    try:
        if sysname in ("Darwin", "Linux"):
            out = subprocess.check_output("lsof -nP -iTCP -sTCP:LISTEN", shell=True,
                                          stderr=subprocess.DEVNULL, timeout=6).decode(errors="ignore")
            for line in out.splitlines():
                if any(k in line.lower() for k in _EMU_KW):
                    for m in re.finditer(r"[:.](\d+)\s*\(LISTEN\)", line):
                        ports.add(int(m.group(1)))
        elif sysname == "Windows":
            names = {}
            try:
                tl = subprocess.check_output('tasklist /fo csv /nh', shell=True, timeout=6).decode("mbcs", errors="ignore")
                for line in tl.splitlines():
                    parts = line.split('","')
                    if len(parts) >= 2:
                        names[parts[1].strip('"').strip()] = parts[0].strip('"').lower()
            except Exception:
                pass
            ns = subprocess.check_output("netstat -ano -p tcp", shell=True, timeout=6).decode(errors="ignore")
            for line in ns.splitlines():
                if "LISTENING" not in line:
                    continue
                m = re.search(r"127\.0\.0\.1:(\d+)\b.*?(\d+)\s*$", line)
                if m:
                    port, pid = int(m.group(1)), m.group(2)
                    if any(k in names.get(pid, "") for k in _EMU_KW):
                        ports.add(port)
    except Exception:
        pass
    return ports


def discover_devices(adb_path, package=None, connect_timeout=2.0):
    """ĐỘNG: dò cổng giả lập đang chạy -> adb connect -> trả list device id.
    package: nếu truyền, CHỈ trả device đang chạy game đó (pidof)."""
    ports = _listening_ports()
    ports |= set(_FALLBACK_PORTS)        # lớp dự phòng (vẫn ưu tiên cổng động ở trên)
    # SONG SONG hoá adb connect: ~29 cổng × timeout 2s TUẦN TỰ = ~1 PHÚT đơ UI. Chạy đồng thời -> ~vài giây.
    def _try_connect(p):
        try:
            subprocess.run(f"{adb_path} connect 127.0.0.1:{p}", shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=connect_timeout)
        except Exception:
            pass
    try:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=24) as ex:
            list(ex.map(_try_connect, sorted(ports)))
    except Exception:
        for p in sorted(ports):
            _try_connect(p)
    devs = []
    try:
        out = subprocess.check_output(f"{adb_path} devices", shell=True, timeout=6).decode(errors="ignore")
        for line in out.splitlines()[1:]:
            if "\tdevice" in line:
                d = line.split("\t")[0].strip()
                if d:
                    devs.append(d)
    except Exception:
        pass
    if not package:
        return devs
    ok = []
    for d in devs:
        try:
            # LỌC THEO GAME ĐÃ CÀI (KHÔNG theo "đang chạy" bằng pidof). Lý do: nếu game CRASH/đóng trên 1 cửa
            # sổ thì pidof rỗng -> cửa sổ đó BIẾN MẤT khỏi danh sách -> không thấy, không bật lại được (đúng bug
            # 3 cửa sổ quét ra 2 khi 1 cửa sổ vừa crash). Đã cài = vẫn hiện -> bật Auto sẽ tự launch lại game.
            out = subprocess.check_output(f"{adb_path} -s {d} shell pm list packages {package}", shell=True,
                                          stderr=subprocess.DEVNULL, timeout=6).decode(errors="ignore")
            if package in out:
                ok.append(d)
        except Exception:
            pass
    return ok
