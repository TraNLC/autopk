# -*- coding: utf-8 -*-
"""listen_huyhoang.py — LISTENER 10 PHÚT cho Quả Huy Hoàng.

Chạy nền, theo dõi nguyên 1 chu kỳ (quả xuất hiện -> chín -> hái). Ghi MỌI sự kiện vào
data/output/huyhoang_listen.log + in ra stdout:
  - QUẢ (NPC id cao >=13000) XUẤT HIỆN / BIẾN MẤT (biến mất = vừa bị hái)
  - gói OUT (client gửi) — eNpcDialogue(click quả) + mọi gói thao tác
  - gói IN đáng chú ý (bỏ ồn: op9 vị trí, op251 heartbeat, op133 chat, op16, sync nhỏ)
  - hook il2cpp 'eNpcDialogue KÍCH TAY THẬT -> npcId=...' (in qua connect stdout)

Dùng:  (TẮT UI cửa sổ đó)  venv/bin/python listen_huyhoang.py [secs] [device]
"""
import sys, time, os
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot
from scan_huyhoang import scan

SECS = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 600
DEV = None
for a in sys.argv[1:]:
    if not a.isdigit():
        DEV = a
        break

# Ồn: vị trí/sync/heartbeat/chat — bỏ khỏi timeline cho dễ đọc gói hái.
NOISE_IN = {7, 8, 9, 16, 17, 18, 19, 20, 23, 63, 66, 133, 251}

LOG = "data/output/huyhoang_listen.log"
os.makedirs("data/output", exist_ok=True)
_lf = open(LOG, "w", encoding="utf-8")


def emit(s):
    print(s, flush=True)
    _lf.write(s + "\n"); _lf.flush()


def main():
    if DEV:
        devs = [DEV]
    else:
        devs = ["127.0.0.1:26624", "127.0.0.1:5555", "emulator-5554"]
    bot = None
    for d in devs:
        try:
            b = VLTK1Bot(device_id=d)
            if not b.connect():
                emit(f"[{d}] connect fail"); continue
            b.capture_sent = True   # BẮT BUỘC: bật bắt gói GỬI (sendto) — mặc định off -> sent_buffer rỗng
            for _ in range(10):
                try: b.poll_recv()
                except: pass
                time.sleep(0.4)
            b.redetect_fd_by_traffic()
            rv = b.rpc.ping().get("recvAny")
            emit(f"[{d}] recvAny={rv} gameFd={b.rpc.ping().get('gameFd')}")
            if rv and rv > 0:
                bot = b; emit(f"==> LIVE: {d}"); break
        except Exception as e:
            emit(f"[{d}] lỗi {e}")
    if not bot:
        emit("KHÔNG có cửa sổ live (recvAny>0). Dừng."); return

    base, bf = scan(bot)
    quas0 = sorted([v[1] for k, v in base.items() if k.startswith("NPC:") and str(v[1]).isdigit() and int(v[1]) >= 13000],
                   key=lambda x: int(x))
    emit(f"[t0] QUẢ ban đầu (NPC id>=13000): {quas0}")
    emit(f"[t0] tổng NPC={sum(1 for k in base if k.startswith('NPC:'))} "
         f"PLR={sum(1 for k in base if k.startswith('PLR:'))} OBJ={sum(1 for k in base if k.startswith('OBJ:'))}")

    bot.sent_buffer = []; bot.recv_buffer = []
    try: bot.poll_recv()
    except: pass
    bot.sent_buffer = []; bot.recv_buffer = []

    emit(f"\n==> LISTEN {SECS}s — đứng ở bãi, click quả CHÍN khi có. (log: {LOG}) <==\n")
    t0 = time.time(); seen = 0; prev = dict(base); last_scan = 0.0; last_beat = 0.0
    while time.time() - t0 < SECS:
        try: bot.poll_recv()
        except: pass
        now = time.time(); el = round(now - t0, 1)
        # OUT — GIỮ TẤT CẢ (gói hái nằm đây)
        sb = list(getattr(bot, "sent_buffer", []))
        for pp in sb[seen:]:
            op = pp.get("opcode")
            emit(f"  t+{el:>5}s →OUT op{op} ({pp.get('name') or '?'}) {(pp.get('hex') or '')[:160]}")
        seen = len(sb)
        # IN — bỏ ồn
        rb = list(getattr(bot, "recv_buffer", []))
        if rb:
            bot.recv_buffer = []
            for pp in rb:
                op = pp.get("opcode")
                if op in NOISE_IN:
                    continue
                emit(f"  t+{el:>5}s ←IN  op{op} ({pp.get('name') or '?'}) {(pp.get('hex') or '')[:160]}")
        # QUÉT quả mỗi ~1.5s
        if now - last_scan >= 1.5:
            last_scan = now
            cur, _ = scan(bot)
            for k, v in cur.items():
                if k.startswith("_") or k in prev:
                    continue
                if k.startswith("NPC:") and str(v[1]).isdigit() and int(v[1]) >= 13000:
                    emit(f"  t+{el:>5}s [🍎 QUẢ XUẤT HIỆN] id={v[1]}")
            for k, v in prev.items():
                if k.startswith("_") or k in cur:
                    continue
                if k.startswith("NPC:") and str(v[1]).isdigit() and int(v[1]) >= 13000:
                    emit(f"  t+{el:>5}s [❌ QUẢ BIẾN MẤT (hái?)] id={v[1]}")
            prev = cur
        # nhịp tiến độ mỗi 30s
        if now - last_beat >= 30:
            last_beat = now
            nq = sum(1 for k in prev if k.startswith("NPC:") and str(prev[k][1]).isdigit() and int(prev[k][1]) >= 13000)
            emit(f"  --- t+{int(el)}s: còn {nq} quả quanh bạn ---")
        time.sleep(0.1)
    emit(f"\n[xong] Listen {SECS}s kết thúc. Log đầy đủ: {LOG}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        emit("\n[*] Dừng (Ctrl+C).")
    finally:
        _lf.close()
