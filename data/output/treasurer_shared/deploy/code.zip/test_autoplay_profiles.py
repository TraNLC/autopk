# -*- coding: utf-8 -*-
"""test_autoplay_profiles.py — CHẨN ĐOÁN vì sao bot báo "KHÔNG có profile Auto" dù game CÓ profile.

Đọc profile autoplay từ CẢ 2 nguồn để biết nguồn nào có dữ liệu:
  (A) data-layer: PlayerMain.autoplay(MainUnity).profileMapping  -> get_named_autoplay_profile
  (B) UI-layer:   game.ui.autoplay.UnityAutoplay.selectedProfile -> get_autoplay_profile

Cách dùng: TẮT UI bot trước (Frida attach 1 lần) rồi:
  venv/bin/python -u test_autoplay_profiles.py [device]
  vd: venv/bin/python -u test_autoplay_profiles.py 127.0.0.1:26624
"""
import sys, time, json
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

DEV = next((a for a in sys.argv[1:] if (":" in a or a.startswith("emulator"))), "127.0.0.1:26624")


def pj(label, obj):
    print(f"\n===== {label} =====")
    try:
        print(json.dumps(obj, ensure_ascii=False, indent=2))
    except Exception:
        print(repr(obj))


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect():
        print("connect FAIL (UI bot còn attach? tắt đi rồi chạy lại)"); return
    for _ in range(6):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.4)
    try:
        p = bot.rpc.ping(); print(f"ping gameFd={p.get('gameFd')} recvAny={p.get('recvAny')}")
    except Exception as e:
        print(f"ping lỗi: {e}")

    # (A) data-layer profileMapping (InitializeForce(false)) — đúng đường bot đang dùng
    try:
        a = bot.rpc.get_named_autoplay_profile("Luyện công")
    except Exception as e:
        a = {"exc": str(e)}
    pj("A) get_named_autoplay_profile('Luyện công')  [data-layer, InitializeForce(false)]", a)

    # (B) UI-layer UnityAutoplay.selectedProfile — chỉ có khi đã MỞ panel trong game
    try:
        b = bot.rpc.get_autoplay_profile()
    except Exception as e:
        b = {"exc": str(e)}
    pj("B) get_autoplay_profile()  [UI-layer UnityAutoplay]", b)

    print("\n----- KẾT LUẬN GỢI Ý -----")
    a_all = (a or {}).get("all") or []
    if a_all:
        print(f"-> data-layer CÓ {len(a_all)} profile: {[p.get('name') for p in a_all]} (bug ở match-tên/lấy-guid, không phải thiếu profile).")
    else:
        err = (a or {}).get("error")
        print(f"-> data-layer RỖNG (error={err!r}). profileMapping chưa nạp qua InitializeForce(false).")
        if (b or {}).get("ok") or (b or {}).get("name") or (b or {}).get("guid"):
            print(f"   NHƯNG UI-layer CÓ: {b}. => profile chỉ materialize khi MỞ panel; fix = InitializeForce(TRUE) hoặc đọc UI-layer.")
        else:
            print("   UI-layer cũng rỗng (chưa mở panel lần nào trong phiên này?).")


if __name__ == "__main__":
    main()
