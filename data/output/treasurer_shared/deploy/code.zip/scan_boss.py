# -*- coding: utf-8 -*-
"""scan_boss.py — QUÉT LIÊN TỤC quái/NPC gần để NHẬN DIỆN BOSS (HP/level cao + tên riêng).

Đọc getNearNpcsDetail (name/level/hp/hpMax/npcKind/npcType). Mỗi vòng in danh sách quái CÓ MÁU
(loại NPC chức năng hp=0), sắp theo HP giảm dần; gắn 🔥BOSS cho con HP/level cao nhất rõ rệt.

Dùng:  (TẮT UI cửa sổ đó)  venv/bin/python scan_boss.py [secs] [device]
"""
import sys, time, json, os
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot
try:
    from database.db_manager import db as _MAPDB
except Exception:
    _MAPDB = None

CATALOG = "data/output/boss_map.json"


def cur_map(bot):
    """(mapId, mapName, x, y) hiện tại của nhân vật."""
    try:
        info = bot.rpc.get_player_info() or {}
    except Exception:
        return None, "?", 0, 0
    mid = info.get("mapId")
    nm = "?"
    if mid is not None and _MAPDB:
        try:
            nm = _MAPDB.get_map_name(mid) or "?"
        except Exception:
            pass
    return mid, nm, info.get("mapX") or 0, info.get("mapY") or 0


def record_boss_map(name, mid, mname, x, y):
    """Lưu boss -> map đã gặp vào boss_map.json (cộng dồn count, lưu lần gặp gần nhất)."""
    os.makedirs("data/output", exist_ok=True)
    try:
        cat = json.load(open(CATALOG, encoding="utf-8"))
    except Exception:
        cat = {}
    b = cat.setdefault(name, {})
    key = str(mid)
    e = b.setdefault(key, {"mapId": mid, "mapName": mname, "count": 0})
    e["count"] += 1
    e["mapName"] = mname
    e["last_pos"] = [x, y]
    try:
        json.dump(cat, open(CATALOG, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    except Exception:
        pass

SECS = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 600
DEV = next((a for a in sys.argv[1:] if not a.isdigit()), "127.0.0.1:26624")


def detail(bot):
    try:
        r = bot.rpc.get_near_npcs_detail() or {}
    except Exception as e:
        return [], {"err": str(e)}
    return (r.get("npcs") or []), (r.get("diag") or {})


# Tên boss đã biết (thêm dần khi user xác nhận). So khớp KHÔNG dấu, lower, substring.
import unicodedata
BOSS_NAMES = ("hac y sat thu", "dieu nhu")   # boss xác nhận 2026-06-15: Hắc Y Sát Thủ + Diệu Như (id~13030, npcType=2)


def _norm(s):
    s = unicodedata.normalize("NFD", str(s or ""))
    return "".join(c for c in s if unicodedata.category(c) != "Mn").lower()


def boss_flag(n):
    """Trả nhãn: '🔥BOSS' nếu tên khớp BOSS_NAMES; '⚡đặc biệt' nếu npcType!=0 (elite/quest);
    'quái' nếu type 0. HP đều là %(/100) nên KHÔNG dùng để nhận boss."""
    nm = _norm(n.get("name"))
    if BOSS_NAMES and any(k in nm for k in BOSS_NAMES):
        return "🔥BOSS"
    if (n.get("npcType", 0) or 0) != 0:
        return "⚡đặc biệt"
    return "      quái"


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect():
        print("[-] connect FAIL — UI còn attach Frida? Tắt UI cửa sổ đó rồi chạy lại."); return
    for _ in range(8):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.4)
    bot.redetect_fd_by_traffic()
    p = bot.rpc.ping()
    print(f"[*] gameFd={p.get('gameFd')} recvAny={p.get('recvAny')}")
    if not p.get("recvAny"):
        print("[-] recvAny=0 — cửa sổ chưa vào thế giới."); return
    print(f"[*] QUÉT BOSS liên tục {SECS}s (Ctrl+C để dừng)...\n")

    t0 = time.time(); rnd = 0; prev_special = set()
    while time.time() - t0 < SECS:
        rnd += 1
        npcs, diag = detail(bot)
        if rnd == 1 and diag.get("errors"):
            print(f"[diag] errors={diag['errors'][:3]} n={diag.get('n')}")
        flagged = [(boss_flag(n), n) for n in npcs]
        # sắp: BOSS trước, rồi đặc biệt, rồi quái
        order = {"🔥BOSS": 0, "⚡đặc biệt": 1}
        flagged.sort(key=lambda fn: order.get(fn[0], 2))
        special = {n.get("id") for f, n in flagged if f != "      quái"}
        if rnd % 3 == 1 or special != prev_special:
            el = int(time.time() - t0)
            nb = sum(1 for f, _ in flagged if f == "🔥BOSS")
            ns = sum(1 for f, _ in flagged if f == "⚡đặc biệt")
            print(f"--- t+{el}s | NPC quanh={len(npcs)} | BOSS={nb} đặc biệt={ns} ---")
            for f, n in flagged[:12]:
                print(f"  {f} id={n.get('id')} name={n.get('name')!r} lv={n.get('level')} "
                      f"hp%={n.get('hp')} type={n.get('npcType')} kind={n.get('npcKind')} series={n.get('series')}")
            if special != prev_special:
                new = special - prev_special; gone = prev_special - special
                if new:
                    print(f"  ✨ XUẤT HIỆN (boss/đặc biệt): {new}")
                    # GHI MAP: đọc map hiện tại + lưu catalog cho từng boss/đặc biệt mới xuất hiện
                    mid, mname, x, y = cur_map(bot)
                    for f, n in flagged:
                        if f != "      quái" and n.get("id") in new:
                            record_boss_map(n.get("name") or f"npc{n.get('id')}", mid, mname, x, y)
                            print(f"  📍 '{n.get('name')}' ({f}) Ở MAP {mid} '{mname}' (toạ độ {x},{y}) "
                                  f"→ đã lưu {CATALOG}")
                if gone: print(f"  ❌ BIẾN MẤT (chết/rời): {gone}")
            prev_special = special
        time.sleep(1.5)
    print("\n[xong] hết giờ quét boss.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[*] Dừng.")
