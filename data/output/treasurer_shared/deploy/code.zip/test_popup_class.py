"""
test_popup_class.py — DÒ class popup "về thành dưỡng sức" (đóng không được).
Mục đích: closeDatauPopups đang đoán StandardConfirmPc -> KHÔNG đóng được popup này.
Cần biết TÊN class thật của popup để thêm vào SPECS.

DÙNG:
  1. TẮT Auto cửa sổ test (Frida attach 1 lần/PID). Lên động cho char chết/HP thấp để popup "về thành dưỡng sức" HIỆN.
  2. venv/bin/python test_popup_class.py 127.0.0.1:26784
  3. Khi popup ĐANG HIỆN -> nhìn danh sách 'active' in mỗi 1.5s, tìm class lạ (confirm/box/notice/standard/revive/relive...).
  4. Copy danh sách active GỬI LẠI.
"""
import sys, time
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot


def main():
    dev = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1:26784"
    print(f"[*] Attach {dev}…", flush=True)
    bot = VLTK1Bot(device_id=dev)
    if not bot.connect():
        print("[-] Attach FAIL (còn bật Auto? game chưa vào?).", flush=True)
        return
    print("=" * 56, flush=True)
    print("👉 Để popup 'về thành dưỡng sức' HIỆN trên màn hình. Đang quét 45s…", flush=True)
    print("=" * 56, flush=True)
    t0 = time.time()
    last = None
    while time.time() - t0 < 45:
        try:
            res = bot.rpc.enum_active_ui() or {}
            active = res.get("active") or {}
        except Exception as e:
            active = {}
            print(f"[err] {e}", flush=True)
        snap = " | ".join(f"{k}={v}" for k, v in sorted(active.items()))
        if snap != last:
            print(f"[{int(time.time()-t0):>2}s] {snap or '(none)'}", flush=True)
            last = snap
        time.sleep(1.5)
    try: bot.close()
    except Exception: pass


if __name__ == "__main__":
    main()
