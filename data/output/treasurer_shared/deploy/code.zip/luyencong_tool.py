# -*- coding: utf-8 -*-
"""luyencong_tool.py — TOOL RIÊNG (chạy 1 lần) tạo + treo account luyện công.

Dán list acc:pass:tên → mỗi account: login → tạo nhân vật → ra bãi quái thôn → ăn Bạch Câu Hoàn →
bật auto → trainoff → account kế. Dùng frida-il2cpp qua VLTK1Bot.

Tối ưu LOGIN (bài học từ debug): KHÔNG logout khi đang ở màn login (phá popup); chỉ logout khi IN-WORLD.
Bắn login lặp tới khi AccountLoginPopup sẵn sàng. connect(fast=True). Switch account = BackToLogin (không
restart game → nhanh); fallback relaunch nếu kẹt.

Chạy: venv/bin/python luyencong_tool.py    (TẮT ui_bot_app.py trước — Frida attach 1 lần)
"""
import sys, time, json, threading, subprocess
sys.path.insert(0, ".")
import tkinter as tk
from tkinter import ttk, scrolledtext

from features.bot.game_bot import VLTK1Bot
from core import luyencong_accounts as LA
try:
    from core.adb_helper import ADB_PATH
except Exception:
    ADB_PATH = "adb"

# Toạ độ TAP (1920x1080 landscape) — verify live. Nút TO (dễ trúng) dùng ADB; nút submit/vào game dùng il2cpp.
TAP_QUAYLAI   = (960, 794)    # popup "Thông báo" -> Quay lại
TAP_TAIKHOAN  = (1776, 130)   # màn server -> "Tài Khoản" (góc trên-phải)
TAP_DANGNHAP_MENU = (960, 497)  # menu Tài khoản -> "Đăng Nhập"
TAP_ACC_FIELD = (1120, 486)   # form: ô Tài khoản
TAP_PASS_FIELD = (1120, 566)  # form: ô Mật mã

# EQUIP vũ khí (verify live 2026-06-13) — op24/eAutoEquip KHÔNG equip; cơ chế ĐÚNG = tap item trong túi →
# menu Ném/Rao/Mặc → "Mặc". Char MỚI có túi starter cố định (slot1 = vũ khí đầu, top-left).
TAP_BAG_ICON     = (1748, 405)  # HUD: icon túi nâu (mở HÀNH TRANG) — KHÔNG phải lưới-4-ô(menu)/áo-giáp
TAP_WEAPON_SLOT1 = (1315, 250)  # ô vũ khí đầu (slot1) trong lưới túi (view bag-only)
TAP_EXPAND_ARROW = (600, 658)   # icon ♥ góc dưới-TRÁI panel detail = TOGGLE bung/thu 3 nút Ném|Rao|Mặc (mặc định ẨN)
TAP_MAC          = (1200, 772)  # nút "Mặc" sau khi đã bung (Ném~690 / Rao~960 / Mặc~1200, y~772)
TAP_BAG_CLOSE    = (1568, 534)  # nút "Đóng" panel HÀNH TRANG

# Item DÙNG ở bãi quái (particular = id magicscript). 3 = Tiên Thảo Lộ (+KN luyện công 1h).
# Thêm id "Toán Đầu Chuỳ" vào đây khi xác nhận (vd USE_ITEMS_AT_SPOT = [3, <id>]).
USE_ITEMS_AT_SPOT = [3]

SPOTS_PATH = "data/output/luyencong_spawn_spots.json"
SERIES = [("Kim", 0), ("Mộc", 1), ("Thủy", 2), ("Hỏa", 3), ("Thổ", 4)]
SEXES = [("Nam", 0), ("Nữ", 1)]


class Tool:
    def __init__(self, root):
        self.root = root
        root.title("🏋️ Tool Tạo + Treo Account Luyện Công (chạy 1 lần)")
        root.geometry("640x720")
        self.bot = None
        self.stop_flag = False
        self.worker = None

        top = tk.Frame(root); top.pack(fill=tk.X, padx=8, pady=6)
        tk.Label(top, text="Device:").pack(side=tk.LEFT)
        self.var_dev = tk.StringVar(value="127.0.0.1:26624")
        tk.Entry(top, textvariable=self.var_dev, width=20).pack(side=tk.LEFT, padx=4)
        tk.Label(top, text="Phái:").pack(side=tk.LEFT, padx=(8, 0))
        self.var_series = tk.StringVar(value="Kim")
        ttk.Combobox(top, textvariable=self.var_series, values=[s[0] for s in SERIES],
                     width=6, state="readonly").pack(side=tk.LEFT, padx=4)
        tk.Label(top, text="Giới:").pack(side=tk.LEFT)
        self.var_sex = tk.StringVar(value="Nam")
        ttk.Combobox(top, textvariable=self.var_sex, values=[s[0] for s in SEXES],
                     width=5, state="readonly").pack(side=tk.LEFT, padx=4)

        tk.Label(root, text="Danh sách (mỗi dòng: taikhoan:matkhau:tennhanvat):",
                 font=("Helvetica", 10, "bold")).pack(anchor="w", padx=8)
        self.txt = scrolledtext.ScrolledText(root, wrap=tk.WORD, height=8)
        self.txt.pack(fill=tk.X, padx=8, pady=4)
        # nạp sẵn list đã lưu của device (nếu có) cho tiện
        try:
            self.txt.insert("1.0", LA.queue_text(self.var_dev.get()))
        except Exception:
            pass

        btn = tk.Frame(root); btn.pack(fill=tk.X, padx=8)
        self.btn_run = tk.Button(btn, text="▶️ Chạy", bg="#1a7f37", fg="white",
                                 font=("Helvetica", 11, "bold"), command=self._start)
        self.btn_run.pack(side=tk.LEFT)
        tk.Button(btn, text="⏹ Dừng", command=self._stop).pack(side=tk.LEFT, padx=6)

        tk.Label(root, text="Log:", font=("Helvetica", 10, "bold")).pack(anchor="w", padx=8, pady=(6, 0))
        self.log_area = scrolledtext.ScrolledText(root, wrap=tk.WORD, height=20, state="disabled")
        self.log_area.pack(fill=tk.BOTH, expand=True, padx=8, pady=4)

    def log(self, m):
        ts = time.strftime("%H:%M:%S")
        def _a():
            self.log_area.config(state="normal")
            self.log_area.insert(tk.END, f"{ts} - {m}\n")
            self.log_area.see(tk.END)
            self.log_area.config(state="disabled")
        try: self.root.after(0, _a)
        except Exception: print(m)

    def _start(self):
        if self.worker and self.worker.is_alive():
            self.log("Đang chạy rồi."); return
        self.stop_flag = False
        self.btn_run.config(state="disabled")
        self.worker = threading.Thread(target=self._run, daemon=True)
        self.worker.start()

    def _stop(self):
        self.stop_flag = True
        self.log("⏹ Đã yêu cầu dừng (xong account hiện tại sẽ dừng).")

    # ---------- core ----------
    # ---------- ADB helpers (gõ account = ADB; bấm submit/vào game = il2cpp) ----------
    def _adb(self, *args):
        try:
            subprocess.run([ADB_PATH, "-s", self.dev, "shell"] + list(args),
                           timeout=12, capture_output=True)
        except Exception as e:
            self.log(f"   adb lỗi: {e}")

    def _tap(self, xy):
        self._adb("input", "tap", str(xy[0]), str(xy[1]))

    def _type_field(self, xy, text):
        """Tap ô -> xoá sạch (pre-fill) -> gõ text."""
        self._tap(xy); time.sleep(0.4)
        self._adb("input", "keyevent", "KEYCODE_MOVE_END"); time.sleep(0.2)
        for _ in range(20):
            self._adb("input", "keyevent", "67")   # 67 = DEL (backspace)
        time.sleep(0.2)
        self._adb("input", "text", text); time.sleep(0.3)

    def _equip_weapon_adb(self, gb, name):
        """Mặc vũ khí starter qua ADB (verify live): mở túi → chọn vũ khí slot1 → tap ♥(bung 3 nút) → tap 'Mặc'.
        op24/eAutoEquip/SetItemLocation/EquipItem ĐỀU không equip; CHỈ menu Ném/Rao/Mặc mới mặc thật, mà 3 nút
        đó MẶC ĐỊNH ẨN — phải tap icon ♥ (góc dưới-trái panel) để bung. ♥ là TOGGLE → retry tối đa 2 lần phòng
        panel lỡ đang ở trạng thái expanded. Trả True nếu dump thấy genre0 location==1 (đang mặc)."""
        self._tap(TAP_BAG_ICON);     time.sleep(1.2)
        self._tap(TAP_WEAPON_SLOT1); time.sleep(0.9)   # chọn vũ khí (panel detail mở, thường COLLAPSED)
        ok = False
        for _ in range(2):
            self._tap(TAP_EXPAND_ARROW); time.sleep(0.7)   # ♥ bung 3 nút (nếu lỡ đang mở thì thu → vòng sau bung lại)
            self._tap(TAP_MAC);          time.sleep(1.2)   # "Mặc"
            try:
                r = gb.dump_bag_items() or {}
                items = r.get("items") if isinstance(r, dict) else r
                ok = any(it.get("genre") == 0 and it.get("location") == 1 for it in (items or []))
            except Exception:
                ok = False
            if ok:
                break
        self._tap(TAP_BAG_CLOSE); time.sleep(0.5)
        return ok

    def _login_hybrid(self, gb, acc, pwd):
        """Phase B: logout (nếu in-world) -> ADB nav tới FORM nhập acc -> ADB gõ acc/pass ->
        il2cpp OnClickLoginButton (submit) -> il2cpp enter_world (Vào trò chơi). Trả True nếu submit được."""
        if gb.get_login_state() == "in_world":
            # gb.logout (BackToLogin) KHÔNG đáng tin (kẹt in_world). RELAUNCH (force-stop) -> at_login chắc chắn.
            self.log("   đổi acc: relaunch game (force-stop → màn login)…")
            gb.relaunch_game()   # re-attach Frida luôn
            t0 = time.time()
            while time.time() - t0 < 30 and gb.get_login_state() != "at_login":
                time.sleep(1)
            try: gb.rpc.clear_player_main()
            except Exception: pass
            self.log(f"   sau relaunch: state={gb.get_login_state()}")
        # ADB nav tới form: Quay lại(popup nếu có) -> Tài Khoản -> Đăng Nhập(menu)
        self._tap(TAP_QUAYLAI); time.sleep(1.5)
        self._tap(TAP_TAIKHOAN); time.sleep(1.5)
        self._tap(TAP_DANGNHAP_MENU); time.sleep(1.5)
        # ADB gõ account + pass
        self.log(f"   ADB gõ account {acc}…")
        self._type_field(TAP_ACC_FIELD, acc)
        self._type_field(TAP_PASS_FIELD, pwd)
        # il2cpp submit (đọc field đã gõ + OnClickLoginButton)
        r = gb.rpc.login_account(acc, pwd)
        self.log(f"   il2cpp submit: rbAcc={r.get('rbAcc')!r} clickOk={r.get('clickOk')}")
        time.sleep(2)
        return bool(r and (r.get("setOk") or r.get("clickOk")))

    def _ensure_login_screen(self, gb):
        """Về màn login SẠCH để đổi account. ⚠️ BackToLogin in-world KHÔNG đáng tin (char ở lại world →
        tool login nhầm char cũ). Nếu đang in-world (acc trước) -> RELAUNCH (force-stop) về login. Ở màn
        login rồi (acc đầu/game mới) -> KHÔNG đụng (relaunch/logout đều thừa + phá)."""
        st = gb.get_login_state()
        if st == "in_world":
            self.log("   đổi account → relaunch game về màn login (force-stop, ~15s)…")
            gb.relaunch_game()   # force-stop + relaunch + re-attach (connect fast)
            t0 = time.time()
            while time.time() - t0 < 35 and gb.get_login_state() != "at_login":
                time.sleep(1)

    def _login(self, gb, acc, pwd):
        """Bắn login lặp tới khi popup sẵn sàng. LOG chi tiết để biết vì sao fail."""
        t0 = time.time(); n = 0
        while time.time() - t0 < 25 and not self.stop_flag:
            n += 1
            try:
                r = gb.rpc.login_account(acc, pwd)
            except Exception as e:
                r = {"error": str(e)}
            self.log(f"   login#{n}: state={gb.get_login_state()} resp={r}")
            if r and (r.get("setOk") or r.get("clickOk")):
                try: gb.rpc.select_last_server()
                except Exception: pass
                return True
            time.sleep(1.5)
        return False

    def _do_account(self, gb, a, series, sex, spots):
        acc, pwd, name = a["acc"], a["pwd"], a["name"]
        self.log(f"🏋️ [{name}] === bắt đầu {acc} === (state: {gb.get_login_state()})")
        # PHỐI HỢP ADB + il2cpp: logout → ADB nav tới form → ADB GÕ acc/pass → il2cpp submit + Vào trò chơi.
        if not self._login_hybrid(gb, acc, pwd):
            self.log(f"🏋️ [{name}] login KHÔNG được → bỏ qua."); return
        self.log(f"🏋️ [{name}] đã submit login → chờ màn tạo char / world…")
        # SAU LOGIN: game ở màn 'Chọn máy chủ / Vào trò chơi' (state vẫn at_login). Phải BẤM 'Vào trò chơi'
        # (enter_world=OpenGame/PlayNowScreen) — KHÔNG bấm thì ngồi ~1p chờ auto. Nudge mỗi ~3s khi còn at_login.
        t0 = time.time(); created = False; last_st = None
        while time.time() - t0 < 90 and not self.stop_flag:
            st = gb.get_login_state()
            if st != last_st:
                self.log(f"   [{int(time.time()-t0)}s] state={st}")
                last_st = st
            # MÀN TẠO CHAR check TRƯỚC (kể cả khi state stale in_world do PlayerMain cũ chưa xoá).
            if not created and gb.at_create_screen():
                self.log(f"🏋️ [{name}] màn tạo char hiện ([{int(time.time()-t0)}s]) → tạo (phái Kim)…")
                try:
                    cr = gb.rpc.create_char_invoke(name, series, sex)
                    self.log(f"   create: sent={cr.get('sent')!r} readback={cr.get('readback')!r}")
                except Exception as e: self.log(f"   create lỗi: {e}")
                created = True
                try: gb.rpc.clear_player_main()   # xoá cache -> đọc char MỚI sau khi vào world
                except Exception: pass
                time.sleep(2); continue
            if st == "in_world":
                break
            # màn server -> bấm 'Vào trò chơi' (il2cpp)
            try: gb.rpc.select_last_server()
            except Exception: pass
            try: gb.enter_world()
            except Exception: pass
            time.sleep(2)
        if gb.get_login_state() != "in_world":
            self.log(f"🏋️ [{name}] KHÔNG vào được world (timeout 90s, created={created}) → bỏ qua."); return
        try: gb.rpc.clear_player_main()   # đọc char MỚI (không phải cache cũ)
        except Exception: pass
        time.sleep(1)
        gi0 = gb.rpc.get_player_info() or {}
        lv_start = gi0.get("level") or 1   # char MỚI = lv1; mốc để biết "đã lên cấp = đang train" (bug#2 fix)
        self.log(f"🏋️ [{name}] ✅ đã vào world. char THỰC TẾ='{gi0.get('name')}' cấp={gi0.get('level')} (mong đợi: {name})")
        mid = gi0.get("mapId")
        spot = spots.get(str(mid))
        gx, gy = (spot["game"][0], spot["game"][1]) if (spot and spot.get("game")) else (None, None)
        # 1. TRANG BỊ vũ khí starter (làm ngay, kể cả còn ở thành) — auto cần vũ khí mới đánh.
        #    ADB: mở túi → tap ô vũ khí slot1 → tap 'Mặc' (op24 vô tác dụng, chỉ menu Mặc mới equip thật).
        try:
            if self._equip_weapon_adb(gb, name):
                self.log(f"🏋️ [{name}] ✅ đã MẶC vũ khí (genre0 location=1).")
            else:
                self.log(f"🏋️ [{name}] ⚠️ chưa xác nhận mặc vũ khí (dump không thấy loc=1).")
        except Exception as e: self.log(f"🏋️ [{name}] equip lỗi: {e}")
        try:
            if gb.use_bach_cau_hoan(): self.log(f"🏋️ [{name}] đã ăn Bạch Câu Hoàn.")
        except Exception: pass
        try:
            u = gb.use_items_by_particular(USE_ITEMS_AT_SPOT, max_each=1)
            if u: self.log(f"🏋️ [{name}] đã dùng item buff (particular {u}).")
        except Exception: pass
        # 2. ĐI TỚI BÃI QUÁI TRƯỚC (KHÔNG bật auto — vì auto-mode làm char DỪNG đi). IsRunning chỉ = "auto bật"
        #    (true cả ở thành), KHÔNG phải "đang đánh" -> KHÔNG dùng làm tín hiệu tới nơi. Dùng VỊ TRÍ + thời gian.
        if gx is not None:
            self.log(f"🏋️ [{name}] map {mid} → ĐI tới bãi quái game({gx},{gy}) (chưa auto)…")
            arrived = False; t0 = time.time(); last_log = 0
            while time.time() - t0 < 45 and not self.stop_flag:
                gb.walk_to(gx, gy, 90)
                time.sleep(2.5)
                pi = gb.rpc.get_player_info() or {}
                mx, my = pi.get("mapX") or 0, pi.get("mapY") or 0
                if mx and my:
                    cx, cy = mx // 256, my // 256
                    if time.time() - last_log > 6:
                        self.log(f"   vị trí ({cx},{cy}) → bãi ({gx},{gy})"); last_log = time.time()
                    if abs(cx - gx) <= 8 and abs(cy - gy) <= 8:
                        arrived = True; break
            self.log(f"🏋️ [{name}] {'✅ TỚI bãi quái' if arrived else '⚠️ đi 45s (vị trí đọc hụt/chưa sát) — vẫn thử auto'}.")
        # 3. GIỜ mới BẬT AUTO (char đã ở bãi quái -> có quái đánh).
        running = False; t0 = time.time()
        while time.time() - t0 < 20 and not self.stop_flag:
            try:
                r = gb.rpc.start_autoplay_invoke()
                if r and r.get("running"):
                    running = True; break
            except Exception:
                pass
            gb.start_autoplay(arm=False)
            time.sleep(2)
        if not running:
            self.log(f"🏋️ [{name}] ⚠️ auto KHÔNG bật (IsRunning=false) sau 20s → KHÔNG trainoff.")
            return
        # 4. XÁC NHẬN ĐANG ĐÁNH/NHẬN EXP trước khi trainoff (user: nhận exp mới chắc — trainoff uỷ thác
        #    TRẠNG THÁI HIỆN TẠI; char đứng im/chưa tới bãi → cloud cũng đứng im + phí Bạch Câu Hoàn).
        #    Tín hiệu = LEVEL TĂNG: op23 eSyncDamage KHÔNG đáng tin (char lv1→4 mà không bắt được gói);
        #    level đọc ổn định qua get_player_info, char MỚI lv1 ở bãi quái lên cấp trong vài chục giây.
        # Mốc = LEVEL > lv_start (chụp lúc vừa vào world = lv1 char mới). KHÔNG chụp lv0 lại ở đây vì char có
        # thể đã lên cấp trong lúc walk/bật auto → đòi lên cấp THÊM dễ timeout → bỏ trainoff → bị logout (bug#2).
        self.log(f"🏋️ [{name}] auto bật → chờ lên cấp (>{lv_start}) xác nhận đang train…")
        leveled = False; t0 = time.time()
        while time.time() - t0 < 60 and not self.stop_flag:
            lv = (gb.rpc.get_player_info() or {}).get("level") or 0
            if lv > lv_start:
                leveled = True
                self.log(f"🏋️ [{name}] ✅ lên cấp {lv_start}→{lv} = đang train.")
                break
            time.sleep(4)
        if not leveled:
            self.log(f"🏋️ [{name}] ⚠️ 60s không lên cấp (char chưa tới bãi/không đánh được) → KHÔNG trainoff.")
            return
        try:
            gb.trainoff_check(True); time.sleep(1); gb.trainoff_start()
            time.sleep(3)   # để gói trainoff đăng ký (uỷ thác cloud) TRƯỚC khi vòng kế relaunch=logout acc này
            self.log(f"🏋️ [{name}] ✅ XONG: vũ khí + bãi quái + auto + lên-cấp + trainoff (acc tiếp tục đánh ở cloud).")
        except Exception as e:
            self.log(f"🏋️ [{name}] trainoff lỗi: {e}")

    def _run(self):
        try:
            dev = self.var_dev.get().strip()
            self.dev = dev
            series = 0   # MẶC ĐỊNH hệ KIM (user: không cần chọn phái)
            sex = 0      # nam
            accts = LA.parse_lines(self.txt.get("1.0", tk.END))
            if not accts:
                self.log("⚠️ List trống / sai định dạng (acc:pass:tên)."); return
            LA.save_queue(dev, accts)
            self.log(f"Có {len(accts)} account. Kết nối {dev}…")
            try: spots = json.load(open(SPOTS_PATH, encoding="utf-8"))
            except Exception: spots = {}
            gb = VLTK1Bot(device_id=dev)
            if not gb.is_game_running():
                self.log("Game chưa chạy → mở game…"); gb.launch_game(); time.sleep(12)
            if not gb.connect(fast=True):
                self.log(f"❌ Connect Frida fail: {getattr(gb,'connect_diag','')}"); return
            self.bot = gb
            self.log("✅ Đã connect. Bắt đầu dây chuyền.")
            for i, a in enumerate(accts, 1):
                if self.stop_flag:
                    self.log("⏹ Dừng."); break
                self.log(f"--- [{i}/{len(accts)}] ---")
                try:
                    self._do_account(gb, a, series, sex, spots)
                except Exception as e:
                    self.log(f"🏋️ [{a.get('name')}] LỖI: {e}")
            self.log("=== HOÀN TẤT danh sách ===")
        except Exception as e:
            self.log(f"❌ Lỗi tool: {e}")
        finally:
            try: self.root.after(0, lambda: self.btn_run.config(state="normal"))
            except Exception: pass


if __name__ == "__main__":
    root = tk.Tk()
    Tool(root)
    root.mainloop()
