import time
import logging
import os
import sys
import re
from enum import Enum, auto

# Add project root to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from core.adb_helper import ADBHelper, ADB_PATH
from features.bot.game_bot import VLTK1Bot
from core.quest import QuestReader, QuestInfo
from core.navigator import Navigator
from core.npc_interact import NPCInteract
from core.map_manager import MapManager

logger = logging.getLogger("da_tau_sm")

class BotState(Enum):
    BOOTSTRAP = auto()
    IDLE_PRECHECK = auto()
    MOVE_TO_DATAU = auto()
    READ_QUEST = auto()
    EVALUATE = auto()
    EXECUTE_BUY = auto()
    EXECUTE_COMBAT = auto()
    EXECUTE_FIND_ITEM = auto()
    EXECUTE_SUBMIT_POINTS = auto()
    EXECUTE_DELIVER = auto()
    CLEAR_INVENTORY = auto()
    REWARD = auto()
    CANCEL_QUEST = auto()
    ERROR = auto()

class DaTauStateMachine:
    def __init__(self, adb: ADBHelper):
        self.adb = adb
        self.game_bot = VLTK1Bot()
        self.navigator = Navigator(self.adb)
        self.navigator.game_bot = self.game_bot # Attach for RPC gotopath
        self.npc_interact = NPCInteract(self.adb)
        self.map_mgr = MapManager()
        
        self.quest_reader = QuestReader({
            "adb_path": ADB_PATH,
            "device_id": self.adb.device_id
        })
        
        self.state = BotState.BOOTSTRAP
        self.current_quest: QuestInfo = None
        self.is_running = False
        
        # Default config
        self.config = {
            "cancel_rare_items": True,
            "cancel_phuc_duyen": True,
            "preferred_city": "Ba Lăng Huyện" # Default safe city for Da Tau
        }
        
    def start(self):
        self.is_running = True
        logger.info("="*50)
        logger.info("  STARTING DA TAU STATE MACHINE (FULL WORKFLOW)")
        logger.info("="*50)
        while self.is_running:
            try:
                self.tick()
            except Exception as e:
                logger.error(f"Lỗi State Machine: {e}")
                self._goto_state(BotState.ERROR)
            time.sleep(1)
            
    def tick(self):
        handlers = {
            BotState.BOOTSTRAP: self._handle_bootstrap,
            BotState.IDLE_PRECHECK: self._handle_idle_precheck,
            BotState.MOVE_TO_DATAU: self._handle_move_to_datau,
            BotState.READ_QUEST: self._handle_read_quest,
            BotState.EVALUATE: self._handle_evaluate,
            BotState.EXECUTE_BUY: self._handle_execute_buy,
            BotState.EXECUTE_COMBAT: self._handle_execute_combat,
            BotState.EXECUTE_FIND_ITEM: self._handle_execute_find_item,
            BotState.EXECUTE_SUBMIT_POINTS: self._handle_execute_submit_points,
            BotState.EXECUTE_DELIVER: self._handle_execute_deliver,
            BotState.CLEAR_INVENTORY: self._handle_clear_inventory,
            BotState.REWARD: self._handle_reward,
            BotState.CANCEL_QUEST: self._handle_cancel_quest,
            BotState.ERROR: self._handle_error
        }
        
        handler = handlers.get(self.state)
        if handler:
            handler()
        else:
            logger.warning(f"Chưa hỗ trợ xử lý state: {self.state}")
            self._goto_state(BotState.ERROR)

    def _goto_state(self, new_state: BotState):
        logger.info(f"[TRANSITION] {self.state.name} -> {new_state.name}")
        self.state = new_state
        time.sleep(1)

    # ---------------------------------------------------------
    # STATE HANDLERS
    # ---------------------------------------------------------
    
    def _handle_bootstrap(self):
        logger.info("[BOOTSTRAP] Khởi tạo kết nối Frida vào game...")
        if self.game_bot.connect():
            logger.info("[BOOTSTRAP] Kết nối Frida thành công!")
            self.game_bot.auto_keepalive()
            self._goto_state(BotState.IDLE_PRECHECK)
        else:
            logger.warning("[BOOTSTRAP] Kết nối Frida thất bại. Rơi vào chế độ giả lập ADB.")
            self._goto_state(BotState.IDLE_PRECHECK)
            
    def _handle_idle_precheck(self):
        logger.info("[IDLE_PRECHECK] Kiểm tra hành trang, bạc, Thổ địa phù...")
        
        # Giả lập: Nếu phát hiện túi đồ đầy (<2 ô), chuyển sang CLEAR_INVENTORY
        # if inventory_full: self._goto_state(BotState.CLEAR_INVENTORY); return
        
        logger.info("[IDLE_PRECHECK] Đồ đạc đầy đủ.")
        
        quest = self.quest_reader.read_current_quest()
        if quest and quest.is_valid:
            self.current_quest = quest
            logger.info(f"[IDLE_PRECHECK] Đang có sẵn nhiệm vụ: {quest}")
            self._goto_state(BotState.EVALUATE)
        else:
            logger.info("[IDLE_PRECHECK] Không có nhiệm vụ hiện tại.")
            self._goto_state(BotState.MOVE_TO_DATAU)

    def _chat(self, msg: str):
        logger.info(f"[CHAT] {msg}")
        if self.game_bot_connected:
            self.game_bot.chat(msg, channel=1)

    def _handle_move_to_datau(self):
        msg = f"Đang chạy tới Dã Tẩu tại {self.config['preferred_city']}"
        self._chat(msg)
        
        # Sử dụng Navigator hoặc game_bot để di chuyển
        success = self.navigator.move_to_npc("Dã Tẩu", self.config['preferred_city'])
        
        if success:
            logger.info("[MOVE_TO_DATAU] Đã tới vị trí Dã Tẩu.")
            self._goto_state(BotState.READ_QUEST)
        else:
            logger.warning("[MOVE_TO_DATAU] Lỗi di chuyển (kẹt đường/timeout). Thử lại hoặc dùng Thổ Địa Phù.")
            # Xử lý tự cứu hộ: dùng Thổ Địa Phù
            time.sleep(2)
            # Tạm thời bỏ qua
            self._goto_state(BotState.READ_QUEST)

    def _handle_read_quest(self):
        self._chat("Đang trò chuyện với Dã Tẩu để nhận/trả nhiệm vụ...")
        
        # Dọn dẹp buffer trước khi mở dialog
        self.game_bot.poll_recv()
        
        self.npc_interact.click_npc_datau()
        
        # Chờ gói tin dialog từ Dã Tẩu (eContextDescription: 166 hoặc eNpcQuest: 34)
        pkts = self.game_bot.wait_for_packet('eContextDescription', timeout=3.0)
        if not pkts:
            pkts = self.game_bot.wait_for_packet('eNpcQuest', timeout=3.0)
            
        if pkts:
            from core.quest import parse_opcode34
            quest = parse_opcode34(pkts[-1])
            if quest:
                logger.info(f"[READ_QUEST] Đã đọc được hội thoại: {quest.clean_text[:80]}...")
                
                # Nếu có nút "Nhận nhiệm vụ", click nó (giả lập click UI qua adb hoặc gửi eContextDesSelect)
                if any("Nhận nhiệm vụ" in b for b in quest.buttons):
                    # Tạm thời vẫn dùng adb tap
                    self.npc_interact.accept_quest()
                    time.sleep(2)
                
                # Cập nhật thông tin nhiệm vụ luôn từ dialog này
                self.current_quest = quest
                self._chat(f"Đã nhận nhiệm vụ mới!")
                self._goto_state(BotState.EVALUATE)
                return
                
        logger.warning("[READ_QUEST] Không bắt được gói tin nhiệm vụ. Retrying...")
        time.sleep(2)

    def _handle_evaluate(self):
        logger.info("[EVALUATE] Đánh giá độ khó và loại nhiệm vụ...")
        if not self.current_quest:
            self._goto_state(BotState.IDLE_PRECHECK)
            return
            
        q = self.current_quest
        
        # 1. Kiểm tra điều kiện Hủy NV (Hoàng Kim, Phúc Duyên)
        if self.config["cancel_rare_items"] and "hoàng kim" in q.item_name.lower():
            logger.warning("[EVALUATE] Nhiệm vụ yêu cầu đồ Hoàng Kim -> Hủy!")
            self._goto_state(BotState.CANCEL_QUEST)
            return
            
        if self.config["cancel_phuc_duyen"] and "phúc duyên" in q.item_name.lower():
            self._chat("Nhiệm vụ cần Phúc Duyên -> Hủy!")
            self._goto_state(BotState.CANCEL_QUEST)
            return
            
        # 2. Phân loại NV
        text = q.raw_text.lower() if q.raw_text else q.item_name.lower()
        if any(kw in text for kw in ["tìm", "mua", "hệ"]):
            self._goto_state(BotState.EXECUTE_BUY)
        elif any(kw in text for kw in ["tiêu diệt", "đánh bại", "hạ gục", "quái"]):
            self._goto_state(BotState.EXECUTE_COMBAT)
        elif "mật chí" in text or "đồ chí" in text:
            self._goto_state(BotState.EXECUTE_FIND_ITEM)
        elif "nộp" in text:
            self._goto_state(BotState.EXECUTE_SUBMIT_POINTS)
        elif "gặp" in text or "giao" in text:
            self._goto_state(BotState.EXECUTE_DELIVER)
        else:
            logger.info("[EVALUATE] Mặc định chuyển sang hệ thống Mua Đồ / Thu Thập.")
            self._goto_state(BotState.EXECUTE_BUY)

    def _handle_execute_buy(self):
        q = self.current_quest
        self._chat(f"Nhiệm vụ mua đồ: Cần tìm mua {q.item_count}x {q.item_name} (Hệ {q.element})")
        
        target_city = self.config['preferred_city']
        
        logger.info(f"[EXECUTE_BUY] 1. Di chuyển ra Tạp Hóa / Thợ Rèn tại {target_city}")
        if "vũ khí" in q.item_name.lower() or "quần áo" in q.item_name.lower():
            self._chat("Đang chạy tới Thợ Rèn mua trang bị...")
            self.navigator.move_to_npc("Thợ rèn", target_city)
        else:
            self._chat("Đang chạy tới Tạp Hóa mua đồ...")
            self.navigator.move_to_npc("Tạp hóa", target_city)
            
        if self.game_bot_connected:
            self.game_bot.send_gs('eNpcDialog') # Mở shop
            
        logger.info("[EXECUTE_BUY] 2. Mở Shop Tạp Hóa / Thợ Rèn, Liên tục mua và roll Hệ Ngũ Hành...")
        time.sleep(3) # TODO: Hook eBuyItem from RPC
        
        self._chat("Đã mua xong vật phẩm yêu cầu, chuẩn bị về thành!")
        self._goto_state(BotState.REWARD)

    def _navigate_xa_phu_to_map(self, target_map: str):
        self.game_bot.poll_recv() # Clear buffer
        self.game_bot.send_gs('eNpcDialog') # Mở hội thoại Xa Phu
        
        from core.quest import parse_opcode34
        # 1. Chờ hội thoại Xa Phu
        pkts = self.game_bot.wait_for_packet('eContextDescription', timeout=3.0)
        if not pkts: return False
        dialog = parse_opcode34(pkts[-1])
        if not dialog: return False
        
        # Tìm "Khu vực luyện công"
        idx = -1
        for i, b in enumerate(dialog.buttons):
            if "luyện công" in b.lower():
                idx = i
                break
        if idx == -1: return False
        self.game_bot.send_gs('eContextDesSelect', selectIndex=idx)
        
        # 2. Chờ list cấp độ
        pkts = self.game_bot.wait_for_packet('eContextDescription', timeout=3.0)
        if not pkts: return False
        dialog = parse_opcode34(pkts[-1])
        if not dialog: return False
        
        level_menus = [b for b in dialog.buttons if "Khu vực cấp" in b or "cấp" in b.lower()]
        
        if not target_map:
            logger.warning("Không rõ map cần đến!")
            return False
        
        logger.info(f"Target map cần đến: {target_map}")
        
        # 3. Duyệt từng list cấp độ để tìm map
        for i, lvl_menu in enumerate(level_menus):
            self.game_bot.send_gs('eContextDesSelect', selectIndex=i)
            pkts = self.game_bot.wait_for_packet('eContextDescription', timeout=3.0)
            if not pkts: continue
            map_dialog = parse_opcode34(pkts[-1])
            if not map_dialog: continue
            
            # Tìm map
            for j, m_btn in enumerate(map_dialog.buttons):
                if target_map.lower() in m_btn.lower():
                    self.game_bot.send_gs('eContextDesSelect', selectIndex=j)
                    return True
            
            # Nếu không thấy, nhấn "Trở lại" (dòng cuối cùng)
            self.game_bot.send_gs('eContextDesSelect', selectIndex=len(map_dialog.buttons)-1)
            self.game_bot.wait_for_packet('eContextDescription', timeout=3.0)
            
        return False

    def _handle_execute_combat(self):
        self._chat(f"Nhiệm vụ đánh quái: Chuẩn bị đi tiêu diệt {self.current_quest.item_name}")
        
        # Di chuyển tới Xa Phu
        self.navigator.move_to_npc("Xa phu", self.config['preferred_city'])
        
        self._chat("Đã tới Xa Phu (Dịch trạm), đang xin phép tới bãi làm nhiệm vụ...")
        if self.game_bot_connected:
            target_map = getattr(self.current_quest, "target_map", "")
            if self._navigate_xa_phu_to_map(target_map):
                logger.info(f"[EXECUTE_COMBAT] Đã gửi lệnh chọn Map {target_map} thành công!")
            else:
                logger.warning(f"[EXECUTE_COMBAT] Không tìm thấy map {target_map} trong Xa Phu!")
            
        time.sleep(4) # Chờ load map
        
        self._chat("Bắt đầu Auto-Combat đập quái!")
        if self.game_bot_connected:
            self.game_bot.send_gs('eToggleAutoCombat')
            
        time.sleep(3)
        self._chat("Đã xong chỉ tiêu đánh quái, về thành báo cáo!")
        self._goto_state(BotState.REWARD)

    def _handle_execute_find_item(self):
        self._chat("Nhiệm vụ tìm Đồ Chí/Mật Chí: Lên đường sang bãi cày...")
        # Sử dụng Dịch trạm (Xa phu)
        self.navigator.move_to_npc("Xa phu", self.config['preferred_city'])
        
        self._chat("Đã tới Xa Phu (Dịch trạm), đang xin phép tới bãi làm nhiệm vụ...")
        if self.game_bot_connected:
            target_map = getattr(self.current_quest, "target_map", "")
            if self._navigate_xa_phu_to_map(target_map):
                logger.info(f"[EXECUTE_FIND_ITEM] Đã gửi lệnh chọn Map {target_map} thành công!")
            else:
                logger.warning(f"[EXECUTE_FIND_ITEM] Không tìm thấy map {target_map} trong Xa Phu!")
            
        time.sleep(4) # Chờ load map
        
        self._chat("Tạo tổ đội và bắt đầu cày đồ!")
        if self.game_bot_connected:
            self.game_bot.send_gs('eTeamCreate')
            self.game_bot.send_gs('eToggleAutoCombat')
            
        logger.info("[EXECUTE_FIND_ITEM] Bật Auto-Combat & Tự động nhặt đồ...")
        time.sleep(3)
        self._chat("Đã rớt Mật Chí/Đồ Chí, nhặt xong, về thôi!")
        self._goto_state(BotState.REWARD)

    def _handle_execute_submit_points(self):
        self._chat("Nhiệm vụ nộp điểm: Chạy lại Dã Tẩu nộp tiền/điểm...")
        self.navigator.move_to_npc("Dã Tẩu", self.config['preferred_city'])
        self._goto_state(BotState.REWARD)

    def _handle_execute_deliver(self):
        self._chat(f"Nhiệm vụ giao thư: Đang chạy tìm NPC {self.current_quest.item_name}...")
        self.navigator.move_to_npc(self.current_quest.item_name, self.config['preferred_city'])
        self._goto_state(BotState.REWARD)

    def _handle_clear_inventory(self):
        self._chat("Hành trang đã đầy, đang đi cất đồ vào rương!")
        logger.info("  -> Chạy tới Quản lý Rương (Stash). Gửi đồ có giá trị.")
        self.navigator.move_to_npc("Tiền Trang Huyện", self.config['preferred_city'])
        if self.game_bot_connected:
            self.game_bot.send_gs('eNpcDialog')
        time.sleep(2)
        
        self._chat("Đang tạt qua Tạp Hóa bán rác...")
        self.navigator.move_to_npc("Tạp hóa", self.config['preferred_city'])
        if self.game_bot_connected:
            self.game_bot.send_gs('eNpcDialog')
        time.sleep(2)
        
        self._chat("Dọn dẹp xong xuôi, chuẩn bị làm việc tiếp!")
        self._goto_state(BotState.IDLE_PRECHECK)

    def _handle_cancel_quest(self):
        self._chat("Hủy nhiệm vụ Dã Tẩu vì quá khó hoặc lỗ vốn!")
        # Tìm đường về Dã Tẩu
        self.navigator.move_to_npc("Dã Tẩu", self.config['preferred_city'])
        self.npc_interact.click_npc_datau()
        time.sleep(1)
        # Bấm nút Hủy
        logger.info("[CANCEL_QUEST] Đã click nút Hủy. Đứt chuỗi nhiệm vụ.")
        self.current_quest = None
        self._goto_state(BotState.IDLE_PRECHECK)

    def _handle_reward(self):
        self._chat("Về gặp Dã Tẩu nhận thưởng nào!")
        self.navigator.move_to_npc("Dã Tẩu", self.config['preferred_city'])
        
        logger.info("[REWARD] Click Trả Nhiệm Vụ.")
        self.npc_interact.click_npc_datau()
        
        # Chọn phần thưởng ưu tiên
        logger.info("[REWARD] Tự động chọn phần thưởng (Kinh nghiệm / Bạc / Vật phẩm).")
        self.current_quest = None
        
        logger.info("Hoàn thành 1 vòng Dã Tẩu. Trở lại kiểm tra...")
        self._goto_state(BotState.IDLE_PRECHECK)

    def _handle_error(self):
        logger.error("State Machine đã dừng hoàn toàn.")
        self.is_running = False

    @property
    def game_bot_connected(self):
        return self.game_bot.running

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S")
    adb = ADBHelper()
    sm = DaTauStateMachine(adb)
    sm.start()
