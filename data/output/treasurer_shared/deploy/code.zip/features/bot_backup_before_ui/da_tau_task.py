import os
import sys
import time
import logging
from typing import Optional

# Add project root to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from core.quest import QuestReader, QuestInfo
from core.adb_helper import ADBHelper
from features.bot.game_bot import VLTK1Bot

logger = logging.getLogger("da_tau_bot")

class DaTauBot:
    """
    Quản lý luồng thực thi nhiệm vụ Dã Tẩu tự động.
    """
    def __init__(self, adb: ADBHelper):
        self.adb = adb
        self.game_bot = VLTK1Bot()
        self.game_bot_connected = False
        
        # Cấu hình QuestReader để đọc dữ liệu nhiệm vụ qua mạng
        self.quest_reader = QuestReader({
            "adb_path": self.adb.adb if hasattr(self.adb, 'adb') else r"C:\platform-tools\adb.exe",
            "device_id": self.adb.device_id
        })
        
        # Sửa lại adb_path cho đúng vì ADBHelper dùng ADB_PATH
        from core.adb_helper import ADB_PATH
        self.quest_reader.adb = ADB_PATH

        self.current_quest: Optional[QuestInfo] = None

    def check_quest_state(self) -> bool:
        """
        Bước 1: Khởi tạo và kiểm tra trạng thái nhiệm vụ hiện tại.
        Trả về True nếu đang có nhiệm vụ, False nếu chưa có.
        """
        logger.info("="*50)
        logger.info("[STEP 1] KHỞI TẠO & KIỂM TRA TRẠNG THÁI NHIỆM VỤ")
        logger.info("="*50)
        
        logger.info("Đang đọc gói tin từ game để lấy thông tin nhiệm vụ...")
        
        # Gọi hàm read_current_quest (Mặc định sẽ capture passive 3s)
        # Nếu muốn chính xác hơn có thể click vào nút mở bảng NV trước.
        quest = self.quest_reader.read_current_quest()
        
        if quest and quest.is_valid:
            self.current_quest = quest
            logger.info("✅ KẾT QUẢ: ĐANG CÓ NHIỆM VỤ DÃ TẨU!")
            logger.info(f"   - Tên nhiệm vụ: Nhiệm vụ thứ {quest.quest_number}")
            logger.info(f"   - Yêu cầu: Tìm {quest.item_count}x {quest.item_name} (Hệ: {quest.element})")
            if quest.remaining > 0:
                logger.info(f"   - Trạng thái chuỗi: Còn {quest.remaining} nhiệm vụ nữa")
            
            # Ghi log thêm tọa độ NPC giao nhiệm vụ nếu có
            if quest.npc_world_x > 0:
                gx, gy = quest.npc_game_coords
                logger.info(f"   - NPC trả nhiệm vụ ở tọa độ: ({gx}, {gy})")
                
            # Gửi thông báo chat vào trong game
            self._send_chat_notification(f"NV Da Tau: {quest.item_count}x {quest.item_name} ({quest.element})")
                
            return True
        else:
            logger.info("❌ KẾT QUẢ: KHÔNG TÌM THẤY NHIỆM VỤ DÃ TẨU NÀO ĐANG NHẬN.")
            self.current_quest = None
            
            self._send_chat_notification("Hien tai khong co nhiem vu Da Tau.")
            
            return False

    def _send_chat_notification(self, message: str):
        """Kết nối Frida và gửi một đoạn chat vào trong game."""
        if not self.game_bot_connected:
            logger.info("Đang kết nối bot vào game để gửi chat...")
            if self.game_bot.connect():
                self.game_bot_connected = True
            else:
                logger.warning("Không thể kết nối game_bot để gửi chat.")
                return
        
        # Gửi chat lên kênh lân cận (channel=1) hoặc kênh hệ thống/đội
        # Ở đây dùng tiếng Việt không dấu để tránh lỗi font game nếu có
        self.game_bot.chat(message, channel=1)

if __name__ == "__main__":
    # Test nhanh Step 1
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S")
    
    adb_helper = ADBHelper()
    
    bot = DaTauBot(adb_helper)
    bot.check_quest_state()
