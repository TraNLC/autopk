/*
frida_bot.js – VLTK1 Bot socket injector (v3 - clean)

Key discovery: On Houdini x86 emulators, libc functions from ARM libraries
are not callable. Use write() from app_process32 (x86, rwx) instead.

Packet format (confirmed via disassembly):
  [uint32 LE proto_len] [uint16 LE opcode] [proto body]
*/

'use strict';

// ==================== GLOBALS ====================
var gameFd = -1;
var gameFdAutoLocked = false;   // chỉ auto-khóa fd ĐÚNG 1 LẦN (tránh flood/oscillate)
var _captureAllSends = false;   // CHẨN ĐOÁN: bắt gói GỬI trên MỌI fd (không chỉ gameFd) — để dò opcode/fd cú cast tay. Mặc định TẮT (giữ hiệu năng).
// Opcode SERVER hay GỬI cho client (sync/data) -> dùng để nhận diện ĐÚNG game socket.
// (KHÔNG dùng opcode 0=eUnidentified vì là rác, gây khóa nhầm fd.)
var SERVER_PUSH_OPS = {7:1,8:1,9:1,16:1,17:1,18:1,19:1,20:1,23:1,54:1,63:1,66:1,
                       72:1,118:1,124:1,125:1,126:1,166:1,205:1,245:1};
var recvBuffer = [];
var sendBuffer = [];
var op48Buffer = [];   // buffer RIÊNG cho opcode 48 (thông báo nhặt đồ - đồ chí) -> opcode 9/133 KHÔNG đẩy được ra
var op54Buffer = [];   // buffer RIÊNG cho opcode 54 (quest tracker - bảng nhiệm vụ) -> bắt ĐỔI NV passive (không re-open Dã Tẩu)
var dialogBuffer = []; // buffer RIÊNG cho gói HỘI THOẠI/THƯỞNG Dã Tẩu (34/124/126/166/245) -> ở THÀNH ĐÔNG op9
                       // eStringData lụt đẩy tràn recvBuffer (cap 3000) làm MẤT gói trả lời dialog -> "đọc hụt tiến độ,
                       // phải focus mới bắt". Giữ riêng đây để KHÔNG bị op9 đẩy ra. (root cause 2026-06-16)
var _playerMainInstance = null;
var _lastPosition = { x: 0, y: 0, eid: '', ts: 0 };
var _sslReadOk = false;
var _sslWriteOk = false;
var _sslError = '';
var _sslWriteFn = null;  // NativeFunction for SSL_write
var _sslObj = null;      // SSL* object pointer captured from game's SSL_write calls
var _recvTotal = 0;
var _recvAny = 0;        // ĐẾM recv trên MỌI fd (chẩn đoán: game có nhận gói nào không)
var _fdsSeen = {};       // fd -> số lần recv (xem data về trên fd nào)
var _fdsGameOps = {};    // fd -> số recv mang OPCODE GAME HỢP LỆ (parse được) = bằng chứng fd game thật
var _lastOps = [];       // mẫu 'fd:opcode' gần nhất (xem gói gì, fd nào)
var _sendTotal = 0;

// ==================== FIND EXECUTABLE write() AND read() ====================
var nativeWrite = null;
var nativeWritePtr = null;
var nativeReadPtr = null;
var writeSource = 'none';
var readSource = 'none';

(function findExecutableFunctions() {
    var mods = Process.enumerateModules();
    for (var i = 0; i < mods.length; i++) {
        var m = mods[i];
        try {
            // Find write
            if (!nativeWritePtr) {
                var wexp = m.findExportByName('write');
                if (wexp) {
                    var wrange = Process.findRangeByAddress(wexp);
                    if (wrange && wrange.protection.indexOf('x') !== -1) {
                        nativeWritePtr = wexp;
                        nativeWrite = new NativeFunction(wexp, 'int', ['int', 'pointer', 'int']);
                        writeSource = m.name + ' @ ' + wexp + ' (' + wrange.protection + ')';
                    }
                }
            }
            // Find read (same approach as write — needed for Houdini ARM translation)
            if (!nativeReadPtr) {
                var rexp = m.findExportByName('read');
                if (rexp) {
                    var rrange = Process.findRangeByAddress(rexp);
                    if (rrange && rrange.protection.indexOf('x') !== -1) {
                        nativeReadPtr = rexp;
                        readSource = m.name + ' @ ' + rexp + ' (' + rrange.protection + ')';
                    }
                }
            }
        } catch(e) {}
    }
})();

// ==================== HELPERS ====================
function toHex(arr, maxBytes) {
    var n = Math.min(arr.length, maxBytes || arr.length);
    var result = '';
    for (var i = 0; i < n; i++) {
        result += ('0' + arr[i].toString(16)).slice(-2);
    }
    return result;
}

// ==================== OPCODE MAP ====================
var GS_OPCODES = {
    0: 'eUnidentified',
    1: 'ePlayerLoginRequest',    2: 'ePlayerLoginResponse',
    3: 'eEnterWorldSuccess',     4: 'eCharacterDetailResponse',
    5: 'eSkillResponse',         6: 'eItemResponse',
    7: 'eEnterMap',              8: 'eEnterGameServer',
    9: 'eStringData',            10: 'eDelivered',
    13: 'eJumToMap',             20: 'eSyncPlayerMove',
    23: 'eSyncDamage',           33: 'eNpcDialogue',
    34: 'eNpcQuest',             35: 'eNpcSelect',
    40: 'eCastSkill',            48: 'ePlayerTalk',
    49: 'ePlayerUserItem',       54: 'eAddMapObject',
    56: 'eObjectPickup',         58: 'eSetRiding',
    69: 'ePing',                 70: 'ePong',
    71: 'eMapDialogNpcListRequest',
    72: 'eMapDialogNpcListResponse',
    117: 'eSwitchWalking',
    122: 'eTownportal',
    132: 'eChatSend',            133: 'eChatMessage',
    140: 'eApplyAutoplayProfile',
    172: 'eEnterTongMap',        188: 'eSelfRevertMap',
    231: 'eGotoNpc',
    238: 'eDoSkillTargetPlayer', 239: 'eDoSkillTargetNpc',
    240: 'eDoSkillTargetPosition',
    248: 'eGotoPosition',
};

// ==================== SOCKET HOOKS ====================
try {
    var libc = Process.findModuleByName('libc.so');
    if (!libc) throw new Error('libc not found');

    var connectAddr  = libc.findExportByName('connect');
    var recvAddr     = libc.findExportByName('recv');
    var readAddr     = libc.findExportByName('read');
    var recvfromAddr = libc.findExportByName('recvfrom');
    var sendAddr     = libc.findExportByName('send');
    var sendtoAddr   = libc.findExportByName('sendto');
    var writevAddr   = libc.findExportByName('writev');
    var sendmsgAddr  = libc.findExportByName('sendmsg');

    // Hook connect() to auto-detect game fd
    if (connectAddr) {
        Interceptor.attach(connectAddr, {
            onEnter: function(args) {
                this.fd = args[0].toInt32();
                var sockaddr = args[1];
                try {
                    var family = sockaddr.readU16();
                    if (family === 2) { // AF_INET
                        var port = (sockaddr.add(2).readU8() << 8) | sockaddr.add(3).readU8();
                        var ip = sockaddr.add(4).readU8() + '.' + sockaddr.add(5).readU8() +
                                 '.' + sockaddr.add(6).readU8() + '.' + sockaddr.add(7).readU8();
                        if (port > 1000 && port !== 5555 && port !== 5037 && port !== 27042) {
                            gameFd = this.fd;
                            send({ type: 'game_fd', fd: gameFd, ip: ip, port: port });
                        }
                    }
                } catch(e) {}
            }
        });
    }

    // Recv handler – buffer ALL incoming packets and send to Python
    function onRecvEnter(args) {
        this.fd  = args[0].toInt32();
        this.buf = args[1];
    }
    function onRecvLeave(retval) {
        var n = retval.toInt32();
        if (n <= 0) return;
        // PERF: chỉ đọc 6 BYTE HEADER để lấy opcode (nhẹ) — TRÁNH copy TOÀN BỘ buffer cho gói noise của
        // các fd KHÁC (nhiều socket traffic cao). Chỉ gameFd mới đọc full buffer + tính hex.
        var opcode = -1, plen = -1;
        if (n >= 6) {
            try {
                var hdr = new Uint8Array(this.buf.readByteArray(6));
                plen = hdr[0] | (hdr[1] << 8) | (hdr[2] << 16) | (hdr[3] << 24);
                opcode = hdr[4] | (hdr[5] << 8);
            } catch (e) { return; }
        }
        // CHẨN ĐOÁN nhẹ (mọi fd) — để dò gameFd khi cần.
        _recvAny++;
        _fdsSeen[this.fd] = (_fdsSeen[this.fd] || 0) + 1;
        if (opcode >= 0) { _lastOps.push(this.fd + ':' + opcode); if (_lastOps.length > 24) _lastOps.shift(); }
        if (opcode > 0 && GS_OPCODES[opcode] && plen >= 0 && plen <= n) _fdsGameOps[this.fd] = (_fdsGameOps[this.fd] || 0) + 1;
        // FAST EXIT: gói của fd KHÁC gameFd -> bỏ NGAY, KHÔNG copy full buffer (giảm tải lớn khi đông).
        if (this.fd !== gameFd) return;
        var data;
        try { data = new Uint8Array(this.buf.readByteArray(n)); } catch (e) { return; }
        try {
            var hex  = toHex(data, 8192);   // bump 512->8192: shop thợ rèn nhiều món > 512B sẽ bị cắt mất item
            var name = (n >= 6) ? (GS_OPCODES[opcode] || ('UNK_' + opcode)) : 'raw';
            var pkt = { opcode: opcode, name: name, size: n, hex: hex, raw: hex };
            recvBuffer.push(pkt);
            _recvTotal++;
            if (recvBuffer.length > 3000) recvBuffer.shift();
            if (opcode === 48) { op48Buffer.push(hex); if (op48Buffer.length > 200) op48Buffer.shift(); }
            if (opcode === 54) { op54Buffer.push(hex); if (op54Buffer.length > 300) op54Buffer.shift(); }
            if (opcode === 34 || opcode === 124 || opcode === 126 || opcode === 166 || opcode === 245 || opcode === 79) {
                dialogBuffer.push(pkt); if (dialogBuffer.length > 300) dialogBuffer.shift();   // +79 ePartyInvite (auto-accept tổ đội)
            }
            // (BỎ push 'recv' mỗi gói -> tránh flood message gây LAG UI; bot đọc qua get_recv_packets/PULL)
            // Log Shop data for item index discovery
            if (opcode === 119 || opcode === 120 || opcode === 212) {
                send({ type: 'shop_data', opcode: opcode, name: name, hex: hex });
            }

            // Track entity position từ opcode 9. THROTTLE: chỉ parse mỗi ~0.8s (eStringData rất nhiều khi đông
            // người) -> giảm vòng lặp byte trên thread game. Vị trí chính bot đọc qua get_player_info (PlayerMain).
            if (opcode === 9 && n > 10 && (Date.now() - (_lastPosition.ts || 0) > 800)) {
                try {
                    var bodyStr = '';
                    for (var bi = 6; bi < n; bi++) {
                        bodyStr += String.fromCharCode(data[bi]);
                    }
                    var sparts = bodyStr.split('|');
                    if (sparts.length >= 4) {
                        var et = parseInt(sparts[0]);
                        if (et === 1 || et === 2) {
                            var ex = parseInt(sparts[2]);
                            var ey = parseInt(sparts[3]);
                            if (ex > 0 && ey > 0) {
                                _lastPosition = { x: ex, y: ey, eid: sparts[1], ts: Date.now() };
                            }
                        }
                    }
                } catch(ee) {}
            }
        } catch(e) {}
    }

    if (recvAddr)     Interceptor.attach(recvAddr,     { onEnter: onRecvEnter, onLeave: onRecvLeave });
    if (readAddr)     Interceptor.attach(readAddr,     { onEnter: onRecvEnter, onLeave: onRecvLeave });
    // CRITICAL: Game uses recvfrom() not recv()! recvfrom(fd, buf, len, flags, src_addr, addrlen)
    if (recvfromAddr) Interceptor.attach(recvfromAddr, { onEnter: onRecvEnter, onLeave: onRecvLeave });
    // CRITICAL: On Houdini x86, ARM code goes through translation layer.
    // nativeReadPtr is the executable read() from app_process32/Houdini that ARM code actually calls.
    if (nativeReadPtr) {
        Interceptor.attach(nativeReadPtr, { onEnter: onRecvEnter, onLeave: onRecvLeave });
    }

    // ==================== HOOK write() FOR OUTGOING PACKETS ====================
    if (nativeWritePtr) {
        Interceptor.attach(nativeWritePtr, {
            onEnter: function(args) {
                this.fd = args[0].toInt32();
                this.buf = args[1];
                this.len = args[2].toInt32();
            },
            onLeave: function(retval) {
                var n = retval.toInt32();
                if (n <= 0) return;
                // CHỐNG WIPE LÚC LOGIN: lúc vừa vào thế giới gameFd CHƯA lock -> op140-rỗng (client tự bật auto)
                // gửi trên fd "lạ" sẽ bị bỏ qua -> WIPE-DETECT mù. => Với fd KHÁC gameFd: VẪN soi op140 (peek 6B)
                // để emit cho WIPE-DETECT bắt được. fd khác + không-op140 -> bỏ qua như cũ (giữ hiệu năng).
                if (this.fd !== gameFd && !_captureAllSends) {
                    try {
                        if (n < 6) return;
                        var h6 = new Uint8Array(this.buf.readByteArray(6));
                        if ((h6[4] | (h6[5] << 8)) !== 140) return;
                    } catch (e) { return; }
                }
                try {
                    var data = new Uint8Array(this.buf.readByteArray(n));
                    var hex = toHex(data, 256);
                    var opcode = -1;
                    var name = 'raw';
                    if (n >= 6) {
                        opcode = data[4] | (data[5] << 8);
                        name = GS_OPCODES[opcode] || ('UNK_' + opcode);
                    }
                    var pkt = { opcode: opcode, name: name, size: n, hex: hex };
                    sendBuffer.push(pkt);
                    _sendTotal++;
                    if (sendBuffer.length > 100) sendBuffer.shift();
                    send({ type: 'send_out', opcode: opcode, name: name, size: n, hex: hex });
                } catch(e) {}
            }
        });
    }

    if (sendAddr) {
        Interceptor.attach(sendAddr, {
            onEnter: function(args) {
                this.fd = args[0].toInt32();
                this.buf = args[1];
                this.len = args[2].toInt32();
            },
            onLeave: function(retval) {
                var n = retval.toInt32();
                if (n <= 0) return;
                // CHỐNG WIPE LÚC LOGIN: lúc vừa vào thế giới gameFd CHƯA lock -> op140-rỗng (client tự bật auto)
                // gửi trên fd "lạ" sẽ bị bỏ qua -> WIPE-DETECT mù. => Với fd KHÁC gameFd: VẪN soi op140 (peek 6B)
                // để emit cho WIPE-DETECT bắt được. fd khác + không-op140 -> bỏ qua như cũ (giữ hiệu năng).
                if (this.fd !== gameFd && !_captureAllSends) {
                    try {
                        if (n < 6) return;
                        var h6 = new Uint8Array(this.buf.readByteArray(6));
                        if ((h6[4] | (h6[5] << 8)) !== 140) return;
                    } catch (e) { return; }
                }
                try {
                    var data = new Uint8Array(this.buf.readByteArray(n));
                    var hex = toHex(data, 256);
                    var opcode = -1;
                    var name = 'raw';
                    if (n >= 6) {
                        opcode = data[4] | (data[5] << 8);
                        name = GS_OPCODES[opcode] || ('UNK_' + opcode);
                    }
                    var pkt = { opcode: opcode, name: name, size: n, hex: hex };
                    sendBuffer.push(pkt);
                    _sendTotal++;
                    if (sendBuffer.length > 100) sendBuffer.shift();
                    send({ type: 'send_out', opcode: opcode, name: name, size: n, hex: hex });
                } catch(e) {}
            }
        });
    }

    // GAME GỬI qua sendto() (cặp với recvfrom) — TRƯỚC ĐÂY KHÔNG hook nên trượt hết gói gửi của game.
    // sendto(fd, buf, len, flags, dest, addrlen) -> 3 arg đầu giống send. An toàn (lọc fd===gameFd).
    if (sendtoAddr) {
        Interceptor.attach(sendtoAddr, {
            onEnter: function(args) {
                this.fd = args[0].toInt32();
                this.buf = args[1];
                this.len = args[2].toInt32();
            },
            onLeave: function(retval) {
                var n = retval.toInt32();
                if (n <= 0) return;
                // CHỐNG WIPE LÚC LOGIN: lúc vừa vào thế giới gameFd CHƯA lock -> op140-rỗng (client tự bật auto)
                // gửi trên fd "lạ" sẽ bị bỏ qua -> WIPE-DETECT mù. => Với fd KHÁC gameFd: VẪN soi op140 (peek 6B)
                // để emit cho WIPE-DETECT bắt được. fd khác + không-op140 -> bỏ qua như cũ (giữ hiệu năng).
                if (this.fd !== gameFd && !_captureAllSends) {
                    try {
                        if (n < 6) return;
                        var h6 = new Uint8Array(this.buf.readByteArray(6));
                        if ((h6[4] | (h6[5] << 8)) !== 140) return;
                    } catch (e) { return; }
                }
                try {
                    var data = new Uint8Array(this.buf.readByteArray(n));
                    var hex = toHex(data, 256);
                    var opcode = -1;
                    var name = 'raw';
                    if (n >= 6) {
                        opcode = data[4] | (data[5] << 8);
                        name = GS_OPCODES[opcode] || ('UNK_' + opcode);
                    }
                    var pkt = { opcode: opcode, name: name, size: n, hex: hex };
                    sendBuffer.push(pkt);
                    _sendTotal++;
                    if (sendBuffer.length > 100) sendBuffer.shift();
                    send({ type: 'send_out', opcode: opcode, name: name, size: n, hex: hex });
                } catch(e) {}
            }
        });
    }

    // Game CÓ THỂ gửi qua writev()/sendmsg() (scatter-gather) — nhiều lib mạng dùng. Đọc iovec ĐẦU.
    // iovec 64-bit: { void* base @0; size_t len @8 }. msghdr.msg_iov @0x10.
    function emitFromBuf(base, n) {
        try {
            var take = n < 512 ? n : 512;
            var data = new Uint8Array(base.readByteArray(take));
            var opcode = -1, name = 'raw';
            if (take >= 6) { opcode = data[4] | (data[5] << 8); name = GS_OPCODES[opcode] || ('UNK_' + opcode); }
            var hex = toHex(data, 256);
            sendBuffer.push({ opcode: opcode, name: name, size: n, hex: hex });
            _sendTotal++;
            if (sendBuffer.length > 100) sendBuffer.shift();
            send({ type: 'send_out', opcode: opcode, name: name, size: n, hex: hex });
        } catch (e) {}
    }
    if (writevAddr) {
        Interceptor.attach(writevAddr, {
            onEnter: function(args) { this.fd = args[0].toInt32(); this.iov = args[1]; },
            onLeave: function(retval) {
                var n = retval.toInt32();
                if (n <= 0 || this.fd !== gameFd) return;
                try { emitFromBuf(this.iov.readPointer(), n); } catch (e) {}
            }
        });
    }
    if (sendmsgAddr) {
        Interceptor.attach(sendmsgAddr, {
            onEnter: function(args) { this.fd = args[0].toInt32(); this.msg = args[1]; },
            onLeave: function(retval) {
                var n = retval.toInt32();
                if (n <= 0 || this.fd !== gameFd) return;
                try {
                    var iov = this.msg.add(0x10).readPointer();   // msghdr.msg_iov
                    emitFromBuf(iov.readPointer(), n);
                } catch (e) {}
            }
        });
    }

    // ==================== SSL HOOKS (game uses SSL!) ====================
    // NOTE: Module.findExportByName('libssl.so', ...) returns null on Houdini x86.
    // We must use enumerateExports() to find the actual addresses.
    try {
        var sslReadAddr = null;
        var sslWriteAddr = null;
        var sslMod = Process.findModuleByName('libssl.so');
        if (sslMod) {
            var sslExports = sslMod.enumerateExports();
            for (var ei = 0; ei < sslExports.length; ei++) {
                if (sslExports[ei].name === 'SSL_read') sslReadAddr = sslExports[ei].address;
                if (sslExports[ei].name === 'SSL_write') sslWriteAddr = sslExports[ei].address;
            }
        }
        
        if (sslReadAddr) {
            Interceptor.attach(sslReadAddr, {
                onEnter: function(args) {
                    this.ssl = args[0];
                    this.buf = args[1];
                    this.len = args[2].toInt32();
                },
                onLeave: function(retval) {
                    var n = retval.toInt32();
                    if (n <= 0) return;
                    _sslReadOk = true;
                    try {
                        var data = new Uint8Array(this.buf.readByteArray(n));
                        var hex = toHex(data, 512);
                        var opcode = -1;
                        var name = 'raw';
                        if (n >= 6) {
                            opcode = data[4] | (data[5] << 8);
                            name = GS_OPCODES[opcode] || ('UNK_' + opcode);
                        }
                        var pkt = { opcode: opcode, name: name, size: n, hex: hex, raw: hex };
                        recvBuffer.push(pkt);
                        _recvTotal++;
                        if (recvBuffer.length > 3000) recvBuffer.shift();
                        if (opcode === 48) { op48Buffer.push(hex); if (op48Buffer.length > 200) op48Buffer.shift(); }
                        if (opcode === 54) { op54Buffer.push(hex); if (op54Buffer.length > 300) op54Buffer.shift(); }
            if (opcode === 34 || opcode === 124 || opcode === 126 || opcode === 166 || opcode === 245 || opcode === 79) {
                dialogBuffer.push(pkt); if (dialogBuffer.length > 300) dialogBuffer.shift();   // +79 ePartyInvite (auto-accept tổ đội)
            }
                        // (BỎ push 'recv' mỗi gói -> tránh flood message gây LAG UI; bot đọc qua get_recv_packets/PULL)

                        // Track position from opcode 9
                        if (opcode === 9 && n > 10) {
                            try {
                                var bodyStr = '';
                                for (var bi = 6; bi < n; bi++) {
                                    bodyStr += String.fromCharCode(data[bi]);
                                }
                                var sparts = bodyStr.split('|');
                                if (sparts.length >= 4) {
                                    var et = parseInt(sparts[0]);
                                    if (et === 1 || et === 2) {
                                        var ex = parseInt(sparts[2]);
                                        var ey = parseInt(sparts[3]);
                                        if (ex > 0 && ey > 0) {
                                            _lastPosition = { x: ex, y: ey, eid: sparts[1], ts: Date.now() };
                                        }
                                    }
                                }
                            } catch(ee) {}
                        }
                    } catch(e) {}
                }
            });
        }
        
        if (sslWriteAddr) {
            // Store the SSL_write function pointer for sslSend()
            _sslWriteFn = new NativeFunction(sslWriteAddr, 'int', ['pointer', 'pointer', 'int']);
            
            Interceptor.attach(sslWriteAddr, {
                onEnter: function(args) {
                    this.ssl = args[0];
                    this.buf = args[1];
                    this.len = args[2].toInt32();
                    // Capture the SSL object pointer for later use in sslSend()
                    if (!_sslObj) {
                        _sslObj = args[0];
                        send({ type: 'info', msg: 'SSL object captured: ' + _sslObj });
                    }
                },
                onLeave: function(retval) {
                    var n = retval.toInt32();
                    if (n <= 0) return;
                    try {
                        var data = new Uint8Array(this.buf.readByteArray(n));
                        var hex = toHex(data, 256);
                        var opcode = -1;
                        var name = 'raw';
                        if (n >= 6) {
                            opcode = data[4] | (data[5] << 8);
                            name = GS_OPCODES[opcode] || ('UNK_' + opcode);
                        }
                        var pkt = { opcode: opcode, name: name, size: n, hex: hex };
                        sendBuffer.push(pkt);
                        _sendTotal++;
                        if (sendBuffer.length > 100) sendBuffer.shift();
                        _sslWriteOk = true;
                        send({ type: 'send_out', opcode: opcode, name: name, size: n, hex: hex });
                    } catch(e) {}
                }
            });
        }
        
        send({ type: 'ssl_hooks', sslRead: !!sslReadAddr, sslWrite: !!sslWriteAddr });
    } catch(e) {
        _sslError = e.toString();
        send({ type: 'ssl_hooks', error: e.toString() });
    }

    send({ type: 'ready', hooks: {
        connect: !!connectAddr, recv: !!recvAddr, read: !!readAddr,
        recvfrom: !!recvfromAddr,
        nativeRead: !!nativeReadPtr, readSource: readSource,
        write: !!nativeWrite, writeSource: writeSource
    }});

} catch(e) {
    send({ type: 'error', msg: e.toString() + '\n' + e.stack });
}

// ==================== IL2CPP ====================
function getIl2CppBase() {
    var base = null;
    var lines = File.readAllText('/proc/self/maps').split('\n');
    for (var i = 0; i < lines.length; i++) {
        var line = lines[i];
        if (line.indexOf('libil2cpp.so') !== -1 && line.indexOf('r-xp') !== -1) {
            base = ptr('0x' + line.split('-')[0]);
            break;
        }
    }
    if (!base) {
        for (var i = 0; i < lines.length; i++) {
            var line = lines[i];
            if (line.indexOf('libil2cpp.so') !== -1) {
                base = ptr('0x' + line.split('-')[0]);
                break;
            }
        }
    }
    return base;
}

var il2cppBase = getIl2CppBase();
if (il2cppBase) {
    send({ type: 'il2cpp_ready', lib: 'libil2cpp.so', base: il2cppBase });
} else {
    send({ type: 'il2cpp_ready', msg: 'libil2cpp.so not found in maps' });
}

function installPlayerMainHooks() {
    if (!il2cppBase) return;
    if (!il2cppBase) return;
    // Removed 32-bit/Houdini incompatible hooks that set _playerMainInstance using args[0]
    try {
        Interceptor.attach(il2cppBase.add(0x70475c), {
            onEnter: function(args) {
                _playerMainInstance = args[0];
                send({ type: 'il2cpp_event', event: 'PlayerMain.GotoFindingPath captured', ptr: _playerMainInstance.toString() });
            }
        });
    } catch(e) {
        send({ type: 'il2cpp_error', msg: 'hook PlayerMain.GotoFindingPath failed: ' + e.toString() });
    }
}

installPlayerMainHooks();

// ==================== ẨN DIALOG DÃ TẨU (mặc định bật) ====================
// Bot điều khiển hoàn toàn bằng PACKET (eNpcSelect/eGiveBox), cửa sổ NPC chỉ là phần
// client TỰ VẼ khi nhận gói server -> chặn vẽ thì màn hình sạch, server vẫn xử lý bình thường.
// 3 class vẽ dialog (xác định từ dump.cs): NpcDialog10Pc / NpcDialogPc / NpcDialogInfiPc.
// Chiến lược: chặn Open() (không vẽ). Nếu chặn được nhưng vẫn flash, có thêm fallback Close ngay.
function installDialogSuppressHooks() {
    if (typeof Il2Cpp === 'undefined') {
        send({ type: 'dialog_hide', ok: false, msg: 'Il2Cpp bridge chưa sẵn sàng' });
        return;
    }
    try {
        Il2Cpp.perform(function() {
            var img = Il2Cpp.domain.assembly('Assembly-CSharp').image;
            var done = [];
            var seen = [];   // tên class có "Dialog"/"Npc" để soi nếu cần
            var classes = img.classes;
            for (var i = 0; i < classes.length; i++) {
                var k = classes[i];
                var nm = k.name || '';
                var low = nm.toLowerCase();
                // Chỉ nhắm các UI hội thoại NPC (không đụng confirm/popup khác).
                var isDlg = (low.indexOf('dialog') !== -1) &&
                            (low.indexOf('npc') !== -1 || low.indexOf('talk') !== -1 ||
                             low.indexOf('quest') !== -1 || low.indexOf('task') !== -1);
                if (low.indexOf('dialog') !== -1) seen.push(nm);
                if (!isDlg) continue;
                try {
                    var openM = k.method('Open', 1) || k.method('Open');
                    if (!openM) continue;
                    // AN TOÀN: KHÔNG no-op Open (bỏ init -> dễ crash native). Cho Open chạy
                    // đầy đủ rồi Close ngay (client-side, không đụng phiên dialogue server).
                    try {
                        Interceptor.attach(openM.virtualAddress, {
                            onEnter: function(a) { this.self = a[0]; },
                            onLeave: function() {
                                // REALTIME: chụp text dialog NGAY khi server push (vd '...22/15 quyển Thần bí
                                // đồ chí') -> lưu global để bot đọc tức thì, KHÔNG cần poll/gc.choose. Chỉ lưu
                                // text có mẫu 'X/Y' (= tiến độ đồ chí), bỏ tag rich-text.
                                try {
                                    var o = new Il2Cpp.Object(this.self);
                                    var tmp = null;
                                    try { tmp = o.field('descriptionTmp').value; } catch (e) {}
                                    if (!tmp || !tmp.handle || tmp.handle.isNull()) {
                                        try { tmp = o.field('layoutDescriptionTmp').value; } catch (e) {}
                                    }
                                    if (tmp && tmp.handle && !tmp.handle.isNull()) {
                                        var s = '';
                                        try { var v = tmp.field('m_text').value; s = v ? (v.content || '') : ''; } catch (e) {}
                                        if (s) {
                                            var clean = s.replace(/<[^>]*>/g, '');
                                            if (/\d+\s*\/\s*\d+/.test(clean)) {
                                                globalThis._dlgText = clean;
                                                globalThis._dlgTextT = Date.now();
                                            }
                                        }
                                    }
                                } catch (eCap) {}
                                // CHỈ đóng khi BOT đang thao tác Dã Tẩu (cờ bật). Ngoài ra để
                                // dialog hiện bình thường -> người chơi vẫn dùng THP / NPC khác.
                                if (Date.now() >= (globalThis._datauSuppressUntil || 0)) return;
                                try { new Il2Cpp.Object(this.self).method('Close', 1).invoke(false); } catch (e2) {}
                            }
                        });
                        done.push(nm + '.Open(close-when-datau)');
                    } catch (e3) {}
                } catch (e) {}
            }
            // GIVEBOX: ẩn ô nộp đồ (GiveItem.ShowOpen) — cho mở rồi ShowOff ngay (an toàn, không skip init).
            try {
                var gi = img.class('GiveItem');
                if (gi) {
                    var showOpen = gi.method('ShowOpen', 2) || gi.method('ShowOpen');
                    if (showOpen) {
                        Interceptor.attach(showOpen.virtualAddress, {
                            onEnter: function(a) { this.self = a[0]; },
                            onLeave: function() {
                                if (Date.now() >= (globalThis._datauSuppressUntil || 0)) return;
                                try { new Il2Cpp.Object(this.self).method('ShowOff').invoke(); } catch (e) {}
                            }
                        });
                        done.push('GiveItem.ShowOpen(showoff-when-datau)');
                    }
                }
            } catch (e) {}
            // SHOP POPUP (Kỳ Trân Các = NpcKnbShop / NpcMoneyShop / NpcPointShop): LOG mỗi lần bật (timestamp) ->
            // điều tra NGUYÊN NHÂN nó hiện (đối chiếu thời điểm: ngay sau open_datau quét node = do quét trúng NPC
            // bán hàng). Đồng thời nếu đang trong cửa sổ suppress thì ShowOff ngay. globalThis._shopOpenLog (ring 20).
            try {
                globalThis._shopOpenLog = globalThis._shopOpenLog || [];
                // KNB (Kỳ Trân Các) + Point: bot KHÔNG BAO GIỜ dùng -> ShowOff NGAY khi bật (kill-on-sight).
                // MoneyShop: bot CÓ mở để ĐỌC shop lúc mua NV -> CHỈ log, KHÔNG auto-đóng (kẻo vỡ flow mua); nó
                // sẽ được đóng ở milestone (closeDatauPopups) khi đã mua xong.
                // ⚠️ PHẢI DUYỆT img.classes (img.class("tên") trả SAI/null ở build này) — đây là lý do hook
                //    GiveItem/shop cũ KHÔNG cài được; chỉ hook NpcDialog (duyệt classes) là chạy.
                var SHOP_KILL = { 'NpcKnbShop': true, 'NpcPointShop': true, 'NpcMoneyShop': false };
                for (var ci2 = 0; ci2 < classes.length; ci2++) {
                    var kc = classes[ci2];
                    var cn = kc.name || '';
                    if (!(cn in SHOP_KILL)) continue;
                    (function (sc, cname, kill) {
                        try {
                            var so = sc.method('ShowOpen', 2) || sc.method('ShowOpen');
                            if (!so || !so.virtualAddress || so.virtualAddress.isNull()) return;
                            Interceptor.attach(so.virtualAddress, {
                                onEnter: function (a) {
                                    this.self = a[0];
                                    globalThis._shopOpenLog.push({ shop: cname, ts: Date.now(), kill: kill });
                                    if (globalThis._shopOpenLog.length > 20) globalThis._shopOpenLog.shift();
                                },
                                onLeave: function () {
                                    if (!kill) return;   // MoneyShop: để nguyên cho flow mua đọc
                                    try { new Il2Cpp.Object(this.self).method('ShowOff').invoke(); } catch (e) {}
                                }
                            });
                            done.push(cname + '.ShowOpen(' + (kill ? 'log+kill-on-sight' : 'log-only') + ')');
                        } catch (e) {}
                    })(kc, cn, SHOP_KILL[cn]);
                }
            } catch (e) {}
            send({ type: 'dialog_hide', ok: true, hooked: done, seen: seen });
        });
    } catch (e) {
        send({ type: 'dialog_hide', ok: false, err: e.toString() });
    }
}

installDialogSuppressHooks();

// Read PlayerMain instance directly from IL2CPP class static when exports are visible.
function il2cppExport(name) {
    var mod = Process.findModuleByName('libil2cpp.so');
    if (!mod) {
        var mods = Process.enumerateModules();
        for (var i = 0; i < mods.length; i++) {
            if (
                (mods[i].name && mods[i].name.indexOf('libil2cpp.so') !== -1) ||
                (mods[i].path && mods[i].path.indexOf('libil2cpp.so') !== -1)
            ) {
                mod = mods[i];
                break;
            }
        }
    }
    var p = null;
    if (mod) p = mod.findExportByName(name);
    if (!p) {
        try {
            var s = DebugSymbol.fromName(name);
            if (s && s.address && !s.address.isNull()) p = s.address;
        } catch(e) {}
    }
    if (!p) {
        try {
            var s2 = DebugSymbol.fromName('libil2cpp.so!' + name);
            if (s2 && s2.address && !s2.address.isNull()) p = s2.address;
        } catch(e2) {}
    }
    if (!p) throw new Error('Missing il2cpp export: ' + name);
    return p;
}

function readPlayerMainDirect() {
    if (_playerMainInstance) {
        try {
            // Validate instance
            var mapId = _playerMainInstance.add(0xE4).readU32();
            if (mapId > 0 && mapId < 10000) {
                return { ok: true, playerMain: _playerMainInstance.toString(), source: 'cached' };
            }
        } catch(e) {
            _playerMainInstance = null;
        }
    }
    
    if (!il2cppBase) return { ok: false, error: 'il2cpp not found' };
    
    try {
        var domain = new NativeFunction(il2cppExport('il2cpp_domain_get'), 'pointer', [])();
        var assemblyOpen = new NativeFunction(il2cppExport('il2cpp_domain_assembly_open'), 'pointer', ['pointer', 'pointer']);
        var assemblyPb = assemblyOpen(domain, Memory.allocUtf8String('Assembly-CSharp.dll'));
        if (assemblyPb.isNull()) assemblyPb = assemblyOpen(domain, Memory.allocUtf8String('Assembly-CSharp'));
        
        var getImg = new NativeFunction(il2cppExport('il2cpp_assembly_get_image'), 'pointer', ['pointer']);
        var imagePb = getImg(assemblyPb);
        
        var getClass = new NativeFunction(il2cppExport('il2cpp_class_from_name'), 'pointer', ['pointer', 'pointer', 'pointer']);
        var playerMainKlass = getClass(imagePb, Memory.allocUtf8String(''), Memory.allocUtf8String('PlayerMain'));
        
        if (!playerMainKlass.isNull()) {
            var getStaticFields;
            try {
                getStaticFields = new NativeFunction(il2cppExport('il2cpp_class_get_static_field_data'), 'pointer', ['pointer']);
            } catch(e) {
                getStaticFields = null;
            }
            
            var pStaticFields = ptr(0);
            if (getStaticFields) {
                pStaticFields = getStaticFields(playerMainKlass);
            } else {
                pStaticFields = playerMainKlass.add(0xb8).readPointer(); // Fallback offset for Unity 2019+ 64-bit
            }
            
            if (!pStaticFields.isNull()) {
                var activePlayerMain = pStaticFields.readPointer(); // PlayerMain.instance is at 0x0
                if (!activePlayerMain.isNull()) {
                    var mapId = activePlayerMain.add(0xe4).readU32();
                    if (mapId > 0 && mapId < 10000) {
                        _playerMainInstance = activePlayerMain;
                        return { ok: true, playerMain: _playerMainInstance.toString(), source: 'static_field' };
                    }
                }
            }
        }
    } catch (e) {
        return { ok: false, error: 'Exception finding PlayerMain: ' + e.message };
    }
    
    return { ok: false, error: 'PlayerMain not found' };
}

// Tìm 1 instance MonoBehaviour đang sống theo TÊN class (login/logout UI). Dùng Resources.FindObjectsOfTypeAll
// (an toàn — KHÔNG gc.choose, giống probeBilienCommand). Trả Il2Cpp.Object hoặc null. PHẢI gọi trong perform.
function findLoginInstance(className) {
    // img.class(name) THROW khi tên không tồn tại (KHÔNG trả null) -> phải bọc try/catch TỪNG tên, nếu không
    // lần thử đầu throw sẽ nhảy ra ngoài, bỏ qua các namespace còn lại. Class có namespace: game.network.* ...
    function tryClass(img, n) { try { return img.class(n); } catch (e) { return null; } }
    try {
        var img = Il2Cpp.domain.assembly('Assembly-CSharp').image;
        var names = [className, 'game.scene.login.' + className, 'game.network.' + className,
                     'game.ui.' + className, 'game.scene.' + className, 'game.' + className];
        var k = null;
        for (var i = 0; i < names.length && !k; i++) k = tryClass(img, names[i]);
        if (!k) return null;
        var Res = Il2Cpp.domain.assembly('UnityEngine.CoreModule').image.class('UnityEngine.Resources');
        var arr = Res.method('FindObjectsOfTypeAll', 1).invoke(k.type.object);
        if (arr && arr.length) return arr.get(0);
    } catch (e) {}
    return null;
}

// ==================== RPC EXPORTS ====================
rpc.exports = {
    // DIAG: liệt kê method của 1 class (lọc theo chuỗi) — để biết tên/param thật.
    listMethods: function(className, filter) {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'no il2cpp' };
        return Il2Cpp.perform(function () {
            try {
                var img = Il2Cpp.domain.assembly("Assembly-CSharp").image;
                var k = img.class(className);
                if (!k) return { ok: false, error: 'no class ' + className };
                var out = [], ms = k.methods, f = (filter || '').toLowerCase();
                for (var i = 0; i < ms.length; i++) {
                    var n = ms[i].name;
                    if (!f || n.toLowerCase().indexOf(f) !== -1) {
                        var pc = 0; try { pc = ms[i].parameterCount; } catch (e) {}
                        out.push(n + "/" + pc);
                    }
                }
                return { ok: true, methods: out };
            } catch (e) { return { ok: false, error: '' + e }; }
        });
    },
    // DIAG: kiểu của từng param 1 method (để invoke đúng).
    methodSig: function(className, methodName) {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'no il2cpp' };
        return Il2Cpp.perform(function () {
            try {
                var img = Il2Cpp.domain.assembly("Assembly-CSharp").image;
                var k = img.class(className);
                var out = [];
                var ms = k.methods;
                for (var i = 0; i < ms.length; i++) {
                    if (ms[i].name !== methodName) continue;
                    var ps = [];
                    try { var pp = ms[i].parameters; for (var j = 0; j < pp.length; j++) ps.push(pp[j].type.name); } catch (e) {}
                    out.push({ params: ps, count: ms[i].parameterCount });
                }
                return { ok: true, overloads: out };
            } catch (e) { return { ok: false, error: '' + e }; }
        });
    },
    // DI CHUYỂN: invoke PlayerMain.GotoFindingPath(targetX,targetY,approach3d=20, Action onFinish, Action<bool> onResponse)
    // QUA BRIDGE THEO TÊN (bridge resolve đúng 64-bit — KHÁC gotopath cũ dùng offset thô bị 'unable to intercept').
    // Truyền NULL cho 2 callback. targetX/Y thử GAME coords (3 số) trước.
    gotoFindingPath: function(x, y, approach) {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        var pmRes = readPlayerMainDirect();
        if (!pmRes.ok || !_playerMainInstance) return { ok: false, error: 'PlayerMain not found' };
        return Il2Cpp.perform(function () {
            try {
                var pm = new Il2Cpp.Object(_playerMainInstance);
                var m = pm.method("GotoFindingPath", 6);   // (int x, int y, int approach3d, Action,Action,Action)
                if (!m) return { ok: false, error: 'no GotoFindingPath(6)' };
                m.invoke(x | 0, y | 0, (approach | 0) || 20, NULL, NULL, NULL);
                return { ok: true, x: x, y: y };
            } catch (e) { return { ok: false, error: '' + e }; }
        });
    },

    // DI CHUYỂN ĐÚNG BÀI: invoke GotoFindingPath TRÊN MAIN THREAD bằng cách hook PlayerMain.Update
    // (chạy mỗi frame trên main thread) rồi gọi từ onEnter. Off-thread invoke không có tác dụng vì hàm
    // gameplay Unity cần main thread. Set _pendingGoto mỗi lần; hook chỉ cài 1 lần.
    gotoHooked: function(x, y, approach) {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'no il2cpp' };
        var pmRes = readPlayerMainDirect();
        if (!pmRes.ok || !_playerMainInstance) return { ok: false, error: 'no PlayerMain' };
        globalThis._pendingGoto = { x: x | 0, y: y | 0, ap: (approach | 0) || 20 };
        if (globalThis._gotoHookOn) return { ok: true, queued: true };
        return Il2Cpp.perform(function () {
            try {
                var img = Il2Cpp.domain.assembly("Assembly-CSharp").image;
                var pm = img.class("PlayerMain");
                var um = pm.method("Update", 0);
                if (!um || !um.virtualAddress || um.virtualAddress.isNull())
                    return { ok: false, error: 'no Update vaddr' };
                Interceptor.attach(um.virtualAddress, {
                    onEnter: function () {
                        var g = globalThis._pendingGoto;
                        if (!g) return;
                        globalThis._pendingGoto = null;   // bắn 1 lần
                        try {
                            new Il2Cpp.Object(_playerMainInstance).method("GotoFindingPath", 6)
                                .invoke(g.x, g.y, g.ap, NULL, NULL, NULL);
                            globalThis._gotoLastFire = 'ok ' + g.x + ',' + g.y;
                        } catch (e) { globalThis._gotoLastFire = 'err ' + e; }
                    }
                });
                globalThis._gotoHookOn = true;
                return { ok: true, hooked: true };
            } catch (e) { return { ok: false, error: '' + e }; }
        });
    },
    gotoLastFire: function () { return { fire: globalThis._gotoLastFire || '(chưa bắn)' }; },

    // ĐÁNH SKILL ĐÚNG BÀI: invoke PlayerMain.DoSkill(int id) TRÊN MAIN THREAD (hook Update) — giống cách nút-tròn
    // skill của client tự cast: client tự dựng state niệm/hướng/target rồi mới gửi op239 → server TÍNH DAME.
    // (Replay op239 thô KHÔNG dame vì thiếu state này — nhất là skill đánh-xa/caster.) Mỗi lần gọi bắn 1 phát;
    // Python gọi lặp ~nhịp niệm. DoSkill(id) tự target con gần như khi bấm nút.
    doSkillHooked: function (skillId) {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'no il2cpp' };
        var pmRes = readPlayerMainDirect();
        if (!pmRes.ok || !_playerMainInstance) return { ok: false, error: 'no PlayerMain' };
        globalThis._pendingSkill = skillId | 0;
        if (globalThis._skillHookOn) return { ok: true, queued: skillId | 0 };
        return Il2Cpp.perform(function () {
            try {
                var img = Il2Cpp.domain.assembly("Assembly-CSharp").image;
                var um = img.class("PlayerMain").method("Update", 0);
                if (!um || !um.virtualAddress || um.virtualAddress.isNull())
                    return { ok: false, error: 'no Update vaddr' };
                Interceptor.attach(um.virtualAddress, {
                    onEnter: function () {
                        var sid = globalThis._pendingSkill;
                        if (sid === null || sid === undefined) return;
                        globalThis._pendingSkill = null;   // bắn 1 phát mỗi request
                        try {
                            var r = new Il2Cpp.Object(_playerMainInstance).method("DoSkill", 1).invoke(sid);
                            globalThis._skillLastFire = 'ok DoSkill(' + sid + ')=' + r;
                        } catch (e) { globalThis._skillLastFire = 'err ' + e; }
                    }
                });
                globalThis._skillHookOn = true;
                return { ok: true, hooked: true };
            } catch (e) { return { ok: false, error: '' + e }; }
        });
    },
    skillLastFire: function () { return { fire: globalThis._skillLastFire || '(chưa bắn)' }; },

    // ÉP RE-RESOLVE instance PlayerMain: gọi SAU khi ĐỔI MAP (Xa Phu/teleport). Lý do: đổi map có thể TẠO LẠI
    // PlayerMain → con trỏ cache cũ STALE (vẫn đọc được mapId nên validate lọt) → GotoFindingPath invoke vào
    // object cũ = KHÔNG di chuyển. Xoá cache → lần đọc sau lấy instance HIỆN TẠI qua static PlayerMain.instance.
    invalidatePlayerMain: function () {
        _playerMainInstance = null;
        return { ok: true };
    },

    // EQUIP trên MAIN THREAD: invoke PlayerSelfProperties.EquipItem(item) trong hook PlayerMain.Update (off-thread
    // invoke không ăn — equip là UI main-thread). Queue idx; hook resolve props+item rồi invoke 1 phát.
    equipHooked: function (idx) {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'no il2cpp' };
        var pmRes = readPlayerMainDirect();
        if (!pmRes.ok || !_playerMainInstance) return { ok: false, error: 'no PlayerMain' };
        globalThis._pendingEquip = idx | 0;
        if (globalThis._equipHookOn) return { ok: true, queued: idx };
        return Il2Cpp.perform(function () {
            try {
                var img = Il2Cpp.domain.assembly("Assembly-CSharp").image;
                var um = img.class("PlayerMain").method("Update", 0);
                if (!um || !um.virtualAddress || um.virtualAddress.isNull())
                    return { ok: false, error: 'no Update vaddr' };
                Interceptor.attach(um.virtualAddress, {
                    onEnter: function () {
                        var want = globalThis._pendingEquip;
                        if (want === null || want === undefined) return;
                        globalThis._pendingEquip = null;   // 1 phát
                        try {
                            var props = findLoginInstance('PlayerSelfProperties');
                            if (!props) { globalThis._equipLastFire = 'no props'; return; }
                            var pm = new Il2Cpp.Object(_playerMainInstance);
                            var buckets = pm.field('items').value.field('_tables').value.field('_buckets').value;
                            var itemObj = null;
                            for (var b = 0; b < buckets.length && !itemObj; b++) {
                                var node = buckets.get(b);
                                while (node && !node.isNull()) {
                                    var it = node.field('_value').value;
                                    if (it && !it.isNull()) {
                                        var ix = -1; try { ix = it.field('index').value; } catch (e) {}
                                        if (ix === want) { itemObj = it; break; }
                                    }
                                    try { node = node.field('_next').value; } catch (e) { break; }
                                }
                            }
                            if (!itemObj) { globalThis._equipLastFire = 'item ' + want + ' not found'; return; }
                            props.method('EquipItem', 1).invoke(itemObj);
                            globalThis._equipLastFire = 'ok ' + want;
                        } catch (e) { globalThis._equipLastFire = 'err ' + e; }
                    }
                });
                globalThis._equipHookOn = true;
                return { ok: true, hooked: true };
            } catch (e) { return { ok: false, error: '' + e }; }
        });
    },
    equipLastFire: function () { return { fire: globalThis._equipLastFire || '(chưa bắn)' }; },

    // ====== ĐÓNG SẠCH POPUP DÃ TẨU (client-side) — invoke Close() của CHÍNH CLIENT trên MAIN THREAD ======
    // Server đã xử lý accept/turn-in/reward bằng PACKET (eNpcSelect / eAwardSelectionAnswer); popup chỉ là UI
    // client còn sót -> CHỒNG CHÉO khi bot gửi nhiều gói liên tiếp. Đóng đúng bài = liệt kê MỌI instance đang
    // ACTIVE của các class popup Dã Tẩu (Resources.FindObjectsOfTypeAll — đã dùng ở findJoysticks) rồi invoke
    // .Close() (= y hệt bấm nút X), class nào không có Close thì SetActive(false). PHẢI chạy MAIN THREAD (UI) ->
    // piggyback hook PlayerMain.Update như gotoHooked. Gọi SAU khi đã gửi gói accept/answer.
    closeDatauPopups: function () {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'no il2cpp' };
        var pmRes = readPlayerMainDirect();
        if (!pmRes.ok || !_playerMainInstance) return { ok: false, error: 'no PlayerMain' };
        // (class popup, method đóng, số arg). m=null -> SetActive(false) trên gameObject (class không có Close).
        var SPECS = [
            { c: "NpcDialogInfiPc",   m: "Close",   n: 1 },   // hội thoại Dã Tẩu (text NV/đồ chí)
            { c: "NpcDialogPc",       m: "Close",   n: 1 },   // hội thoại NPC thường
            { c: "NpcDialog10Pc",     m: "Close",   n: 1 },   // hội thoại NPC (biến thể 10 nút)
            { c: "AwardSelection",    m: "Close",   n: 0 },   // bảng chọn phần thưởng
            { c: "GiveItem",          m: "ShowOff", n: 0 },   // ô nộp đồ GiveBox (đóng = ShowOff)
            { c: "NpcKnbShop",        m: "ShowOff", n: 0 },   // KỲ TRÂN CÁC (shop Kim Nguyên Bảo) — đóng = ShowOff
            { c: "NpcMoneyShop",      m: "ShowOff", n: 0 },   // shop bạc (tạp hoá/thợ rèn)
            { c: "NpcPointShop",      m: "ShowOff", n: 0 },   // shop điểm
            { c: "StandardConfirmPc", m: null,      n: 0 },   // popup "Biết rồi/Đồng ý" + "về thành dưỡng sức" (confirm)
            { c: "PlayerSelfBagarate", m: null,     n: 0 },   // BẢNG TÚI (mở túi) -> SetActive(false) đóng
            { c: "MessageBox",        m: null,      n: 0 },   // hộp thông báo (tránh OnClose -> load scene)
            { c: "WorldRankPc",       m: null,      n: 0 }    // bảng XẾP HẠNG (Dã Tẩu/thế giới) -> SetActive(false)
        ];
        // ⚠️ Il2Cpp.perform CHẠY BẤT ĐỒNG BỘ -> PHẢI `return Il2Cpp.perform(...)` để exports_sync chờ kết quả
        //    (gọi rồi đọc biến ngoài = đọc TRƯỚC khi callback chạy xong -> luôn rỗng). Mọi việc làm TRONG callback.
        return Il2Cpp.perform(function () {
            var found = {}, queue = [];
            try {
                var img = Il2Cpp.domain.assembly("Assembly-CSharp").image;
                var Res = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Resources");
                var findM = Res.method("FindObjectsOfTypeAll", 1);
                // map tên class -> spec (đóng thế nào)
                var BY = {};
                for (var s = 0; s < SPECS.length; s++) BY[SPECS[s].c] = SPECS[s];
                // (1) ENUMERATE: DUYỆT img.classes rồi khớp tên (img.class("X") tra-theo-tên trả SAI class ở build
                //     này -> FindObjectsOfTypeAll = 0; duyệt classes mới đúng — xem enumActiveUi đã verify). Gom HANDLE.
                var classes = img.classes;
                for (var ci = 0; ci < classes.length; ci++) {
                    var k = classes[ci];
                    var sp = BY[k.name || ''];
                    if (!sp) continue;
                    try {
                        var arr = findM.invoke(k.type.object);
                        var total = (arr && arr.length) ? arr.length : 0, active = 0;
                        for (var i = 0; i < total; i++) {
                            try {
                                var o = arr.get(i);
                                var go = o.method("get_gameObject").invoke();
                                if (!go.method("get_activeInHierarchy").invoke()) continue;   // chỉ popup ĐANG HIỆN
                                active++;
                                queue.push({ obj: o.handle, go: go.handle, m: sp.m, n: sp.n, c: sp.c });
                            } catch (e) {}
                        }
                        if (total) found[sp.c] = (found[sp.c] ? found[sp.c] + '+' : '') + total + '/' + active;
                    } catch (e) {}
                }
                globalThis._popupQueue = queue;
                globalThis._popupFound = found;
                // (2) cài hook PlayerMain.Update (1 lần) — drain queue, ĐÓNG trên MAIN THREAD bằng invoke TRỰC TIẾP
                //     theo handle (KHÔNG FindObjectsOfTypeAll ở đây). Invoke-theo-con-trỏ main thread = bài gotoHooked.
                if (!globalThis._closeHookOn) {
                    var um = img.class("PlayerMain").method("Update", 0);
                    if (um && um.virtualAddress && !um.virtualAddress.isNull()) {
                        Interceptor.attach(um.virtualAddress, {
                            onEnter: function () {
                                var q = globalThis._popupQueue;
                                if (!q || !q.length) return;
                                globalThis._popupQueue = null;   // bắn 1 lần
                                var closed = {};
                                for (var i = 0; i < q.length; i++) {
                                    try {
                                        var it = q[i];
                                        if (it.m) {
                                            var mo = new Il2Cpp.Object(it.obj);
                                            if (it.n === 1) mo.method(it.m, 1).invoke(false); else mo.method(it.m, 0).invoke();
                                        } else {
                                            new Il2Cpp.Object(it.go).method("SetActive").invoke(false);
                                        }
                                        closed[it.c] = (closed[it.c] || 0) + 1;
                                    } catch (e) {}
                                }
                                globalThis._closePopupResult = { closed: closed, found: globalThis._popupFound || {}, ts: Date.now() };
                            }
                        });
                        globalThis._closeHookOn = true;
                    }
                }
                return { ok: true, queued: queue.length, found: found };
            } catch (e) { return { ok: false, error: '' + e }; }
        });
    },
    closePopupResult: function () { return { res: globalThis._closePopupResult || null, pending: (globalThis._popupQueue ? globalThis._popupQueue.length : 0) }; },
    shopOpenLog: function () { return { log: globalThis._shopOpenLog || [] }; },

    // XẾP CHỒNG/GỘP đồ túi = invoke PlayerSelfBagarate.SortItems() (hàm sắp xếp của chính client) trên MAIN THREAD.
    // AN TOÀN (chỉ gộp/sắp xếp đồ mình, KHÔNG mất đồ). LƯU Ý: class PlayerSelfBagarate CHỈ tồn tại khi bảng túi
    // ĐANG MỞ -> found=0 nghĩa là túi chưa mở (cần mở túi trước). Cùng pattern enumerate-frida-thread + invoke-main.
    sortBagItems: function () {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'no il2cpp' };
        var pmRes = readPlayerMainDirect();
        if (!pmRes.ok || !_playerMainInstance) return { ok: false, error: 'no PlayerMain' };
        return Il2Cpp.perform(function () {
            try {
                var img = Il2Cpp.domain.assembly("Assembly-CSharp").image;
                var Res = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Resources");
                var findM = Res.method("FindObjectsOfTypeAll", 1);
                var queue = [];
                var classes = img.classes;
                for (var ci = 0; ci < classes.length; ci++) {
                    if ((classes[ci].name || '') !== 'PlayerSelfBagarate') continue;
                    var arr = findM.invoke(classes[ci].type.object);
                    for (var i = 0; i < ((arr && arr.length) || 0); i++) {
                        try { queue.push(arr.get(i).handle); } catch (e) {}
                    }
                }
                globalThis._sortQueue = queue;
                if (!globalThis._sortHookOn) {
                    var um = img.class("PlayerMain").method("Update", 0);
                    if (um && um.virtualAddress && !um.virtualAddress.isNull()) {
                        Interceptor.attach(um.virtualAddress, {
                            onEnter: function () {
                                var q = globalThis._sortQueue;
                                if (!q || !q.length) return;
                                globalThis._sortQueue = null;
                                var done = 0;
                                for (var i = 0; i < q.length; i++) {
                                    try { new Il2Cpp.Object(q[i]).method("SortItems", 0).invoke(); done++; } catch (e) {}
                                }
                                globalThis._sortResult = { done: done, ts: Date.now() };
                            }
                        });
                        globalThis._sortHookOn = true;
                    }
                }
                return { ok: true, found: queue.length };
            } catch (e) { return { ok: false, error: '' + e }; }
        });
    },
    sortResult: function () { return { res: globalThis._sortResult || null }; },

    // CHẨN ĐOÁN: quét MỌI class Assembly-CSharp tên gợi ý UI (dialog/npc/box/pc/select/confirm/award/quest/give/
    // popup/menu/notice) -> liệt kê class nào ĐANG có instance ACTIVE (đang hiện trên màn) + số lượng. Dùng để
    // xác định ĐÚNG class vẽ popup Dã Tẩu (op34/124/126/245) trước khi đóng. (chạy 1 lần lúc dialog đang mở.)
    enumActiveUi: function () {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'no il2cpp' };
        return Il2Cpp.perform(function () {
            try {
                var img = Il2Cpp.domain.assembly('Assembly-CSharp').image;
                var Res = Il2Cpp.domain.assembly('UnityEngine.CoreModule').image.class('UnityEngine.Resources');
                var findM = Res.method('FindObjectsOfTypeAll', 1);
                var pat = /(dialog|npc|box|pc|select|confirm|award|quest|give|popup|menu|notice|reward|task|rank|hang|xep|view|panel|board|list|window|content|info|datau|activ|tong|standard|trade|input|detail|frame|chain|combo|serial|continuous)/i;
                var active = {};
                var classes = img.classes;
                for (var i = 0; i < classes.length; i++) {
                    var k = classes[i]; var nm = k.name || '';
                    if (!pat.test(nm)) continue;
                    try {
                        var arr = findM.invoke(k.type.object);
                        var total = (arr && arr.length) ? arr.length : 0;
                        if (!total) continue;
                        var act = 0;
                        for (var j = 0; j < total; j++) {
                            try {
                                var o = arr.get(j);
                                var go = o.method('get_gameObject').invoke();
                                if (go.method('get_activeInHierarchy').invoke()) act++;
                            } catch (e) {}
                        }
                        if (act > 0) active[nm] = total + '/' + act;
                    } catch (e) {}
                }
                return { ok: true, active: active };
            } catch (e) { return { ok: false, error: '' + e }; }
        });
    },

    // CHẨN ĐOÁN: hook GotoFindingPath (qua bridge, đúng vaddr 64-bit) để BẮT args khi user TAP TAY đi.
    // -> biết game thật truyền (x,y,approach3d, có callback không) để nhái cho đúng. args[0]=this.
    captureGoto: function () {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'no il2cpp' };
        if (globalThis._gotoCapOn) return { ok: true, already: true };
        globalThis._gotoLog = [];
        return Il2Cpp.perform(function () {
            var img = Il2Cpp.domain.assembly("Assembly-CSharp").image;
            var pm = img.class("PlayerMain");
            var hooked = [];
            function hookM(name, cnt, nargs) {
                try {
                    var m = pm.method(name, cnt);
                    if (!m || !m.virtualAddress || m.virtualAddress.isNull()) return;
                    Interceptor.attach(m.virtualAddress, {
                        onEnter: function (a) {
                            var rec = { m: name + '/' + cnt, ts: Date.now(), args: [] };
                            for (var i = 1; i <= nargs; i++) {
                                try { rec.args.push(a[i].isNull() ? 'NULL' : a[i].toInt32()); }
                                catch (e) { rec.args.push('?'); }
                            }
                            globalThis._gotoLog.push(rec);
                            if (globalThis._gotoLog.length > 30) globalThis._gotoLog.shift();
                        }
                    });
                    hooked.push(name + '/' + cnt);
                } catch (e) {}
            }
            hookM("GotoFindingPath", 6, 6);
            hookM("GotoFindingPathOnVector", 1, 1);
            hookM("ProtocolGotoPosition", 1, 1);
            hookM("GotoAndPickTargetObject", 1, 1);
            hookM("GotoNpc", 2, 2);
            globalThis._gotoCapOn = true;
            return { ok: true, hooked: hooked };
        });
    },
    lastGotoArgs: function () { return { log: globalThis._gotoLog || [] }; },

    // Liệt kê mọi Joystick (Joystick Pack: Dynamic/Fixed/Floating/Variable) đang sống -> biết cái nào DI CHUYỂN.
    findJoysticks: function () {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'no il2cpp' };
        return Il2Cpp.perform(function () {
            try {
                var img = Il2Cpp.domain.assembly("Assembly-CSharp").image;
                var kJoy = img.class("Joystick");
                var Res = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Resources");
                var arr = Res.method("FindObjectsOfTypeAll", 1).invoke(kJoy.type.object);
                var out = [];
                if (arr && arr.length) {
                    for (var i = 0; i < arr.length; i++) {
                        var o = arr.get(i); var rec = { idx: i };
                        try { rec.type = o.class.name; } catch (e) {}
                        try { var go = o.method("get_gameObject").invoke(); rec.go = go.method("get_name").invoke().content; } catch (e) {}
                        try { var inp = o.field("input").value; rec.inx = inp.field("x").value; rec.iny = inp.field("y").value; } catch (e) { rec.inerr = '' + e; }
                        try { rec.active = o.method("get_isActiveAndEnabled").invoke(); } catch (e) {}
                        out.push(rec);
                    }
                }
                return { ok: true, count: out.length, joysticks: out };
            } catch (e) { return { ok: false, error: '' + e }; }
        });
    },
    // Hook các method Joystick để biết game TIÊU THỤ joystick kiểu gì (poll getter hay event OnDrag/HandleInput).
    // Đếm số lần gọi mỗi method. User kéo joystick tay -> xem cái nào tăng.
    captureJoystick: function () {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'no il2cpp' };
        if (globalThis._joyCapOn) return { ok: true, already: true };
        globalThis._joyCnt = {};
        return Il2Cpp.perform(function () {
            var img = Il2Cpp.domain.assembly("Assembly-CSharp").image;
            var kJoy = img.class("Joystick");
            var hooked = [];
            function hk(name, cnt) {
                try {
                    var m = kJoy.method(name, cnt);
                    if (!m || !m.virtualAddress || m.virtualAddress.isNull()) return;
                    Interceptor.attach(m.virtualAddress, {
                        onEnter: function () { globalThis._joyCnt[name] = (globalThis._joyCnt[name] || 0) + 1; }
                    });
                    hooked.push(name);
                } catch (e) {}
            }
            hk("get_Direction", 0); hk("get_Horizontal", 0); hk("get_Vertical", 0);
            hk("HandleInput", 4); hk("OnDrag", 1); hk("OnPointerDown", 1); hk("OnPointerUp", 1);
            globalThis._joyCapOn = true;
            return { ok: true, hooked: hooked };
        });
    },
    joyCounts: function () { return globalThis._joyCnt || {}; },

    // Tìm BỘ TIÊU THỤ joystick: hook get_Vertical, bắt return-address (caller) -> offset từ il2cppBase -> tra dump.cs.
    findJoyConsumer: function () {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'no il2cpp' };
        if (globalThis._joyConsumerOn) return { ok: true, already: true, offs: globalThis._joyRet || [] };
        globalThis._joyRet = [];
        return Il2Cpp.perform(function () {
            try {
                var img = Il2Cpp.domain.assembly("Assembly-CSharp").image;
                var kJoy = img.class("Joystick");
                var m = kJoy.method("get_Vertical", 0);
                Interceptor.attach(m.virtualAddress, {
                    onEnter: function () {
                        try {
                            var off = this.returnAddress.sub(il2cppBase);
                            var s = '0x' + off.toString(16);
                            if (globalThis._joyRet.indexOf(s) === -1 && globalThis._joyRet.length < 12)
                                globalThis._joyRet.push(s);
                        } catch (e) {}
                    }
                });
                globalThis._joyConsumerOn = true;
                return { ok: true, hooked: true };
            } catch (e) { return { ok: false, error: '' + e }; }
        });
    },
    joyConsumerOffs: function () { return { offs: globalThis._joyRet || [] }; },

    // Set field `input` (Vector2) của Joystick thứ idx = (dx,dy) -> game đọc Direction -> đi theo hướng đó.
    // dùng OFFSET từ bridge (đúng 64-bit) + ghi float. dx,dy in [-1,1] (chuẩn hoá). (0,0)=dừng.
    joystickSet: function (idx, dx, dy) {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'no il2cpp' };
        return Il2Cpp.perform(function () {
            try {
                var img = Il2Cpp.domain.assembly("Assembly-CSharp").image;
                var kJoy = img.class("Joystick");
                var Res = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Resources");
                var arr = Res.method("FindObjectsOfTypeAll", 1).invoke(kJoy.type.object);
                if (!arr || idx >= arr.length) return { ok: false, error: 'no joystick idx ' + idx };
                var o = arr.get(idx);
                var off = kJoy.field("input").offset;          // offset 64-bit đúng từ bridge
                o.handle.add(off).writeFloat(dx);
                o.handle.add(off + 4).writeFloat(dy);
                // đọc lại xác nhận
                var inp = o.field("input").value;
                return { ok: true, off: off, set: [dx, dy], now: [inp.field("x").value, inp.field("y").value] };
            } catch (e) { return { ok: false, error: '' + e }; }
        });
    },

    // Đọc TRẠNG THÁI NV từ MEMORY (KHÔNG remote Dã Tẩu): class `Quest` (MonoBehaviour) field
    // mappingGo = Dictionary<questKey, Quest.ItemData> = các NV đang theo dõi trên tracker.
    // count>0 = ĐANG CÓ NV. Mỗi entry cho questKey + content (QuestItem.contentTextMeshPro.m_text).
    // An toàn: field-only + Resources.FindObjectsOfTypeAll (KHÔNG gc.choose, KHÔNG invoke method game).
    readQuestState: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function() {
            var diag = { errors: [], insts: 0 };
            try {
                var img = Il2Cpp.domain.assembly('Assembly-CSharp').image;
                var qClass = null;
                try { qClass = img.class('Quest'); } catch (e) {}
                if (!qClass) return { ok: false, error: 'no Quest class' };
                var Res = Il2Cpp.domain.assembly('UnityEngine.CoreModule').image.class('UnityEngine.Resources');
                var arr = Res.method('FindObjectsOfTypeAll', 1).invoke(qClass.type.object);
                if (!arr || !arr.length) return { ok: true, hasQuest: false, count: 0, quests: [], note: 'no Quest instance' };
                diag.insts = arr.length;
                // Có thể có nhiều instance (kể cả prefab inactive) -> chọn cái mappingGo nhiều entry nhất.
                var best = null, bestCnt = -1;
                for (var i = 0; i < arr.length; i++) {
                    try {
                        var inst = arr.get(i);
                        if (!inst || inst.handle.isNull()) continue;
                        var mg = inst.field('mappingGo').value;
                        if (!mg || mg.handle.isNull()) continue;
                        var c = 0;
                        try { c = mg.field('_count').value; } catch (e) { try { c = mg.method('get_Count').invoke(); } catch (e2) {} }
                        if (c > bestCnt) { bestCnt = c; best = mg; }
                    } catch (e) { diag.errors.push('inst' + i + ':' + e); }
                }
                if (!best) return { ok: true, hasQuest: false, count: 0, quests: [], diag: diag };
                var count = bestCnt > 0 ? bestCnt : 0;
                var quests = [];
                try {
                    var entries = best.field('_entries').value;   // Entry[] {hashCode,next,key,value}
                    var n = entries ? entries.length : 0;
                    for (var j = 0; j < n && quests.length < 20; j++) {
                        try {
                            var en = entries.get(j);
                            if (!en) continue;
                            var hc = 0;
                            try { hc = en.field('hashCode').value; } catch (ex) {}
                            if (hc < 0) continue;   // slot trống của Dictionary
                            var key = '';
                            try { var kv = en.field('key').value; key = kv ? (kv.content || '') : ''; } catch (ex) {}
                            var content = '';
                            try {
                                var idata = en.field('value').value;                 // Quest.ItemData
                                var h = idata ? idata.field('handle').value : null;   // QuestItem
                                if (h && h.handle && !h.handle.isNull()) {
                                    var tmp = h.field('contentTextMeshPro').value;
                                    if (tmp && tmp.handle && !tmp.handle.isNull()) {
                                        var mt = tmp.field('m_text').value;
                                        content = mt ? (mt.content || '') : '';
                                    }
                                }
                            } catch (ex) {}
                            if (key || content) quests.push({ key: key, content: content });
                        } catch (ex) { diag.errors.push('e' + j + ':' + ex); }
                    }
                } catch (e) { diag.errors.push('entries:' + e); }
                return { ok: true, hasQuest: count > 0, count: count, quests: quests, diag: diag };
            } catch (e) { return { ok: false, error: e.message, diag: diag }; }
        });
    },

    // Bật ẩn dialog Dã Tẩu trong `ms` mili-giây tới (bot gọi ngay trước khi thao tác DT).
    // Ngoài cửa sổ này, dialog hiện bình thường -> người chơi vẫn dùng THP / NPC khác.
    suppressDatauDialog: function(ms) {
        globalThis._datauSuppressUntil = Date.now() + (ms || 5000);
        return { ok: true, until: globalThis._datauSuppressUntil };
    },
    ping: function() {
        return {
            gameFd: gameFd,
            recvBufferSize: recvBuffer.length,
            recvTotal: _recvTotal,
            recvAny: _recvAny,
            fdsSeen: _fdsSeen,
            lastOps: _lastOps,
            sendTotal: _sendTotal,
            write: !!nativeWrite,
            sslRead: _sslReadOk,
            sslWrite: _sslWriteOk,
            sslError: _sslError,
            hasPosition: _lastPosition.x > 0
        };
    },

    getGameFd: function() { return gameFd; },

    setGameFd: function(fd) {
        gameFd = fd;
        return true;
    },

    // CHẨN ĐOÁN: bật để bắt gói GỬI trên MỌI fd (không chỉ gameFd) — dò opcode/fd của cú cast tay khi
    // gameFd-detect không ổn định. TẮT sau khi dò xong (giữ hiệu năng). Trả trạng thái.
    setCaptureAllSends: function(on) {
        _captureAllSends = !!on;
        return { ok: true, on: _captureAllSends, gameFd: gameFd };
    },

    // Chọn fd game theo BẰNG CHỨNG: fd nhận NHIỀU opcode game hợp lệ nhất (parse được). Bền với
    // đổi tài khoản/đổi map (game mở socket mới) — không đoán theo /proc. -1 nếu chưa thấy fd nào.
    pickBestFd: function() {
        var best = -1, bestN = 0;
        for (var fd in _fdsGameOps) {
            if (_fdsGameOps[fd] > bestN) { bestN = _fdsGameOps[fd]; best = parseInt(fd); }
        }
        return { ok: best >= 0, fd: best, n: bestN, gameOps: _fdsGameOps, cur: gameFd };
    },

    // Xoá bộ đếm bằng-chứng (gọi khi đổi account để dò lại từ đầu, tránh fd cũ lấn át).
    resetFdEvidence: function() { _fdsGameOps = {}; return true; },

    getRecvPackets: function() {
        var pkts = recvBuffer.slice();
        recvBuffer = [];
        return pkts;
    },

    // Buffer RIÊNG opcode 48 (thông báo nhặt đồ chí 'tổng tích lũy N') — không bị opcode 9/133 flood đẩy ra.
    getOp48: function() {
        var b = op48Buffer.slice();
        op48Buffer = [];
        return { ok: true, items: b };
    },
    // Buffer RIÊNG gói hội thoại/thưởng Dã Tẩu (34/124/126/166/245) — KHÔNG bị op9 flood đẩy ra ở thành đông.
    // poll_recv merge danh sách này vào recv_buffer (dedupe theo hex) -> wait_for_packet luôn bắt được.
    getDialogPackets: function() {
        var b = dialogBuffer.slice();
        dialogBuffer = [];
        return b;
    },
    getOp54: function() {   // drain buffer op54 (quest tracker) — bắt ĐỔI NV passive (không re-open Dã Tẩu)
        var b = op54Buffer.slice();
        op54Buffer = [];
        return { ok: true, items: b };
    },

    getSendPackets: function() {
        var pkts = sendBuffer.slice();
        sendBuffer = [];
        return pkts;
    },

    // Hook ChatInput.IsBil4i3nCommand (RVA 0x716E4C) + các so khớp chuỗi System.String.
    // Khi gửi 1 tin chat, IsBil4i3nCommand chạy & so text với hằng lệnh -> ta bắt được hằng đó.
    installBilienHook: function() {
        if (typeof Il2Cpp === 'undefined' || !il2cppBase)
            return { ok: false, error: 'il2cpp chưa nạp' };
        try {
            return Il2Cpp.perform(function() {
                if (globalThis._bilienHooked) return { ok: true, already: true };
                globalThis._bilienHooked = true;
                globalThis._bilienDepth = 0;

                function rdStr(p) {
                    try {
                        if (!p || p.isNull()) return null;
                        var len = p.add(0x10).readS32();
                        if (len < 0 || len > 2000) return null;
                        return p.add(0x14).readUtf16String(len);
                    } catch (e) { return null; }
                }

                // [1] Thử hook IsBil4i3nCommand để tự bật cờ (một số máy Frida không attach được -> bỏ qua,
                //     khi đó dựa vào probeBilienCommand tự bật cờ _bilienDepth quanh lúc gọi).
                try {
                    Interceptor.attach(il2cppBase.add(0x716E4C), {
                        onEnter: function(args) {
                            globalThis._bilienDepth++;
                            send({ type: 'bilien', ev: 'call', text: rdStr(args[1]) });
                        },
                        onLeave: function(ret) {
                            if (globalThis._bilienDepth > 0) globalThis._bilienDepth--;
                            send({ type: 'bilien', ev: 'ret', result: ret.toInt32() });
                        }
                    });
                    globalThis._bilienAttached = true;
                } catch (e) {
                    send({ type: 'bilien', ev: 'attach_fail', err: e.toString() });
                }

                // [2] Hook so khớp chuỗi -> bắt HẰNG lệnh trong lúc IsBil4i3n đang chạy
                var hooked = [];
                try {
                    var S = Il2Cpp.corlib.class('System.String');
                    var want = ['op_Equality', 'op_Inequality', 'StartsWith', 'Equals', 'Contains', 'IndexOf'];
                    var ms = S.methods;
                    for (var i = 0; i < ms.length; i++) {
                        var m = ms[i];
                        if (want.indexOf(m.name) < 0) continue;
                        try {
                            var addr = m.virtualAddress;
                            if (!addr || addr.isNull()) continue;
                            (function(mname) {
                                Interceptor.attach(addr, {
                                    onEnter: function(a) {
                                        if (!globalThis._bilienDepth) return;
                                        send({ type: 'bilien', ev: 'cmp', m: mname,
                                               a0: rdStr(a[0]), a1: rdStr(a[1]) });
                                    }
                                });
                            })(m.name);
                            hooked.push(m.name);
                        } catch (e) {}
                    }
                } catch (e) {}

                return { ok: true, hooked: hooked, base: il2cppBase.toString() };
            });
        } catch (e) {
            return { ok: false, error: e.toString() };
        }
    },

    // TỰ gọi ChatInput.IsBil4i3nCommand với vài chuỗi thử (không cần user gõ).
    // Phần so khớp bên trong sẽ chạy -> hook 'cmp' bắt được HẰNG lệnh.
    probeBilienCommand: function() {
        if (typeof Il2Cpp === 'undefined' || !il2cppBase)
            return { ok: false, error: 'il2cpp chưa nạp' };
        try {
            return Il2Cpp.perform(function() {
                var img = Il2Cpp.domain.assembly('Assembly-CSharp').image;
                var ChatInput = img.class('ChatInput');
                if (!ChatInput) return { ok: false, error: 'không thấy class ChatInput' };

                // Lấy instance ChatInput đang sống qua Resources.FindObjectsOfTypeAll(typeof(ChatInput))
                var inst = null, count = 0;
                try {
                    var Res = Il2Cpp.domain.assembly('UnityEngine.CoreModule').image.class('UnityEngine.Resources');
                    var sysType = ChatInput.type.object;
                    var arr = Res.method('FindObjectsOfTypeAll', 1).invoke(sysType);
                    if (arr && arr.length) { count = arr.length; inst = arr.get(0); }
                } catch (e) {
                    return { ok: false, error: 'FindObjectsOfTypeAll lỗi: ' + e.toString() };
                }
                if (!inst) return { ok: false, error: 'không tìm thấy instance ChatInput (mở khung chat trong game rồi thử lại)' };

                var tests = ['test', '/test', '@test', '#test', '.test', '!test', 'gm', 'bilien', 'BiLien', 'Bil4i3n'];
                var results = [];
                for (var i = 0; i < tests.length; i++) {
                    try {
                        send({ type: 'bilien', ev: 'probe', text: tests[i] });
                        globalThis._bilienDepth = 1;   // bật cờ để hook String 'cmp' ghi nhận
                        var r = inst.method('IsBil4i3nCommand').invoke(Il2Cpp.string(tests[i]));
                        globalThis._bilienDepth = 0;
                        results.push({ t: tests[i], r: (r === true || r === 1) });
                        send({ type: 'bilien', ev: 'probe_ret', text: tests[i], result: (r === true || r === 1) });
                    } catch (e) {
                        globalThis._bilienDepth = 0;
                        results.push({ t: tests[i], err: e.toString() });
                    }
                }
                return { ok: true, count: count, results: results };
            });
        } catch (e) {
            return { ok: false, error: e.toString() };
        }
    },

    // ===== ACCOUNT ROTATION: login/logout qua method il2cpp (KHÔNG packet, KHÔNG tap toạ độ) =====
    // Trạng thái: 'in_world' (đang trong game), 'at_login' (màn login), 'unknown' (đang chuyển/loading).
    // Đọc TEXT panel nhiệm vụ (NpcDialogInfiPc.descriptionTmp) = "Nhiệm vụ thứ N... X/Y quyển Thần bí <đồ|mật> chí".
    // CÓ CẢ loại lẫn X/Y -> tiến độ CHÍNH XÁC theo loại (khác op=48 generic). Trả LIST text mọi instance sống.
    readQuestTrackerText: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function () {
            var out = [];
            try {
                var img = Il2Cpp.domain.assembly('Assembly-CSharp').image;
                var Res = Il2Cpp.domain.assembly('UnityEngine.CoreModule').image.class('UnityEngine.Resources');
                var classes = ['NpcDialogInfiPc', 'NpcDialogPc', 'NpcDialog10Pc'];
                for (var c = 0; c < classes.length; c++) {
                    var k = null; try { k = img.class(classes[c]); } catch (e) { continue; }
                    if (!k) continue;
                    var arr = Res.method('FindObjectsOfTypeAll', 1).invoke(k.type.object);
                    if (!arr) continue;
                    for (var i = 0; i < arr.length; i++) {
                        try {
                            var inst = arr.get(i);
                            var tmp = inst.field('descriptionTmp').value;
                            if (tmp && !tmp.isNull()) {
                                var s = tmp.method('get_text').invoke();
                                if (s) { var t = s.content; if (t && t.length) out.push(t); }
                            }
                        } catch (e) {}
                    }
                }
            } catch (e) { return { ok: false, error: '' + e }; }
            return { ok: true, texts: out };
        });
    },

    // DISCOVERY: quét MỌI TextMeshProUGUI đang sống, trả text chứa 'chí'/'quyển'/'thần'/'X/N'.
    // Tìm xem text tiến độ "X/N quyển Thần bí <loại>" nằm ở UI nào (panel quest? tracker HUD?).
    // Tìm 1 CỤM TỪ trong MỌI TMP đang sống (vd dòng autoplay 'thoát khỏi vị trí đứng' = char kẹt). Trả {found,sample}.
    findTmpText: function(keyword) {
        if (typeof Il2Cpp === 'undefined') return { found: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function () {
            try {
                var Res = Il2Cpp.domain.assembly('UnityEngine.CoreModule').image.class('UnityEngine.Resources');
                var tmp = null;
                var asms = ['Unity.TextMeshPro', 'Unity.TextMeshPro.Runtime'];
                var names = ['TMPro.TextMeshProUGUI', 'TMPro.TMP_Text'];
                for (var a = 0; a < asms.length && !tmp; a++)
                    for (var b = 0; b < names.length && !tmp; b++) {
                        try { tmp = Il2Cpp.domain.assembly(asms[a]).image.class(names[b]); } catch (e) {}
                    }
                if (!tmp) return { found: false, error: 'no TMP class' };
                var arr = Res.method('FindObjectsOfTypeAll', 1).invoke(tmp.type.object);
                if (!arr) return { found: false };
                var kw = (keyword || '').toLowerCase();
                for (var i = 0; i < arr.length; i++) {
                    try {
                        var s = arr.get(i).method('get_text').invoke();
                        if (!s) continue;
                        var t = s.content;
                        if (t && t.toLowerCase().indexOf(kw) >= 0)
                            return { found: true, sample: t.replace(/<[^>]*>/g, '').substring(0, 120) };
                    } catch (e) {}
                }
            } catch (e) { return { found: false, error: '' + e }; }
            return { found: false };
        });
    },

    dumpQuestTexts: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function () {
            var out = [];
            try {
                var Res = Il2Cpp.domain.assembly('UnityEngine.CoreModule').image.class('UnityEngine.Resources');
                var tmp = null;
                var asms = ['Unity.TextMeshPro', 'Unity.TextMeshPro.Runtime'];
                var names = ['TMPro.TextMeshProUGUI', 'TMPro.TMP_Text'];
                for (var a = 0; a < asms.length && !tmp; a++) {
                    for (var b = 0; b < names.length && !tmp; b++) {
                        try { tmp = Il2Cpp.domain.assembly(asms[a]).image.class(names[b]); } catch (e) {}
                    }
                }
                if (!tmp) return { ok: false, error: 'no TMP class' };
                var arr = Res.method('FindObjectsOfTypeAll', 1).invoke(tmp.type.object);
                if (!arr) return { ok: true, texts: [] };
                for (var i = 0; i < arr.length; i++) {
                    try {
                        var s = arr.get(i).method('get_text').invoke();
                        if (!s) continue;
                        var t = s.content;
                        // 'nhiệm vụ thứ' = marker MỌI loại NV (tìm tấm/đồ/mua/trang bị); 'quyển|thần bí' giữ cho đồ chí.
                        if (t && /(quyển|thần bí|nhiệm vụ thứ)/i.test(t)) out.push(t.replace(/<[^>]*>/g, '').substring(0, 160));
                    } catch (e) {}
                }
            } catch (e) { return { ok: false, error: '' + e }; }
            return { ok: true, texts: out };
        });
    },

    // DISCOVERY: dump MỌI TextMeshProUGUI sống (KHÔNG lọc) + đường dẫn GameObject cha (để biết panel nào
    // giữ text 'X/Y quyển Thần bí' -> tìm class điều khiển kênh notice). Trả [{text, path:[go names]}].
    dumpAllTmp: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function () {
            var out = [];
            try {
                var Res = Il2Cpp.domain.assembly('UnityEngine.CoreModule').image.class('UnityEngine.Resources');
                var tmp = null;
                var asms = ['Unity.TextMeshPro', 'Unity.TextMeshPro.Runtime'];
                var names = ['TMPro.TextMeshProUGUI', 'TMPro.TMP_Text'];
                for (var a = 0; a < asms.length && !tmp; a++) {
                    for (var b = 0; b < names.length && !tmp; b++) {
                        try { tmp = Il2Cpp.domain.assembly(asms[a]).image.class(names[b]); } catch (e) {}
                    }
                }
                if (!tmp) return { ok: false, error: 'no TMP class' };
                var arr = Res.method('FindObjectsOfTypeAll', 1).invoke(tmp.type.object);
                if (!arr) return { ok: true, items: [] };
                for (var i = 0; i < arr.length; i++) {
                    try {
                        var comp = arr.get(i);
                        var s = comp.method('get_text').invoke();
                        var t = s ? s.content : '';
                        if (!t || !t.trim()) continue;
                        var path = [];
                        var tr = comp.method('get_transform').invoke();
                        var depth = 0;
                        while (tr && depth < 8) {
                            try {
                                var g = tr.method('get_gameObject').invoke();
                                var nm = g.method('get_name').invoke();
                                path.push(nm ? nm.content : '?');
                            } catch (e2) { path.push('?'); }
                            tr = tr.method('get_parent').invoke();
                            depth++;
                        }
                        out.push({ text: t.replace(/<[^>]*>/g, '').substring(0, 70), path: path });
                    } catch (e) {}
                }
            } catch (e) { return { ok: false, error: '' + e }; }
            return { ok: true, items: out };
        });
    },

    // ĐỌC tracker NV trái: QuestItem(Clone) gồm QuestTitle + QuestContent. Trả content của item
    // QuestTitle=='Dã Tẩu' (chứa tiến độ 'X/Y quyển Thần bí đồ chí' khi làm NV đồ chí). LUÔN hiện bất kể kênh
    // 1/2/3 -> KHỎI cần chuyển kênh. Trả {ok, datau_content, all:[{title,content}]}.
    readDatauTracker: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function () {
            try {
                var Res = Il2Cpp.domain.assembly('UnityEngine.CoreModule').image.class('UnityEngine.Resources');
                var tmp = null;
                var asms = ['Unity.TextMeshPro', 'Unity.TextMeshPro.Runtime'];
                var names = ['TMPro.TextMeshProUGUI', 'TMPro.TMP_Text'];
                for (var a = 0; a < asms.length && !tmp; a++) {
                    for (var b = 0; b < names.length && !tmp; b++) {
                        try { tmp = Il2Cpp.domain.assembly(asms[a]).image.class(names[b]); } catch (e) {}
                    }
                }
                if (!tmp) return { ok: false, error: 'no TMP class' };
                var arr = Res.method('FindObjectsOfTypeAll', 1).invoke(tmp.type.object);
                if (!arr) return { ok: true, all: [] };
                var groups = {};   // instanceId QuestItem -> {title, content}
                for (var i = 0; i < arr.length; i++) {
                    try {
                        var comp = arr.get(i);
                        var s = comp.method('get_text').invoke();
                        var t = s ? s.content : '';
                        if (!t) continue;
                        var tr = comp.method('get_transform').invoke();
                        var go = tr.method('get_gameObject').invoke();
                        var role = go.method('get_name').invoke().content;   // QuestTitle / QuestContent
                        if (role !== 'QuestTitle' && role !== 'QuestContent') continue;
                        var par = tr.method('get_parent').invoke();
                        if (!par) continue;
                        var pgo = par.method('get_gameObject').invoke();
                        if (pgo.method('get_name').invoke().content !== 'QuestItem(Clone)') continue;
                        var key = '' + pgo.method('GetInstanceID').invoke();
                        if (!groups[key]) groups[key] = { title: '', content: '' };
                        if (role === 'QuestTitle') groups[key].title = t.replace(/<[^>]*>/g, '');
                        else groups[key].content = t.replace(/<[^>]*>/g, '');
                    } catch (e) {}
                }
                var all = [], datau = null;
                for (var k in groups) {
                    all.push(groups[k]);
                    if (/d[ãa]\s*t[ẩa]u/i.test(groups[k].title)) datau = groups[k].content;
                }
                return { ok: true, datau_content: datau, all: all };
            } catch (e) { return { ok: false, error: '' + e }; }
        });
    },

    diagFindClass: function(name) {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function () {
            var img = Il2Cpp.domain.assembly('Assembly-CSharp').image;
            var tries = [name, 'game.scene.login.' + name, 'game.network.' + name, 'game.ui.' + name, 'game.' + name];
            var out = [];
            for (var i = 0; i < tries.length; i++) {
                var k = null, cnt = -1, err = '';
                try { k = img.class(tries[i]); } catch (e) { err = 'class:' + e; }
                if (k) {
                    try {
                        var Res = Il2Cpp.domain.assembly('UnityEngine.CoreModule').image.class('UnityEngine.Resources');
                        var arr = Res.method('FindObjectsOfTypeAll', 1).invoke(k.type.object);
                        cnt = arr ? arr.length : -2;
                    } catch (e) { err = 'find:' + e; }
                }
                out.push({ n: tries[i], resolved: !!k, count: cnt, err: err });
            }
            return { ok: true, out: out };
        });
    },

    // XOÁ cache _playerMainInstance -> lần đọc kế re-find qua static PlayerMain.instance (tránh đọc char CŨ
    // sau logout: cache cũ pass validation vì mapId cũ vẫn hợp lệ). Gọi sau logout + sau tạo char.
    clearPlayerMain: function() {
        _playerMainInstance = null;
        return { ok: true };
    },

    getLoginState: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        // CHECK LOGIN UI TRƯỚC: nếu còn LoginManger/AccountLoginPopup -> đang ở màn login (kể cả màn server),
        // CHƯA vào world — kể cả khi _playerMainInstance còn STALE từ session cũ (logout chưa xoá kịp).
        return Il2Cpp.perform(function () {
            var lm = findLoginInstance('LoginManger');
            var ap = findLoginInstance('AccountLoginPopup');
            if (lm || ap) return { ok: true, state: 'at_login', hasLoginManger: !!lm, hasLoginPopup: !!ap };
            var pm = readPlayerMainDirect();
            if (pm.ok && _playerMainInstance) return { ok: true, state: 'in_world' };
            return { ok: true, state: 'unknown' };
        });
    },

    logoutAccount: function() {
        // LoginManger CHỈ sống ở màn login (probe xác nhận: in-world không có). Lúc đang TRONG GAME phải
        // dùng UIManager.BackToLogin() (UIManager là MonoBehaviour sống in-world) -> về màn login. Fallback:
        // NetCoreManager.Disconnect(); cuối cùng LoginManger.LogOut() (nếu đã ở màn login).
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function () {
            var tried = [];
            var ui = findLoginInstance('UIManager');
            if (ui) { try { ui.method('BackToLogin').invoke(); _playerMainInstance = null;
                            return { ok: true, via: 'UIManager.BackToLogin' }; }
                      catch (e) { tried.push('BackToLogin:' + e); } }
            var nc = findLoginInstance('NetCoreManager');
            if (nc) { try { nc.method('Disconnect').invoke(); _playerMainInstance = null;
                            return { ok: true, via: 'NetCoreManager.Disconnect' }; }
                      catch (e) { tried.push('Disconnect:' + e); } }
            var lm = findLoginInstance('LoginManger');
            if (lm) { try { lm.method('LogOut').invoke(); _playerMainInstance = null;
                            return { ok: true, via: 'LoginManger.LogOut' }; }
                      catch (e) { tried.push('LogOut:' + e); } }
            return { ok: false, error: 'không gọi được logout', tried: tried,
                     hasUI: !!ui, hasNet: !!nc, hasLM: !!lm };
        });
    },

    // CHUẨN BỊ FORM NHẬP ACC SẠCH để đổi account: game auto-resume acc cũ -> phải LogOut (xoá session) +
    // LoginScreen (hiện form). Nếu đang in-world -> UIManager.BackToLogin về login scene trước.
    prepareLoginForm: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function () {
            var done = [];
            var lm = findLoginInstance('LoginManger');
            if (!lm) {   // chưa ở login scene (đang in-world) -> BackToLogin
                var ui = findLoginInstance('UIManager');
                if (ui) { try { ui.method('BackToLogin').invoke(); done.push('BackToLogin'); } catch (e) {} }
                lm = findLoginInstance('LoginManger');
            }
            if (lm) {
                try { lm.method('LogOut').invoke(); done.push('LogOut'); } catch (e) { done.push('LogOut_err'); }
                try { lm.method('LoginScreen').invoke(); done.push('LoginScreen'); } catch (e) { done.push('LoginScreen_err'); }
            }
            return { ok: !!lm, done: done };
        });
    },

    loginAccount: function(acc, pass) {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function () {
            var ap = findLoginInstance('AccountLoginPopup');
            if (!ap) return { ok: false, error: 'no live AccountLoginPopup (chưa ở màn login?)' };
            var setOk = false, clickOk = false, warn = '', rbAcc = null;
            // Set text vào ô input (đề phòng OnClickLoginButton đọc field thay vì arg).
            try {
                var fa = ap.field('tmpInputAccount').value;
                var fp = ap.field('tmpInputPassword').value;
                if (fa && !fa.isNull()) fa.method('set_text').invoke(Il2Cpp.string(acc));
                if (fp && !fp.isNull()) fp.method('set_text').invoke(Il2Cpp.string(pass));
                setOk = true;
                try { rbAcc = fa.method('get_text').invoke().content; } catch (e) {}   // ô account THỰC nhận gì
            } catch (e) { warn += 'set_text:' + e + '; '; }
            // Bấm login. 'breakpoint triggered' là artifact của bridge SAU khi method đã chạy -> login VẪN
            // đi (đã verify in_world). Coi ok nếu ÍT NHẤT 1 bước chạy; phán quyết thật = wait_in_world (Python).
            try {
                ap.method('OnClickLoginButton', 2).invoke(Il2Cpp.string(acc), Il2Cpp.string(pass));
                clickOk = true;
            } catch (e) { warn += 'click:' + e; }
            return { ok: (setOk || clickOk), setOk: setOk, clickOk: clickOk, sentAcc: acc, rbAcc: rbAcc, warn: warn };
        });
    },

    // ĐỌC TEXT đang hiện trên màn LOGIN (TMP) — bắt POPUP TỪ CHỐI của server ("tài khoản đang đăng nhập",
    // "sai mật khẩu", "bảo trì", "server đầy"…) để biết VÌ SAO login fail thay vì chỉ "login lỗi" mù mịt.
    // An toàn: Resources.FindObjectsOfTypeAll + getter Unity (get_text/get_activeInHierarchy), KHÔNG gc.choose.
    loginScreenMessage: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function () {
            try {
                var Res = Il2Cpp.domain.assembly('UnityEngine.CoreModule').image.class('UnityEngine.Resources');
                var tmpCls = null;
                try { tmpCls = Il2Cpp.domain.assembly('Unity.TextMeshPro').image.class('TMPro.TextMeshProUGUI'); } catch (e) {}
                if (!tmpCls) return { ok: false, error: 'no TMP class' };
                var arr = Res.method('FindObjectsOfTypeAll', 1).invoke(tmpCls.type.object);
                var out = [];
                if (arr && arr.length) {
                    for (var i = 0; i < arr.length && out.length < 50; i++) {
                        try {
                            var t = arr.get(i);
                            if (!t || t.handle.isNull()) continue;
                            var act = false;
                            try { act = t.method('get_gameObject').invoke().method('get_activeInHierarchy').invoke(); } catch (e) {}
                            if (!act) continue;
                            var s = '';
                            try { s = t.method('get_text').invoke().content; } catch (e) {}
                            s = (s || '').trim();
                            if (s && s.length <= 80) out.push(s);
                        } catch (e) {}
                    }
                }
                return { ok: true, texts: out };
            } catch (e) { return { ok: false, error: e.toString() }; }
        });
    },

    // TẠO NHÂN VẬT bằng INVOKE (giống login): set tên vào createNameInputTmp + invoke UIManager.CreateCharacter()
    // -> game TỰ mã hoá field 'data' (op5) đúng session. (Replay raw op5 bị server từ chối vì data đổi mỗi request.)
    // PHẢI đang ở màn TẠO NHÂN VẬT (createNameInputTmp != null). Tuỳ chọn chọn phái qua createCharSelectSeries.
    createCharInvoke: function(name, series, sex) {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        if (typeof series !== 'number') series = 0;   // 0=Metal/Kim ... 4=Earth (khớp op5 factionId=0)
        if (typeof sex !== 'number') sex = 0;          // 0=man, 1=girl
        return Il2Cpp.perform(function () {
            var ui = findLoginInstance('UIManager');
            if (!ui) return { ok: false, error: 'no UIManager instance' };
            var setOk = false, clickOk = false, serOk = false, warn = '';
            // CHỌN PHÁI + GIỚI trước (CreateCharacter đọc currentSeries/currentSex; màn mới chưa chọn -> fail).
            try { ui.method('SelectSeries', 1).invoke(series); serOk = true; }
            catch (e) { warn += 'SelectSeries:' + e + '; '; }
            try { ui.method('ChangeActiveCharacter', 1).invoke(sex); }
            catch (e) { warn += 'ChangeActiveCharacter:' + e + '; '; }
            var readback = null;
            try {
                var inp = ui.field('createNameInputTmp').value;
                if (inp && !inp.isNull()) {
                    inp.method('set_text').invoke(Il2Cpp.string(name)); setOk = true;
                    try { readback = inp.method('get_text').invoke().content; } catch (e) {}
                }
                else warn += 'createNameInputTmp NULL (chưa mở màn tạo char?); ';
            } catch (e) { warn += 'set_text:' + e + '; '; }
            try {
                ui.method('CreateCharacter', 0).invoke();
                clickOk = true;
            } catch (e) { warn += 'CreateCharacter:' + e; }   // 'breakpoint triggered' = đã chạy
            return { ok: (setOk && clickOk), setOk: setOk, clickOk: clickOk, serOk: serOk,
                     sent: name, readback: readback, warn: warn };
        });
    },
    // Đọc trạng thái màn tạo char: createNameInputTmp có null không (= đã ở màn tạo chưa) + tên hiện tại.
    createCharProbe: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function () {
            var ui = findLoginInstance('UIManager');
            if (!ui) return { ok: false, error: 'no UIManager' };
            var r = { ok: true };
            try { var inp = ui.field('createNameInputTmp').value; r.inputNull = (!inp || inp.isNull());
                   if (!r.inputNull) { try { r.curText = inp.method('get_text').invoke().content; } catch(e){} } }
            catch (e) { r.err = '' + e; }
            return r;
        });
    },

    // Mở màn TẠO NHÂN VẬT (fallback nếu account mới không tự mở): invoke UIManager.OpenBackgroundCreateCharacter().
    openCreateScreen: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function () {
            var ui = findLoginInstance('UIManager');
            if (!ui) return { ok: false, error: 'no UIManager' };
            try { ui.method('OpenBackgroundCreateCharacter', 0).invoke(); return { ok: true }; }
            catch (e) { return { ok: false, error: '' + e }; }   // 'breakpoint triggered' = đã chạy
        });
    },

    // Nudge: re-trigger chọn SERVER LẦN TRƯỚC (game tự nhớ). KHÔNG tự chọn server cụ thể (user tự lo
    // account mới). Gọi khi login xong mà chưa vào world (phòng auto-select chậm).
    selectLastServer: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function () {
            var rl = findLoginInstance('RegionServerList');
            if (!rl) return { ok: false, error: 'no RegionServerList' };
            try { var r = rl.method('LoadLastServerSelected').invoke(); return { ok: true, loaded: (r === true || r === 1) }; }
            catch (e) { return { ok: false, error: 'LoadLastServerSelected: ' + e }; }
        });
    },

    enterWorld: function() {   // FALLBACK (user xác nhận auto-enter; chỉ dùng nếu kẹt at_login)
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function () {
            var lm = findLoginInstance('LoginManger');
            if (!lm) return { ok: false, error: 'no LoginManger' };
            try { lm.method('OpenGame').invoke(); return { ok: true, tried: 'OpenGame' }; }
            catch (e) {
                try { lm.method('PlayNowScreen').invoke(); return { ok: true, tried: 'PlayNowScreen' }; }
                catch (e2) { return { ok: false, error: 'enterWorld: ' + e2 }; }
            }
        });
    },

    // Read last known position from recv hooks (no tcpdump needed!)
    readPosition: function() {
        return _lastPosition;
    },

    getBagSlots: function() {
        if (typeof Il2Cpp === 'undefined') return {ok: false, error: "il2cpp not loaded"};
        try {
            var slots = [];
            Il2Cpp.perform(function() {
                var PlayerSelfBagarate = Il2Cpp.domain.assembly("Assembly-CSharp").image.class("game.ui.PlayerSelfBagarate");
                var instances = Il2Cpp.gc.choose(PlayerSelfBagarate);
                for (var i = 0; i < instances.length; i++) {
                    var bag = instances[i];
                    var cellListing = bag.field("cellListing").value;
                    if (!cellListing.isNull()) {
                        var itemsArr = cellListing.field("_items").value;
                        var count = cellListing.field("_size").value;
                        for (var j = 0; j < count; j++) {
                            try {
                                var cellObj = itemsArr.get(j);
                                if (!cellObj.isNull()) {
                                    var itemObj = cellObj.field("item").value;
                                    if (!itemObj.isNull()) {
                                        slots.push(j);
                                    }
                                }
                            } catch (e) {}
                        }
                    }
                }
            });
            return {ok: true, count: slots.length, slots: slots};
        } catch(e) {
            return {ok: false, error: e.toString()};
        }
    },

    // Đọc inventory thật từ PlayerMain.items (ConcurrentDictionary<int,Item>) qua frida-il2cpp-bridge.
    // KHÔNG cần mở bag, KHÔNG cần gc.choose (gc.choose bị strip). Trả item kèm thuộc tính (Attrib.type+value).
    // EQUIP item theo index: iterate PlayerMain.items tìm itemObj.index==idx -> invoke Item.SetItemLocation(place).
    // place: thử các giá trị (1..) để tìm slot mặc đúng. Trả tried + genre/detail của item để soi.
    equipItemByIndex: function(idx, place) {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'no il2cpp' };
        if (typeof place !== 'number') place = 1;
        var pmRes = readPlayerMainDirect();
        if (!pmRes.ok || !_playerMainInstance) return { ok: false, error: 'no PlayerMain' };
        return Il2Cpp.perform(function() {
            try {
                var pm = new Il2Cpp.Object(_playerMainInstance);
                var dict = pm.field('items').value;
                var buckets = dict.field('_tables').value.field('_buckets').value;
                for (var b = 0; b < buckets.length; b++) {
                    var node = buckets.get(b);
                    while (node && !node.isNull()) {
                        var it = node.field('_value').value;
                        if (it && !it.isNull()) {
                            var ix = -1; try { ix = it.field('index').value; } catch (e) {}
                            if (ix === idx) {
                                var info = { ok: true, found: true, idx: idx, tried: [] };
                                try { info.genre = it.field('genre').value; } catch (e) {}
                                try { info.detail = it.field('detail').value; } catch (e) {}
                                try { info.equipPlace = it.field('equipPlace').value; } catch (e) {}
                                try { it.method('SetItemLocation', 1).invoke(place); info.tried.push('SetItemLocation(' + place + ')'); }
                                catch (e) { info.tried.push('SetItemLocation_err:' + e); }
                                return info;
                            }
                        }
                        try { node = node.field('_next').value; } catch (e) { break; }
                    }
                }
                return { ok: false, error: 'idx ' + idx + ' không thấy' };
            } catch (e) { return { ok: false, error: '' + e }; }
        });
    },

    // EQUIP client-side đúng: PlayerSelfProperties.EquipItem(Item) — gửi op24 raw KHÔNG mặc (client-side).
    // Lấy Item object từ PlayerMain.items theo index rồi invoke EquipItem(item).
    equipItemViaProperties: function(idx) {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'no il2cpp' };
        var pmRes = readPlayerMainDirect();
        if (!pmRes.ok || !_playerMainInstance) return { ok: false, error: 'no PlayerMain' };
        return Il2Cpp.perform(function() {
            try {
                var props = findLoginInstance('PlayerSelfProperties');
                if (!props) return { ok: false, error: 'no PlayerSelfProperties instance' };
                var pm = new Il2Cpp.Object(_playerMainInstance);
                var buckets = pm.field('items').value.field('_tables').value.field('_buckets').value;
                var itemObj = null;
                for (var b = 0; b < buckets.length && !itemObj; b++) {
                    var node = buckets.get(b);
                    while (node && !node.isNull()) {
                        var it = node.field('_value').value;
                        if (it && !it.isNull()) {
                            var ix = -1; try { ix = it.field('index').value; } catch (e) {}
                            if (ix === idx) { itemObj = it; break; }
                        }
                        try { node = node.field('_next').value; } catch (e) { break; }
                    }
                }
                if (!itemObj) return { ok: false, error: 'item idx ' + idx + ' not found' };
                props.method('EquipItem', 1).invoke(itemObj);   // 'breakpoint triggered' = đã chạy
                return { ok: true, equipped: idx };
            } catch (e) { return { ok: false, error: '' + e }; }
        });
    },

    dumpBagItems: function() {
        if (typeof Il2Cpp === 'undefined') return {ok: false, error: "il2cpp not loaded"};
        try {
            // Đảm bảo có PlayerMain (raw native, chạy ngoài perform được)
            var pmRes = readPlayerMainDirect();
            if (!pmRes.ok || !_playerMainInstance) return {ok: false, error: "PlayerMain not found: " + (pmRes.error || '')};

            var result = [];
            var diag = { buckets: 0, nodes: 0, withAttrib: 0, errors: [] };

            function readAttribs(itemObj) {
                var attribs = [];
                var magicList = null;
                try { magicList = itemObj.field("magicAttrib").value; } catch(e) {}
                if (magicList && !magicList.isNull()) {
                    var sz = 0, arr = null;
                    try { sz = magicList.field("_size").value; } catch(e) {}
                    try { arr = magicList.field("_items").value; } catch(e) {}
                    for (var k = 0; arr && k < sz; k++) {
                        try {
                            var a = arr.get(k);
                            if (!a || a.isNull()) continue;
                            var t = "";
                            try { var ts = a.field("type").value; if (ts && !ts.isNull()) { try { t = ts.content; } catch(e2) { t = ts.toString(); } } } catch(e3) {}
                            var vals = [];
                            try { var v = a.field("value").value; if (v && !v.isNull()) { for (var m = 0; m < v.length; m++) vals.push(v.get(m)); } } catch(e4) {}
                            attribs.push({ type: t, value: vals });
                        } catch(e5) {}
                    }
                }
                return attribs;
            }

            // QUAN TRỌNG: Il2Cpp.perform CHẠY BẤT ĐỒNG BỘ -> phải RETURN promise của nó
            // để exports_sync (Python) chờ kết quả, nếu không sẽ trả về trước khi callback chạy xong.
            return Il2Cpp.perform(function() {
                var pm = new Il2Cpp.Object(_playerMainInstance);
                try { diag.pmClass = pm.class.type.name; } catch(e) { diag.errors.push("pmClass: " + e); }
                // Thử các method đếm item để biết PlayerMain có rỗng không
                try { diag.bagCount = pm.method("GetBagarateItemCount").invoke(); } catch(e) { diag.errors.push("GetBagarateItemCount: " + e); }
                try { diag.allItemCount = pm.method("GetAllItemCount").invoke(); } catch(e) {}

                var dict = pm.field("items").value;        // ConcurrentDictionary<int, Item>
                if (!dict || dict.isNull()) { diag.errors.push("items dict null"); return { ok: true, diag: diag, items: result }; }
                try { diag.dictClass = dict.class.type.name; } catch(e) {}
                try { diag.dictCount = dict.method("get_Count").invoke(); } catch(e) { diag.errors.push("get_Count: " + e); }
                // Liệt kê tên field thật của dict để biết tên đúng (_tables vs m_tables...)
                try {
                    var fnames = [];
                    var fs = dict.class.fields;
                    for (var fi = 0; fi < fs.length; fi++) fnames.push(fs[fi].name);
                    diag.dictFields = fnames;
                } catch(e) {}

                var tables = dict.field("_tables").value;   // Tables<int, Item>
                if (!tables || tables.isNull()) { diag.errors.push("_tables null"); return { ok: true, diag: diag, items: result }; }
                var buckets = tables.field("_buckets").value; // Node[]
                if (!buckets || buckets.isNull()) { diag.errors.push("_buckets null"); return { ok: true, diag: diag, items: result }; }
                diag.buckets = buckets.length;

                for (var b = 0; b < buckets.length; b++) {
                    var node = null;
                    try { node = buckets.get(b); } catch(e) { continue; }
                    while (node && !node.isNull()) {
                        diag.nodes++;
                        try {
                            var slot = node.field("_key").value;          // int
                            var itemObj = node.field("_value").value;     // Item
                            if (itemObj && !itemObj.isNull()) {
                                var attribs = readAttribs(itemObj);
                                var entry = { slot: slot };
                                // index (ItemDatafield 0x20) = id item -> THỬ cho trade itemid (eTradeProcessSendItemToGsv).
                                try { entry.index = itemObj.field("index").value; } catch(e) {}
                                try { entry.genre = itemObj.field("genre").value; } catch(e) {}
                                try { entry.detail = itemObj.field("detail").value; } catch(e) {}
                                try { entry.particular = itemObj.field("particular").value; } catch(e) {}
                                try { entry.level = itemObj.field("level").value; } catch(e) {}
                                try { entry.series = itemObj.field("series").value; } catch(e) {}
                                try { entry.stack = itemObj.field("stack").value; } catch(e) {}
                                try { entry.location = itemObj.field("location").value; } catch(e) {}
                                try { entry.equipPlace = itemObj.field("equipPlace").value; } catch(e) {}
                                // cờ KHOÁ: GetLockstate() != 0 = đồ đang khoá -> KHÔNG giao dịch
                                try { entry.lockstate = itemObj.method("GetLockstate").invoke(); } catch(e) {}
                                try { entry.lockUntil = itemObj.method("GetLockToTimestampSeconds").invoke(); } catch(e) {}
                                // HOÀNG KIM = "Gold equip". CẨN THẬN: goldequip (GoldEquipBase) KHÔNG null cho MỌI item
                                // (game khởi tạo object rỗng) -> check != null báo NHẦM mọi món = hoàng kim, làm CHẾT
                                // luồng bán/lọc đồ. PHẢI check NỘI DUNG: hoàng kim thật có magic0..5/idSet != 0 hoặc
                                // magicIndexList có phần tử. Field-only (không invoke IsEmpty -> an toàn).
                                try {
                                    var _ge = itemObj.field("goldequip").value;
                                    var _isg = false;
                                    var _gdiag = null;
                                    if (_ge && !_ge.isNull()) {
                                        var _misz = -1, _mags = [];
                                        try {
                                            var _mi = _ge.field("magicIndexList").value;
                                            if (_mi && !_mi.isNull()) { _misz = _mi.field("_size").value | 0; if (_misz > 0) _isg = true; }
                                        } catch(e) {}
                                        try {
                                            var _gm = ["magic0","magic1","magic2","magic3","magic4","magic5","idSet"];
                                            for (var _gi = 0; _gi < _gm.length; _gi++) {
                                                var _v = _ge.field(_gm[_gi]).value | 0;
                                                _mags.push(_v);
                                                if (_v !== 0) _isg = true;
                                            }
                                        } catch(e) {}
                                        _gdiag = {misz: _misz, mags: _mags};   // DIAG: để verify discriminator trên account thật
                                    }
                                    entry.isGold = _isg;
                                    entry.goldDiag = _gdiag;
                                } catch(e) { entry.isGold = false; }
                                // TÊN item qua ItemDatabase.GetItemName(item, itemType, withMaterial) -> tìm THP theo tên.
                                try {
                                    if (!globalThis._idbClass) globalThis._idbClass = Il2Cpp.domain.assembly("Assembly-CSharp").image.class("ItemDatabase");
                                    // thử itemType = genre, nếu rỗng thử 0
                                    var _nm = globalThis._idbClass.method("GetItemName").invoke(itemObj, entry.genre || 0, false);
                                    entry.name = _nm ? _nm.content : "";
                                    if (!entry.name) {
                                        var _nm2 = globalThis._idbClass.method("GetItemName").invoke(itemObj, 0, false);
                                        entry.name = _nm2 ? _nm2.content : "";
                                    }
                                } catch(e) { entry.name = ""; entry.nameErr = e.message; }
                                entry.attribs = attribs;
                                if (attribs.length > 0) diag.withAttrib++;
                                if (result.length < 120) result.push(entry);
                            }
                        } catch(e6) {}
                        try { node = node.field("_next").value; } catch(e7) { node = null; }
                    }
                }
                return { ok: true, diag: diag, items: result };
            });
        } catch(e) {
            return { ok: false, error: e.toString() };
        }
    },

    // Read position directly from IL2CPP PlayerMain memory (no packets needed!)
    readPositionFromMemory: function() {
        if (!il2cppBase) return { ok: false, error: 'il2cpp not found' };
        try {
            if (typeof _playerMainInstance === 'undefined' || _playerMainInstance === null) {
                var loadRes = readPlayerMainDirect();
                if (!loadRes.ok) return { ok: false, error: 'PlayerMain not captured' };
            }
            var characterPtr32 = _playerMainInstance.add(0x14).readU32();
            if (characterPtr32 === 0) return { ok: false, error: 'character not found' };
            var characterPtr = ptr(characterPtr32 >>> 0);
            var x = characterPtr.add(0x8C).readS32();
            var y = characterPtr.add(0x90).readS32();
            if (x > 0 && y > 0) {
                _lastPosition = { x: x, y: y, eid: 'memory', ts: Date.now() };
                return { ok: true, x: x, y: y, source: 'Character' };
            }
            return { ok: false, error: 'Position was zero' };
        } catch(e) {
            return { ok: false, error: e.stack };
        }
    },

    // Get debug info about hook status
    getDebugInfo: function() {
        return {
            gameFd: gameFd,
            recvTotal: _recvTotal,
            sendTotal: _sendTotal,
            recvBufferSize: recvBuffer.length,
            sslReadOk: _sslReadOk,
            sslWriteOk: _sslWriteOk,
            sslError: _sslError,
            writeOk: !!nativeWrite,
            writeSource: writeSource,
            lastPosition: _lastPosition,
            il2cppBase: il2cppBase ? il2cppBase.toString() : null,
            playerMain: _playerMainInstance ? _playerMainInstance.toString() : null
        };
    },

    getPlayerMain: function() {
        return readPlayerMainDirect();
    },

    scanPlayerMainCandidates: function(expectedMapId) {
        var targetMapId = expectedMapId || 53;
        var candidates = [];
        try {
            var ranges = Process.enumerateRanges({ protection: 'rw-', coalesce: true });
            var readable = Process.enumerateRanges({ protection: 'r--', coalesce: true })
                .concat(Process.enumerateRanges({ protection: 'rw-', coalesce: true }))
                .concat(Process.enumerateRanges({ protection: 'r-x', coalesce: true }))
                .concat(Process.enumerateRanges({ protection: 'rwx', coalesce: true }));
            function inRanges(v) {
                if (v === 0) return false;
                var pv = ptr(v >>> 0);
                for (var k = 0; k < readable.length; k++) {
                    if (pv.compare(readable[k].base) >= 0 && pv.compare(readable[k].base.add(readable[k].size)) < 0) {
                        return true;
                    }
                }
                return false;
            }
            for (var r = 0; r < ranges.length; r++) {
                var range = ranges[r];
                if (range.size > 16 * 1024 * 1024) continue;
                var start = range.base;
                var end = range.base.add(range.size - 0x100);
                for (var p = start; p.compare(end) < 0; p = p.add(4)) {
                    try {
                        var mapId = p.add(0xE4).readS32();
                        if (targetMapId !== -1 && mapId !== targetMapId) continue;
                        if (mapId < 0 || mapId > 1000) continue;

                        var items32 = p.add(0x30).readU32();
                        var skills32 = p.add(0x38).readU32();
                        var skillgames32 = p.add(0x40).readU32();
                        var world32 = p.add(0x48).readU32();
                        var target32 = p.add(0xA0).readU32();
                        var near = 0;
                        if (inRanges(items32)) near++;
                        if (inRanges(skills32)) near++;
                        if (inRanges(skillgames32)) near++;
                        if (inRanges(world32)) near++;
                        if (inRanges(target32)) near++;
                        if (near < 3) continue;

                        var findingRunning = p.add(0xE8).readU8();
                        var findingUpdate = p.add(0xE9).readU8();

                        candidates.push({
                            ptr: p.toString(),
                            mapId: mapId,
                            score: near,
                            items: ptr(items32 >>> 0).toString(),
                            skills: ptr(skills32 >>> 0).toString(),
                            skillgames: ptr(skillgames32 >>> 0).toString(),
                            world: ptr(world32 >>> 0).toString(),
                            target: ptr(target32 >>> 0).toString(),
                            findingRunning: findingRunning,
                            findingUpdate: findingUpdate
                        });
                        if (candidates.length >= 50) {
                            candidates.sort(function(a, b) { return b.score - a.score; });
                            return { ok: true, candidates: candidates };
                        }
                    } catch(e) {}
                }
            }
            candidates.sort(function(a, b) { return b.score - a.score; });
            return { ok: true, candidates: candidates };
        } catch(e) {
            return { ok: false, error: e.toString() };
        }
    },

    setPlayerMain: function(ptrText) {
        try {
            _playerMainInstance = ptr(ptrText);
            return { ok: true, playerMain: _playerMainInstance.toString() };
        } catch(e) {
            return { ok: false, error: e.toString() };
        }
    },

    // BẬT/TẮT autoplay game qua il2cpp ButtonAutoplay.EnableAutoplay(enabled, resetMovingPoint).
    // Gói 140 đơn thuần KHÔNG khởi động được auto client từ đầu -> phải gọi hàm này.
    enableAutoplay: function(on) {
        // 'BẤM nút Auto' thật = ButtonAutoplay.EnableAutoplay(on,true) -> game tự cày bằng profile mặc định
        // (Luyện công) MÀ KHÔNG cần guid. Đây là cơ chế khởi động autoplay (gói 140 chỉ set profile, không start).
        // Dùng FindObjectsOfTypeAll thay gc.choose -> KHÔNG STOP-THE-WORLD -> KHÔNG đơ/crash.
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function() {
            try {
                var img = Il2Cpp.domain.assembly("Assembly-CSharp").image;
                var k = img.class("game.ui.rightHotkey.ButtonAutoplay");
                if (!k) return { ok: false, error: 'no ButtonAutoplay class' };
                var Res = Il2Cpp.domain.assembly('UnityEngine.CoreModule').image.class('UnityEngine.Resources');
                var insts = Res.method('FindObjectsOfTypeAll', 1).invoke(k.type.object);   // KHÔNG gc.choose
                if (!insts || insts.length === 0)
                    return { ok: false, error: 'Chưa có instance ButtonAutoplay (vào game 1 lần để UI tạo nút Auto).' };
                var applied = 0;
                for (var i = 0; i < insts.length; i++) {
                    try { insts.get(i).method("EnableAutoplay").invoke(!!on, true); applied++; } catch (e) {}
                }
                return { ok: applied > 0, count: insts.length, applied: applied };
            } catch (e) { return { ok: false, error: e.message }; }
        });
    },

    // SET DEFAULT PROFILE của autoplay = guid (MainUnity.SetDefaultProfile). CỰC QUAN TRỌNG chống WIPE:
    // nút Auto (EnableAutoplay) cày bằng profile MẶC ĐỊNH; acc mới default RỖNG -> bấm nút = client gửi
    // eApplyAutoplayProfile RỖNG = XOÁ profile. Set default = guid hợp lệ TRƯỚC khi bấm nút -> an toàn.
    setDefaultAutoplayProfile: function(guid) {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        if (!guid) return { ok: false, error: 'empty guid' };
        var pmRes = readPlayerMainDirect();
        if (!pmRes.ok || !_playerMainInstance) return { ok: false, error: 'PlayerMain not found' };
        return Il2Cpp.perform(function() {
            try {
                var pm = new Il2Cpp.Object(_playerMainInstance);
                var au = pm.field('autoplay').value;   // MainUnity (0x2C)
                if (!au || !au.handle || au.handle.isNull()) return { ok: false, error: 'autoplay(MainUnity) null' };
                au.method('SetDefaultProfile', 1).invoke(Il2Cpp.string(guid));
                return { ok: true, guid: guid };
            } catch (e) { return { ok: false, error: '' + e }; }
        });
    },

    // Đọc QUEST TRACKER (live) qua bridge: mỗi QuestItem có title + content TextMeshPro.
    // Content chứa "...24/15 quyển Thần bí đồ chí" -> bot parse X/Y để biết tiến độ NV đồ chí (KHÔNG cần recv).
    readQuestProgress: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function() {
            try {
                var img = Il2Cpp.domain.assembly("Assembly-CSharp").image;
                // Lấy class TextMeshProUGUI từ KIỂU field của QuestItem (khỏi đoán assembly TMP).
                var tmpClass = null;
                try { tmpClass = img.class("QuestItem").field("contentTextMeshPro").type.class; } catch (e) {}
                if (!tmpClass) { try { tmpClass = Il2Cpp.domain.assembly("Unity.TextMeshPro").image.class("TMPro.TextMeshProUGUI"); } catch (e) {} }
                if (!tmpClass) return { ok: false, error: 'no TextMeshProUGUI class' };
                var insts = Il2Cpp.gc.choose(tmpClass);
                var hits = [];      // text khớp từ khoá đồ chí
                var xyTexts = [];   // text có mẫu N/M (tiến độ) — không phụ thuộc dấu tiếng Việt
                var KW = ["chí", "quyển", "Thần", "tìm giúp", "Dã Tẩu", "Tẩu"];
                var XY = /\d+\s*\/\s*\d+/;
                for (var i = 0; i < insts.length; i++) {
                    var t = "";
                    try { t = insts[i].method("get_text").invoke().content || ""; } catch (e) { continue; }
                    if (!t) continue;
                    if (XY.test(t) && xyTexts.length < 30) xyTexts.push(t);
                    for (var k = 0; k < KW.length; k++) { if (t.indexOf(KW[k]) !== -1) { if (hits.length < 20) hits.push(t); break; } }
                }
                return { ok: true, tmpCount: insts.length, hits: hits, xyTexts: xyTexts };
            } catch (e) { return { ok: false, error: e.message }; }
        });
    },

    // Đọc TRACKER NHIỆM VỤ (đáng tin) — đọc thẳng các QuestItem (mappingGo của Quest panel), lấy
    // questKey + m_text (field backing, KHÔNG dùng get_text() vì khi panel ẩn TMP chưa rebuild -> rỗng).
    // Trả [{key,title,content}] -> Python parse 'X/15 ... đồ chí'. KHÔNG cần query Dã Tẩu trong động.
    // REALTIME: text dialog 'X/Y' mới nhất do hook Open chụp lúc server push (không gc.choose, không perform).
    getLastDialogText: function() {
        return { ok: true, text: globalThis._dlgText || '', t: globalThis._dlgTextT || 0 };
    },
    // Xoá text dialog đã chụp (gọi lúc bắt đầu NV mới -> tránh đọc nhầm 'X/15' CŨ từ NV trước).
    clearDialogText: function() {
        globalThis._dlgText = ''; globalThis._dlgTextT = 0;
        return { ok: true };
    },

    readQuestTracker: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function() {
            var diag = { src: '', qi: 0, errors: [] };
            var items = [];
            try {
                var img = Il2Cpp.domain.assembly("Assembly-CSharp").image;
                var qiClass = img.class("QuestItem");
                if (!qiClass) return { ok: false, error: 'no QuestItem class' };

                // đọc m_text (backing field) của 1 TMP object; rỗng thì thử get_text().
                function readTmp(tmp) {
                    if (!tmp || !tmp.handle || tmp.handle.isNull()) return "";
                    var s = "";
                    try { var v = tmp.field("m_text").value; s = v ? (v.content || "") : ""; } catch (e) {}
                    if (!s) { try { s = tmp.method("get_text").invoke().content || ""; } catch (e) {} }
                    return s;
                }
                function pushQi(qi) {
                    try {
                        var key = "", title = "", content = "";
                        try { var k = qi.field("questKey").value; key = k ? (k.content || "") : ""; } catch (e) {}
                        try { title = readTmp(qi.field("titleTextMeshPro").value); } catch (e) {}
                        try { content = readTmp(qi.field("contentTextMeshPro").value); } catch (e) {}
                        if (key || title || content) items.push({ key: key, title: title, content: content });
                    } catch (e) { diag.errors.push('qi:' + e); }
                }

                // ⚠️ KHÔNG dùng Il2Cpp.gc.choose ở ĐÂY: gc.choose STOP-THE-WORLD (quét cả heap) -> ĐƠ GAME
                //    mỗi lần đọc (vòng cày gọi ~20s, nhân nhiều account = treo). Đi THẲNG qua PopUpCanvas.instance
                //    (static singleton) — đủ lấy text "X/15" từ dialog Dã Tẩu, KHÔNG cần gc.choose.
                if (qiClass) {}   // giữ tham chiếu, không dùng
                // NGUỒN: dialog NPC (Dã Tẩu floating) — mỗi lần nhặt tấm
                //     server push count mới vào descriptionTmp; bot ẩn dialog nhưng m_text vẫn còn. Đi THẲNG qua
                //     PopUpCanvas.instance (SINGLETON — chắc chắn, KHÔNG gc.choose hên xui) -> 3 loại dialog.
                try {
                    var pc = img.class("PopUpCanvas");
                    var inst = pc ? pc.field("instance").value : null;   // static singleton
                    if (inst && inst.handle && !inst.handle.isNull()) {
                        diag.popup = true;
                        var dlgs = [
                            { f: "npcDialogInfiPc", t: "descriptionTmp" },
                            { f: "npcDialogPc", t: "layoutDescriptionTmp" },
                            { f: "npcDialog10Pc", t: "layoutDescriptionTmp" }
                        ];
                        for (var d = 0; d < dlgs.length; d++) {
                            try {
                                var dlg = inst.field(dlgs[d].f).value;
                                if (!dlg || !dlg.handle || dlg.handle.isNull()) continue;
                                var desc = readTmp(dlg.field(dlgs[d].t).value);
                                var nm2 = readTmp(dlg.field("thumbnailNameTmp").value);
                                if (desc || nm2) items.push({ key: dlgs[d].f, title: nm2, content: desc });
                            } catch (e) { diag.errors.push(dlgs[d].f + ':' + e); }
                        }
                    } else { diag.errors.push('no PopUpCanvas.instance'); }
                } catch (e) { diag.errors.push('popupC:' + e); }

                return { ok: true, items: items, diag: diag };
            } catch (e) { return { ok: false, error: e.message, diag: diag }; }
        });
    },

    // Đọc PROFILE AUTOPLAY đang chọn (guid+name) qua bridge -> để bot bật auto game đúng cấu hình cày.
    // Cần đã MỞ bảng Auto trong game ít nhất 1 lần (để có instance UnityAutoplay + selectedProfile).
    // Tìm guid profile THEO TÊN (vd 'Luyện công') từ PlayerMain.autoplay(MainUnity).profileMapping
    // (Dictionary<guid, ProfileData>; ProfileData:ProfileIdentify có name@0x10, guid@0x8). FIELD-ONLY:
    // KHÔNG gc.choose, KHÔNG invoke method -> AN TOÀN. Mọi account đều có 'Luyện công' nên luôn ra guid RIÊNG
    // đúng của account đó, KHÔNG cần tap tay, KHÔNG phụ thuộc selectedProfile đang chọn cái gì.
    // BẬT auto bằng INVOKE MainUnity.Start(true) (packet 140 không đủ cho char mới lvl1 chưa có profile).
    // InitializeForce(false) nạp profile trước. Trả started.
    startAutoplayInvoke: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        var pmRes = readPlayerMainDirect();
        if (!pmRes.ok || !_playerMainInstance) return { ok: false, error: 'no PlayerMain' };
        return Il2Cpp.perform(function() {
            try {
                var pm = new Il2Cpp.Object(_playerMainInstance);
                var au = pm.field('autoplay').value;
                if (!au || !au.handle || au.handle.isNull()) return { ok: false, error: 'autoplay null' };
                // TRUE = TẠO profile mặc định khi rỗng (char mới chưa có profile -> Start không đánh).
                try { au.method('InitializeForce', 1).invoke(true); } catch (e) {}
                var r = au.method('Start', 1).invoke(true);
                var running = false; try { running = (au.method('IsRunning', 0).invoke() === true); } catch (e) {}
                return { ok: true, started: (r === true || r === 1), running: running };
            } catch (e) { return { ok: false, error: '' + e }; }
        });
    },

    // Auto game CÓ ĐANG CHẠY không: PlayerMain.autoplay(MainUnity).IsRunning(). Dùng để VERIFY auto bật rồi
    // mới trainoff (trainoff uỷ thác trạng thái hiện tại — auto chưa chạy thì cloud treo đứng im).
    isAutoplayRunning: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        var pmRes = readPlayerMainDirect();
        if (!pmRes.ok || !_playerMainInstance) return { ok: false, error: 'no PlayerMain' };
        return Il2Cpp.perform(function() {
            try {
                var pm = new Il2Cpp.Object(_playerMainInstance);
                var au = pm.field('autoplay').value;
                if (!au || !au.handle || au.handle.isNull()) return { ok: false, error: 'autoplay null' };
                var r = au.method('IsRunning', 0).invoke();
                return { ok: true, running: (r === true || r === 1) };
            } catch (e) { return { ok: false, error: '' + e }; }
        });
    },

    getNamedAutoplayProfile: function(wantName) {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        var want = (wantName || 'luyện công').toLowerCase();
        var pmRes = readPlayerMainDirect();
        if (!pmRes.ok || !_playerMainInstance) return { ok: false, error: 'PlayerMain not found' };
        return Il2Cpp.perform(function() {
            var diag = { errors: [], n: 0 };
            try {
                var pm = new Il2Cpp.Object(_playerMainInstance);
                var au = pm.field('autoplay').value;            // MainUnity (0x2C)
                if (!au || !au.handle || au.handle.isNull()) return { ok: false, error: 'autoplay(MainUnity) null' };
                // đọc toàn bộ profile trong Dictionary profileMapping._entries -> [{name,guid}]
                function readAllProfiles() {
                    var mp = au.field('profileMapping').value;  // Dictionary<string, ProfileData>
                    if (!mp || !mp.handle || mp.handle.isNull()) return null;   // chưa nạp
                    // _entries có thể NULL (Dictionary RỖNG chưa cấp mảng) -> đọc .length sẽ access-violation @0x18.
                    // => coi như 0 profile (KHÔNG crash) thì mới chạy được nhánh tạo profile bên dưới.
                    var entries = null;
                    try { entries = mp.field('_entries').value; } catch (ex) { diag.errors.push('entriesField:' + ex); }
                    var n = 0;
                    try { if (entries && entries.handle && !entries.handle.isNull()) n = entries.length; }
                    catch (ex) { diag.errors.push('entriesLen:' + ex); n = 0; }
                    diag.n = n;
                    var arr = [];
                    for (var i = 0; i < n; i++) {
                        try {
                            var e = entries.get(i);
                            if (!e) continue;
                            var hc = 0; try { hc = e.field('hashCode').value; } catch (ex) {}
                            if (hc < 0) continue;               // slot trống
                            var pd = e.field('value').value;    // ProfileData : ProfileIdentify
                            if (!pd || !pd.handle || pd.handle.isNull()) continue;
                            var nm = ''; try { var v = pd.field('name').value; nm = v ? (v.content || '') : ''; } catch (ex) {}
                            var gu = ''; try { var v2 = pd.field('guid').value; gu = v2 ? (v2.content || '') : ''; } catch (ex) {}
                            if (nm || gu) arr.push({ name: nm, guid: gu });
                        } catch (ex) { diag.errors.push('e' + i + ':' + ex); }
                    }
                    return arr;
                }
                // (1) NẠP profile sẵn có: InitializeForce(false) = không tạo mới (an toàn cho acc đã có profile).
                try { au.method('InitializeForce', 1).invoke(false); } catch (e) { diag.errors.push('InitFalse:' + e); }
                var all = readAllProfiles() || [];
                // (2) FIX BUG LẶP NHIỀU LẦN: acc chưa từng mở bảng Auto -> profileMapping RỖNG -> không có guid ->
                // không bật được auto (PENDING). Mở panel tay tạo 2 profile mặc định; ta làm y vậy bằng
                // InitializeForce(TRUE) = TẠO profile mặc định khi rỗng (CHỈ tạo LOCAL, KHÔNG gửi packet nên
                // KHÔNG thể wipe; op140 wipe là do GỬI profile rỗng, mà start_autoplay đã chặn gửi guid rỗng).
                if (all.length === 0) {
                    diag.tried_create = true;
                    try { au.method('InitializeForce', 1).invoke(true); } catch (e) { diag.errors.push('InitTrue:' + e); }
                    all = readAllProfiles() || [];
                    diag.after_create_n = all.length;
                }
                var match = all.filter(function (p) { return p.name && p.name.toLowerCase().indexOf(want) !== -1 && p.guid; });
                if (match.length) return { ok: true, guid: match[0].guid, name: match[0].name, all: all, created: !!diag.tried_create };
                // không khớp tên nhưng CÓ profile -> trả all để Python dùng profile đầu tiên (fallback đã có)
                return { ok: false, error: (all.length ? 'no profile named ' + want : 'profileMapping rỗng kể cả sau InitializeForce(true)'), all: all, diag: diag };
            } catch (e) { return { ok: false, error: e.message, diag: diag }; }
        });
    },

    getAutoplayProfile: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function() {
            try {
                var img = Il2Cpp.domain.assembly("Assembly-CSharp").image;
                var klass = img.class("game.ui.autoplay.UnityAutoplay");
                if (!klass) return { ok: false, error: 'no UnityAutoplay class' };
                var insts = Il2Cpp.gc.choose(klass);
                if (!insts || insts.length === 0)
                    return { ok: false, error: 'Chưa có instance UnityAutoplay — MỞ bảng AUTO trong game 1 lần rồi thử lại.' };
                var out = { ok: false, count: insts.length };
                for (var i = 0; i < insts.length; i++) {
                    try {
                        var sel = insts[i].field("selectedProfile").value;
                        if (sel && sel.handle && !sel.handle.isNull()) {
                            var g = sel.field("guid").value;
                            var n = sel.field("name").value;
                            out.ok = true;
                            out.guid = g ? g.content : "";
                            out.name = n ? n.content : "";
                            break;
                        }
                    } catch (e) { out.err = e.message; }
                }
                if (!out.ok && !out.err) out.error = 'selectedProfile null — vào bảng Auto CHỌN 1 profile rồi thử lại.';
                return out;
            } catch (e) { return { ok: false, error: e.message }; }
        });
    },

    // ==================== IL2CPP MEMORY READ ====================

    // Call PlayerMain::GetNearPlayers() via IL2CPP
    // Returns list of nearby players/stalls
    // Gọi PlayerMain.GetNearPlayers() qua bridge -> ConcurrentDictionary<string cid, NpcRes.Special>.
    // Đọc field theo TÊN (hết lệ thuộc offset cứng đã lệch). Trả [{id: cid}, ...].
    getNearPlayers: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        var pmRes = readPlayerMainDirect();
        if (!pmRes.ok || !_playerMainInstance) return { ok: false, error: 'PlayerMain not found: ' + (pmRes.error || '') };
        var players = [];
        var diag = { nodes: 0, errors: [] };
        return Il2Cpp.perform(function() {
            try {
                var pm = new Il2Cpp.Object(_playerMainInstance);
                var dict = pm.method("GetNearPlayers").invoke();   // ConcurrentDictionary<string, NpcRes.Special>
                if (!dict || dict.isNull()) return { ok: true, players: [], diag: diag };
                var tables = dict.field("_tables").value;
                if (!tables || tables.isNull()) { diag.errors.push("_tables null"); return { ok: true, players: [], diag: diag }; }
                var buckets = tables.field("_buckets").value;
                if (!buckets || buckets.isNull()) { diag.errors.push("_buckets null"); return { ok: true, players: [], diag: diag }; }
                for (var b = 0; b < buckets.length; b++) {
                    var node = null;
                    try { node = buckets.get(b); } catch(e) { continue; }
                    while (node && !node.isNull()) {
                        diag.nodes++;
                        try {
                            var keyObj = node.field("_key").value;   // Il2Cpp.String = cid
                            var cid = "";
                            try { cid = keyObj.content; } catch(e2) { try { cid = keyObj.toString(); } catch(e3) {} }
                            if (cid) players.push({ id: cid });
                        } catch(e4) {}
                        try { node = node.field("_next").value; } catch(e5) { node = null; }
                    }
                }
            } catch(eMain) { diag.errors.push(eMain.toString()); }
            return { ok: true, players: players, diag: diag };
        });
    },

    // Như getNearPlayers nhưng ĐỌC THÊM VỊ TRÍ mỗi player gần (NpcRes.Special : Controller -> position(Position)
    // -> field left(x)/top(y)). Dùng để WORKER đọc toạ độ THỦ QUỸ từ near-players của CHÍNH NÓ (recv worker tốt),
    // bypass recv hỏng của thủ quỹ đứng yên. Trả [{cid, x, y}] (x/y = toạ độ Position; so với pos mình để biết scale).
    getNearPlayersPos: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        var pmRes = readPlayerMainDirect();
        if (!pmRes.ok || !_playerMainInstance) return { ok: false, error: 'PlayerMain not found: ' + (pmRes.error || '') };
        var players = [];
        var diag = { nodes: 0, errors: [] };
        return Il2Cpp.perform(function() {
            try {
                var pm = new Il2Cpp.Object(_playerMainInstance);
                var dict = pm.method("GetNearPlayers").invoke();
                if (!dict || dict.isNull()) return { ok: true, players: [], diag: diag };
                var tables = dict.field("_tables").value;
                if (!tables || tables.isNull()) { diag.errors.push("_tables null"); return { ok: true, players: [], diag: diag }; }
                var buckets = tables.field("_buckets").value;
                if (!buckets || buckets.isNull()) { diag.errors.push("_buckets null"); return { ok: true, players: [], diag: diag }; }
                for (var b = 0; b < buckets.length; b++) {
                    var node = null;
                    try { node = buckets.get(b); } catch(e) { continue; }
                    while (node && !node.isNull()) {
                        diag.nodes++;
                        var rec = { cid: "", x: null, y: null };
                        try {
                            var keyObj = node.field("_key").value;
                            try { rec.cid = keyObj.content; } catch(e2) { try { rec.cid = keyObj.toString(); } catch(e3) {} }
                        } catch(e4) {}
                        try {
                            var special = node.field("_value").value;   // NpcRes.Special : Controller
                            if (special && !special.isNull()) {
                                var posObj = special.field("position").value;   // npcres.Position (wrapper)
                                if (posObj && !posObj.isNull()) {
                                    // mapPositionFloat = Vector2 (world float x,y) -> nhân vật đứng đâu cũng có
                                    try {
                                        var mpf = posObj.field("mapPositionFloat").value;
                                        if (mpf) { rec.x = Math.round(mpf.field("x").value); rec.y = Math.round(mpf.field("y").value); }
                                    } catch(eF) { diag.errors.push("mpf:" + eF); }
                                    // mapPosition = Position int (grid) -> dự phòng
                                    if (rec.x === null) {
                                        try {
                                            var mp = posObj.field("mapPosition").value;
                                            if (mp) { try { rec.x = mp.method("get_x").invoke(); rec.y = mp.method("get_y").invoke(); } catch(eg) {} }
                                        } catch(eM) { diag.errors.push("mp:" + eM); }
                                    }
                                }
                            }
                        } catch(e5) { diag.errors.push("val:" + e5); }
                        if (rec.cid) players.push(rec);
                        try { node = node.field("_next").value; } catch(e6) { node = null; }
                    }
                }
            } catch(eMain) { diag.errors.push(eMain.toString()); }
            return { ok: true, players: players, diag: diag };
        });
    },

    // Đọc NPC gần qua BRIDGE (an toàn, method/field theo TÊN) — KHÁC getNearNpcs (offset cứng 0x700194 -> crash 0x11).
    // PlayerMain.GetNearNpcs() -> ConcurrentDictionary<string npcid, NpcRes.Normal>. Trả [{id, name}].
    getNearNpcsSafe: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        var pmRes = readPlayerMainDirect();
        if (!pmRes.ok || !_playerMainInstance) return { ok: false, error: 'PlayerMain not found: ' + (pmRes.error || '') };
        var npcs = [];
        var diag = { nodes: 0, errors: [], fields: null };
        return Il2Cpp.perform(function() {
            try {
                var pm = new Il2Cpp.Object(_playerMainInstance);
                var dict = pm.method("GetNearNpcs").invoke();   // ConcurrentDictionary<string, NpcRes.Normal>
                if (!dict || dict.isNull()) return { ok: true, npcs: [], diag: diag };
                var tables = dict.field("_tables").value;
                if (!tables || tables.isNull()) { diag.errors.push("_tables null"); return { ok: true, npcs: [], diag: diag }; }
                var buckets = tables.field("_buckets").value;
                if (!buckets || buckets.isNull()) { diag.errors.push("_buckets null"); return { ok: true, npcs: [], diag: diag }; }
                function readName(o) {
                    var names = ['m_szName', 'name', 'Name', 'm_name', 'szName', 'm_strName', 'NpcName'];
                    for (var k = 0; k < names.length; k++) {
                        try { var v = o.field(names[k]).value; if (v && !v.isNull()) { try { return v.content; } catch(e) { return v.toString(); } } } catch(e) {}
                    }
                    return "";
                }
                for (var b = 0; b < buckets.length; b++) {
                    var node = null;
                    try { node = buckets.get(b); } catch(e) { continue; }
                    while (node && !node.isNull()) {
                        diag.nodes++;
                        try {
                            var keyObj = node.field("_key").value;
                            var cid = ""; try { cid = keyObj.content; } catch(e2) { try { cid = keyObj.toString(); } catch(e3) {} }
                            var val = null; try { val = node.field("_value").value; } catch(e) {}
                            var nm = "";
                            if (val && !val.isNull()) {
                                if (diag.fields === null) { try { var fl = []; var sf = val.class.fields; for (var z = 0; z < sf.length; z++) fl.push(sf[z].name); diag.fields = fl; } catch(e) {} }
                                nm = readName(val);
                            }
                            if (cid) npcs.push({ id: cid, name: nm });
                        } catch(e4) {}
                        try { node = node.field("_next").value; } catch(e5) { node = null; }
                    }
                }
            } catch(eMain) { diag.errors.push(eMain.toString()); }
            return { ok: true, npcs: npcs, diag: diag };
        });
    },

    // Đọc OBJECT GẦN (rộng hơn NPC/player) — PlayerMain.GetNearObjects() -> ConcurrentDictionary<string, Object>.
    // Quả Huy Hoàng / node hái / vật phẩm scene thường nằm Ở ĐÂY (không phải NPC). Trả [{id, name, cls}] +
    // diag.fields = field-list của value đầu tiên (để lộ cấu trúc nếu chưa biết field tên). An toàn (field theo tên).
    getNearObjects: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        var pmRes = readPlayerMainDirect();
        if (!pmRes.ok || !_playerMainInstance) return { ok: false, error: 'PlayerMain not found: ' + (pmRes.error || '') };
        var objs = [];
        var diag = { nodes: 0, errors: [], fields: null };
        return Il2Cpp.perform(function() {
            try {
                var pm = new Il2Cpp.Object(_playerMainInstance);
                var dict = pm.method("GetNearObjects").invoke();   // ConcurrentDictionary<string, Object>
                if (!dict || dict.isNull()) return { ok: true, objs: [], diag: diag };
                var tables = dict.field("_tables").value;
                if (!tables || tables.isNull()) { diag.errors.push("_tables null"); return { ok: true, objs: [], diag: diag }; }
                var buckets = tables.field("_buckets").value;
                if (!buckets || buckets.isNull()) { diag.errors.push("_buckets null"); return { ok: true, objs: [], diag: diag }; }
                function readName(o) {
                    var names = ['m_szName', 'name', 'Name', 'm_name', 'szName', 'm_strName', 'NpcName', 'title'];
                    for (var k = 0; k < names.length; k++) {
                        try { var v = o.field(names[k]).value; if (v && !v.isNull()) { try { return v.content; } catch(e) { return v.toString(); } } } catch(e) {}
                    }
                    return "";
                }
                for (var b = 0; b < buckets.length; b++) {
                    var node = null;
                    try { node = buckets.get(b); } catch(e) { continue; }
                    while (node && !node.isNull()) {
                        diag.nodes++;
                        try {
                            var keyObj = node.field("_key").value;
                            var id = ""; try { id = keyObj.content; } catch(e2) { try { id = keyObj.toString(); } catch(e3) {} }
                            var val = null; try { val = node.field("_value").value; } catch(e) {}
                            var nm = "", cls = "";
                            if (val && !val.isNull()) {
                                try { cls = val.class.name; } catch(e) {}
                                if (diag.fields === null) { try { var fl = []; var sf = val.class.fields; for (var z = 0; z < sf.length; z++) fl.push(sf[z].name); diag.fields = fl; } catch(e) {} }
                                nm = readName(val);
                            }
                            if (id) objs.push({ id: id, name: nm, cls: cls });
                        } catch(e4) {}
                        try { node = node.field("_next").value; } catch(e5) { node = null; }
                    }
                }
            } catch(eMain) { diag.errors.push(eMain.toString()); }
            return { ok: true, objs: objs, diag: diag };
        });
    },

    // Đọc CHI TIẾT NPC/QUÁI gần để NHẬN DIỆN BOSS. NpcRes.Normal : Controller -> đọc nested 'data'(Datafield:
    // name/level/npcKind/npcType/series/faction) + 'identify'(Identification: nameValue/healthCurrent/healthMax/
    // titleValue). Boss = HP/level CAO + tên riêng. Trả [{id,name,title,level,hp,hpMax,npcKind,npcType,series}].
    getNearNpcsDetail: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        var pmRes = readPlayerMainDirect();
        if (!pmRes.ok || !_playerMainInstance) return { ok: false, error: 'PlayerMain not found' };
        var out = [];
        var diag = { errors: [], n: 0 };
        return Il2Cpp.perform(function() {
            function S(o, f) { try { var v = o.field(f).value; return v && !v.isNull() ? v.content : ''; } catch (e) { return ''; } }
            function I(o, f) { try { return o.field(f).value; } catch (e) { return null; } }
            try {
                var pm = new Il2Cpp.Object(_playerMainInstance);
                var dict = pm.method("GetNearNpcs").invoke();
                if (!dict || dict.isNull()) return { ok: true, npcs: [], diag: diag };
                var tables = dict.field("_tables").value;
                if (!tables || tables.isNull()) { diag.errors.push("_tables null"); return { ok: true, npcs: [], diag: diag }; }
                var buckets = tables.field("_buckets").value;
                if (!buckets || buckets.isNull()) { diag.errors.push("_buckets null"); return { ok: true, npcs: [], diag: diag }; }
                for (var b = 0; b < buckets.length; b++) {
                    var node = null;
                    try { node = buckets.get(b); } catch (e) { continue; }
                    while (node && !node.isNull()) {
                        diag.n++;
                        try {
                            var id = ""; try { id = node.field("_key").value.content; } catch (e) {}
                            var ctrl = null; try { ctrl = node.field("_value").value; } catch (e) {}
                            var rec = { id: id, name: '', title: '', level: 0, hp: 0, hpMax: 0, npcKind: -1, npcType: -1, series: -1, x: null, y: null };
                            if (ctrl && !ctrl.isNull()) {
                                var d = I(ctrl, "data");
                                if (d && !d.isNull()) {
                                    rec.name = S(d, "name");
                                    var lv = I(d, "level"); if (lv !== null) rec.level = lv;
                                    var nk = I(d, "npcKind"); if (nk !== null) rec.npcKind = nk;
                                    var nt = I(d, "npcType"); if (nt !== null) rec.npcType = nt;
                                    var se = I(d, "series"); if (se !== null) rec.series = se;
                                }
                                var idn = I(ctrl, "identify");
                                if (idn && !idn.isNull()) {
                                    if (!rec.name) rec.name = S(idn, "nameValue");
                                    rec.title = S(idn, "titleValue");
                                    var hc = I(idn, "healthCurrent"); if (hc !== null) rec.hp = hc;
                                    var hm = I(idn, "healthMax"); if (hm !== null) rec.hpMax = hm;
                                }
                                // TOẠ ĐỘ NPC (world) — field-only an toàn (Controller.position.mapPositionFloat),
                                // để ĐI TỚI Dã Tẩu (sạp bu quanh). Giống getNearPlayersPos, KHÔNG invoke.
                                try {
                                    var posO = I(ctrl, "position");
                                    if (posO && !posO.isNull()) {
                                        var mpf = posO.field("mapPositionFloat").value;
                                        if (mpf) { rec.x = Math.round(mpf.field("x").value); rec.y = Math.round(mpf.field("y").value); }
                                    }
                                } catch (eP) {}
                            }
                            out.push(rec);
                        } catch (e) { diag.errors.push('node:' + e); }
                        try { node = node.field("_next").value; } catch (e) { node = null; }
                    }
                }
            } catch (e) { diag.errors.push('main:' + e); }
            return { ok: true, npcs: out, diag: diag };
        });
    },

    // Đọc DANH SÁCH SẠP gần (game.scene.CharManager.instance.salesmans) — Dictionary<string cid, NpcRes.Special>.
    // ĐÂY mới là list sạp người chơi bày bán (players là người thường, KHÔNG có sạp).
    getNearSalesmans: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function() {
            var diag = { count: null, n: 0, errors: [] };
            try {
                var img = Il2Cpp.domain.assembly('Assembly-CSharp').image;
                // img.class('CharManager') hay fail vì namespace -> DUYỆT classes tìm theo tên.
                var cm = null;
                var cs = img.classes;
                for (var ci = 0; ci < cs.length; ci++) { if (cs[ci].name === 'CharManager') { cm = cs[ci]; break; } }
                if (!cm) {
                    var cand = [];
                    for (var cj = 0; cj < cs.length; cj++) {
                        var nn = (cs[cj].name || '').toLowerCase();
                        if (nn.indexOf('salesman') >= 0 || nn.indexOf('charmanager') >= 0 || nn.indexOf('charmgr') >= 0 || nn.indexOf('scenemanager') >= 0)
                            cand.push(cs[cj].name);
                    }
                    return { ok: false, error: 'CharManager class not found', candidates: cand.slice(0, 40) };
                }
                try { cm.initialize(); } catch (e) {}
                var inst = cm.field('instance').value;   // static instance
                if (!inst || inst.isNull()) {
                    try { var arr = Il2Cpp.gc.choose(cm); if (arr && arr.length) inst = arr[0]; } catch (e) { diag.errors.push('gc: ' + e); }
                }
                if (!inst || inst.isNull()) return { ok: false, error: 'CharManager.instance null' };
                var sm = inst.field('salesmans').value;  // Dictionary<string, NpcRes.Special>
                if (!sm || sm.isNull()) return { ok: true, players: [], diag: diag };
                var count = null;
                try { count = sm.method('get_Count').invoke(); } catch (e) { try { count = sm.field('_count').value; } catch (e2) {} }
                diag.count = count;
                var entries = null;
                try { entries = sm.field('_entries').value; } catch (e) { try { entries = sm.field('entries').value; } catch (e2) { diag.errors.push('entries: ' + e2); } }
                var out = [];
                if (entries && !entries.isNull()) {
                    var n = entries.length;
                    if (typeof count === 'number' && count >= 0 && count < n) n = count;
                    diag.n = n;
                    for (var i = 0; i < n; i++) {
                        try {
                            var e = entries.get(i);
                            var keyObj = e.field('key').value;   // string cid
                            var cid = '';
                            try { cid = keyObj.content; } catch (x) { try { cid = keyObj.toString(); } catch (y) {} }
                            if (!cid || cid === 'null') continue;
                            var rec = { id: cid };
                            // value = NpcRes.Special: lấy TÊN chủ sạp + TOẠ ĐỘ (thử các tên field phổ biến).
                            try {
                                var sp = e.field('value').value;
                                if (sp && !sp.isNull()) {
                                    if (i === 0) {   // học tên field thật 1 lần để soi
                                        try { var fl = []; var sf = sp.class.fields;
                                              for (var z = 0; z < sf.length; z++) fl.push(sf[z].name);
                                              diag.specialFields = fl; } catch (q) {}
                                    }
                                    function rdStrF(o, names) {
                                        for (var z = 0; z < names.length; z++) {
                                            try { var v = o.field(names[z]).value;
                                                  if (v && !v.isNull()) { try { return v.content; } catch (q) { return v.toString(); } } } catch (q) {}
                                        }
                                        return null;
                                    }
                                    function rdNumF(o, names) {
                                        for (var z = 0; z < names.length; z++) {
                                            try { var v = o.field(names[z]).value;
                                                  if (typeof v === 'number') return v; } catch (q) {}
                                        }
                                        return null;
                                    }
                                    var nm = rdStrF(sp, ['name', 'Name', 'nickName', 'nickname', 'ownerName', 'title', 'shopName']);
                                    if (!nm) {   // tên rỗng ở top-level -> thử object 'character' lồng bên trong
                                        try {
                                            var ch = sp.field('character').value;
                                            if (ch && !ch.isNull())
                                                nm = rdStrF(ch, ['name', 'm_name', 'Name', 'nickName', 'playerName', 'roleName', 'charName', 'tmpName', 'displayName', 'userName']);
                                        } catch (eC) {}
                                    }
                                    if (nm) rec.name = nm;
                                    // TOẠ ĐỘ SẠP (world) để homing tới tâm cụm. Thử field int trực tiếp trước (cũ),
                                    // rồi position.mapPositionFloat (Vector2 world) — ĐỌC FIELD, KHÔNG invoke nên AN TOÀN
                                    // (giống getNearPlayersPos; crash cũ là do INVOKE method, field-only thì không).
                                    var px = rdNumF(sp, ['posX', 'PosX', 'x', 'X', 'tileX', 'cellX']);
                                    var py = rdNumF(sp, ['posY', 'PosY', 'y', 'Y', 'tileY', 'cellY']);
                                    if (px === null || py === null) {
                                        try {
                                            var posO = sp.field('position').value;
                                            if (posO && !posO.isNull()) {
                                                var mpf = posO.field('mapPositionFloat').value;
                                                if (mpf) { px = Math.round(mpf.field('x').value); py = Math.round(mpf.field('y').value); }
                                            }
                                        } catch (eP) {}
                                    }
                                    if (px !== null) rec.x = px;
                                    if (py !== null) rec.y = py;
                                }
                            } catch (ee2) {}
                            out.push(rec);
                        } catch (ee) {}
                    }
                }
                return { ok: true, players: out, diag: diag };
            } catch (eMain) { return { ok: false, error: eMain.toString(), diag: diag }; }
        });
    },

    // Đọc BẠC chuẩn qua method PlayerMain (KHÔNG đọc offset 0x50 hay bị sai = 3):
    //   GetBagarateMoney() = bạc HÀNH TRANG (mang theo), GetStorageMoney() = Tiền Trang. Đều trả long.
    getMoney: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        try {
            var pmRes = readPlayerMainDirect();
            if (!pmRes.ok || !_playerMainInstance) return { ok: false, error: 'PlayerMain not found: ' + (pmRes.error || '') };
            return Il2Cpp.perform(function() {
                var pm = new Il2Cpp.Object(_playerMainInstance);
                var res = { ok: true };
                function num(v) { try { return (typeof v === 'number') ? v : Number(v); } catch (e) { return null; } }
                try { res.bagarate = num(pm.method('GetBagarateMoney').invoke()); } catch (e) { res.errBag = String(e); }
                try { res.storage = num(pm.method('GetStorageMoney').invoke()); } catch (e) { res.errSto = String(e); }
                return res;
            });
        } catch (e) { return { ok: false, error: e.toString() }; }
    },

    // Đọc static Dictionary<int,string> game.magic.Attrib.StringMapping -> {magicId: tên thuộc tính}.
    // Dùng để dịch magic id trong gói sạp (magicInt = value*1000 + id) ra tên/hệ.
    readMagicStringMapping: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        return Il2Cpp.perform(function() {
            var diag = {};
            try {
                var k = Il2Cpp.domain.assembly("Assembly-CSharp").image.class("game.magic.Attrib");
                try { k.initialize(); } catch(e) { diag.init = String(e); }
                var dict = k.field("StringMapping").value;   // static Dictionary<int,string>
                diag.dictNull = (!dict || dict.isNull());
                if (diag.dictNull) return { ok: false, error: 'StringMapping null', diag: diag };
                // liệt kê field thật của Dictionary để biết tên đúng
                try {
                    var fns = []; var fs = dict.class.fields;
                    for (var fi = 0; fi < fs.length; fi++) fns.push(fs[fi].name);
                    diag.dictFields = fns;
                } catch(e) {}
                function pick(names) {
                    for (var i = 0; i < names.length; i++) {
                        try { var v = dict.field(names[i]).value; return v; } catch(e) {}
                    }
                    return null;
                }
                var count = pick(["_count", "count"]);
                var entries = pick(["_entries", "entries"]);
                diag.count = count;
                diag.entriesNull = (!entries || entries.isNull());
                var map = {};
                if (entries && !entries.isNull()) {
                    var n = entries.length;
                    if (typeof count === 'number' && count > 0 && count < n) n = count;
                    for (var i = 0; i < n; i++) {
                        try {
                            var e = entries.get(i);
                            var key = e.field("key").value;
                            var vo = e.field("value").value;
                            var val = "";
                            if (vo && !vo.isNull()) { try { val = vo.content; } catch(x) { val = vo.toString(); } }
                            if (val) map[key] = val;
                        } catch(ee) {}
                    }
                }
                return { ok: true, count: Object.keys(map).length, map: map, diag: diag };
            } catch(e) { return { ok: false, error: e.toString(), diag: diag }; }
        });
    },

    getNearNpcs: function() {
        if (!il2cppBase) return { ok: false, error: 'il2cpp not found' };
        try {
            if (typeof _playerMainInstance === 'undefined' || _playerMainInstance === null) {
                var res = readPlayerMainDirect();
                if (!res.ok) return { ok: false, error: 'PlayerMain load failed: ' + res.error };
            }
            
            var GetNearNpcs = new NativeFunction(
                il2cppBase.add(0x700194), 'pointer', ['pointer']
            );
            var dict = GetNearNpcs(_playerMainInstance);
            if (dict.isNull()) return { ok: true, npcs: [] };

            // Parse ConcurrentDictionary
            var il2cpp_object_get_class = new NativeFunction(Module.findExportByName('libil2cpp.so', 'il2cpp_object_get_class'), 'pointer', ['pointer']);
            var il2cpp_class_get_field_from_name = new NativeFunction(Module.findExportByName('libil2cpp.so', 'il2cpp_class_get_field_from_name'), 'pointer', ['pointer', 'pointer']);
            var il2cpp_field_get_offset = new NativeFunction(Module.findExportByName('libil2cpp.so', 'il2cpp_field_get_offset'), 'uint', ['pointer']);

            function getOffset(klass, name) {
                var f = il2cpp_class_get_field_from_name(klass, Memory.allocUtf8String(name));
                if (f.isNull()) return -1;
                return il2cpp_field_get_offset(f);
            }

            var dictKlass = il2cpp_object_get_class(dict);
            var tablesOffset = getOffset(dictKlass, 'm_tables');
            if (tablesOffset < 0) return { ok: false, error: 'm_tables not found' };

            var tables = dict.add(tablesOffset).readPointer();
            if (tables.isNull()) return { ok: true, npcs: [] };

            var tablesKlass = il2cpp_object_get_class(tables);
            var bucketsOffset = getOffset(tablesKlass, 'm_buckets');
            if (bucketsOffset < 0) return { ok: false, error: 'm_buckets not found' };

            var bucketsArr = tables.add(bucketsOffset).readPointer();
            if (bucketsArr.isNull()) return { ok: true, npcs: [] };

            var pSize = Process.pointerSize;
            var arrLen = bucketsArr.add(pSize * 3).readU32(); // max_length
            var arrData = bucketsArr.add(pSize * 4); 

            var resultList = [];
            for (var i = 0; i < arrLen; i++) {
                var node = arrData.add(i * pSize).readPointer();
                while (!node.isNull()) {
                    var nodeKlass = il2cpp_object_get_class(node);
                    var keyOffset = getOffset(nodeKlass, 'm_key');
                    var valOffset = getOffset(nodeKlass, 'm_value');
                    var nextOffset = getOffset(nodeKlass, 'm_next');
                    
                    var keyPtr = node.add(keyOffset).readPointer();
                    var valPtr = node.add(valOffset).readPointer();
                    
                    // Read string key
                    var keyStr = "";
                    if (!keyPtr.isNull()) {
                        var strLen = keyPtr.add(pSize * 2).readU32();
                        var chars = keyPtr.add(pSize * 2 + 4).readUtf16String(strLen);
                        keyStr = chars;
                    }
                    
                    // Try to read NPC name (thu nhieu ten field: m_szName/Name/name/m_name)
                    var npcName = "";
                    if (!valPtr.isNull()) {
                        try {
                            var valKlass = il2cpp_object_get_class(valPtr);
                            var nameFields = ['m_szName', 'Name', 'name', 'm_name', 'm_strName'];
                            for (var nf = 0; nf < nameFields.length; nf++) {
                                var nameOffset = getOffset(valKlass, nameFields[nf]);
                                if (nameOffset > 0) {
                                    var namePtr = valPtr.add(nameOffset).readPointer();
                                    if (!namePtr.isNull() && namePtr.compare(0x10000) > 0) {
                                        var nLen = namePtr.add(pSize * 2).readU32();
                                        if (nLen > 0 && nLen < 100) {
                                            npcName = namePtr.add(pSize * 2 + 4).readUtf16String(nLen);
                                            if (npcName) break;
                                        }
                                    }
                                }
                            }
                        } catch(e) {}
                    }
                    
                    if (keyStr && !valPtr.isNull()) {
                        resultList.push({ id: keyStr, ptr: valPtr.toString(), name: npcName });
                    }
                    
                    node = node.add(nextOffset).readPointer();
                }
            }

            return { ok: true, npcs: resultList };
        } catch(e) {
            return { ok: false, error: e.toString() };
        }
    },

    // Hook GotoFindingPath to capture PlayerMain 'this' pointer (Failed on Houdini x86)
    gotopath: function(x, y) {
        if (!il2cppBase) return { ok: false, error: 'il2cpp not found' };
        try {
            if (typeof globalThis.GotoFindingPath === 'undefined') {
                globalThis.GotoFindingPath = new NativeFunction(
                    il2cppBase.add(0x706A70), 'void', ['pointer', 'int', 'int', 'int', 'pointer', 'pointer', 'pointer']
                );
                
                // Hook PlayerMain.Update (runs every frame on Unity Main Thread)
                var playerMainUpdate = il2cppBase.add(0x6FCA3C);
                globalThis.pendingGoto = null;
                
                Interceptor.attach(playerMainUpdate, {
                    onEnter: function(args) {
                        if (!_playerMainInstance) {
                            _playerMainInstance = args[0];
                            send({ type: 'il2cpp_event', event: 'PlayerMain.Update captured', ptr: _playerMainInstance.toString() });
                        }
                        
                        if (globalThis.pendingGoto) {
                            try {
                                globalThis.GotoFindingPath(_playerMainInstance, globalThis.pendingGoto.x, globalThis.pendingGoto.y, 20, ptr(0), ptr(0), ptr(0));
                            } catch (e) {
                                send({ type: 'il2cpp_error', msg: 'GotoFindingPath exception: ' + e.toString() });
                            }
                            globalThis.pendingGoto = null;
                        }
                    }
                });
            }

            if (!_playerMainInstance) {
                var res = readPlayerMainDirect();
                if (!res.ok) return { ok: false, error: 'PlayerMain: ' + res.error };
            }
            if (typeof _playerMainInstance !== 'undefined' && _playerMainInstance) {
                globalThis.pendingGoto = { x: x, y: y };
                return { ok: true, x: x, y: y, playerMain: _playerMainInstance.toString() };
            }
            return { ok: false, error: 'PlayerMain not captured' };
        } catch(e) {
            return { ok: false, error: e.toString() };
        }
    },

    sendRaw: function(hexData) {
        if (gameFd < 0) return { ok: false, error: 'No game fd' };
        if (!nativeWrite) return { ok: false, error: 'write() not available' };
        var bytes = [];
        for (var i = 0; i < hexData.length; i += 2) {
            bytes.push(parseInt(hexData.substr(i, 2), 16));
        }
        var n = bytes.length;
        if (n === 0) return { ok: false, error: 'Empty data' };
        var buf = Memory.alloc(n);
        for (var i = 0; i < n; i++) {
            buf.add(i).writeU8(bytes[i]);
        }
        var ret = nativeWrite(gameFd, buf, n);
        return { ok: ret === n, sent: ret, len: n };
    },

    // Send data through the game's SSL connection (proper encryption!)
    sslSend: function(hexData) {
        if (!_sslWriteFn) return { ok: false, error: 'SSL_write not hooked yet' };
        if (!_sslObj) return { ok: false, error: 'SSL object not captured yet (wait for game to send a packet first)' };
        var bytes = [];
        for (var i = 0; i < hexData.length; i += 2) {
            bytes.push(parseInt(hexData.substr(i, 2), 16));
        }
        var n = bytes.length;
        if (n === 0) return { ok: false, error: 'Empty data' };
        var buf = Memory.alloc(n);
        for (var i = 0; i < n; i++) {
            buf.add(i).writeU8(bytes[i]);
        }
        var ret = _sslWriteFn(_sslObj, buf, n);
        return { ok: ret === n, sent: ret, len: n };
    },

    // Check SSL hook status
    getSslStatus: function() {
        return {
            sslWriteHooked: !!_sslWriteFn,
            sslObjCaptured: !!_sslObj,
            sslObj: _sslObj ? _sslObj.toString() : null,
            sslReadOk: _sslReadOk,
            sslWriteOk: _sslWriteOk
        };
    },
    getNearNpcsRaw: function() {
        if (typeof _playerMainInstance === 'undefined' || _playerMainInstance === null) {
            var loadRes = readPlayerMainDirect();
            if (!loadRes.ok) return {ok: false, error: "PlayerMain not captured"};
        }
        if (typeof globalThis.GetNearNpcsFunc === 'undefined') {
            globalThis.GetNearNpcsFunc = new NativeFunction(
                il2cppBase.add(0x700194),
                'pointer',
                ['pointer']
            );
        }
        var listPtr = globalThis.GetNearNpcsFunc(_playerMainInstance);
        if (listPtr.isNull()) return {ok: true, listPtr: "null"};
        
        // C# List<T> has _items at 0x10 and _size at 0x18
        var itemsPtr = listPtr.add(0x10).readPointer();
        var size = listPtr.add(0x18).readInt();
        var npcList = [];
        
        for (var i = 0; i < size; i++) {
            var npcPtr = itemsPtr.add(0x20 + i * 8).readPointer();
            if (!npcPtr.isNull()) {
                npcList.push(npcPtr.toString());
            }
        }
        
        return {ok: true, listPtr: listPtr.toString(), size: size, npcs: npcList};
    },
    getMonsterCount: function() {
        // ❌ VÔ HIỆU HOÁ: offset/RVA 32-bit CỨNG trên runtime 64-bit -> đọc con trỏ rác -> ACCESS VIOLATION
        //    làm TREO thread game. KHÔNG dùng. Trả ok:false ngay, KHÔNG đụng native.
        return { ok: false, error: "getMonsterCount disabled (32-bit offsets unsafe on 64-bit -> crash)" };
        /* eslint-disable no-unreachable */
        if (typeof _playerMainInstance === 'undefined' || _playerMainInstance === null) {
            var loadRes = readPlayerMainDirect();
            if (!loadRes.ok) return {ok: false, error: "PlayerMain not captured"};
        }
        if (typeof globalThis.GetNearNpcsFunc === 'undefined') {
            globalThis.GetNearNpcsFunc = new NativeFunction(
                il2cppBase.add(0x700194),
                'pointer',
                ['pointer']
            );
        }
        var dictPtr = globalThis.GetNearNpcsFunc(_playerMainInstance);
        if (dictPtr.isNull()) return {ok: true, count: 0};

        // 32-bit offsets:
        // dictPtr -> ConcurrentDictionary
        // +0x08: m_tables (pointer)
        var tablesPtr = dictPtr.add(0x08).readPointer();
        if (tablesPtr.isNull()) return {ok: true, count: 0};
        
        // m_tables -> Tables object
        // +0x10: m_countPerLock (pointer to int[])
        var countArrayPtr = tablesPtr.add(0x10).readPointer();
        if (countArrayPtr.isNull()) return {ok: true, count: 0};
        
        // int[] object:
        // +0x0C: length of array
        // +0x10: first element
        var arrayLen = countArrayPtr.add(0x0C).readInt();
        var total = 0;
        for (var i = 0; i < arrayLen; i++) {
            total += countArrayPtr.add(0x10 + i * 4).readInt();
        }
        
        return {ok: true, count: total};
    },
    dumpPlayerMain: function() {
        if (!_playerMainInstance) return {ok: false};
        var buf = _playerMainInstance.readByteArray(0x40);
        
        var bytes = new Uint8Array(buf);
        var hex = [];
        for (var i = 0; i < bytes.length; i+=4) {
            var val = (bytes[i+3] << 24) | (bytes[i+2] << 16) | (bytes[i+1] << 8) | bytes[i];
            hex.push(val.toString(16).padStart(8, '0'));
        }
        return {ok: true, data: hex};
    },
    // Đọc điểm THUỘC TÍNH + điểm tiềm năng (cho NV Dã Tẩu "nâng cấp điểm <stat>"). App.Character (npcontroller+0xa0)
    // có power(Sức Mạnh)/agility(Thân Pháp)/outer(Sinh Khí)/inside(Nội Công)/leftProp(điểm tiềm năng còn lại).
    // Đọc theo TÊN qua il2cpp-bridge (KHÔNG offset cứng). Read-only — an toàn.
    getCharStats: function() {
        if (typeof Il2Cpp === 'undefined') return { ok: false, error: 'il2cpp not loaded' };
        var loadRes = readPlayerMainDirect();
        if (!loadRes.ok || !_playerMainInstance) return { ok: false, error: 'PlayerMain not found' };
        return Il2Cpp.perform(function () {
            var diag = { errors: [] };
            try {
                var npc = _playerMainInstance.add(0x20).readPointer();
                if (!npc || npc.isNull()) return { ok: false, error: 'npcontroller null' };
                var charPtr = npc.add(0xa0).readPointer();
                if (!charPtr || charPtr.isNull() || charPtr.compare(ptr("0x10000")) <= 0)
                    return { ok: false, error: 'character null' };
                var ch = new Il2Cpp.Object(charPtr);
                function rd(f) { try { var v = ch.field(f).value; return (typeof v === 'object' && v !== null && v.toNumber) ? v.toNumber() : v; } catch (e) { diag.errors.push(f + ':' + e); return null; } }
                // App.Character là class protobuf -> field backing có dấu '_' cuối.
                return {
                    ok: true, power: rd('power_'), agility: rd('agility_'), outer: rd('outer_'),
                    inside: rd('inside_'), leftProp: rd('leftProp_'), level: rd('level_'), diag: diag
                };
            } catch (e) { return { ok: false, error: e.message, diag: diag }; }
        });
    },

    getPlayerInfo: function() {
        try {
            var loadRes = readPlayerMainDirect();
            if (!loadRes.ok) return {ok: false, error: "PlayerMain not found: " + loadRes.error};
            
            var mapId = _playerMainInstance.add(0xE4).readS32();
            
            var nameStr = "";
            var level = 0;
            var moneyLow = 0;
            var moneyHigh = 0;
            var cidStr = "";
            
            var npcontroller = _playerMainInstance.add(0x20).readPointer();
            if (!npcontroller.isNull()) {
                var dataPtr = npcontroller.add(0x30).readPointer();
                if (!dataPtr.isNull() && dataPtr.compare(ptr("0x10000")) > 0) {
                    // Read cid from Datafield (offset 0x10 on 64-bit)
                    var cidPtr = dataPtr.add(0x10).readPointer();
                    if (!cidPtr.isNull()) {
                        var cidLen = cidPtr.add(0x10).readInt();
                        if (cidLen > 0 && cidLen < 100) {
                            cidStr = cidPtr.add(0x14).readUtf16String(cidLen);
                        }
                    }
                    
                    var namePtr = dataPtr.add(0x40).readPointer();
                    if (!namePtr.isNull() && namePtr.compare(ptr("0x10000")) > 0) {
                        var strLen = namePtr.add(0x10).readU32();
                        if (strLen > 0 && strLen < 100) {
                            nameStr = namePtr.add(0x14).readUtf16String(strLen);
                        }
                    }
                    level = dataPtr.add(0x54).readU32();
                }
                
                var character = npcontroller.add(0xa0).readPointer();
                if (!character.isNull() && character.compare(ptr("0x10000")) > 0) {
                    moneyLow = character.add(0x50).readU32();
                    moneyHigh = character.add(0x54).readU32();
                }
            }

            var mapX = _lastPosition.x;
            var mapY = _lastPosition.y;

            return {
                ok: true,
                cid: cidStr,
                name: nameStr,
                level: level,
                money: moneyLow, // Only sending moneyLow for simplicity, but backend can support long
                moneyHigh: moneyHigh,
                mapX: mapX,
                mapY: mapY,
                mapId: mapId
            };
        } catch(e) {
            return {ok: false, error: "Error getting player info: " + e.message};
        }
    },
    talkToNpcByName: function(nameStr) {
        if (typeof _playerMainInstance === 'undefined' || _playerMainInstance === null) {
            var loadRes = readPlayerMainDirect();
            if (!loadRes.ok) return {ok: false, error: "PlayerMain not captured"};
        }
        
        var CallTargetNpcFunc = new NativeFunction(il2cppBase.add(0x704A40), 'void', ['pointer', 'pointer', 'pointer']);
        
        // Dynamically find Npc name offset and NearNpcs dictionary offset to avoid crash
        if (typeof globalThis.NpcNameOffset === 'undefined') {
            globalThis.NpcNameOffset = 0x38; // Default
            globalThis.NearNpcsOffset = -1;
            try {
                var getClass = new NativeFunction(il2cppExport('il2cpp_class_from_name'), 'pointer', ['pointer', 'pointer', 'pointer']);
                var getField = new NativeFunction(il2cppExport('il2cpp_class_get_field_from_name'), 'pointer', ['pointer', 'pointer']);
                var classGetFields = new NativeFunction(il2cppExport('il2cpp_class_get_fields'), 'pointer', ['pointer', 'pointer']);
                var fieldGetName = new NativeFunction(il2cppExport('il2cpp_field_get_name'), 'pointer', ['pointer']);
                var fieldGetType = new NativeFunction(il2cppExport('il2cpp_field_get_type'), 'pointer', ['pointer']);
                var typeGetName = new NativeFunction(il2cppExport('il2cpp_type_get_name'), 'pointer', ['pointer']);
                var getOffset = new NativeFunction(il2cppExport('il2cpp_field_get_offset'), 'int', ['pointer']);
                var classGetParent = new NativeFunction(il2cppExport('il2cpp_class_get_parent'), 'pointer', ['pointer']);
                
                var domain = new NativeFunction(il2cppExport('il2cpp_domain_get'), 'pointer', [])();
                var assemblyOpen = new NativeFunction(il2cppExport('il2cpp_domain_assembly_open'), 'pointer', ['pointer', 'pointer']);
                var asm = assemblyOpen(domain, Memory.allocUtf8String('Assembly-CSharp.dll'));
                if (asm.isNull()) asm = assemblyOpen(domain, Memory.allocUtf8String('Assembly-CSharp'));
                var getImg = new NativeFunction(il2cppExport('il2cpp_assembly_get_image'), 'pointer', ['pointer']);
                var img = getImg(asm);
                
                var npcKlass = getClass(img, Memory.allocUtf8String(''), Memory.allocUtf8String('Npc'));
                if (!npcKlass.isNull()) {
                    var nameField = getField(npcKlass, Memory.allocUtf8String('m_szName'));
                    if (!nameField.isNull()) {
                        globalThis.NpcNameOffset = getOffset(nameField);
                    }
                }
            } catch (e) {}
        }
        
        if (typeof globalThis.GetNearNpcsFunc === 'undefined') {
            globalThis.GetNearNpcsFunc = new NativeFunction(
                il2cppBase.add(0x700194),
                'pointer',
                ['pointer']
            );
        }
        
        var dictPtr = globalThis.GetNearNpcsFunc(_playerMainInstance);
        if (dictPtr.isNull()) return {ok: false, error: "GetNearNpcs returned null"};
        
        var tablesPtr = dictPtr.add(0x08).readPointer();
        if (tablesPtr.isNull()) return {ok: false, error: "Tables is null"};
        
        var entriesPtr = tablesPtr.add(0x20).readPointer();
        if (entriesPtr.isNull()) return {ok: false, error: "Entries is null"};
        
        var entryCount = entriesPtr.add(0x18).readInt();
        if (entryCount <= 0 || entryCount > 10000) return {ok: false, error: "Invalid entry count"};
        
        var foundNpcId = -1;
        var foundNpcIdStr = "";
        var ptrSize = Process.pointerSize;
        
        for (var i = 0; i < entryCount; i++) {
            // Entry size is 24 bytes in 64-bit (int hash, int next, int key, padding, pointer value)
            var entryBase = entriesPtr.add(0x20 + (i * 24));
            var npcPtr = entryBase.add(0x10).readPointer();
            
            if (!npcPtr.isNull()) {
                try {
                    var namePtr = npcPtr.add(globalThis.NpcNameOffset).readPointer();
                    // CRITICAL FIX: Only read if pointer is a valid memory address (> 0x10000) to prevent Access Violation
                    if (!namePtr.isNull() && namePtr.compare(0x10000) > 0) {
                        var len = namePtr.add(0x10).readInt(); 
                        if (len > 0 && len < 100) {
                            var npcName = namePtr.add(0x14).readUtf16String(len);
                            if (npcName === nameStr) {
                                foundNpcId = entryBase.add(0x08).readInt(); // TKey is at +0x08
                                foundNpcIdStr = foundNpcId.toString();
                                break;
                            }
                        }
                    }
                } catch(e) {}
            }
        }
        
        if (foundNpcId === -1) {
            return {ok: false, error: "NPC not found in dictionary"};
        }
        
        return {ok: true, npcId: foundNpcIdStr};
    },
    dumpClasses: function() {
        var found = [];
        Il2Cpp.perform(function() {
            var image = Il2Cpp.domain.assembly('Assembly-CSharp').image;
            var classes = image.classes;
            for (var i = 0; i < classes.length; i++) {
                if (classes[i].name.indexOf('Manager') !== -1 || classes[i].name.indexOf('Obj') !== -1 || classes[i].name.indexOf('Npc') !== -1) {
                    found.push(classes[i].name);
                }
            }
        });
        return found;
    }
};
