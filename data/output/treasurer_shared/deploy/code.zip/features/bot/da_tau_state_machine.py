import time
import logging
import os
import sys
import re
from enum import Enum, auto

# Add project root to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from core.adb_helper import ADBHelper, ADB_PATH
from features.bot.game_bot import VLTK1Bot, DEBUG_DUMP
from core.quest import QuestReader, QuestInfo
from core.navigator import Navigator
from core.npc_interact import NPCInteract
from core.map_manager import MapManager
from core import tracker
from core import quest_actions
from core.money import fmt_money

logger = logging.getLogger("da_tau_sm")

# KHOÁ GHI FILE DÙNG CHUNG (10 cửa sổ = 10 thread/1 process). account_progress.json / datau_nodes.json
# bị read-modify-write từ nhiều device -> KHÔNG khoá thì ghi đè/mất tiến độ/JSON rách. 1 lock chung là đủ.
import threading as _threading
_SHARED_FILE_LOCK = _threading.RLock()

def _atomic_write_json(path, data):
    """Ghi JSON an toàn đa-thread: ghi file tmp rồi os.replace (atomic) — không bao giờ để file rách giữa chừng."""
    import json, os
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = f"{path}.tmp.{os.getpid()}.{_threading.get_ident()}"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)

# Tất cả opcode/tên gói tin có thể chứa hội thoại Dã Tẩu:
#   34=eNpcQuest (bảng mời quest mới), 166=eContextDescription,
#   124/126=bảng khi đã có nhiệm vụ (tên frida là UNK_124/UNK_126 -> phải khớp theo SỐ).
DATAU_DIALOG_OPS = ('eNpcQuest', 'eContextDescription', 'eNpcDialogue', 34, 124, 126, 166)

# CÂU MỜI / DẪN của Dã Tẩu (KHÔNG phải nội dung NV) — gặp text này thì NHẬN bằng packet
# rồi đọc lại bảng NV THẬT, tuyệt đối không mang sang EVALUATE (sẽ bị phân loại nhầm).
OFFER_TEXT_MARKERS = (
    "muốn tiếp nhận nhiệm vụ", "tiếp nhận nhiệm vụ mới", "tiếp nhận nhiệm vụ không",
    "có muốn nhận nhiệm vụ", "muốn nhận nhiệm vụ",
    # "Chỗ ta có vài thứ, ngươi có muốn xem thử không?"
    "có muốn xem thử", "muốn xem thử không", "có vài thứ", "xem thử không",
    # "...có muốn tham gia khảo nghiệm nhiệm vụ liên tục của ta không?"
    "khảo nghiệm nhiệm vụ", "tham gia khảo nghiệm", "nhiệm vụ liên tục",
)

class BotState(Enum):
    BOOTSTRAP = auto()
    IDLE_PRECHECK = auto()
    MOVE_TO_DATAU = auto()
    READ_QUEST = auto()
    EVALUATE = auto()
    EXECUTE_BUY = auto()
    EXECUTE_COMBAT = auto()
    EXECUTE_FIND_ITEM = auto()
    EXECUTE_FIND_EQUIP = auto()
    EXECUTE_SUBMIT_EQUIP = auto()
    EXECUTE_SUBMIT_POINTS = auto()
    EXECUTE_DELIVER = auto()
    CLEAR_INVENTORY = auto()
    REWARD = auto()
    CANCEL_QUEST = auto()
    ERROR = auto()
    LOST = auto()
    TRAINING = auto()
    TREASURER = auto()       # cửa sổ thủ quỹ: đứng yên, thu đồ + cấp tiền cho worker
    GO_TREASURER = auto()    # worker: đi tới thủ quỹ để giao đồ / nhận tiền

class DaTauStateMachine:
    def __init__(self, adb: ADBHelper):
        self.adb = adb
        self.device_id = self.adb.device_id    # để tracker gắn đúng thiết bị vào log ngày
        self.game_bot = VLTK1Bot(device_id=self.adb.device_id)
        self.navigator = Navigator(self.adb)
        self.navigator.game_bot = self.game_bot # Attach for RPC gotopath
        self.npc_interact = NPCInteract(self.adb)
        self.npc_interact.game_bot = self.game_bot
        self.map_mgr = MapManager()
        
        self.quest_reader = QuestReader({
            "adb_path": ADB_PATH,
            "device_id": self.adb.device_id
        })
        
        self.state = BotState.BOOTSTRAP
        self.current_quest: QuestInfo = None
        self.is_running = False
        self.read_quest_retries = 0
        self.last_monster_count = -1
        self.last_count_time = 0
        self.last_player_info_time = 0
        self.player_name = ""   # tên nhân vật hiện tại (để log theo NHÂN VẬT, không chỉ theo máy)
        self.datau_npc_id = None        # Cache ID Dã Tẩu của thành hiện tại (tránh dò lại 716/714/396 gây popup chồng)
        self._datau_dialog_open = False # Cờ: đang có popup Dã Tẩu/GiveBox mở trên màn hình hay không
        # Thống kê nhiệm vụ ngày (đẩy lên UI)
        self.daily_done = 0             # số NV đã hoàn thành trong phiên
        self._riu_use_count = 0         # số lần DÙNG RÌU thành công của account hiện tại (cap RIU_DAILY_CAP)
        self.last_quest_number = 0      # mốc "Nhiệm vụ thứ N" gần nhất
        self.last_remaining = 0         # "còn X nhiệm vụ" gần nhất
        self.daily_rewards = []         # [(quest_no, mô tả thưởng)] nhận trong ngày/phiên
        self.buy_threshold_van = 5      # ngưỡng giá mua từ sạp (vạn) — UI truyền vào động (mặc định 2 vạn)
        self.quest_action_cfg = quest_actions.load_config()  # {loại NV -> hành động} (UI cấu hình)
        self._cancel_do_chi = False     # cờ: lần hủy này dùng "hủy 100 đồ chí" hay hủy thường
        self._quest_changed_flag = False  # cờ user đổi/huỷ NV giữa chừng (_cache_buy_loop đọc) — init phòng AttributeError
        self.paused = False             # PENDING: bot dừng chờ người chơi xử lý (nạp tiền / làm NV tay) rồi bấm Resume
        # WATCHDOG: nhịp tim (heartbeat) — mốc thời gian LẦN CUỐI bot còn "nhúc nhích" (đổi state HOẶC 1 vòng
        # cày đồ chí). UI watchdog đọc field này: im quá lâu (không phải PENDING) = luồng treo/Frida chết -> tự
        # khởi động lại RIÊNG cửa sổ đó. Bump ở _goto_state + trong vòng _monitor_dochi_grind (cày lâu 1 state).
        self._hb_ts = time.time()
        # NHẬN BUFF TÂN THỦ TỪ XA: mốc lần cuối nhận. 0 = nhận NGAY ở tick kế (UI set 0 khi vừa tick checkbox).
        self._last_buff_ts = 0.0
        # ACCOUNT ROTATION: mỗi cửa sổ ôm danh sách account, xong 30 NV/ngày -> logout -> login account kế.
        self.ACCOUNT_QUEUE_PATH = "data/output/account_queue.json"      # {device_id: [{acc,pass}]}
        self.ACCOUNT_PROGRESS_PATH = "data/output/account_progress.json"  # {device_id: {date, done:[acc...]}}
        self.account_queue = []
        self.account_index = 0
        try:
            self._load_account_queue()
        except Exception:
            pass

        # Default config
        self.config = {
            "cancel_rare_items": True,
            "cancel_phuc_duyen": True,
            "preferred_city": "Ba Lăng Huyện" # Default safe city for Da Tau
        }
        
    @property
    def game_bot_connected(self):
        return self.game_bot and self.game_bot.is_connected()
        
    def start(self):
        self.is_running = True
        logger.info("="*50)
        logger.info("  STARTING DA TAU STATE MACHINE (FULL WORKFLOW)")
        logger.info("="*50)
        while self.is_running:
            try:
                self.tick()
                self._tick_err_streak = 0
            except Exception as e:
                self._tick_err_streak = getattr(self, '_tick_err_streak', 0) + 1
                # log VÀI lần đầu + thưa dần (không spam "Lỗi tick" mỗi 0.2s khi game crash).
                if self._tick_err_streak <= 3 or self._tick_err_streak % 30 == 0:
                    logger.error(f"Lỗi State Machine (lần {self._tick_err_streak}): {e}")
                # MẤT KẾT NỐI (game crash/đóng) HOẶC lỗi LIÊN TỤC (>=5, nghi session hỏng ngầm) -> ép coi như rớt
                # + về BOOTSTRAP để TỰ relaunch game + đăng nhập lại (KHÔNG goto ERROR = dừng/spin). "bỏ qua chạy tiếp".
                if not self.game_bot_connected or self._tick_err_streak >= 5:
                    try: self.game_bot._detached = True
                    except Exception: pass
                    self._ensure_login_done = False   # RESET → BOOTSTRAP sẽ kiểm game-chạy + RELAUNCH game nếu chết
                    self._goto_state(BotState.BOOTSTRAP)
                    self._tick_err_streak = 0
                    time.sleep(1.0)
                # else: lỗi lẻ tẻ -> BỎ QUA, giữ nguyên state, tick sau chạy tiếp (KHÔNG dừng bot).
            time.sleep(0.2)
            
    def tick(self):
        # PENDING: đang chờ người chơi xử lý (thiếu tiền / NV không làm được). KHÔNG xử lý state —
        # đứng im, GIỮ nguyên trạng thái, đợi người chơi bấm Resume trên UI (resume() bỏ cờ + chạy tiếp).
        if getattr(self, 'paused', False):
            # CHỜ-ĐỔI-NV (find/submit không tìm được): định kỳ re-read Dã Tẩu, nếu user HOÀN THÀNH/ĐỔI NV thì
            # tự làm NV mới (khỏi bấm Resume). Các PENDING khác (thiếu tiền/thủ quỹ) KHÔNG bật cờ này → đứng yên.
            if getattr(self, '_await_quest_change', False):
                # (1) USER NÂNG NGƯỠNG GIÁ: PENDING vì món > ngưỡng → nếu giờ ngưỡng ≥ giá món đang chờ thì
                #     TỰ quay lại mua (khỏi bấm Resume). _pending_buy_van = giá rẻ nhất (vạn) lúc bị chặn.
                try:
                    pv = int(getattr(self, '_pending_buy_van', 0) or 0)
                    if pv > 0 and int(getattr(self, 'buy_threshold_van', 0) or 0) >= pv:
                        self._chat(f"💰 Ngưỡng mua đã nâng lên {self.buy_threshold_van}v ≥ giá món đang chờ {pv}v "
                                   f"→ TỰ quay lại mua (không cần Resume).")
                        self._pending_buy_van = 0
                        self.resume()
                        return
                except Exception:
                    pass
                # (2) USER ĐỔI/HOÀN THÀNH NV ở Dã Tẩu → tự làm NV mới.
                try:
                    self._maybe_detect_quest_change()
                except Exception:
                    pass
            time.sleep(0.5)
            return

        # NHẬN BUFF TÂN THỦ TỪ XA (nếu BẬT ở UI): char <79 -> remote Lễ Quan nhận buff, mỗi 5 phút.
        # ⚠️ CHỈ ở STATE COMBAT/LEVELING (buff mới có ý nghĩa). Buff = mở Lễ Quan NPC dialog → nếu gọi NGAY TRƯỚC
        # khi nộp Dã Tẩu (state mua/nộp/đọc-NV) thì server bận dialog → Dã Tẩu CÂM ~46s (user log 17:03-17:04:
        # "mua xong → buff → 13 node câm cả phút"). Trước/trong lúc cày đã có _maybe_receive_buff(force=True) riêng
        # (3288/3405) nên bỏ ở các state NPC-interaction KHÔNG mất buff lúc cày. char >=79 -> hàm tự bỏ qua.
        if self.state in (BotState.TRAINING, BotState.EXECUTE_COMBAT, BotState.EXECUTE_FIND_ITEM):
            try:
                self._maybe_receive_buff()
            except Exception:
                pass

        # MẤT KẾT NỐI (is_connected=False do game crash/đóng) & KHÔNG ở BOOTSTRAP → về BOOTSTRAP để relaunch+login.
        # Bắt cả ca RỚT SẠCH: vòng grind thoát do game_bot_connected=False mà KHÔNG throw exception → start()
        # không bắt được → trước đây kẹt idle. (chỉ goto khi chưa ở BOOTSTRAP → không lặp.)
        if not self.game_bot_connected and self.state != BotState.BOOTSTRAP:
            self._ensure_login_done = False   # RESET → BOOTSTRAP relaunch game nếu game đã chết (không chỉ re-attach)
            self._goto_state(BotState.BOOTSTRAP)

        # PHÁT HIỆN GAME ĐƠ (treo MÀN HÌNH, KHÔNG crash/đóng): Frida VẪN attach → game_bot_connected=True →
        # watchdog + check trên KHÔNG bắt được; bot tưởng còn sống, cày/hỏi-node vô ích ("toàn màn hình game đứng
        # mà bot không nhận ra"). DẤU HIỆU: game đứng hình → server NGỪNG đẩy gói → recvAny ĐỨNG YÊN. Theo dõi
        # recvAny ~10s/lần; đứng yên > FREEZE_SEC = ĐƠ → force-stop + relaunch (game đơ vẫn còn pid nên phải
        # force-stop, không chỉ launch). Bỏ qua BOOTSTRAP/THỦ QUỸ-đứng-yên/PENDING.
        try:
            if (self.game_bot_connected and self.state not in (BotState.BOOTSTRAP, BotState.TREASURER)
                    and not self.paused):
                _now = time.time()
                if _now - getattr(self, '_freeze_chk_ts', 0) > 10:
                    self._freeze_chk_ts = _now
                    try: _rv = int((self.game_bot.rpc.ping() or {}).get('recvAny', -1))
                    except Exception: _rv = -1
                    if _rv < 0 or _rv != getattr(self, '_freeze_rv', None):
                        self._freeze_rv = _rv; self._freeze_rv_ts = _now      # còn nhận gói → tươi
                    elif _now - getattr(self, '_freeze_rv_ts', _now) > self.FREEZE_SEC:
                        self._chat(f"🧊 GAME ĐƠ (recvAny đứng yên {int(_now - self._freeze_rv_ts)}s dù Frida còn attach) "
                                   f"→ force-stop + relaunch game + login.")
                        self._freeze_rv_ts = _now            # tránh kích lại ngay khi đang relaunch
                        try: self._recover_by_relaunch()
                        except Exception as e: logger.error(f"[freeze-relaunch] {e}")
                        return
        except Exception:
            pass

        # THỦ QUỸ: cửa sổ được CỐ ĐỊNH làm thủ quỹ -> CHỈ chế độ TREASURER, KHÔNG BAO GIỜ làm Dã Tẩu.
        # Guard mỗi tick: kể cả khi config lưu SAU lúc bấm Auto, hay lỡ đang ở state Dã Tẩu nào đó -> ép về TREASURER.
        # (cho BOOTSTRAP chạy để kết nối Frida trước; TREASURER thì giữ nguyên.)
        try:
            from core import treasurer as _T
            if _T.is_treasurer_device(self.device_id) and self.state not in (BotState.BOOTSTRAP, BotState.TREASURER):
                self._goto_state(BotState.TREASURER)
        except Exception:
            pass

        # Parse available packets to find current Map ID
        if self.game_bot_connected:
            pkts = self.game_bot.poll_recv()
            if pkts:
                for p in pkts:
                    if p.get('opcode') in (7, 8): # eEnterMap or eEnterGameServer
                        try:
                            # Parse map_id from hex
                            hx = p.get('hex', '')
                            if len(hx) >= 12:
                                data = bytes.fromhex(hx)[6:] # skip 6 bytes header
                                if len(data) >= 2 and data[0] == 0x08: # field 1 (mapId), varint
                                    val = 0
                                    shift = 0
                                    pos = 1
                                    while pos < len(data):
                                        b = data[pos]
                                        pos += 1
                                        val |= (b & 0x7F) << shift
                                        if not (b & 0x80):
                                            break
                                        shift += 7
                                    self.current_map_id = val
                                    self._chat(f"Nhân vật hiện đang đứng ở Map ID: {self.current_map_id}")
                        except: pass

        handlers = {
            BotState.BOOTSTRAP: self._handle_bootstrap,
            BotState.IDLE_PRECHECK: self._handle_idle_precheck,
            BotState.MOVE_TO_DATAU: self._handle_move_to_datau,
            BotState.READ_QUEST: self._handle_read_quest,
            BotState.EVALUATE: self._handle_evaluate,
            BotState.EXECUTE_BUY: self._handle_execute_buy,
            BotState.EXECUTE_COMBAT: self._handle_execute_combat,
            BotState.EXECUTE_FIND_ITEM: self._handle_execute_find_item,
            BotState.EXECUTE_FIND_EQUIP: self._handle_execute_find_equip,
            BotState.EXECUTE_SUBMIT_EQUIP: self._handle_execute_submit_equip,
            BotState.EXECUTE_SUBMIT_POINTS: self._handle_execute_submit_points,
            BotState.EXECUTE_DELIVER: self._handle_execute_deliver,
            BotState.CLEAR_INVENTORY: self._handle_clear_inventory,
            BotState.REWARD: self._handle_reward,
            BotState.CANCEL_QUEST: self._handle_cancel_quest,
            BotState.ERROR: self._handle_error,
            BotState.LOST: self._handle_lost,
            BotState.TRAINING: self._handle_training,
            BotState.TREASURER: self._handle_treasurer_mode,
            BotState.GO_TREASURER: self._handle_go_treasurer,
        }
        
        handler = handlers.get(self.state)
        if handler:
            handler()
        else:
            logger.warning(f"Chưa hỗ trợ xử lý state: {self.state}")
            self._goto_state(BotState.ERROR)
            
        # Update player info to UI mỗi 8s (giảm RPC khi chạy nhiều account; trạng thái không cần realtime).
        if self.game_bot_connected and time.time() - self.last_player_info_time > 8:
            try:
                res = self.game_bot.rpc.get_player_info()
                if res and res.get('ok'):
                    # PHÁT HIỆN ĐỔI NHÂN VẬT (kể cả login TAY, không qua _do_account_switch) → reset tiến độ NV/ngày.
                    # Trước đây đổi char tay mà daily_limit_reached_flag/daily_done/max_remaining_today giữ từ char cũ
                    # → khung cửa sổ hiện 20/20 mãi dù char mới đang làm. So sánh cid (duy nhất); đổi → _reinit.
                    _cid = res.get('cid') or ''
                    _prev_cid = getattr(self, '_last_cid', '')
                    if _cid and _prev_cid and _cid != _prev_cid:
                        self._chat(f"🔄 Phát hiện ĐỔI NHÂN VẬT (cid {_prev_cid}→{_cid}) → reset tiến độ NV/ngày + làm lại từ đầu cho nhân vật mới.")
                        self._reinit_after_relogin()        # reset flag/daily_done/last_remaining/max_remaining_today (+ đặt _last_cid='')
                        self._goto_state(BotState.IDLE_PRECHECK)
                    if _cid:
                        self._last_cid = _cid
                    name = res.get('name') or "Unknown"
                    self.player_name = name   # cache để gắn vào log (per nhân vật)
                    level = res.get('level') or 0
                    # Bạc HIỂN THỊ = hành trang (bagarate) + KHO (Tiền Trang). Đọc qua method chuẩn.
                    carried, storage = self._money_info()
                    if carried is None and storage is None:
                        money = res.get('money') or 0
                    else:
                        money = (carried or 0) + (storage or 0)
                    map_x = res.get('mapX') or 0
                    map_y = res.get('mapY') or 0
                    map_id = res.get('mapId') or getattr(self, 'current_map_id', '')

                    if map_id:
                        try:
                            from database.db_manager import db
                            tn = db.get_map_name(map_id)
                        except Exception:
                            tn = None
                        if tn and not str(tn).startswith("Map_"):
                            map_name = f"{tn} [{map_id}] ({map_x},{map_y})"
                        else:
                            map_name = f"Map {map_id} ({map_x},{map_y})"
                    else:
                        map_name = f"({map_x},{map_y})"
                        
                    if hasattr(self, 'ui_update_player'):
                        self.ui_update_player(f"{name} (Lv.{level})", map_name, fmt_money(money))
                else:
                    logger.warning(f"get_player_info failed: {res}")
            except Exception as e:
                logger.error(f"Error getting player info: {e}")
            self.last_player_info_time = time.time()

        # AUTO-ACCEPT TỔ ĐỘI (mặc định, mọi state): ai mời (op79) → tự vào (op92). Trong party ai nhặt đồ-chí
        # mình CŨNG được tính (user xác nhận) → cày chung nhân tiến độ. Throttle 2s.
        if self.game_bot_connected and time.time() - getattr(self, '_last_party_accept_ts', 0) > 2:
            self._last_party_accept_ts = time.time()
            try:
                self._auto_accept_party()
            except Exception as e:
                logger.error(f"[auto-party] {e}")

        # AUTO-NHẶT đồ-chí + bạc khi CÀY (ngoài thành): op54 → op56 (verify live). Đảm bảo nhặt đồ-chí dù
        # autoplay profile không bật 'nhặt'. Throttle 1.5s; bỏ qua trong thành (không có đồ-chí + tránh nhặt linh tinh).
        if self.game_bot_connected and time.time() - getattr(self, '_last_pickup_ts', 0) > 1.5:
            self._last_pickup_ts = time.time()
            try:
                if not self._in_town():
                    self._auto_pickup_ground()
            except Exception as e:
                logger.error(f"[auto-pickup] {e}")

        # AUTO-ĐÁNH caster (CHỈ khi caster_skill_id>0, mặc định TẮT): invoke client DoSkill ~1s/lần, ngoài thành.
        if self.game_bot_connected and time.time() - getattr(self, '_last_attack_ts', 0) > 1.0:
            self._last_attack_ts = time.time()
            try:
                if not self._in_town():
                    self._auto_attack_caster()
            except Exception as e:
                logger.error(f"[auto-attack] {e}")

    @staticmethod
    def _parse_party_invite_teamid(hexstr):
        """op79 ePartyInvite: field1=PartyData(nested, field4=teamId), field2=captainCid. Trả (teamId, captainCid)."""
        try:
            b = bytes.fromhex(hexstr)[6:]   # bỏ header [len4][op2]
        except Exception:
            return None, None
        i = 0; team = None; cap = None
        while i < len(b):
            tag = b[i]; i += 1; fno = tag >> 3; wt = tag & 7
            if wt == 2:
                if i >= len(b): break
                ln = b[i]; i += 1; sub = b[i:i+ln]; i += ln
                if fno == 1:                       # PartyData → field4 varint = teamId
                    j = 0
                    while j < len(sub):
                        t2 = sub[j]; j += 1; f2 = t2 >> 3; w2 = t2 & 7
                        if w2 == 0:
                            v = 0; sh = 0
                            while j < len(sub):
                                c = sub[j]; j += 1; v |= (c & 0x7f) << sh; sh += 7
                                if not c & 0x80: break
                            if f2 == 4: team = v
                        elif w2 == 2:
                            if j >= len(sub): break
                            l2 = sub[j]; j += 1; j += l2
                        else: break
                elif fno == 2:
                    try: cap = sub.decode('utf-8', 'ignore')
                    except Exception: cap = None
            elif wt == 0:
                while i < len(b):
                    c = b[i]; i += 1
                    if not c & 0x80: break
            else:
                break
        return team, cap

    PARTY_COOLDOWN_SEC = 30.0    # vừa vào 1 đội thì BỎ QUA mọi lời mời CÙNG đội trong ngần này (chống nhấp nháy)
    FREEZE_SEC = 120             # recvAny đứng yên ngần này (game đơ, Frida còn attach) → force-stop + relaunch

    def _auto_accept_party(self):
        """Quét recv_buffer tìm op79 ePartyInvite → lấy teamId → ePartySelfAccept(op92) TỰ VÀO tổ đội.

        ⚠️ CHỐNG NHẤP NHÁY (fix 2026-06-16, user chốt): dedup-theo-hex KHÔNG đủ — server gửi lời mời gói MỚI
        (hex khác) mỗi ~2s và/hoặc op77 reset `_joined_team` → vẫn re-accept (op92) + re-log liên tục (đã thấy
        'Tự vào tổ đội teamId 25/31' lặp ở LinhDL dù đã build). FIX dứt điểm:
          1) COOLDOWN theo teamId: vừa vào đội X thì BỎ QUA mọi op79 đội X trong PARTY_COOLDOWN_SEC.
          2) Vào xong → XOÁ SẠCH gói mời op79/op77 khỏi recv_buffer để vòng sau không quét lại.
        Mời đội KHÁC → vào ngay. Rời đội (op77) → quên `_joined_team`; vào lại được sau khi hết cooldown đội đó."""
        from core.equip_matcher import split_frames
        buf = list(getattr(self.game_bot, 'recv_buffer', []) or [])
        cooldown = getattr(self, '_party_cooldown', None)
        if cooldown is None:
            cooldown = self._party_cooldown = {}
        now = time.time()
        invite_team = None
        for p in buf:
            for op, hx in (split_frames(p.get('hex', '')) or [(p.get('opcode'), p.get('hex', ''))]):
                if op == 79:
                    t, _cap = self._parse_party_invite_teamid(hx)
                    if t:
                        invite_team = t
                elif op == 77:                      # ePartyOut: rời đội → quên đội đang giữ (cho phép vào lại sau)
                    self._joined_team = None
        if invite_team is None:
            return
        if invite_team == getattr(self, '_joined_team', None):
            return
        if now - cooldown.get(invite_team, 0) < self.PARTY_COOLDOWN_SEC:   # vừa vào đội này → KỆ lời mời (hết nhấp nháy)
            self._clear_party_invites_from_buffer()
            return
        self.game_bot.accept_party(invite_team)
        self._joined_team = invite_team
        cooldown[invite_team] = now
        self._chat(f"🤝 Tự vào tổ đội (teamId {invite_team}) — đồ-chí ai trong đội nhặt mình cũng được tính.")
        self._clear_party_invites_from_buffer()      # XOÁ SẠCH lời mời để vòng sau không quét lại = không nhấp nháy

    def _clear_party_invites_from_buffer(self):
        """Bỏ các gói lời mời/rời tổ đội (op79/op77) khỏi recv_buffer — chỉ bỏ gói THUẦN party (opcode đầu là
        77/79), KHÔNG đụng gói gộp chứa op khác (245/124…) để không mất dữ liệu nhiệm vụ."""
        try:
            rb = getattr(self.game_bot, 'recv_buffer', None)
            if not rb:
                return
            self.game_bot.recv_buffer = [p for p in rb if p.get('opcode') not in (77, 79)]
        except Exception:
            pass

    @staticmethod
    def _parse_op54_obj(hx):
        """op54 eAddMapObject: field1=objectId(string), field7=name, field9=type(int32).
        type phân loại vật thể: quái/NPC vs ĐỒ RƠI (vàng/item). Trả (objectId, name, otype)."""
        try:
            b = bytes.fromhex(hx)[6:]
        except Exception:
            return None, None, None
        i = 0; oid = None; name = None; otype = None
        while i < len(b):
            tag = b[i]; i += 1; fno = tag >> 3; wt = tag & 7
            if wt == 2:
                if i >= len(b): break
                ln = b[i]; i += 1; sub = b[i:i+ln]; i += ln
                if fno == 1:
                    try: oid = sub.decode('utf-8', 'ignore')
                    except Exception: oid = None
                elif fno == 7:
                    try: name = sub.decode('utf-8', 'ignore')
                    except Exception: name = None
            elif wt == 0:
                val = 0; sh = 0
                while i < len(b):
                    c = b[i]; i += 1
                    val |= (c & 0x7f) << sh; sh += 7
                    if not c & 0x80: break
                if fno == 9:
                    otype = val
            elif wt == 5: i += 4
            elif wt == 1: i += 8
            else: break
        return oid, name, otype

    @staticmethod
    def _parse_op54_dataid(hx):
        """Lấy field2=dataId (id LOẠI vật phẩm) từ op54 — để so đồ-chí động A vs B có cùng loại không."""
        try:
            b = bytes.fromhex(hx)[6:]
        except Exception:
            return None
        i = 0
        while i < len(b):
            tag = b[i]; i += 1; fno = tag >> 3; wt = tag & 7
            if wt == 2:
                if i >= len(b): break
                ln = b[i]; i += 1; i += ln
            elif wt == 0:
                val = 0; sh = 0
                while i < len(b):
                    c = b[i]; i += 1; val |= (c & 0x7f) << sh; sh += 7
                    if not c & 0x80: break
                if fno == 2:
                    return val
            elif wt == 5: i += 4
            elif wt == 1: i += 8
            else: break
        return None

    def _auto_pickup_ground(self):
        """TỰ NHẶT vật phẩm dưới đất (REMOTE op56). Nguồn = buffer riêng op54 (get_op54), không bị op9 flood
        đẩy ra. Mỗi objectId gửi pickup PICKUP_REPEAT lần rồi nhớ (seen) -> KHÔNG gửi lại.
        ⚠️ Server TIN CLIENT: mỗi gói eObjectPickup = +1 tiến độ đồ-chí (dù 1 tấm thật) → PICKUP_REPEAT phải = 1
           lúc chạy thật, chỉ tăng để TEST client-trust. (user xác nhận live 2026-06-20)"""
        PICKUP_REPEAT = 20   # ✅ mặc định 1 (chuẩn). Tăng để test client-trust (1 tấm → +N tiến độ ảo).
        try:
            r = self.game_bot.rpc.get_op54() or {}
            items = r.get('items') or []
        except Exception:
            items = []
        seen_ids = getattr(self, '_pickup_seen', None)
        if seen_ids is None:
            seen_ids = self._pickup_seen = set()
        fired = 0
        for hx in items:
            try:
                oid, name, otype = self._parse_op54_obj(hx)
            except Exception:
                continue
            if not oid or oid in seen_ids:
                continue
            seen_ids.add(oid)
            try:
                _did = self._parse_op54_dataid(hx)   # dataId (field2) = id LOẠI item (log để soi nếu cần)
            except Exception:
                _did = None
            logger.info(f"[PICKUP] id={oid} dataId={_did} type={otype} name={name!r} repeat={PICKUP_REPEAT}")
            for _ in range(PICKUP_REPEAT):
                try:
                    self.game_bot.pickup(str(oid)); fired += 1
                except Exception:
                    pass
        # 🆕 BỔ SUNG: BOSS thả MẬT CHÍ KHÔNG đi qua op54 (user xác nhận live 2026-06-20: đánh boss rớt 4 mật chí,
        #    op54 không hề có → bot không nhặt, phải nhặt tay). Đọc thẳng vật quanh char từ MEMORY (GetNearObjects)
        #    — không phụ thuộc packet. Object tên chứa chí/thần bí/mật → gửi op56 (1 lần/id). Throttle 2s riêng
        #    (RPC il2cpp nặng hơn getOp54). Log [PICKUP][near] để verify có bắt được mật chí không.
        now = time.time()
        if now - getattr(self, '_last_near_pick_ts', 0) > 2.0:
            self._last_near_pick_ts = now
            try:
                nr = self.game_bot.rpc.get_near_objects() or {}
                for o in (nr.get('objs') or []):
                    oid = o.get('id'); nm = (o.get('name') or '')
                    if not oid or oid in seen_ids:
                        continue
                    nlow = nm.lower()
                    if any(k in nlow for k in ('chí', 'thần bí', 'mật')):
                        seen_ids.add(oid)
                        logger.info(f"[PICKUP][near] id={oid} name={nm!r} cls={o.get('cls')} "
                                    f"(GetNearObjects — op54 SÓT) → gửi op56 ×{PICKUP_REPEAT}")
                        for _ in range(PICKUP_REPEAT):
                            try:
                                self.game_bot.pickup(str(oid)); fired += 1
                            except Exception:
                                pass
            except Exception as e:
                logger.info(f"[PICKUP][near] GetNearObjects lỗi: {e}")
        if fired:
            logger.info(f"[PICKUP] tổng request: {fired} (đã thấy {len(seen_ids)} object)")
        if len(seen_ids) > 6000:
            self._pickup_seen = set(list(seen_ids)[-3000:])

    def _auto_attack_caster(self):
        """TỰ ĐÁNH bằng cách invoke client DoSkill(skill) (caster đánh-xa replay packet KHÔNG dame — phải để client
        tự cast, xem [[boss-detection]]). Chỉ chạy khi BẬT: self.caster_skill_id > 0 (mặc định 0 = TẮT, không đụng
        flow autoplay). DoSkill tự nhắm con gần. Gọi trong tick + vòng cày, throttle ~1s. CHỈ ngoài thành."""
        sid = getattr(self, 'caster_skill_id', 0) or 0
        if sid <= 0:
            return
        try:
            self.game_bot.do_skill(int(sid))
        except Exception as e:
            logger.debug(f"[auto-attack] {e}")

    def _maybe_receive_buff(self, force=False):
        """BẬT 'nhận buff từ xa' (UI) + char <79 -> remote Lễ Quan nhận buff Tân Thủ. Nhận lại MỖI 5 PHÚT ở tick();
        force=True (gọi khi LÊN ĐỘNG cày đồ chí/mật chí) -> BỎ QUA throttle, nhận NGAY (acc mới login/hết buff
        đều có buff trước khi cày). char >=79 -> bỏ qua. Đọc cờ TOÀN CỤC buff_config."""
        from core import buff_config
        if not buff_config.is_enabled():
            return
        # THỦ QUỸ đứng yên (không cày/lên cấp) → KHÔNG cần buff Lễ Quan.
        try:
            from core import treasurer as _T
            if _T.is_treasurer_device(self.device_id):
                return
        except Exception:
            pass
        now = time.time()
        if not force and now - getattr(self, '_last_buff_ts', 0.0) < 300:   # nhận lại mỗi 5 phút
            return
        if not getattr(self, 'game_bot_connected', False):
            return
        try:
            info = self.game_bot.rpc.get_player_info() or {}
        except Exception:
            return
        lv = info.get('level') or 0
        if not lv:
            return                         # CHƯA đọc được cấp (acc vừa login chưa load xong) -> KHÔNG đặt mốc
                                           # -> tick sau thử lại (FIX: trước đây set mốc ngay -> kẹt 1h, acc mới
                                           # không bao giờ tự nhận buff).
        if lv >= 79:
            self._last_buff_ts = now       # cao thủ >=79 -> không cần buff, khỏi check lại 5 phút
            return
        self._chat(f"🔆 Nhận buff Tân Thủ từ xa (cấp {lv} < 79)…")
        res = self.game_bot.receive_tan_thu_buff()
        # ĐÓNG popup Lễ Quan (receive_tan_thu_buff mở dialog NPC qua eNpcDialogue → để lại popup che màn).
        try:
            self._clear_popups("sau nhận buff Lễ Quan")
        except Exception:
            pass
        if res == 'ok':
            self._last_buff_ts = now       # nhận THẬT (có op48 xác nhận) -> 5 phút sau nhận lại
            self._chat("🔆 Đã nhận buff Tân Thủ (Lễ Quan cùng vùng — đã xác nhận).")
        elif res == 'unconfirmed':
            # Mở được menu + select 0 nhưng KHÔNG bắt được op48 xác nhận -> KHÔNG dám báo "đã nhận" (tránh
            # dương-tính-giả như user phát hiện). Có thể: Lễ Quan sai/đông/cooldown. Thử lại sau ~60s.
            self._last_buff_ts = now - 300 + 120
            self._chat("🔆 Đã GỬI nhận buff Tân Thủ nhưng CHƯA bắt được xác nhận (có thể miss) — thử lại sau ~120s.")
        else:
            # THẤT BẠI (no_lequan: đang ở động/vùng KHÔNG có Lễ Quan; hoặc err) -> KHÔNG coi như đã buff.
            # Thử lại sau ~90s (đừng spam mỗi tick): vòng cày/về thành sau sẽ ở vùng CÓ Lễ Quan -> lần kế thành công.
            self._last_buff_ts = now - 300 + 90
            if res == 'no_lequan':
                self._chat("🔆 Chưa gọi được Lễ Quan cùng vùng (động này?) — sẽ thử lại sau ~90s.")
            else:
                self._chat("🔆 Nhận buff lỗi — thử lại sau ~3 phút.")

    # ==================== FLOW LUYỆN CÔNG (cửa sổ đánh dấu Luyện Công) ====================
    def _lc_reload_queue(self):
        from core import luyencong_accounts as LA
        self._lc_queue = LA.load_queue(getattr(self, 'device_id', None)) or []

    def _luyencong_tick(self):
        """Mỗi tick (cửa sổ luyện công, đã connect): lấy account kế CHƯA xử trong phiên -> chạy cả cycle.
        Xong hết -> đứng im."""
        nxt = None
        for a in self._lc_queue:
            if a.get('acc') and a['acc'] not in self._lc_done_session:
                nxt = a; break
        if not nxt:
            if not getattr(self, '_lc_all_done_logged', False):
                self._chat("🏋️ Đã xử hết danh sách account luyện công (hoặc danh sách trống). Dừng.")
                self._lc_all_done_logged = True
            time.sleep(2); return
        self._lc_done_session.add(nxt['acc'])
        self._lc_all_done_logged = False
        try:
            self._luyencong_do_account(nxt)
        except Exception as e:
            self._chat(f"🏋️ [{nxt.get('name')}] lỗi cycle: {e}")

    def _luyencong_do_account(self, a):
        """1 chu trình: relaunch→login→(tạo char nếu acc mới)→ra bãi quái→ăn Bạch Câu Hoàn→auto→trainoff."""
        import json
        acc, pwd, name = a.get('acc'), a.get('pwd'), a.get('name')
        gb = self.game_bot
        self._hb_ts = time.time()
        # ĐĂNG NHẬP: CHỈ logout khi đang IN-WORLD (acc trước còn trong game). ⚠️ KHÔNG logout khi đã ở màn login
        # (acc đầu/game mới mở) — logout lúc đó gọi LoginManger.LogOut/BackToLogin → PHÁ màn login → popup biến mất
        # → login fail 30s (đã verify: ở login, login_account setOk=true OK; logout làm hỏng). Rồi BẮN login LẶP
        # tới khi AccountLoginPopup sẵn sàng (gb.login True). Ăn ngay khi màn login load, KHÔNG relaunch.
        if gb.get_login_state() == 'in_world':
            try: gb.logout()
            except Exception: pass
            time.sleep(1.5)
        self._chat(f"🏋️ [{name}] đăng nhập {acc}…")
        logged = False; t0 = time.time()
        while time.time() - t0 < 30:
            if self._stopping(): return
            self._hb_ts = time.time()
            if gb.login(acc, pwd):   # True = popup có + đã login
                logged = True; break
            time.sleep(1)
        if not logged:
            self._chat(f"🏋️ [{name}] không thấy màn login (popup) sau 30s → bỏ qua acc."); return
        try: gb.rpc.select_last_server()
        except Exception: pass
        # chờ màn TẠO CHAR (acc mới) hoặc vào thẳng world (acc có char) — poll 0.5s.
        t0 = time.time(); at_create = False
        while time.time() - t0 < 25:
            if self._stopping(): return
            self._hb_ts = time.time()
            if gb.get_login_state() == 'in_world':
                break
            if gb.at_create_screen():
                at_create = True; break
            time.sleep(0.5)
        if gb.get_login_state() != 'in_world':
            if not at_create:
                try: gb.rpc.open_create_screen()
                except Exception: pass
                time.sleep(2); at_create = gb.at_create_screen()
            if at_create:
                self._chat(f"🏋️ [{name}] tạo nhân vật…")
                gb.create_character(name)
            if not gb.wait_in_world(timeout=80):
                self._chat(f"🏋️ [{name}] KHÔNG vào được world (tạo char/login lỗi) → bỏ qua."); return
        # ra bãi quái theo thôn
        try:
            spots = json.load(open('data/output/luyencong_spawn_spots.json', encoding='utf-8'))
        except Exception:
            spots = {}
        mid = (gb.rpc.get_player_info() or {}).get('mapId')
        spot = spots.get(str(mid))
        if spot and spot.get('game'):
            gx, gy = spot['game'][0], spot['game'][1]
            self._chat(f"🏋️ [{name}] map {mid} → đi bãi quái game({gx},{gy})…")
            for _ in range(6):
                if self._stopping(): return
                self._hb_ts = time.time()
                gb.walk_to(gx, gy, 90)
                time.sleep(2)
        else:
            self._chat(f"🏋️ [{name}] map {mid} CHƯA có bãi quái trong bảng → bật auto tại chỗ.")
        # ăn Bạch Câu Hoàn (nạp giờ trainoff)
        if gb.use_bach_cau_hoan():
            self._chat(f"🏋️ [{name}] đã ăn Bạch Câu Hoàn.")
        # bật auto + treo offline
        gb.start_autoplay(arm=True); time.sleep(2)
        try:
            gb.trainoff_check(True); time.sleep(1)
            gb.trainoff_start()
        except Exception as e:
            self._chat(f"🏋️ [{name}] trainoff lỗi: {e}")
        self._chat(f"🏋️ [{name}] ✅ XONG: ra bãi quái + auto + treo offline.")

    def _goto_state(self, new_state: BotState):
        logger.info(f"[TRANSITION] {self.state.name} -> {new_state.name}")
        if new_state != BotState.LOST:
            self._lost_logged = False   # rời LOST -> cho phép log lại lần sau
        self.state = new_state
        self._hb_ts = time.time()       # nhịp tim: đổi state = bot còn sống (watchdog)
        time.sleep(0.1)

    # ---------------------------------------------------------
    # STATE HANDLERS
    # ---------------------------------------------------------
    
    def _ensure_game_and_login(self):
        """TICK CỬA SỔ: nếu game CHƯA mở -> tự mở game; nếu đang ở màn login -> đăng nhập ACCOUNT ĐẦU của
        cửa sổ (account_queue[account_index]); chờ vào world. Game đã in_world rồi -> không làm gì.
        Chạy 1 LẦN lúc bootstrap (cờ _ensure_login_done)."""
        if getattr(self, '_ensure_login_done', False):
            return
        self._ensure_login_done = True
        try:
            self._load_account_queue()
            acc = None
            if self.account_queue and 0 <= self.account_index < len(self.account_queue):
                acc = self.account_queue[self.account_index]   # account ĐẦU (chưa done) của cửa sổ
            # 1) game chưa mở -> tự mở (KHÔNG force-stop)
            if not self.game_bot.is_game_running():
                self._chat("🎮 Game chưa mở → tự mở game...")
                self.game_bot.launch_game()
                time.sleep(12)   # chờ splash -> màn login
            # 2) attach Frida để đọc trạng thái login + bơm login
            if not self.game_bot.connect():
                return   # connect hụt -> bootstrap sẽ retry
            st = self.game_bot.get_login_state()
            if st == 'in_world':
                return   # đã vào game sẵn -> giữ nguyên
            # 3) đang ở màn login (hoặc unknown sau khi mới mở) -> login account đầu
            if acc:
                self._chat(f"🔑 Game ở màn login → đăng nhập account đầu của cửa sổ: {acc['acc']}...")
                self.game_bot.login(acc['acc'], acc['pass'])   # 'breakpoint' artifact OK; verdict = wait_in_world
                if self.game_bot.wait_in_world(timeout=90):
                    self._reinit_after_relogin()
                    nm = (self.game_bot.rpc.get_player_info() or {}).get('name') if self.game_bot_connected else '?'
                    self._chat(f"✅ Đã vào game account {acc['acc']} (nhân vật: {nm}).")
                else:
                    self._chat(f"⚠️ Login {acc['acc']} chưa vào được world (thử lại ở bootstrap).")
            else:
                self._chat("ℹ️ Game ở màn login nhưng cửa sổ CHƯA có account trong tab — dán account rồi bật lại.")
        except Exception as e:
            logger.error(f"[ensure_login] lỗi: {e}")

    def _handle_bootstrap(self):
        logger.info("[BOOTSTRAP] Khởi tạo kết nối Frida vào game...")
        self._chat("⏳ Đang kết nối Frida vào game (mất vài giây)...")
        # MỚI: tick cửa sổ mà game chưa mở/chưa login -> tự mở game + login account đầu của cửa sổ.
        self._ensure_game_and_login()
        if self.game_bot.connect():
            logger.info("[BOOTSTRAP] Kết nối Frida thành công!")
            diag = getattr(self.game_bot, 'connect_diag', '') or "Kết nối OK."
            self._chat(f"✅ Đã bắt được game. {diag}")
            self.game_bot.auto_keepalive()
            # Cửa sổ THỦ QUỸ -> KHÔNG làm Dã Tẩu, vào chế độ đứng yên thu đồ + cấp tiền.
            try:
                from core import treasurer as _T
                if _T.is_treasurer_device(self.device_id):
                    self._chat("💰 Cửa sổ THỦ QUỸ — đứng yên, chờ worker tới giao dịch.")
                    self._goto_state(BotState.TREASURER)
                    return
            except Exception as e:
                logger.error(f"[treasurer] check device lỗi: {e}")
            # Bắt đầu luồng chuẩn: IDLE_PRECHECK (Dùng THP về thành -> Tìm Dã Tẩu)
            self._goto_state(BotState.IDLE_PRECHECK)
        else:
            diag = getattr(self.game_bot, 'connect_diag', '') or "Không rõ lý do (xem cửa sổ console)."
            logger.warning(f"[BOOTSTRAP] Kết nối Frida thất bại: {diag}")
            self._chat(f"❌ KHÔNG bắt được nhân vật. {diag}")
            self._chat("   → Sẽ thử lại sau 5s. Kiểm tra: MEmu BẬT Root, game đã vào nhân vật.")
            time.sleep(5)
            # KHÔNG rơi vào chế độ ADB (sẽ click vật lý / dùng THP — không mong muốn). Thử attach lại.
            self._goto_state(BotState.BOOTSTRAP)
            
    def _handle_idle_precheck(self):
        logger.info("[IDLE_PRECHECK] Kiểm tra hành trang, bạc, Thổ địa phù...")
        
        logger.info("[IDLE_PRECHECK] Đồ đạc đầy đủ.")
        
        # TEST BỎ DI CHUYỂN VỀ THÀNH: Nếu có game_bot thì bỏ qua bước dùng THP, đứng im tại chỗ gọi Dã Tẩu!
        if not self.game_bot_connected and self.config.get("force_return_balanghuyen", True):
            logger.debug("Dùng THP (Click giả lập) về Ba Lăng Huyện...")
            if self._use_than_hanh_phu():
                if self._navigate_thp_to_city(self.config['preferred_city']):
                    logger.debug(f"Đang dịch chuyển về {self.config['preferred_city']}...")
                    if self._isleep(4): return
                else:
                    self._chat(f"Không tìm thấy {self.config['preferred_city']} trong menu THP.")
            else:
                logger.debug("Không dùng được THP, bỏ qua bước dịch chuyển về thành.")
                time.sleep(1.0)
        
        if self.current_quest and self.current_quest.is_valid:
            logger.info(f"[IDLE_PRECHECK] Đang có sẵn nhiệm vụ (cached): {self.current_quest}")
            self._goto_state(BotState.EVALUATE)
        else:
            # MỚI: ĐANG Ở ĐỘNG + đọc MEMORY thấy đã có NV đồ chí/mật chí -> CÀY TIẾP TẠI CHỖ, KHÔNG query Dã Tẩu.
            # Fix: tắt/bật Auto lúc nhân vật đang ở động giữa chừng cày -> trước đây mất current_quest -> chạy
            # MOVE_TO_DATAU/READ_QUEST gọi Dã Tẩu trong động -> loạt lỗi/lạc map. Ở THÀNH thì bỏ qua (flow cũ).
            if self.game_bot_connected and not self._in_town():
                dq = self._dochi_quest_from_memory()
                if dq:
                    self.current_quest = dq
                    self._chat(f"📍 Đang ở ĐỘNG + đã có NV (NV{dq.quest_number}: {dq.clean_text[:50]}) "
                               f"→ cày tiếp tại chỗ (KHÔNG gọi Dã Tẩu).")
                    self._resume_grind_in_dong()
                    return
            quest = None
            if not self.game_bot_connected:
                quest = self.quest_reader.read_current_quest()
            
            if quest and quest.is_valid:
                self.current_quest = quest
                logger.info(f"[IDLE_PRECHECK] Đang có sẵn nhiệm vụ: {quest}")
                self._goto_state(BotState.EVALUATE)
            else:
                logger.info("[IDLE_PRECHECK] Không có nhiệm vụ hiện tại.")
                self._goto_state(BotState.MOVE_TO_DATAU)

    def _chat(self, msg: str):
        logger.info(f"[CHAT] {msg}")
        self._hb_ts = time.time()   # nhịp tim: mỗi dòng log = bot còn nhúc nhích (watchdog dùng làm liveness chung)
        # KHÔNG ghi log hệ thống vào tracking nữa (chỉ hiển thị live). Tracking chỉ lưu sự kiện
        # nhận/trả NV + thưởng KHI THÀNH CÔNG (xem _on_quest_completed/_push_reward_to_ui).
        # Có UI -> đẩy qua hook hiển thị live. Không UI -> báo vào kênh chat game như cũ.
        if getattr(self, 'ui_log', None):
            try:
                self.ui_log(msg)
            except Exception:
                pass
        elif self.game_bot_connected:
            self.game_bot.chat(msg, channel=1)

    def _handle_move_to_datau(self):
        logger.info(f"[MOVE_TO_DATAU] Đang chạy tới Dã Tẩu tại {self.config['preferred_city']}")
        logger.debug(f"Đang chạy tới Dã Tẩu tại {self.config['preferred_city']} bằng Numpad...")
        
        # Đóng mọi bảng đang hiển thị trên màn hình trước khi bắt đầu
        self.npc_interact.dismiss_dialog()
        
        if self.game_bot_connected:
            logger.info("[MOVE_TO_DATAU] Bỏ qua di chuyển! Dùng Packet để giao tiếp từ xa.")
            self.read_quest_retries = 0
            self._goto_state(BotState.READ_QUEST)
        else:
            success = self.navigator.move_to_npc("Dã Tẩu", self.config['preferred_city'])
            if success:
                logger.info("[MOVE_TO_DATAU] Đã tới vị trí Dã Tẩu.")
                self.read_quest_retries = 0
                self._goto_state(BotState.READ_QUEST)
            else:
                logger.warning("[MOVE_TO_DATAU] Lỗi di chuyển (kẹt đường/timeout).")
            self.read_quest_retries += 1
            if self.read_quest_retries > 3:
                self.read_quest_retries = 0
                self._goto_state(BotState.LOST)
            else:
                time.sleep(2)
                self._goto_state(BotState.MOVE_TO_DATAU)

    def open_datau(self, _retry=True):
        """Mở hội thoại Dã Tẩu từ xa, ĐẢM BẢO chỉ tạo đúng 1 popup.

        - Nếu còn popup/GiveBox cũ đang mở (cờ _datau_dialog_open) -> đóng sạch trước.
        - Cache ID Dã Tẩu của thành hiện tại: chỉ gửi 1 talk_npc khi đã biết ID,
          tránh spam 716/714/396 sinh nhiều popup chồng lên nhau.
        - Xoá recv_buffer trước khi chờ để không bắt nhầm gói tin cũ.
        """
        if not self.game_bot_connected:
            # KHÔNG di chuyển/tap khi mất kết nối (tránh tap nhầm → teleport). Báo + đứng.
            self._chat("⚠️ Mất kết nối Frida — KHÔNG thao tác (tránh teleport). Bật lại Auto khi game ổn.")
            return []

        # LUÔN đóng DIALOG SERVER còn sót TRƯỚC khi gọi node mới (gửi eNpcSelect rỗng = báo server đóng đối thoại).
        # LÝ DO (bug "ngay sau trả NV → 13 node Dã Tẩu câm ~48s rồi mới được"): sau turn-in, server VẪN còn dialog
        # reward/GiveBox/Dã Tẩu MỞ (client đã .Close() nhưng SESSION server chưa đóng) → talk_npc mới BỊ TỪ CHỐI
        # (câm) tới khi dialog cũ tự timeout. Đóng nó NGAY → talk_npc kế được chấp nhận liền. (_datau_dialog_open
        # nhiều khi False sau turn-in nên dismiss-có-điều-kiện cũ KHÔNG chạy → đây là chỗ thiếu.)
        try:
            self.game_bot.send_gs('eNpcSelect')   # đóng dialog server bất kỳ đang mở
            # ĐIỂM NGHẼN CHUNG: trước đây sleep CỨNG 0.4s → nếu vừa MUA NPC/MUA SẠP/BÁN ĐỒ/RÚT TIỀN TRANG/GỘP ĐỒ
            # thì server CÒN BẬN xử lý dialog cũ → talk_npc kế bị TỪ CHỐI → "13 node Dã Tẩu câm ~40-70s" (chậm).
            # Thay bằng DRAIN tới khi server YÊN ~0.6s (tối đa 3s): dialog cũ đóng + ack rỗng xong RỒI mới gọi node
            # → trúng node đầu, KHỎI chờ. Bình thường (không có dialog tồn) chỉ tốn ~0.6s.
            quiet_t = time.time(); t0 = time.time()
            while time.time() - t0 < 3.0:
                if self.game_bot.poll_recv():
                    quiet_t = time.time()
                elif time.time() - quiet_t > 0.6:
                    break
                time.sleep(0.12)
        except Exception:
            pass
        self._datau_dialog_open = False

        # Xoá buffer cũ để chờ đúng gói tin phản hồi cho lần mở này
        if hasattr(self.game_bot, 'recv_buffer'):
            self.game_bot.recv_buffer = []
        self.game_bot.poll_recv()

        mid = None
        try:
            mid = (self.game_bot.rpc.get_player_info() or {}).get('mapId')
        except Exception:
            pass
        # REMOTE CALL Dã Tẩu bằng NODE CỐ ĐỊNH CỦA CÁC THÀNH (config datau_town_nodes.json) — server KHÔNG
        # check khoảng cách nên gọi node THÀNH từ XA (kể cả trong động) vẫn được. KHÔNG dùng node theo mapId
        # (động hay học nhầm NPC -> "tương tác linh tinh"). Node thành cố định -> gọi đâu cũng đúng Dã Tẩu.
        order = []
        # ƯU TIÊN node CỦA MAP HIỆN TẠI (last-success per map, đã verify) -> thử TRƯỚC -> NHANH ở MỌI thành
        # (không phải duyệt time-out 2.8s qua node của thành khác). Đây là vì sao Tương Dương nhanh còn
        # thành khác chậm: trước đây node TD ở đầu list, thành khác phải timeout hết rồi mới tới node đúng.
        try:
            pm_node = self._load_datau_nodes().get(str(mid))
            # ƯU TIÊN NODE-THEO-VÙNG: remote NPC-call hoạt động trong TOÀN VÙNG (verify sống 2026-06-12) → node
            # Dã Tẩu của THÀNH cùng vùng gọi 1 phát trúng từ động. Đáng tin hơn entry datau_nodes.json (có thể
            # SAI, vd map1 Phượng Tường từng map→1723 Biện Kinh vùng khác → retry 3×3.5s phí ~10s). Override.
            try:
                from core import map_region as _MR
                rnode = _MR.datau_node_for_map(mid)
                if rnode:
                    pm_node = str(rnode)
            except Exception:
                pass
            if pm_node:
                order.append(str(pm_node))
        except Exception:
            pass
        # node vừa HỌC khi người chơi KÍCH TAY (≤120s) -> ưu tiên (học node thành mới).
        try:
            nid = getattr(self.game_bot, 'last_npc_dialogue_id', None)
            nt = getattr(self.game_bot, 'last_npc_dialogue_t', 0)
            if nid and (time.time() - nt) <= 120:
                order.append(str(nid))
        except Exception:
            pass
        if self.datau_npc_id:
            order.append(self.datau_npc_id)   # node Dã Tẩu vừa dùng thành công gần đây (cache session)
        order += self._load_town_datau_nodes()  # DANH SÁCH NODE THÀNH CỐ ĐỊNH (config, đã xác nhận)
        order += list(self.TRUSTED_SEED)        # luôn có seed tin cậy ở cuối (kể cả khi config trống)

        # TIN CẬY = seed xác nhận + node config đã từng ĐÚNG. Node tin cậy: KHÔNG lọc blacklist, KHÔNG cần
        # keyword (bất kỳ dialog = Dã Tẩu). CHỈ node LẠ mới lọc blacklist + cần validate keyword.
        trusted = set(self.TRUSTED_SEED) | set(self._load_town_datau_nodes())
        bl = self._load_datau_node_blacklist()
        seen = set(); cand = []
        for n in order:
            if n and n not in seen and (n in trusted or n not in bl):
                seen.add(n); cand.append(n)

        logger.info(f"[open_datau] MAP ĐANG ĐỨNG={mid} | sẽ gọi {len(cand)} node Dã Tẩu: {cand} "
                    f"(tin cậy: {sorted(trusted & set(cand))}; loại blacklist node lạ: {sorted(bl - trusted)})")

        # NODE CỦA MAP ĐÃ VERIFY (datau_nodes.json[mid]) = node ĐÚNG cho thành này. Dưới tải nhiều cửa sổ,
        # Frida RPC + emulator chung host nghẽn -> phản hồi node về SAU 2.8s (flaky). Thấy rõ trong log: cùng
        # map 37, 1723 lúc trượt lúc trả "ĐÚNG Dã Tẩu" cách nhau 5s. -> THỬ LẠI CHÍNH NODE NÀY tối đa 3 lần
        # TRƯỚC khi quét mù 10 node (tránh phí 28s/pass chỉ vì node đúng flaky lần đầu).
        if pm_node and str(pm_node) in cand:
            for _t in range(3):
                if self._stopping(): return []
                if not self.game_bot_connected:
                    break
                self.game_bot.talk_npc(str(pm_node))
                pkts = self.game_bot.wait_for_packet(DATAU_DIALOG_OPS, timeout=2.5)
                if pkts and self._resp_is_datau(pkts):
                    logger.info(f"[open_datau] map{mid} node-của-map {pm_node} ĐÚNG Dã Tẩu (lần {_t+1}).")
                    self.datau_npc_id = str(pm_node)
                    self._save_datau_node(mid, str(pm_node))
                    self._save_town_datau_node(str(pm_node))
                    self._datau_dialog_open = True
                    self._reattach_count = 0   # đọc Dã Tẩu OK -> reset budget re-attach
                    return pkts
                if pkts:   # popup NPC khác -> đóng rồi thử lại node đúng
                    self.npc_interact.dismiss_dialog()
                    time.sleep(0.3)
            logger.info(f"[open_datau] map{mid} node-của-map {pm_node} chưa phản hồi sau 3 lần -> quét rộng.")

        # BẢN GỐC (ổn định mấy ngày): gọi MỖI node 1 LẦN, chờ 2.8s, KHÔNG retry, KHÔNG dismiss giữa chừng
        # (dismiss = eNpcSelect rỗng giữa các lần huỷ luôn dialog server vừa mở -> node câm). Chỉ dismiss khi
        # node trả về NPC KHÁC (có popup thật cần đóng).
        any_resp = False
        for npc_id in cand:
            if self._stopping(): return []
            is_trusted = npc_id in trusted
            self.game_bot.talk_npc(npc_id)
            pkts = self.game_bot.wait_for_packet(DATAU_DIALOG_OPS, timeout=2.2)
            is_dt = self._resp_is_datau(pkts) if pkts else False
            logger.info(f"[open_datau] map{mid} node {npc_id} (tin cậy={is_trusted}): "
                        f"{'KHÔNG phản hồi' if not pkts else ('CÓ phản hồi → ĐÚNG Dã Tẩu' if is_dt else 'CÓ phản hồi → NPC khác/chào')}")
            if pkts and is_dt:
                any_resp = True
                self.datau_npc_id = npc_id
                self._save_datau_node(mid, npc_id)
                self._save_town_datau_node(npc_id)   # move-to-front + đánh dấu confirmed
                self._datau_dialog_open = True
                self._reattach_count = 0   # đọc Dã Tẩu OK -> reset budget re-attach
                return pkts
            if pkts:
                # Có popup nhưng KHÔNG phải Dã Tẩu -> đóng nó (popup thật). node LẠ thì blacklist.
                if not is_trusted:
                    self._blacklist_datau_node(npc_id)
                    if self.datau_npc_id == npc_id:
                        self.datau_npc_id = None
                self.npc_interact.dismiss_dialog()
            # KHÔNG phản hồi -> sang node kế (KHÔNG dismiss: không có popup nào mở).
        if not any_resp:
            # ===== CHẨN ĐOÁN KĨ (vì sao thành khác câm) — phân biệt: kết nối/fd vs node sai =====
            try:
                st = self.game_bot.rpc.ping() or {}
                best = self.game_bot.rpc.pick_best_fd() or {}
                recvAny = st.get('recvAny'); recvTot = st.get('recvTotal')
                fdsSeen = st.get('fdsSeen', {}); curfd = st.get('gameFd')
                gameOps = best.get('gameOps', {})
                logger.info(f"[open_datau][CHẨN ĐOÁN] map={mid} đã thử nodes={cand} | gameFd={curfd} "
                            f"recvAny={recvAny} recvTotal={recvTot} fdsSeen={fdsSeen} "
                            f"fdCó-opcode-game={gameOps} pickBest={best.get('fd')}")
                if not recvAny:
                    self._chat(f"⚠️ [Map {mid}] Game KHÔNG nhận gói nào (server/kết nối chết) — không phải lỗi node.")
                elif not gameOps:
                    self._chat(f"⚠️ [Map {mid}] Có traffic nhưng KHÔNG fd nào parse được opcode game "
                               f"(data mã hoá/SSL?) — fd hiện {curfd}. Đây là vì sao thành khác câm.")
                elif best.get('fd') and best.get('fd') != curfd:
                    self._chat(f"⚠️ [Map {mid}] Đang đọc nhầm fd {curfd}; fd có gói game thật = {best.get('fd')}. Đổi fd...")
                else:
                    self._chat(f"⚠️ [Map {mid}] fd OK ({curfd}) nhưng {len(cand)} node Dã Tẩu không phản hồi "
                               f"→ có thể node thành này khác. Thử dò theo tên...")
            except Exception as e:
                logger.info(f"[open_datau] chẩn đoán lỗi: {e}")

            try:
                if self.game_bot_connected and _retry:
                    st = self.game_bot.rpc.ping() or {}
                    best = self.game_bot.rpc.pick_best_fd() or {}
                    curfd = st.get('gameFd'); bestfd = best.get('fd'); gameOps = best.get('gameOps', {})
                    # (0) recvAny=0 = chưa bắt được gói. Có thể chỉ là char ĐỨNG IM (benign) HOẶC hook recv chết
                    #     (re-attach lỗi / 2-session cùng PID). RE-ATTACH có CAP xuyên các vòng gọi: quá _REATTACH_CAP
                    #     lần mà vẫn câm -> PENDING (KHÔNG lặp vô tận). Đếm trên self -> bền qua nhiều lần state machine
                    #     gọi open_datau. Reset ở các điểm return-thành-công + resume().
                    if not st.get('recvAny'):
                        # Kết nối CÂM (recvAny=0). KHÔNG re-attach cùng PID nữa (hay câm tiếp — log đã chứng minh:
                        # detach+attach cùng PID = 'KHÔNG nhận gói', còn RELAUNCH game = 'Kết nối OK'). → RELAUNCH
                        # game + login lại account hiện tại (đường account-rotation). Có CAP để không relaunch vô tận.
                        self._reattach_count = int(getattr(self, '_reattach_count', 0)) + 1
                        if self._reattach_count > self._REATTACH_CAP:
                            self._need_help(
                                f"Relaunch {self._reattach_count - 1} lần mà game vẫn KHÔNG nhận gói "
                                f"(server/kết nối chết hoặc MEmu/MuMu lỗi). → Kiểm tra game rồi bấm ▶ Resume.")
                            return []
                        if self._recover_by_relaunch():
                            return self.open_datau(_retry=False)
                        return []   # _recover_by_relaunch đã PENDING nếu fail → KHÔNG loop
                    # (A) fd SAI thật (có fd khác mang opcode game) -> đổi fd theo BẰNG CHỨNG (KHÔNG dùng /proc mù).
                    if bestfd and bestfd != curfd and best.get('n', 0) > 0:
                        logger.info(f"[open_datau] fd sai {curfd}->{bestfd} (bằng chứng) -> đổi + thử lại.")
                        self.game_bot.redetect_fd_by_traffic()
                        self._chat("🔌 Đổi fd game theo traffic, gọi Dã Tẩu lại...")
                        time.sleep(0.5)
                        return self.open_datau(_retry=False)
                    # (B) ❌ KHÔNG quét NPC gần (getNearNpcsSafe gc.choose = ĐƠ game). Đã ping HẾT node Dã Tẩu
                    #     đã biết ở trên (kể cả từ động — server không check k/c). Vẫn câm -> báo, KHÔNG quét.
                    else:
                        self._chat(f"⚠️ [Map {mid}] Đã thử {len(cand)} node Dã Tẩu đã biết, không node nào phản hồi. "
                                   f"(Map lạ/kết nối? Đưa về thành hoặc click tay 1 lần vào Dã Tẩu để học node.)")
            except Exception as e:
                logger.info(f"[open_datau] xử lý câm lỗi: {e}")

        if self.datau_npc_id and _retry:
            logger.info("[open_datau] node cache sai, dò lại toàn bộ.")
            self.datau_npc_id = None
            return self.open_datau(_retry=False)
        self.npc_interact.dismiss_dialog()
        self._datau_dialog_open = False
        return []

    def _suppress_datau(self, ms=6000):
        """Bật ẩn dialog Dã Tẩu trong `ms` ms tới (chỉ lúc bot thao tác DT). Lỗi thì bỏ qua."""
        try:
            if self.game_bot_connected:
                self.game_bot.rpc.suppress_datau_dialog(ms)
        except Exception:
            pass

    def _discover_datau_candidates(self):
        """Lấy DANH SÁCH id NPC gần (qua getNearNpcsSafe — bridge an toàn) để thử tìm Dã Tẩu ở MỌI thành.
        NpcRes.Normal không lưu tên trực tiếp (chỉ npcDeclareLine) nên tên hay rỗng -> trả HẾT id gần,
        node nào có tên khớp 'Dã Tẩu' xếp trước. open_datau sẽ thử từng id + kiểm phản hồi là Dã Tẩu."""
        try:
            res = self.game_bot.rpc.get_near_npcs_safe()
        except Exception as e:
            logger.info(f"[open_datau] getNearNpcsSafe lỗi: {e}")
            return []
        if not res or not res.get("ok"):
            logger.info(f"[open_datau] getNearNpcsSafe fail: {res.get('error') if res else 'no res'}")
            return []
        npcs = res.get("npcs", [])
        diag = res.get("diag", {})
        sample = [(n.get("id"), n.get("name")) for n in npcs[:12]]
        logger.info(f"[open_datau] NearNpcs={len(npcs)} fields={diag.get('fields')} mẫu={sample}")
        named, rest = [], []
        for n in npcs:
            nid = str(n.get("id") or "").strip()
            if not nid:
                continue
            nm = (n.get("name") or "").lower()
            (named if any(k in nm for k in ("dã tẩu", "da tau", "tẩu", "lão tẩu")) else rest).append(nid)
        return named + rest   # tên-khớp trước, rồi tất cả id gần

    @staticmethod
    def _resp_is_datau(pkts):
        """Phản hồi có PHẢI Dã Tẩu? (lọc NPC khác cũng trả dialog). Dấu hiệu: 'nhiệm vụ'/'khảo nghiệm'/
        'tẩu' trong text, hoặc có quest_number, hoặc nút Dã Tẩu."""
        if not pkts:
            return False
        try:
            from core.quest import parse_quest_dialog
            for p in pkts:
                try:
                    q = parse_quest_dialog(bytes.fromhex(p['hex'])[6:], opcode=p.get('opcode', 124))
                except Exception:
                    continue
                if not q:
                    continue
                txt = ((getattr(q, 'clean_text', '') or '') + ' ' + (getattr(q, 'raw_text', '') or '')).lower()
                if getattr(q, 'quest_number', 0):
                    return True
                if any(k in txt for k in ("nhiệm vụ", "khảo nghiệm", "dã tẩu", "lão tẩu", "tiếp nhận", "hoàn thành")):
                    return True
            # FALLBACK: decode RAW bytes mỗi gói (pkts ĐÃ lọc sẵn = dialog-ops, KHÔNG có chat op133 → an toàn).
            # parse_quest_dialog có khi KHÔNG parse được op34 'Nhiệm vụ thứ N. Hãy giúp ta…' (Dã Tẩu thành như Đại
            # Lý chào kiểu này, KHÔNG có 'thiếu hiệp') → trước bị MISS → tưởng vùng chưa có node. Bắt thẳng keyword.
            for p in pkts:
                try:
                    raw = bytes.fromhex(p['hex'])[6:].decode('utf-8', 'ignore').lower()
                except Exception:
                    continue
                if any(k in raw for k in ("nhiệm vụ", "khảo nghiệm", "dã tẩu", "lão tẩu", "hãy giúp", "hoàn thành nv")):
                    return True
        except Exception:
            pass
        return False

    TOWN_NODES_PATH = "data/output/datau_town_nodes.json"
    # Node Dã Tẩu ĐÃ XÁC NHẬN (memory: 714=Tương Dương, 716=Ba Lăng, 396=khác). Remote không check khoảng
    # cách -> các node này gọi TỪ ĐÂU CŨNG mở Dã Tẩu. TUYỆT ĐỐI không blacklist (tránh loại nhầm do lossy).
    TRUSTED_SEED = ("714", "716", "396")

    # CAP re-attach Frida khi gọi Dã Tẩu câm: open_datau re-attach 1 lần/call, nhưng state machine gọi mỗi
    # vòng -> nếu cứ câm sẽ re-attach VÔ TẬN. Đếm xuyên các lần gọi (self._reattach_count), quá CAP -> PENDING
    # (không lặp). Reset khi đọc Dã Tẩu thành công + lúc resume().
    _REATTACH_CAP = 2

    def _load_town_datau_nodes(self):
        """Danh sách node Dã Tẩu CỐ ĐỊNH của các THÀNH (config) — remote call từ đâu cũng được.
        KHÔNG theo mapId (động học nhầm). Seed cứng + gộp config (tự lớn dần khi học node thành mới)."""
        import json
        # VERIFIED 2026-06-07 (remote OK): map1 PhượngTường=588, map11 ThànhĐô=1049, map37 BiệnKinh=1723,
        # map78 TươngDương=1425, map80 DươngChâu=1192. 588+1723 từng bị THIẾU -> BK/PhượngTường câm.
        seed = ["1425", "1723", "588", "1049", "1192", "396", "714", "716", "3447", "8746"]
        try:
            cfg = json.load(open(self.TOWN_NODES_PATH, encoding="utf-8"))
            lst = [str(x) for x in (cfg.get("town_datau_nodes") or [])]
            # giữ thứ tự: config trước, seed bổ sung sau (dedup)
            out, s = [], set()
            for n in (lst + seed):
                if n and n not in s:
                    s.add(n); out.append(n)
            return out
        except Exception:
            return seed

    def _read_town_cfg(self):
        import json
        try:
            return json.load(open(self.TOWN_NODES_PATH, encoding="utf-8"))
        except Exception:
            return {"town_datau_nodes": [], "npc_khac_nodes": []}

    def _write_town_cfg(self, cfg):
        try:
            with _SHARED_FILE_LOCK:
                _atomic_write_json(self.TOWN_NODES_PATH, cfg)
        except Exception:
            pass

    def _save_town_datau_node(self, node):
        """Node Dã Tẩu THÀNH vừa verify ĐÚNG -> ĐẨY LÊN ĐẦU config (most-recently-good first) để vòng
        quét sau thử node ĐÃ CHỨNG MINH trước, bớt timeout 7 node trên kết nối lossy; gỡ khỏi blacklist."""
        if not node:
            return
        node = str(node)
        with _SHARED_FILE_LOCK:   # read-modify-write atomic (nhiều device học node cùng lúc)
            cfg = self._read_town_cfg()
            lst = [str(x) for x in (cfg.get("town_datau_nodes") or [])]
            bl = [str(x) for x in (cfg.get("npc_khac_nodes") or [])]
            # move-to-front: gỡ ra rồi chèn đầu (nếu đã ở đầu thì không ghi lại để đỡ I/O).
            if lst and lst[0] == node and node not in bl:
                return
            if node in lst:
                lst.remove(node)
            lst.insert(0, node)
            if node in bl:
                bl.remove(node)   # đã verify ĐÚNG -> bỏ khỏi blacklist
            cfg["town_datau_nodes"] = lst; cfg["npc_khac_nodes"] = bl
            self._write_town_cfg(cfg)

    def _load_datau_node_blacklist(self):
        """Set node ĐÃ XÁC ĐỊNH là NPC KHÁC (không phải Dã Tẩu) -> không gọi lại."""
        return set(str(x) for x in (self._read_town_cfg().get("npc_khac_nodes") or []))

    def _blacklist_datau_node(self, node):
        """Ghi node là NPC KHÁC (loại khỏi danh sách gọi Dã Tẩu) — hết gọi linh tinh.
        KHÔNG bao giờ blacklist node TIN CẬY (seed Dã Tẩu xác nhận) — tránh loại nhầm do gói lossy dở dang."""
        if not node:
            return
        if str(node) in self.TRUSTED_SEED:
            logger.info(f"[open_datau] node {node} thuộc TRUSTED_SEED -> KHÔNG blacklist (bỏ qua).")
            return
        with _SHARED_FILE_LOCK:   # read-modify-write atomic
            cfg = self._read_town_cfg()
            bl = [str(x) for x in (cfg.get("npc_khac_nodes") or [])]
            lst = [str(x) for x in (cfg.get("town_datau_nodes") or [])]
            if str(node) in bl:
                return
            bl.append(str(node))
            if str(node) in lst:
                lst.remove(str(node))   # gỡ khỏi danh sách Dã Tẩu nếu lỡ có
            cfg["npc_khac_nodes"] = bl; cfg["town_datau_nodes"] = lst
            self._write_town_cfg(cfg)
        logger.info(f"[open_datau] node {node} = NPC khác -> thêm blacklist (không gọi lại).")

    def _load_datau_nodes(self):
        import json
        # seed map->node ĐÃ VERIFY: PhượngTường1=588, ThànhĐô11=1049, BiệnKinh37=1723, TươngDương78=1425, DươngChâu80=1192
        nodes = {"1": "588", "11": "1049", "37": "1723", "78": "1425", "80": "1192", "176": "3447"}
        try:
            d = json.load(open("data/output/datau_nodes.json", encoding="utf-8"))
            nodes.update({str(k): str(v) for k, v in (d or {}).items()})
        except Exception:
            pass
        return nodes

    def _save_datau_node(self, mid, node):
        if not mid:
            return
        import json
        # READ-MODIFY-WRITE atomic dưới lock (nhiều device có thể học node cùng lúc -> đừng ghi đè/rách JSON).
        try:
            with _SHARED_FILE_LOCK:
                d = {}
                try:
                    d = json.load(open("data/output/datau_nodes.json", encoding="utf-8"))
                except Exception:
                    pass
                if d.get(str(mid)) == str(node):
                    return
                d[str(mid)] = str(node)
                _atomic_write_json("data/output/datau_nodes.json", d)
        except Exception:
            pass

    def _looks_like_datau(self, pkts):
        """Xác thực dialog ĐÚNG là Dã Tẩu bằng marker chắc chắn (có trong Dã Tẩu, KHÔNG có ở
        dialog THP/NPC lạ kiểu 'Thần Hành Thuật'/'Lời thề năm xưa')."""
        MARK = ('nhiệm vụ', 'thiếu hiệp', 'dã tẩu', 'tiếp nhận', 'giao nhiệm', 'hủy nv')
        for p in pkts or []:
            try:
                txt = bytes.fromhex(p['hex'])[6:].decode('utf-8', 'ignore').lower()
                if any(k in txt for k in MARK):
                    return True
                logger.info(f"[open_datau] dialog BỊ TỪ CHỐI (không phải Dã Tẩu?): {txt[:90]!r}")
            except Exception:
                pass
        return False

    # ---------------------------------------------------------
    # PACKET ACTIONS Dã Tẩu (verified sniff 2026-06, KHÔNG tap, KHÔNG cần nodeId nút)
    #   Tiếp nhận = eNpcSelect() rỗng | Hủy = eNpcSelect(1)+submenu | Nộp = eNpcSelect()+GiveBox
    # ---------------------------------------------------------
    def _select_pkt(self, index=None, wait=0.45):
        """Gửi eNpcSelect. index=None -> rỗng (nút chính/index0/advance); index=N -> chọn option N."""
        if not self.game_bot_connected:
            return
        if index is None:
            self.game_bot.send_gs('eNpcSelect')
        else:
            self.game_bot.send_gs('eNpcSelect', selectIndex=index)
        time.sleep(wait)

    def _clear_popups(self, where=""):
        """ĐÓNG SẠCH popup Dã Tẩu client bằng invoke .Close() của chính client (không tap ESC, đóng được
        TẤT CẢ popup chồng). Log số popup đã đóng để soi. Gọi SAU khi đã gửi gói (server xử lý xong)."""
        if not self.game_bot_connected:
            return
        # 🎁 LƯỚI AN TOÀN CHỐNG MẤT THƯỞNG: nếu có bảng thưởng 245 đang chờ thì NHẬN NÓ TRƯỚC khi đóng popup.
        #    (Mọi nơi gọi _clear_popups đều qua đây → không còn chỗ nào đóng nhầm AwardSelection chưa nhận.)
        #    dochi=False: chỉ nhặt thưởng, không đụng bookkeeping NV (các flow gọi nó tự lo việc của mình).
        try:
            self._claim_award_if_present(dochi=False)
        except Exception:
            pass
        try:
            closed = self.game_bot.close_datau_popups()
        except Exception as e:
            logger.info(f"[popup] close lỗi: {e}")
            closed = None
        if closed:
            tot = sum(closed.values())
            # CHỈ ghi FILE-LOG (logger), KHÔNG đẩy lên panel UI (_chat) — log đóng popup quá nhiều gây rối panel.
            logger.info(f"[popup] Đóng {tot} popup{(' ' + where) if where else ''}: " +
                        ", ".join(f"{k}×{v}" for k, v in closed.items()))
        self._datau_dialog_open = False

    def _datau_accept(self):
        """Nhận nhiệm vụ bằng PACKET: đã mở Dã Tẩu rồi -> eNpcSelect() rỗng (nút 'Tiếp nhận'). Xong -> đóng popup."""
        self._select_pkt()
        self._clear_popups("sau khi nhận NV")
        self._stack_bag_items()   # xếp chồng/gộp đồ tiết kiệm ô (sau mỗi lần nhận NV)

    def _stack_bag_items(self):
        """Gộp/xếp chồng đồ túi cùng loại bằng PACKET `eItemJoin` (op209) — server gộp stack cùng loại, KHÔNG
        cần mở bảng túi. (verify gói live 2026-06-11: click gộp = eItemJoin{itemIndex} -> server trả op27 remove
        + op16 sync.) CHỈ gộp đồ STACKABLE (genre 6 = thuốc/Thiết La Hán/Tống Kim...; BỎ QUA trang bị có attribs
        để không đụng gear). AN TOÀN (đồ cùng loại). Gọi sau mỗi lần nhận NV."""
        if not self.game_bot_connected:
            return
        try:
            from collections import defaultdict
            dump = self.game_bot.dump_bag_items() or {}
            items = [it for it in dump.get('items', []) if it.get('location') == 2]
            groups = defaultdict(list)
            for it in items:
                # CHỈ đồ stackable: genre 6 (consumable/magicscript/Tống Kim) + KHÔNG có attribs (gear có attribs).
                if it.get('genre') != 6 or it.get('attribs'):
                    continue
                groups[(it.get('genre'), it.get('detail'), it.get('particular'))].append(it)
            merged = 0
            for sig, lst in groups.items():
                if len(lst) < 2:
                    continue   # 1 stack -> khỏi gộp
                for it in lst:
                    idx = it.get('index')
                    if idx is None:
                        continue
                    try:
                        self.game_bot.send_gs('eItemJoin', itemIndex=int(idx))
                        merged += 1
                        time.sleep(0.25)
                    except Exception:
                        pass
                    if merged >= 40:   # chốt an toàn, tránh spam
                        break
                if merged >= 40:
                    break
            if merged:
                self._chat(f"🧱 Gộp đồ cùng loại (eItemJoin ×{merged}) — tiết kiệm ô túi.")
                # DRAIN ack gộp đồ (server trả op27 remove + op16 sync cho TỪNG eItemJoin): nếu để dở mà mở Dã Tẩu
                # ngay -> server đang bận xử lý merge -> NPC dialog bị câm ~30-60s ("13 node câm" oan). Hút sạch
                # gói trả tới khi YÊN ~1s (tối đa ~5s) => server đã xử lý xong => bước nộp NV mở Dã Tẩu TRÚNG NGAY,
                # KHÔNG phải chờ. (tối ưu time theo yêu cầu user — biến nó thành flow nộp bình thường.)
                quiet_t = time.time()
                t0 = time.time()
                while time.time() - t0 < 5.0:
                    got = self.game_bot.poll_recv() or []
                    if got:
                        quiet_t = time.time()       # còn gói -> reset mốc yên
                    elif time.time() - quiet_t > 1.0:
                        break                        # yên >1s -> server xong
                    time.sleep(0.15)
        except Exception as e:
            logger.info(f"[STACK] lỗi: {e}")

    def _datau_complete(self, item_slot):
        """Hoàn thành/nộp đồ. Trả True CHỈ KHI server xác nhận (bắt 245 sau khi nộp).
        Mở GiveBox theo HYBRID: thử eNpcSelect() (packet) trước; không mở được thì TAP nút 'Hoàn thành'
        (cách hôm qua, đã chứng minh mướt). Rồi eGiveBoxSend(_key) -> eGiveBoxConfirm -> chờ 245."""
        # CHỐNG RƯƠNG ĐẦY (điểm nộp CHUNG cho mọi NV: tìm/nộp đồ + mua NPC): nếu túi gần đầy -> bán đồ rác +
        # cất kho TRƯỚC (giữ món cần nộp). Bán mở shop dialog -> dismiss_dialog + xoá buffer NGAY DƯỚI sẽ dọn sạch.
        self._prep_bag_before_turnin(item_slot)
        # STEP TRƯỚC (mua shop/sạp) để lại 1 ĐỐNG gói (eSyncPlayerItem...) trong recv_buffer + UI mở ->
        # open_datau sau đó dễ khớp/nuốt nhầm gói cũ rồi báo "node không phản hồi" dù đang ở thành.
        # DỌN SẠCH (an toàn, không gửi gói suy đoán): đóng UI client + xoá buffer + nghỉ ngắn để step mua
        # KẾT THÚC hẳn rồi mới mở Dã Tẩu — không chồng chéo step.
        self.npc_interact.dismiss_dialog()
        if hasattr(self.game_bot, 'recv_buffer'):
            self.game_bot.recv_buffer = []
        time.sleep(0.6)   # giảm 1.2->0.6: tăng tốc (vẫn đủ để step mua kết thúc + UI đóng)
        from core.equip_matcher import split_frames
        # eNpcSelect() rỗng = nút 'Đã hoàn thành' -> server đẩy 126 (eGiveBoxOpen). Server HAY GỘP 126
        # CHUNG gói với 124 -> wait_for_packet(126) bỏ sót (opcode top-level=124) = lỗi lúc được lúc không.
        # PHẢI split_frames bắt 126 cả trong bundle.
        def _givebox_opened(secs=2.0):
            t0 = time.time()
            while time.time() - t0 < secs:
                for p in (self.game_bot.poll_recv() or []):
                    subs = split_frames(p.get('hex', '')) or [(p.get('opcode'), '')]
                    if any(op == 126 for op, _ in subs):
                        return True
                time.sleep(0.1)
            return False
        # RETRY mở Dã Tẩu/GiveBox khi CÂM TẠM: vừa gộp đồ (eItemJoin)/bán/đổi map → server còn giữ dialog cũ
        # ~30-48s → open_datau dò 13 node đều câm rồi đổ oan "node lạ/map lạ" dù char ĐỨNG YÊN Ở THÀNH. Đây KHÔNG
        # phải node sai (như flow đồ-chí đã xử) → retry vài lần có chờ, đừng fail ngay. (bug user 16:10 NV "trả lại")
        opened = False
        n_before = None                 # 'còn N nhiệm vụ' TRƯỚC khi nộp (bảng Dã Tẩu) — so sau nộp để biết NV xong
        for _try in range(4):           # ~4 lần × (open_datau + 3×GiveBox + chờ) ≈ tối đa ~60s
            if not self.game_bot_connected or self._stopping():
                break
            _board = self.open_datau()
            if n_before is None:
                n_before = self._parse_remaining_quests(_board)
            for _ in range(3):
                if self._stopping(): break
                self._select_pkt()
                if _givebox_opened(2.0):
                    opened = True
                    break
            if opened:
                break
            if _try < 3:
                self._chat(f"⏳ Dã Tẩu/GiveBox chưa mở (câm tạm sau gộp/bán đồ?) — thử lại {_try+1}/4 sau 12s…")
                if self._isleep(12):
                    return False
        if not opened:
            self._chat("Không mở được ô nộp đồ (GiveBox) sau ~60s retry. NV chưa đủ điều kiện / Dã Tẩu câm lâu?")
            self.npc_interact.dismiss_dialog()
            self._datau_dialog_open = False
            return False
        ok = False
        seen = []; frames = []
        if self.game_bot_connected and item_slot is not None and item_slot >= 0:
            self._chat(f"Nộp đồ: eGiveBoxSend(itemId={item_slot}) + Confirm...")
            if hasattr(self.game_bot, 'recv_buffer'):
                self.game_bot.recv_buffer = []   # xoá buffer để bắt ĐÚNG gói server trả cho lần nộp này
            self.game_bot.send_gs('eGiveBoxSend', itemId=str(item_slot))
            time.sleep(0.5)
            self.game_bot.send_gs('eGiveBoxConfirm')

            # === BẮT GÓI server TRẢ sau Confirm -> tìm kết quả pass/fail+thưởng. BREAK NGAY khi có 245 (thành
            #     công) thay vì chờ cứng 3s -> tăng tốc; vẫn chờ tối đa 3s nếu chưa thấy. ===
            seen = []
            t0 = time.time()
            while time.time() - t0 < 3.0:
                if self._stopping(): break
                got245 = False
                for p in (self.game_bot.poll_recv() or []):
                    op = p.get('opcode'); nm = p.get('name', '')
                    seen.append((op, nm, p.get('hex', '')))
                    for sop, _h in (split_frames(p.get('hex', '')) or [(op, '')]):
                        if sop == 245:
                            got245 = True
                if got245:
                    break   # đã có bảng thưởng 245 = nộp THÀNH CÔNG -> khỏi chờ hết 3s
                time.sleep(0.1)
            # Server hay GỘP nhiều gói trong 1 lần recv (vd 124+245 dính nhau) -> tách frame con.
            from core.equip_matcher import split_frames
            frames = []   # (op, frame_hex) đã tách phẳng từ MỌI buffer
            for op, nm, hx in seen:
                sub = split_frames(hx)
                frames.extend(sub if sub else [(op, hx)])
            if seen:
                # (Không chat danh sách opcode thô lên UI — nhiễu; chỉ ghi log file để debug.)
                logger.info(f"[REWARD] post-confirm frames: {[(op, hx) for op, hx in frames]}")
                try:
                    with open(f"data/output/turnin_response_dump_{self.device_id.replace(':','_')}.txt", "a", encoding="utf-8") as f:
                        f.write(f"--- qno={self.last_quest_number} slot={item_slot} ---\n")
                        for op, nm, hx in seen:
                            f.write(f"{nm or ''}({op}) {hx}\n")
                except Exception:
                    pass
        # === XÁC ĐỊNH KẾT QUẢ (THẬT): gói 245 (eAwardSelectionAsk) = server ĐÃ NHẬN NV = THÀNH CÔNG. ===
        # 245 là tín hiệu authoritative. NHIỀU NV ('...xem xong ta sẽ trả lại ngươi') server GIỮ rồi TRẢ LẠI
        # đồ -> món VẪN CÒN túi -> "món còn túi" KHÔNG phải dấu hiệu thất bại. Chỉ KHÔNG có 245 mới là chưa nộp.
        award_hex = next((hx for op, hx in frames if op == 245), None)
        if award_hex:
            ok = True
            logger.info("[ĐỒ CHÍ] Server xác nhận 245 -> NỘP OK.")
            try:
                self._select_reward(prefetched_hex=award_hex)
            except Exception as e:
                logger.error(f"[REWARD] chọn thưởng lỗi: {e}")
        else:
            ok = False
            # === BẢNG NHIỆM VỤ = CHÂN LÝ khi MẤT 245 (flood thành đông) ===
            # 245 hay rớt → trước đây kết luận FAIL oan. Đọc lại bảng Dã Tẩu: 'còn N nhiệm vụ' GIẢM so với
            # n_before = NV ĐÃ HOÀN THÀNH (server nhận) → coi THÀNH CÔNG, KHÔNG PENDING oan. Nếu lần đọc lại
            # CÓ kèm 245 (auto-complete trễ) thì nhận thưởng luôn.
            # ⚠️ KHÔNG re-open Dã Tẩu ở đây: vừa mua NPC/GiveBox xong, server CÒN GIỮ dialog shop/GiveBox →
            #    open_datau bị câm, quét 13 node mất ~40s ("node không phản hồi"). Chỉ đọc 'còn N' từ gói
            #    post-confirm ĐÃ CÓ, và xác minh nộp bằng MÓN ĐÃ RỜI TÚI (đáng tin, khỏi mở lại Dã Tẩu).
            n_after = self._parse_remaining_quests(frames)
            item_gone = None
            try:
                dump = self.game_bot.dump_bag_items()
                if dump and dump.get("ok"):
                    item_gone = not any(it.get("slot") == item_slot for it in dump.get("items", []))
            except Exception:
                pass
            if n_before is not None and n_after is not None and n_after < n_before:
                ok = True
                logger.info(f"[ĐỒ CHÍ] KHÔNG bắt 245 nhưng bảng NV 'còn {n_before}→{n_after}' GIẢM → NV ĐÃ NỘP (thành công).")
                self._chat(f"✅ Nộp đồ OK (bảng NV {n_before}→{n_after} giảm; gói 245 rớt do thành đông).")
            elif item_gone:
                ok = True
                logger.info("[ĐỒ CHÍ] KHÔNG bắt 245 nhưng MÓN ĐÃ RỜI TÚI → server đã nhận = NỘP OK (thưởng tự trao).")
                self._chat("✅ Nộp đồ OK (món đã rời túi; gói 245 rớt — bỏ qua, KHÔNG mở lại Dã Tẩu để khỏi câm).")
            else:
                self._chat(f"Chưa thấy 245; bảng NV {n_before}→{n_after}; món {'đã rời' if item_gone else 'còn'} túi "
                           f"→ CHƯA xác nhận nộp (tham khảo).")
        self.npc_interact.dismiss_dialog()
        self._datau_dialog_open = False
        return ok

    def _datau_cancel(self, do_chi=False):
        """Hủy nhiệm vụ bằng PACKET (verified):
           'Ta muốn hủy' = eNpcSelect(1) -> submenu:
              Hủy 100 đồ chí = eNpcSelect() rỗng (index0); Hủy thường = eNpcSelect(1) (index1)
           rồi eNpcSelect() xác nhận."""
        self.open_datau()
        self._select_pkt(1)               # 'Ta muốn hủy nv' -> mở submenu
        if do_chi:
            self._select_pkt()            # Hủy 100 đồ chí = index 0 (rỗng)
        else:
            self._select_pkt(1)           # Hủy thường = index 1
        self._select_pkt()                # xác nhận
        self.npc_interact.dismiss_dialog()
        self._datau_dialog_open = False

    def _datau_quest_still_active(self, qno):
        """Mở Dã Tẩu đọc NV hiện tại — True nếu VẪN là NV #qno (tức hủy CHƯA thành: thiếu tấm). False nếu NV đã
        đổi/biến mất (hủy OK). Dùng để phân biệt 'hủy được' vs 'thiếu 100 tấm → pending'."""
        from core.quest import parse_quest_dialog
        try:
            pkts = self.open_datau() or []
        except Exception:
            return False
        for p in pkts:
            try:
                q = parse_quest_dialog(bytes.fromhex(p['hex'])[6:], opcode=p.get('opcode', 124))
                if q and getattr(q, 'quest_number', 0) == qno:
                    return True
            except Exception:
                continue
        return False

    def _cancel_dochi_or_pending(self, what=""):
        """Thư viện KHÔNG có đồ → mặc định HỦY NV bằng 100 tấm đồ chí. Sau khi hủy, kiểm lại Dã Tẩu: NV CÒN
        (cùng quest_number) = KHÔNG đủ 100 tấm → PENDING + log cho người chơi xử lý. NV đã đổi = hủy OK."""
        qno = getattr(self.current_quest, 'quest_number', 0) or self.last_quest_number or 0
        self._chat(f"📚 Thư viện không có {what} → hủy NV bằng 100 tấm đồ chí…")
        self._cancel_do_chi = True
        try:
            self._datau_cancel(do_chi=True)
        except Exception as e:
            logger.error(f"[FIND] hủy 100 đồ chí lỗi: {e}")
        if self._isleep(2):
            return
        if self._datau_quest_still_active(qno):
            # NV còn nguyên = hủy không thành → gần như chắc THIẾU 100 tấm đồ chí.
            self._cancel_do_chi = False
            self._need_help(f"KHÔNG đủ 100 tấm đồ chí để hủy NV tìm đồ {what} (NV #{qno}). "
                            f"Đứng chờ — bạn xử lý tay (mua giúp / đổi cấu hình nhóm 'Tìm đồ').")
            self._goto_state(BotState.TRAINING)
            return
        # Hủy thành công.
        self._cancel_do_chi = False
        if qno and qno != getattr(self, "_last_cancelled_qno", None):
            self._last_cancelled_qno = qno
            try:
                tracker.record(self.device_id, "quest_cancelled", char=self.player_name,
                               qno=qno, mode="Hủy 100 đồ chí (thư viện trống)")
            except Exception:
                pass
        self._chat(f"✅ Đã hủy NV #{qno} bằng 100 tấm đồ chí (thư viện không có {what}).")
        self.current_quest = None
        self._goto_state(BotState.IDLE_PRECHECK)

    def _handle_read_quest(self):
        # Log RÕ map hiện tại để biết chắc nhân vật đang ở đâu (thành có Dã Tẩu hay đang lạc ở động/field).
        if self.read_quest_retries == 0:
            try:
                mid = (self.game_bot.rpc.get_player_info() or {}).get('mapId')
                from database.db_manager import db as _db
                mname = _db.get_map_name(mid) if mid else "?"
                self._chat(f"📍 Đang ở: {mname} (Map {mid}). Gọi Dã Tẩu...")
            except Exception:
                self._chat("Đang trò chuyện với Dã Tẩu...")
        # Mở Dã Tẩu qua 1 cổng duy nhất (open_datau): gửi packet từ xa, có guard chống popup chồng
        pkts = self.open_datau()
        
        quest = None
        if pkts:
            from core.quest import parse_quest_dialog
            # Khi mở Dã Tẩu, server có thể gửi NHIỀU gói (lời chào + chi tiết NV). Lấy gói GIÀU
            # thông tin nhất (có 'Nhiệm vụ thứ N' / tên đồ) thay vì gói cuối (thường là lời chào).
            best, best_score, best_op = None, -1, 124
            for p in pkts:
                try:
                    body = bytes.fromhex(p['hex'])[6:]
                    op = p.get('opcode', 124)
                    q = parse_quest_dialog(body, opcode=op)
                except Exception as e:
                    logger.error(f"[READ_QUEST] parse err: {e}")
                    continue
                if not q:
                    continue
                score = (2 if getattr(q, 'quest_number', 0) else 0) \
                        + (1 if getattr(q, 'item_name', '') else 0) \
                        + (1 if q.buttons else 0)
                if score > best_score:
                    best, best_score, best_op = q, score, op
            quest = best
            if quest is not None:
                self._lost_recall_tries = 0   # đọc được NV = char ở Dã Tẩu ổn -> reset đếm về-thành
                self.last_dialog_opcode = 166 if best_op == 166 else 34
                if quest.opcode in (124, 126) and not quest.buttons:
                    quest.buttons = ["Đã hoàn thành nv", "Ta muốn hủy nv", "Biết rồi!"]
                logger.info(f"[READ_QUEST] Best quest: num={getattr(quest,'quest_number',0)} item={quest.item_name!r} text={quest.clean_text[:60]!r}")
                
        if not quest or (not quest.is_valid and not quest.buttons):
            self.read_quest_retries += 1
            if self.read_quest_retries > 6:   # kiên nhẫn hơn (kết nối lossy + chờ redetect fd)
                mid = None
                try:
                    mid = (self.game_bot.rpc.get_player_info() or {}).get('mapId')
                except Exception:
                    pass
                try:
                    from database.db_manager import db as _db
                    mname = _db.get_map_name(mid) if mid else "?"
                except Exception:
                    mname = "?"
                # MAP LẠ / KHÔNG PHẢI THÀNH (vd Map_995): không có Dã Tẩu ở đây -> TỰ VỀ THÀNH rồi thử lại,
                # ĐỪNG PENDING oan. Chỉ pause khi đã ở thành mà vẫn câm, HOẶC về thành cũng fail. (KHÔNG tự hủy NV.)
                if not self._in_town() and getattr(self, '_lost_recall_tries', 0) < 2:
                    self._lost_recall_tries = getattr(self, '_lost_recall_tries', 0) + 1
                    self._chat(f"📍 Ở map lạ ({mname}/Map {mid}) không có Dã Tẩu → tự VỀ THÀNH thử lại "
                               f"(lần {self._lost_recall_tries}/2).")
                    self.npc_interact.dismiss_dialog()
                    self.read_quest_retries = 0
                    if self._recall_to_town():
                        if self._isleep(6): return
                        self._goto_state(BotState.READ_QUEST)
                        return
                    # về thành cũng fail -> rơi xuống PENDING bên dưới
                self._chat(f"❌ KHÔNG có Dã Tẩu ở đây (đang ở {mname} / Map {mid}). "
                           f"Nhân vật cần ĐỨNG TRONG THÀNH có Dã Tẩu (Tương Dương/Biện Kinh/Lâm An/Thành Đô...). "
                           f"Hãy đưa nhân vật về thành rồi bật lại Auto.")
                self.npc_interact.dismiss_dialog()
                self.read_quest_retries = 0
                self._lost_recall_tries = 0
                self._goto_state(BotState.LOST)
                return
            else:
                self.npc_interact.dismiss_dialog()
                self._goto_state(BotState.READ_QUEST)
                return
        
        self.read_quest_retries = 0
        self.current_quest = quest

        # HẾT HẠN NGẠCH NGÀY (tối đa 30 NV): server trả popup "...đã hoàn thành 30 nhiệm vụ, đã đạt mong đợi
        # của lão, hôm sau hãy quay lại". -> KHÔNG còn NV nào hôm nay -> DỪNG + tô ĐỎ tên cho người chơi biết.
        _qt = (getattr(quest, 'clean_text', '') or getattr(quest, 'raw_text', '') or '').lower()
        if any(k in _qt for k in ("hôm sau hãy quay lại", "đạt mong đợi", "hoàn thành 30 nhiệm")):
            self._daily_limit_reached()
            return

        # MENU KHI HẾT NV NGÀY (user xác nhận logic): Dã Tẩu CHỈ còn [Bảng Xếp Hạng, Kết thúc đối thoại]
        # (KHÔNG có 'nhận'/'hoàn thành nhiệm vụ'). eNpcSelect() rỗng = chọn DÒNG ĐẦU = 'Bảng Xếp Hạng' -> tự MỞ
        # bảng xếp hạng (popup không tắt được). -> Nhận diện menu này = ĐÃ XONG NV NGÀY: ĐÓNG dialog (KHÔNG
        # eNpcSelect), vào _daily_limit_reached. (buttons op34 đã được parse_quest_dialog trích.)
        # ⚠️ VERIFY LIVE (bắt gói 2026-06-11): menu done = op34/NpcDialogPc, DÒNG ĐẦU = "Bảng Xếp Hạng".
        # Click dòng đầu / bot gửi `eNpcSelect()` RỖNG (op35 body rỗng) = CHỌN "Bảng Xếp Hạng" -> server trả
        # danh sách xếp hạng -> bảng xếp hạng bung. `dismiss_dialog()` cũng gửi eNpcSelect() rỗng -> y hệt.
        # => Nhận diện menu done (có "Bảng Xếp Hạng" HOẶC "Kết thúc đối thoại", KHÔNG có nút nhận/hoàn-thành-NV)
        #    -> ĐÓNG client-side (_clear_popups đóng NpcDialogPc), TUYỆT ĐỐI KHÔNG eNpcSelect, vào daily_limit.
        _btns = [str(b).lower() for b in (getattr(quest, 'buttons', None) or [])]
        _DONE_KW = ('xếp hạng', 'xep hang', 'bảng xếp', 'kết thúc đối thoại', 'ket thuc doi thoai', 'kết thúc đối')
        _has_done_menu = any(any(kw in b for kw in _DONE_KW) for b in _btns) or any(kw in _qt for kw in _DONE_KW)
        _has_offer = any(k in b for b in _btns
                         for k in ('nhận nhiệm', 'tiếp nhận', 'tham gia', 'hoàn thành nhiệm', 'biết rồi', 'hủy'))
        if _has_done_menu and not _has_offer:
            self._chat("🏁 Dã Tẩu chỉ còn [Bảng Xếp Hạng / Kết thúc đối thoại] → ĐÃ HẾT NV NGÀY. "
                       "Đóng dialog client-side (KHÔNG eNpcSelect → không mở bảng xếp hạng).")
            self._clear_popups("đóng menu Dã Tẩu (hết NV)")   # đóng NpcDialogPc client-side, KHÔNG eNpcSelect
            self._daily_limit_reached()
            return

        # NHẬN NV BẰNG PACKET (verified): CHỈ khi là bảng MỜI nhận NV MỚI (nút 'Tiếp nhận'/'Tham gia').
        # KHÔNG tính "Biết rồi"/"Đồng ý" của bảng NV-ĐANG-CÓ (124) là mời -> tránh gửi eNpcSelect dư = popup linh tinh.
        # Bảng 124 (đang có NV) -> chỉ đọc rồi để EVALUATE quyết định làm/hủy.
        qtext_l = (getattr(quest, 'clean_text', '') or getattr(quest, 'raw_text', '') or '').lower()
        # Lời MỜI nhận NV: qua NÚT ('tiếp nhận'/'tham gia') HOẶC qua CÂU HỎI trong text
        # ('có muốn tiếp nhận nhiệm vụ không', 'tiếp nhận nhiệm vụ mới'...) — nút có thể là 'Đồng ý/Không'.
        offer_by_btn = bool(quest.buttons) and any(
            k in b.lower() for b in quest.buttons
            for k in ("tiếp nhận", "tham gia", "nhận nhiệm vụ"))
        # CÂU MỜI rõ ràng trong text ("có muốn tiếp nhận nhiệm vụ không") = lời mời -> nhận BẤT KỂ opcode
        # (server đẩy câu này dưới opcode 124). Active-quest panel KHÔNG chứa câu hỏi này nên an toàn.
        offer_by_text = any(p in qtext_l for p in OFFER_TEXT_MARKERS)
        # nút 'tiếp nhận' chỉ tính khi KHÔNG phải panel NV-đang-có (124/126)
        offer = offer_by_text or (offer_by_btn and quest.opcode not in (124, 126))
        logger.info(f"[READ_QUEST] opcode={quest.opcode} offer={offer} (text={offer_by_text} btn={offer_by_btn}) "
                    f"text={qtext_l[:50]!r}")
        if offer and self.game_bot_connected:
            logger.info("[READ_QUEST] Bảng mời NV -> nhận bằng packet (eNpcSelect rỗng).")
            self._select_pkt()   # tiếp nhận
            # đọc lại bảng NV thực sự sau khi nhận (nếu server đẩy tiếp 34/124)
            pkts2 = self.game_bot.wait_for_packet(DATAU_DIALOG_OPS, timeout=2.5)
            if pkts2:
                from core.quest import parse_quest_dialog
                p2 = pkts2[-1]
                try:
                    body2 = bytes.fromhex(p2['hex'])[6:]
                    op2 = p2.get('opcode', 124)
                    quest2 = parse_quest_dialog(body2, opcode=op2)
                    if quest2 and quest2.is_valid:
                        if quest2.opcode in (124, 126) and not quest2.buttons:
                            quest2.buttons = ["Đã hoàn thành nv", "Ta muốn hủy nv", "Biết rồi!"]
                        self.current_quest = quest2
                        logger.info(f"[READ_QUEST] Bảng NV thực sự: {quest2.clean_text[:60]!r}")
                except Exception as e:
                    logger.error(f"[READ_QUEST] re-parse lỗi: {e}")
        # Nếu current_quest VẪN là CÂU MỜI (nhận xong chưa ra NV thật, hoặc đọc lại hụt) -> ĐỌC LẠI,
        # tuyệt đối KHÔNG mang câu mời sang EVALUATE (sẽ bị phân loại nhầm find_equip).
        cur_txt = (getattr(self.current_quest, 'clean_text', '') or
                   getattr(self.current_quest, 'raw_text', '') or '').lower()
        if any(p in cur_txt for p in OFFER_TEXT_MARKERS):
            self.read_quest_retries += 1
            self.npc_interact.dismiss_dialog()
            self._datau_dialog_open = False
            if self.read_quest_retries <= 5:
                logger.info("[READ_QUEST] Sau khi nhận vẫn là câu MỜI -> đọc lại để lấy NV thật.")
                self._goto_state(BotState.READ_QUEST)
            else:
                self.read_quest_retries = 0
                self._goto_state(BotState.IDLE_PRECHECK)
            return
        # Đóng panel TRƯỚC EVALUATE bằng CLIENT-SIDE (_clear_popups invoke Close) — TUYỆT ĐỐI KHÔNG
        # dismiss_dialog (nó gửi eNpcSelect() RỖNG = CHỌN dòng đầu menu; nếu lỡ là menu done thì = mở Bảng
        # Xếp Hạng). Quyết định làm/hủy ở EVALUATE; dialog chỉ cần biến mất khỏi màn, không cần select server.
        self._clear_popups("đóng dialog Dã Tẩu trước EVALUATE")
        self._datau_dialog_open = False

        if self.current_quest:
            q = self.current_quest
            self._chat(f"==============================")
            self._chat(f"📜 Đã nhận nhiệm vụ: {q.item_name}")
            self._chat(f"📝 Yêu cầu: {q.clean_text}")
            self._chat(f"==============================")
            self._update_quest_stats(q)
            # Ghi 'quest_received' MỖI NV 1 LẦN (theo qno) -> UI luôn hiện NV hiện tại, không spam trùng.
            # GHI CẢ KHI item_name RỖNG (vd NV tìm đồ theo thuộc tính/đánh quái) -> UI vẫn hiện được text NV.
            qno = getattr(q, 'quest_number', 0) or self.last_quest_number
            qtxt = getattr(q, 'clean_text', '') or getattr(q, 'raw_text', '')
            if qno and qtxt and qno != getattr(self, '_last_recorded_qno', None):
                self._last_recorded_qno = qno
                try:
                    tracker.record(self.device_id, "quest_received", char=self.player_name,
                                   qno=qno, item=q.item_name or "", text=qtxt,
                                   remaining=self.last_remaining)
                except Exception:
                    pass
            # GỘP đồ cùng loại (eItemJoin) + cất túi đầy vào kho — MỖI NV 1 LẦN (qno guard), tiết kiệm ô túi.
            if qno and qno != getattr(self, '_last_stacked_qno', None):
                self._last_stacked_qno = qno
                self._stack_bag_items()
                self._stash_full_bag()

        logger.debug("Đã cập nhật thông tin nhiệm vụ.")
        self._goto_state(BotState.EVALUATE)

    def _need_help(self, reason):
        """Bot chưa làm được -> PENDING: tô ĐỎ + nút Resume trên UI, ĐỨNG IM chờ người chơi xử lý.
        Sau khi người chơi giúp xong (nạp tiền / làm NV tay) + bấm Resume -> resume() chạy tiếp.
        KHÔNG auto-retry, KHÔNG tắt Auto (thread vẫn sống, chỉ idle)."""
        self._chat(f"🆘 CẦN TRỢ GIÚP (PENDING): {reason}")
        self._chat("   ⏸ Đã PAUSE. Xử lý xong bấm ▶ Resume trên dòng nhân vật để chạy tiếp.")
        self.paused = True
        if getattr(self, 'ui_need_help', None):
            try:
                self.ui_need_help(reason)
            except Exception:
                pass

    def _start_await_quest_change(self, reason):
        """Find/submit KHÔNG tìm được → PENDING nhưng BẬT chế độ tự bắt đổi NV: tick sẽ định kỳ re-read Dã Tẩu,
        nếu user hoàn thành/đổi NV (quest_number hoặc tên khác) → tự làm NV mới. (Khắc phục: trước đây vào
        TRAINING chờ op54 = kẹt mãi cho NV tìm-đồ; đổi NV tay cũng không nhận ra.)"""
        q = self.current_quest
        self._await_quest_change = True
        self._pending_buy_van = 0   # mặc định KHÔNG phải chờ-nâng-giá; nhánh giá tự set lại SAU khi gọi hàm này
        self._await_quest_key = ((getattr(q, 'quest_number', 0) or 0),
                                 (getattr(q, 'item_name', '') or '')) if q else (0, '')
        self._await_last_check_ts = time.time()
        self._need_help(reason + " Đang chờ — nếu bạn HOÀN THÀNH/ĐỔI NV ở Dã Tẩu, bot tự nhận biết + làm NV mới.")

    def _read_best_quest_key(self):
        """Re-read Dã Tẩu → (quest_number, item_name) của NV hiện ở Dã Tẩu, hoặc None nếu đọc hụt."""
        if not self.game_bot_connected:
            return None
        try:
            pkts = self.open_datau()
        except Exception:
            return None
        if not pkts:
            return None
        from core.quest import parse_quest_dialog
        best, bs = None, -1
        for p in pkts:
            try:
                q = parse_quest_dialog(bytes.fromhex(p['hex'])[6:], opcode=p.get('opcode', 124))
            except Exception:
                continue
            if not q:
                continue
            sc = (2 if getattr(q, 'quest_number', 0) else 0) + (1 if getattr(q, 'item_name', '') else 0)
            if sc > bs:
                best, bs = q, sc
        if best is None:
            return None
        return ((getattr(best, 'quest_number', 0) or 0), (getattr(best, 'item_name', '') or ''))

    def _quest_changed_since_start(self):
        """should_stop PHỤ khi quét/rảo: phát hiện user HUỶ/ĐỔI NV → set _quest_changed_flag + trả True (dừng
        quét NGAY, handler re-route làm NV mới). 2 lớp:
        (1) PASSIVE op54 (bảng nhiệm vụ) — server TỰ đẩy khi NV đổi (giống đếm op48 cho đồ chí), KHÔNG re-open
            Dã Tẩu → bắt NGAY mỗi vòng. (2) FALLBACK ~60s re-open Dã Tẩu (phòng op54 không bắt)."""
        if getattr(self, '_quest_changed_flag', False):
            return True
        base = getattr(self, '_active_quest_key', None)
        if not base:
            return False
        # (1) PASSIVE: drain buffer op54 (quest tracker). quest_number KHÁC base = đã đổi NV.
        try:
            from core.quest import parse_opcode54
            op = self.game_bot.rpc.get_op54() or {}
            for hx in (op.get('items') or []):
                try:
                    q = parse_opcode54(bytes.fromhex(hx))
                except Exception:
                    continue
                qn = getattr(q, 'quest_number', 0) if q else 0
                if qn and qn != base[0]:
                    self._chat(f"🔄 (bảng NV op54: thứ {qn} ≠ {base[0]}) bạn đã đổi NV → DỪNG quét, làm NV MỚI.")
                    self._quest_changed_flag = True
                    return True
        except Exception:
            pass
        # (2) FALLBACK chậm: ~60s/lần re-open Dã Tẩu.
        now = time.time()
        if now - getattr(self, '_qchg_last_ts', 0) < 60:
            return False
        self._qchg_last_ts = now
        key = self._read_best_quest_key()
        if key is not None and key != base:
            self._chat("🔄 (re-read Dã Tẩu) bạn đã HUỶ/ĐỔI NV → DỪNG quét, làm NV MỚI.")
            self._quest_changed_flag = True
            return True
        return False

    def _arm_quest_change_watch(self):
        """Bắt đầu theo dõi ĐỔI NV cho NV hiện tại (gọi đầu find/submit): ghi `_active_quest_key`, reset cờ, +
        XẢ buffer op54 tồn (của NV trước) để `_quest_changed_since_start` KHÔNG báo đổi-NV nhầm."""
        q = self.current_quest
        self._active_quest_key = ((getattr(q, 'quest_number', 0) or 0), (getattr(q, 'item_name', '') or '')) if q else None
        self._quest_changed_flag = False
        self._qchg_last_ts = time.time()
        try:
            self.game_bot.rpc.get_op54()
        except Exception:
            pass

    def _maybe_detect_quest_change(self):
        """(Khi PENDING chờ-đổi-NV) ~20s/lần ĐỌC TRACKER (read_datau_tracker = memory, KHÔNG mở popup) để biết
        user đã đổi/hoàn thành NV chưa. TRƯỚC ĐÂY gọi open_datau (mở dialog Dã Tẩu) → lúc PENDING cứ 20s lại
        BẬT popup Dã Tẩu (user thấy 'pending nhưng vẫn gọi Dã Tẩu + mở popup liên tục'). Nay đọc memory, 0 popup."""
        now = time.time()
        if now - getattr(self, '_await_last_check_ts', 0) < 20:
            return
        self._await_last_check_ts = now
        if not self.game_bot_connected:
            return
        try:
            content = (self.game_bot.rpc.read_datau_tracker() or {}).get('datau_content') or ''
        except Exception:
            return
        if not content:
            return
        import re as _re
        cl = _re.sub(r'<[^>]*>', '', content).lower()
        m = _re.search(r'nhiệm vụ thứ\s*(\d+)', cl)
        live_qno = int(m.group(1)) if m else None
        pend_qno = (getattr(self, '_await_quest_key', (0, '')) or (0, ''))[0]
        # GIỮA-các-NV (đã hoàn thành NV cũ, chưa nhận NV mới): tracker hiện 'đối thoại với Dã Tẩu / còn N nhiệm vụ'
        # mà KHÔNG có 'Nhiệm vụ thứ N' = user vừa xong NV đang chờ.
        between = (live_qno is None) and ('đối thoại' in cl or 'tiếp nhận' in cl or 'chưa hoàn thành' in cl)
        changed = (live_qno is not None and pend_qno and live_qno != pend_qno) or between
        if changed:
            self._chat("🔄 Phát hiện NV ĐỔI/XONG ở Dã Tẩu (đọc tracker, KHÔNG mở popup) → đọc lại + làm NV MỚI.")
            self._await_quest_change = False
            self.paused = False
            self.current_quest = None
            self.datau_npc_id = None
            self._datau_dialog_open = False
            if getattr(self, 'ui_need_help', None):
                try:
                    self.ui_need_help(None)
                except Exception:
                    pass
            self._goto_state(BotState.IDLE_PRECHECK)

    def resume(self):
        """Người chơi bấm Resume sau khi xử lý xong -> bỏ PENDING, bỏ đỏ, đọc lại NV chạy tiếp."""
        self._await_quest_change = False
        self.paused = False
        # XOÁ quest CACHE trước khi đọc lại: PENDING thường do quest CŨ đã LỖI THỜI (vd giữ 'đồ chí 18/15'
        # trong khi server ĐÃ sang 'mật chí 0/2'). Nếu không xoá, IDLE_PRECHECK (line ~330) xài lại cache cũ ->
        # nộp non -> server từ chối 'chưa đạt yêu cầu' -> PENDING -> Resume -> LẶP VÔ TẬN (bug acc Muội Yêu).
        # Xoá cache = ĐỌC LẠI LIVE từ Dã Tẩu (server là chân lý). KHÔNG phải huỷ NV (không gửi _datau_cancel).
        self.current_quest = None
        self._dochi_regrind = 0
        self._dochi_last_town_x = -1
        # RE-SYNC MẠNH (fix: sau khi user can thiệp tay — mua/nộp/đổi NV — bot hay kẹt "không tìm thấy Dã Tẩu"
        # hoặc bám NV CŨ). Nguyên nhân: fd Frida chết sau pause dài → open_datau đọc câm; popup Dã Tẩu user mở
        # tay còn treo; node cache sai sau khi char bị di chuyển. → đóng popup + hồi fd + QUÊN node cache (dò lại) +
        # reset đếm lạc.
        self._lost_logged = False
        self._lost_recall_tries = 0
        self.read_quest_retries = 0
        self._reattach_count = 0              # Resume = cấp lại budget re-attach (user đã mồi traffic tay)
        self._pending_buy_van = 0             # bỏ cờ chờ-nâng-giá (Resume = làm lại từ đầu)
        self.datau_npc_id = None              # quên node cache → open_datau dò lại từ đầu
        self._datau_dialog_open = False
        try:
            self.npc_interact.dismiss_dialog()        # đóng popup Dã Tẩu user mở tay (tránh chồng/đọc nhầm)
        except Exception:
            pass
        try:
            self.game_bot.redetect_fd_by_traffic()    # hồi gameFd → đọc gói TƯƠI (không câm = "không tìm thấy")
        except Exception:
            pass
        self._chat("▶️ RESUME — re-sync (hồi fd + dò lại Dã Tẩu), đọc lại nhiệm vụ LIVE, chạy tiếp.")
        if getattr(self, 'ui_need_help', None):
            try:
                self.ui_need_help(None)
            except Exception:
                pass
        self._goto_state(BotState.IDLE_PRECHECK)

    def _clear_help(self):
        """Bot làm được trở lại -> bỏ PENDING + bỏ báo đỏ."""
        self.paused = False
        if getattr(self, 'ui_need_help', None):
            try:
                self.ui_need_help(None)   # None = hết cần trợ giúp
            except Exception:
                pass

    # ==================== ACCOUNT ROTATION ====================
    def _today_str(self):
        import datetime
        return datetime.date.today().isoformat()

    def _read_json(self, path):
        import json
        try:
            return json.load(open(path, encoding="utf-8"))
        except Exception:
            return {}

    def _write_json(self, path, data):
        try:
            with _SHARED_FILE_LOCK:
                _atomic_write_json(path, data)
        except Exception as e:
            logger.error(f"[acct] ghi {path} lỗi: {e}")

    def _load_account_queue(self):
        """Đọc list account của device + merge progress (account đã done HÔM NAY). account_index = account
        chưa-done đầu tiên. Sang ngày mới -> reset done. Queue rỗng -> rotation tắt (giữ hành vi 1-acc)."""
        q = self._read_json(self.ACCOUNT_QUEUE_PATH).get(self.device_id) or []
        self.account_queue = [{"acc": str(a.get("acc", "")).strip(),
                               "pass": str(a.get("pass", "")),
                               "done": False, "errored": False} for a in q if a.get("acc")]
        prog = self._read_json(self.ACCOUNT_PROGRESS_PATH).get(self.device_id) or {}
        _today = prog.get("date") == self._today_str()
        done = set(prog.get("done") or []) if _today else set()
        errored = set(prog.get("errored") or []) if _today else set()   # account LỖI (login fail) — KHÔNG phải xong
        for a in self.account_queue:
            if a["acc"] in done:
                a["done"] = True
            if a["acc"] in errored:
                a["errored"] = True
        self.account_index = next((i for i, a in enumerate(self.account_queue)
                                   if not a["done"] and not a.get("errored")), 0)
        if self.account_queue:
            logger.info(f"[acct] {self.device_id}: {len(self.account_queue)} account, "
                        f"{sum(1 for a in self.account_queue if a['done'])} done hôm nay, "
                        f"đang ở index {self.account_index}.")

    def _remaining_accounts(self):
        return sum(1 for a in self.account_queue if not a.get("done") and not a.get("errored"))

    def _save_progress(self):
        # READ-MODIFY-WRITE atomic dưới 1 lock: đọc bản MỚI NHẤT (device khác có thể vừa ghi) -> chỉ đụng
        # KEY của device mình -> ghi atomic. KHÔNG để 10 cửa sổ ghi đè tiến độ nhau (mất account done).
        try:
            with _SHARED_FILE_LOCK:
                data = self._read_json(self.ACCOUNT_PROGRESS_PATH)
                data[self.device_id] = {"date": self._today_str(),
                                        "done": [a["acc"] for a in self.account_queue if a.get("done")],
                                        "errored": [a["acc"] for a in self.account_queue if a.get("errored")]}
                _atomic_write_json(self.ACCOUNT_PROGRESS_PATH, data)
        except Exception as e:
            logger.error(f"[acct] _save_progress lỗi: {e}")

    def _advance_account(self, failed=False):
        """Đánh dấu account hiện tại DONE (xong NV) — hoặc ERRORED (failed=True: lỗi login, KHÔNG phải xong) —
        lưu progress, trả account KẾ cần xử lý (hoặc None).
        2 PHA (yêu cầu user): account 'OK' chỉ khi ĐÃ XONG NV **và ĐÃ NỘP** thủ quỹ.
          Pha 1: còn account CHƯA xong NV -> làm NV.
          Pha 2: mọi account xong NV rồi -> account nào XONG NV nhưng CHƯA NỘP -> QUAY LẠI login để nộp
                 (cap dep_tries<3/account để KHÔNG lặp vô hạn khi thủ quỹ offline/không nộp được)."""
        if not self.account_queue:
            return None
        if not hasattr(self, '_switch_pass'):
            self._switch_pass = set()        # acc đã THỬ đổi trong PASS này (chống lặp vô tận, không loại vĩnh viễn)
        if 0 <= self.account_index < len(self.account_queue):
            cur = self.account_queue[self.account_index]
            if failed:
                # LỖI login/đổi account — KHÔNG mark done. Login fail thường TẠM THỜI (tải nặng) → RETRYABLE:
                # chỉ 'errored' (bỏ vĩnh viễn ngày) sau MAX_LOGIN_ERR lần. Dưới đó vẫn thử lại ở PASS sau.
                cur["err_tries"] = cur.get("err_tries", 0) + 1
                cur["errored"] = cur["err_tries"] >= self.MAX_LOGIN_ERR
                self._switch_pass.add(cur.get("acc"))   # đã thử acc này trong pass hiện tại
            else:
                cur["done"] = True
                self._switch_pass.clear()               # đổi thành công → bắt đầu PASS mới
        self._save_progress()
        # PHA 1: account CHƯA xong NV, CHƯA errored-vĩnh-viễn, CHƯA thử trong pass này (mỗi acc thử 1 lần/pass).
        nd = next((i for i, a in enumerate(self.account_queue)
                   if not a.get("done") and not a.get("errored") and a.get("acc") not in self._switch_pass), None)
        if nd is not None:
            self.account_index = nd
            return self.account_queue[nd]
        # PHA 2: mọi account xong NV -> revisit account XONG-nhưng-CHƯA-NỘP (có thủ quỹ + dep_tries<3 + chưa thử pass này)
        try:
            from core import treasurer as _T
            if _T.treasurer_device() and not _T.is_treasurer_device(self.device_id):
                dep = _T.deposited_today(self.device_id)
                un = next((i for i, a in enumerate(self.account_queue)
                           if a.get("done") and not a.get("errored")
                           and a.get("acc") and a.get("acc") not in dep
                           and a.get("acc") not in self._switch_pass
                           and a.get("dep_tries", 0) < 3), None)
                if un is not None:
                    self.account_index = un
                    self._chat(f"🔁 {self.account_queue[un].get('acc')} đã xong NV nhưng CHƯA nộp thủ quỹ "
                               f"(lần {self.account_queue[un].get('dep_tries',0)+1}/3) → quay lại login để nộp.")
                    return self.account_queue[un]
        except Exception as e:
            logger.error(f"[advance_account pha2] {e}")
        # KHÔNG còn account -> LOG RÕ vì sao (hết đoán "danh sách còn nhiều mà báo hết"):
        try:
            q = self.account_queue
            done = [a['acc'] for a in q if a.get('done')]
            errd = [f"{a['acc']}(fail×{a.get('err_tries',0)})" for a in q if a.get('errored')]
            retry = [a['acc'] for a in q if not a.get('done') and not a.get('errored')]
            self._chat(f"📋 HẾT account để chạy: tổng {len(q)} | ✅done {len(done)} | ❌lỗi-bỏ {len(errd)}:{errd} "
                       f"| ⏳còn-thử-được {len(retry)}:{retry} (đã thử trong lượt này: {sorted(self._switch_pass)}). "
                       f"Nếu 'còn-thử-được' > 0 → resume/khởi động lại sẽ thử tiếp.")
        except Exception:
            pass
        return None

    def _reinit_after_relogin(self):
        """Reset mọi state gắn với nhân vật CŨ sau khi login account mới (PlayerMain pointer đã đổi)."""
        self.daily_limit_reached_flag = False
        self.paused = False
        self.current_quest = None
        self.target_givebox_slot = -1
        self.datau_npc_id = None
        self._datau_dialog_open = False
        self.daily_done = 0
        self.max_remaining_today = 0        # reset đỉnh 'còn N' (cap) — char mới có cap riêng (đừng kế thừa lệnh-bài char cũ)
        self._last_cid = ''                 # quên cid cũ → tick info-read KHÔNG hiểu nhầm là 'đổi char' ngay sau reinit
        self._riu_use_count = 0             # account mới → đếm lại số lần dùng rìu từ 0 (cap RIU_DAILY_CAP)
        self.last_quest_number = 0
        self.last_remaining = 0
        self.daily_rewards = []
        self._dochi_regrind = 0
        self._dochi_last_town_x = -1
        self._lost_logged = False
        self._last_buff_ts = 0.0            # BUG FIX: acc MỚI phải nhận buff NGAY (trước đây thừa cooldown 1h
                                            # của acc cũ -> acc auto-đổi không tự nhận buff suốt tới 1h).
        self.player_name = ""               # ép tick() đọc lại tên nhân vật mới
        self._tlh_seen = None               # reset mốc đếm TLH (acc mới: baseline lại, không tính TLH có sẵn)
        self.last_player_info_time = 0
        # Account MỚI: RESET cache guid autoplay -> đọc guid 'Luyện công' RIÊNG của account mới (guid khác nhau
        # theo account). KHÔNG để dùng nhầm guid account CŨ trong last_autoplay; BỎ QUA file per-device (file
        # theo DEVICE = guid account cũ vừa rời) -> ép đọc lại selectedProfile qua il2cpp của account mới.
        try:
            self.game_bot.last_autoplay = None
            self.game_bot._autoplay_named_tries = 0       # tìm lại 'Luyện công' theo tên cho account MỚI
            if hasattr(self.game_bot, '_autoplay_guid_resolved'):
                del self.game_bot._autoplay_guid_resolved
        except Exception:
            pass
        try:
            if hasattr(self.game_bot, 'recv_buffer'):
                self.game_bot.recv_buffer = []
        except Exception:
            pass

    def _do_account_switch(self, acc):
        """LOGOUT = relaunch game (force-stop+launch+re-attach -> màn login) -> login(acc) -> chờ vào world
        -> re-init. Phán quyết THÀNH CÔNG = wait_in_world (KHÔNG tin login() bool vì 'breakpoint' artifact)."""
        for attempt in range(2):
            if self._stopping(): return False
            self._chat(f"🔄 Đổi tài khoản → {acc['acc']} (lần {attempt+1}): khởi động lại game...")
            if not self.game_bot.relaunch_game():
                self._chat("⚠️ relaunch/re-attach game lỗi, thử lại."); time.sleep(3); continue
            t0 = time.time()
            while time.time() - t0 < 45 and self.game_bot.get_login_state() != 'at_login':
                if self._stopping(): return False
                time.sleep(2)
            self.game_bot.login(acc['acc'], acc['pass'])   # 'breakpoint' artifact OK; verdict = wait_in_world
            if self.game_bot.wait_in_world(timeout=90):
                self._reinit_after_relogin()
                self._chat(f"✅ Đã vào game tài khoản {acc['acc']} (nhân vật: {self.game_bot.rpc.get_player_info().get('name') if self.game_bot.rpc.get_player_info() else '?'}).")
                return True
            # FAIL: KHÔNG báo "login lỗi" mù mịt — ĐỌC LÝ DO THẬT (acc đúng nhưng vào world fail vì gì):
            #   - login RPC result (vd 'no live AccountLoginPopup' = không ở màn login → relaunch/chọn-server hỏng)
            #   - login_state cuối (at_login = kẹt màn login → thường server TỪ CHỐI; unknown = chưa attach/đơ)
            #   - text popup màn login (server báo: 'tài khoản đang đăng nhập', 'sai mật khẩu', 'bảo trì'…)
            try:
                lr = getattr(self.game_bot, 'last_login_result', None) or {}
                st = self.game_bot.get_login_state()
                msg = self.game_bot.login_screen_message()
                self._chat(f"⚠️ Vào thế giới THẤT BẠI (lần {attempt+1}) — acc {acc['acc']}. "
                           f"login_rpc={{ok:{lr.get('ok')},err:{lr.get('error') or lr.get('warn') or '-'}}} | "
                           f"state={st}" + (f" | 📢 màn login: «{msg}»" if msg else " | (không đọc được text màn login)"))
            except Exception:
                self._chat(f"⚠️ Vào thế giới thất bại (lần {attempt+1}).")
        return False

    def _recover_by_relaunch(self):
        """PHỤC HỒI kết nối câm bằng RELAUNCH GAME (force-stop+launch+re-attach SẠCH → login lại account
        HIỆN TẠI → vào world), KHÔNG re-attach cùng PID (đường đó hay câm — log chứng minh). Đây là đường
        account-rotation đang dùng → log 'Kết nối OK'. Trả True nếu vào lại world.
        CẦN account trong queue để login lại; KHÔNG có (login tay) → PENDING (login tay + Resume)."""
        acc = None
        try:
            if self.account_queue and 0 <= self.account_index < len(self.account_queue):
                acc = self.account_queue[self.account_index]
        except Exception:
            acc = None
        if not acc or not acc.get('acc'):
            self._need_help("Kết nối game CÂM mà cửa sổ này KHÔNG có account trong danh sách để tự login lại "
                            "→ relaunch sẽ kẹt ở màn login. Hãy đưa nhân vật vào thế giới (login tay nếu cần) "
                            "rồi bấm ▶ Resume.")
            return False
        for attempt in range(2):
            if self._stopping(): return False
            if not self.game_bot_connected:
                return False
            self._chat(f"♻️ Kết nối câm → RELAUNCH game + login {acc['acc']} (lần {attempt+1}, đường chắc chắn)…")
            if not self.game_bot.relaunch_game():
                self._chat("⚠️ relaunch/re-attach lỗi → thử lại."); time.sleep(3); continue
            t0 = time.time()
            while time.time() - t0 < 45 and self.game_bot.get_login_state() != 'at_login':
                if self._stopping(): return False
                self._hb_ts = time.time(); time.sleep(2)
            self.game_bot.login(acc['acc'], acc['pass'])   # verdict = wait_in_world (login() bool có artifact)
            if self.game_bot.wait_in_world(timeout=90):
                # re-sync NHẸ (cùng account → KHÔNG reset daily_done/tiến độ; chỉ quên cache để đọc LIVE).
                self.current_quest = None
                self.datau_npc_id = None
                self._datau_dialog_open = False
                try:
                    if hasattr(self.game_bot, 'recv_buffer'):
                        self.game_bot.recv_buffer = []
                except Exception:
                    pass
                self._chat("✅ Relaunch + vào world OK → đọc lại Dã Tẩu.")
                return True
            self._chat(f"⚠️ Relaunch xong nhưng chưa vào world (lần {attempt+1}).")
        self._need_help("Relaunch + login lại vẫn KHÔNG vào được thế giới. Kiểm tra game/MEmu/acc rồi ▶ Resume.")
        return False

    MAX_LOGIN_ERR = 3   # login/đổi-account fail ngần này lần MỚI bỏ vĩnh viễn ngày (dưới đó = tạm thời, retry)

    def _daily_limit_reached(self):
        """Đã làm hết 30 NV Dã Tẩu hôm nay. Nếu CÒN account trong danh sách cửa sổ này -> logout + login
        account kế, chạy tiếp. Hết danh sách (hoặc đổi thất bại) -> DỪNG + tô đỏ tên (hành vi cũ)."""
        self.daily_limit_reached_flag = True
        self.last_remaining = 0
        self._switch_pass = set()   # PASS xoay-account MỚI → cho phép thử lại các acc lỗi-tạm-thời (err_tries<MAX)
        try:
            tracker.record(self.device_id, "daily_limit", char=self.player_name,
                           qno=self.last_quest_number, remaining=0)
        except Exception:
            pass
        # ĐÓNG dialog Dã Tẩu CLIENT-SIDE — TUYỆT ĐỐI KHÔNG dismiss_dialog (nó gửi eNpcSelect() RỖNG = CHỌN
        # dòng đầu menu = "Bảng Xếp Hạng" -> mở bảng xếp hạng). Khi hết NV menu chỉ còn [Bảng Xếp Hạng/Kết thúc].
        self._clear_popups("đóng Dã Tẩu (hết NV ngày)")
        self._datau_dialog_open = False
        self.current_quest = None
        self.target_givebox_slot = -1

        # THỦ QUỸ: xong NV / hết rìu -> GIAO ĐỒ cho thủ quỹ TRƯỚC khi xoay account (nếu có cấu hình + không phải
        # chính mình + còn đồ-giao trong túi). LOG RÕ lý do nếu bỏ qua (đừng "âm thầm out" — user cần biết tại sao).
        try:
            from core import treasurer as _T
            cur_idx = getattr(self, 'account_index', 0)
            cur_acc = (self.account_queue[cur_idx].get('acc')
                       if (self.account_queue and 0 <= cur_idx < len(self.account_queue)) else None)
            def _bump_dep_try():
                # tăng số lần đã thử nộp (cho account hiện tại) -> pha-2 revisit dừng sau 3 lần (chống lặp vô hạn).
                if self.account_queue and 0 <= cur_idx < len(self.account_queue):
                    self.account_queue[cur_idx]['dep_tries'] = self.account_queue[cur_idx].get('dep_tries', 0) + 1
            def _settle_no_give():
                # KHÔNG có đồ để nộp (khoá/rỗng) = account này coi như ĐÃ XỬ LÝ NỘP -> đánh dấu để pha-2 không revisit.
                if cur_acc:
                    _T.mark_deposited(self.device_id, cur_acc)
            t_dev = _T.treasurer_device()
            if not t_dev:
                self._chat("💼 (Chưa cấu hình thủ quỹ → không giao đồ, đổi account luôn.)")
            elif _T.is_treasurer_device(self.device_id):
                pass   # chính mình là thủ quỹ -> không tự giao
            elif not _T.read_info():
                _bump_dep_try()
                self._chat("💼 ⚠️ Thủ quỹ KHÔNG online (info quá hạn 30s / cửa sổ thủ quỹ chưa bật Auto) → "
                           "KHÔNG giao được đồ. Bật Auto cửa sổ thủ quỹ; sẽ quay lại nộp sau (tối đa 3 lần).")
            else:
                parts = _T.give_particulars(_T.load_config().get('give_names'))
                # ĐỌC TÚI có thể HỤT 1 nhịp (Frida) -> RETRY tối đa 3 lần trước khi kết luận "không có đồ".
                give_items = []
                locked = []
                for _try in range(3):
                    bag = (self.game_bot.dump_bag_items() or {})
                    items = bag.get('items', []) if bag.get('ok', True) else []
                    # ĐẾM CẢ KHO (location 3): give-set có thể đã bị cất kho (_stash_full_bag) -> vẫn coi là "có đồ
                    # để giao" (errand sẽ lấy lại từ kho trước khi giao). KHÔNG khoá.
                    give_items = [it for it in items
                                  if it.get('location') in (2, 3) and it.get('particular') in parts and not it.get('lockstate')]
                    locked = [it for it in items
                              if it.get('location') in (2, 3) and it.get('particular') in parts and it.get('lockstate')]
                    if give_items or items:
                        break
                    time.sleep(1.0)   # đọc hụt -> nghỉ rồi đọc lại
                if give_items:
                    self._chat(f"💼 Còn {len(give_items)} món cần giao → tới thủ quỹ TRƯỚC khi đổi account…")
                    ok_dep = self._do_treasurer_errand('deposit')   # thành công -> tự mark_deposited bên trong
                    if not ok_dep:
                        _bump_dep_try()
                        self._chat("💼 ⚠️ Giao đồ thủ quỹ CHƯA xong (không tới được/đối phương bận) → giữ đồ; "
                                   "sẽ QUAY LẠI nộp sau (tối đa 3 lần) trước khi nghỉ.")
                elif locked:
                    _settle_no_give()   # còn đồ nhưng KHOÁ -> không giao được, coi như đã xử lý (đừng revisit hoài)
                    self._chat(f"💼 Có {len(locked)} món thuộc danh-sách-giao nhưng ĐANG KHOÁ → bỏ qua (đồ khoá "
                               f"không giao dịch), coi như đã xử lý nộp. Đổi account.")
                else:
                    _settle_no_give()   # không có đồ giao -> đã xử lý nộp
                    self._chat("💼 (Túi không còn đồ thuộc danh sách giao → coi như đã xử lý nộp, đổi account.)")
        except Exception as e:
            logger.error(f"[daily_limit treasurer] {e}")

        # XOAY TÀI KHOẢN: account hiện tại xong -> đánh dấu done, login account kế.
        nxt = self._advance_account()
        while nxt is not None:
            self._chat(f"✅ {self.player_name or 'Nhân vật'} xong 30 NV. Còn {self._remaining_accounts()} "
                       f"tài khoản trong danh sách → đổi sang {nxt['acc']}.")
            if self._do_account_switch(nxt):
                self._goto_state(BotState.IDLE_PRECHECK)   # _reinit đã chạy -> làm Dã Tẩu cho account mới
                return
            self._chat(f"❌ Đổi sang {nxt['acc']} thất bại (login lỗi) — đánh dấu LỖI (không phải xong), thử account kế.")
            if self._stopping():
                return
            time.sleep(1.5)                            # NGHỈ phòng hot-spin + tránh hammer login khi nhiều acc lỗi
            nxt = self._advance_account(failed=True)   # bỏ qua account LỖI (errored, không phải done), thử tiếp

        # HẾT danh sách (hoặc queue rỗng) -> DỪNG như cũ.
        self.paused = True
        self._chat("🛑 ĐÃ HẾT 30 NV + hết danh sách tài khoản hôm nay. Dừng Auto — tô đỏ tên. Mai bật lại.")
        if getattr(self, 'ui_need_help', None):
            try:
                self.ui_need_help("✅ Đã chạy hết danh sách tài khoản hôm nay — nghỉ, mai làm tiếp.")
            except Exception:
                pass
        self._lost_logged = True
        self._goto_state(BotState.LOST)

    def _handle_evaluate(self):
        logger.info("[EVALUATE] Phân loại NV + tra hành động cấu hình...")
        self._clear_help()   # bắt đầu xử lý NV mới -> tạm bỏ cờ đỏ (sẽ bật lại nếu bí)
        if not self.current_quest:
            self._goto_state(BotState.IDLE_PRECHECK)
            return

        q = self.current_quest
        # 1) PHÂN LOẠI + tra HÀNH ĐỘNG người dùng cấu hình (4 lựa chọn / loại NV)
        qtype = quest_actions.classify_quest(q)
        # NV "nâng điểm tích luỹ Tống Kim": bot TỰ LÀM bằng phiếu (dù cấu hình nhóm khác = hủy) -> chặn TRƯỚC,
        # KHÔNG đi qua action-config (tránh bị hủy oan). Lấy phiếu (túi/thủ quỹ) -> dùng -> trả NV.
        # CHỈ intercept khi action = AUTO (dùng Phiếu Tích Lũy Tống Kim). Các action khác (dùng rìu / hủy /
        # tự làm) RƠI XUỐNG flow action-config chung bên dưới (đã xử dung_riu/huy/huy_do_chi/tu_lam) — sửa bug
        # "chọn dùng rìu nhưng vẫn sang thủ quỹ lấy phiếu".
        if qtype == "tongkim_points" and quest_actions.get_action(qtype, self.quest_action_cfg) == "auto":
            self._chat("📂 Loại NV: Nâng điểm tích luỹ Tống Kim (auto) → dùng Phiếu Tích Lũy Tống Kim.")
            self._handle_tongkim_points()
            return
        # NV "nâng cấp điểm <sức mạnh/sinh khí/nội công/thân pháp> lên ít nhất N điểm(+M)" -> bot TỰ cộng điểm
        # tiềm năng bằng eAddPropField rồi trả NV. CHỈ intercept khi action='auto' (cấu hình UI nhóm 'nang_thuoc_tinh');
        # action khác (hủy/tự làm) RƠI XUỐNG xử lý chung bên dưới (qtype=nang_attr -> nhóm nang_thuoc_tinh).
        _nv_tt = self._parse_nang_thuoc_tinh(q)
        if _nv_tt and quest_actions.get_action("nang_thuoc_tinh", self.quest_action_cfg) == "auto":
            self._handle_nang_thuoc_tinh(*_nv_tt)
            return
        action = quest_actions.get_action(qtype, self.quest_action_cfg)
        self._chat(f"📂 Loại NV: {quest_actions.type_label(qtype)} → "
                   f"Hành động: {quest_actions.action_label(action)}")

        if action == "tu_lam":
            # TỰ LÀM: bot KHÔNG xử lý NV này, nhưng BẬT cơ chế bắt-đổi-NV (passive op54 + re-open Dã Tẩu) —
            # khi bạn HOÀN THÀNH/ĐỔI NV ở Dã Tẩu, bot TỰ nhận biết + làm NV kế tiếp (KHỎI bấm Resume).
            self._chat("→ TỰ LÀM: bạn tự làm NV này. Bot CHỜ — làm xong/đổi NV ở Dã Tẩu là bot tự nhận NV kế.")
            self._start_await_quest_change("NV cấu hình TỰ LÀM (vd Đồ hiếm) — chờ bạn hoàn thành/đổi NV.")
            return
        if action == "dung_riu":
            # PRE-CHECK (persist, sống qua restart): account đã dùng rìu đủ cap hôm nay → KHỎI thử rìu (tránh
            # tốn rìu + tránh server mở GiveBox), giao đồ thủ quỹ + đổi account luôn.
            if self._riu_count_today() >= self.RIU_DAILY_CAP:
                self._chat(f"🪓 Account đã dùng rìu đủ {self.RIU_DAILY_CAP} lần hôm nay (persist) → "
                           f"coi như hết NV ngày → giao đồ thủ quỹ + đổi account.")
                self.current_quest = None
                self._daily_limit_reached()
                return
            # Dùng 'Dã Tẩu Hoàn Thành Lệnh' (rìu) hoàn thành nhanh + nhận thưởng.
            st = self._use_datau_riu()
            if st == 'ok':
                n = self._bump_riu_count()
                self._chat(f"✅ Đã dùng rìu hoàn thành NV + nhận thưởng. (rìu {n}/{self.RIU_DAILY_CAP})")
                self._on_quest_completed()
                self.current_quest = None
                # CAP: dùng đủ RIU_DAILY_CAP (15) lần -> dù còn NV cũng coi như XONG NGÀY -> giao đồ thủ quỹ + đổi acc.
                if n >= self.RIU_DAILY_CAP:
                    self._chat(f"🪓 Đã dùng rìu đủ {self.RIU_DAILY_CAP} lần → coi như hết NV ngày → giao đồ thủ quỹ + đổi account.")
                    self._daily_limit_reached()
                else:
                    self._goto_state(BotState.IDLE_PRECHECK)
            elif st in ('max', 'no_axe'):
                # MAX (đạt giới hạn rìu hôm nay) / HẾT RÌU -> account này hết khả năng cày bằng rìu ->
                # GIAO ĐỒ cho thủ quỹ rồi ĐỔI ACCOUNT khác (dùng chung flow _daily_limit_reached: deposit + rotate).
                self._chat(f"🪓 Rìu {'đạt giới hạn (max)' if st=='max' else 'đã hết'} → giao đồ thủ quỹ + đổi account.")
                self.current_quest = None
                self._daily_limit_reached()
            else:
                # Lỗi KHÁC (chưa định danh / mạng) -> ĐỨNG chờ, TUYỆT ĐỐI KHÔNG tự hủy.
                self._need_help("Không dùng được rìu (chưa định danh rìu trong rương / lỗi tạm). "
                                "Đứng chờ — KHÔNG tự hủy.")
                self._goto_state(BotState.TRAINING)
            return
        if action == "huy":
            self._cancel_do_chi = False
            self._goto_state(BotState.CANCEL_QUEST)
            return
        if action == "huy_do_chi":
            self._cancel_do_chi = True
            self._goto_state(BotState.CANCEL_QUEST)
            return

        # 2) AUTO -> điều hướng theo loại NV
        if qtype == "rare":
            # Đồ hiếm: không tự làm -> hủy (an toàn) dù đặt auto.
            self._chat("Đồ hiếm (Hoàng Kim/Phúc Duyên) -> hủy cho an toàn.")
            self._cancel_do_chi = False
            self._goto_state(BotState.CANCEL_QUEST)
            return
        # buy = MUA SHOP NPC (remote theo shop_index) -> KHÔNG quét sạp người chơi.
        if qtype == "buy":
            self._goto_state(BotState.EXECUTE_BUY)
            return
        # find_equip: thử khớp đồ cụ thể qua bảng map (quét rương/SẠP người chơi)
        if qtype == "find_equip":
            try:
                from core.stall_shopper import resolve_quest_target
                if resolve_quest_target(q.clean_text or q.raw_text or ""):
                    self._goto_state(BotState.EXECUTE_FIND_EQUIP)
                    return
            except Exception as e:
                logger.error(f"[EVALUATE] resolve_quest_target lỗi: {e}")
        ROUTING = {
            "submit_equip": BotState.EXECUTE_SUBMIT_EQUIP,
            "find_item": BotState.EXECUTE_FIND_ITEM,
            "combat": BotState.EXECUTE_COMBAT,
            "submit_points": BotState.EXECUTE_SUBMIT_POINTS,
            "deliver": BotState.EXECUTE_DELIVER,
            "buy": BotState.EXECUTE_BUY,
            "find_equip": BotState.EXECUTE_FIND_EQUIP,
        }
        self._goto_state(ROUTING.get(qtype, BotState.EXECUTE_FIND_EQUIP))

    POTION_CFG_PATH = "data/output/potion_buy_config.json"

    def _stash_money_keep(self, keep=1000):
        """Cất TOÀN BỘ bạc trong TÚI vào kho, CHỈ để lại `keep` lượng — gọi TRƯỚC khi lên động (chống mất bạc
        khi bị quái/người chơi giết). eSendStorageMoney moneyToStorage>0 = túi->kho. (mua TDP/thuốc XONG mới gọi.)"""
        try:
            carried, _ = self._money_info()
            if carried is None:
                return
            amt = int(carried) - int(keep)
            if amt > 0:
                self.game_bot.send_gs('eSendStorageMoney', moneyToStorage=int(amt))
                time.sleep(0.8)
                self._chat(f"🏦 Cất {fmt_money(amt)} vào kho (giữ {keep} lượng) trước khi lên động.")
        except Exception as e:
            logger.error(f"[stash_money] {e}")

    # Particular đồ THIẾT YẾU — KHÔNG cất kho (cần dùng liên tục): rìu=33, THP=10, TDP=39, Tiên Thảo Lộ=3/34.
    BAG_KEEP_PARTICULARS = {33, 10, 39, 3, 34}

    def _bag_occupied(self):
        """Số ô túi (location==2) đang dùng — None nếu đọc hụt."""
        try:
            items = (self.game_bot.dump_bag_items() or {}).get('items', [])
            return sum(1 for it in items if it.get('location') == 2)
        except Exception:
            return None

    def _stash_full_bag(self, threshold=18, exclude_slots=None):
        """ĐẦY RƯƠNG -> cất bớt đồ TÍCH LUỸ (Thiết La Hán/Tống Kim... g6, KHÔNG thiết yếu, KHÔNG khoá) vào KHO
        (eItemLocationRequest itemLocation=3 — gói verify live). Giữ đồ thiết yếu (TDP/THP/thuốc/rìu) + gear.
        Deposit sau sẽ quét cả kho + lấy lại để giao thủ quỹ. Gọi sau khi nhận thưởng (túi phình).
        exclude_slots: tập slot KHÔNG đụng (vd món đang chờ nộp Dã Tẩu)."""
        if not self.game_bot_connected:
            return
        exclude_slots = set(exclude_slots or ())
        try:
            occ = self._bag_occupied()
            if occ is None or occ < threshold:
                return
            bag = [it for it in (self.game_bot.dump_bag_items() or {}).get('items', []) if it.get('location') == 2]
            moved = 0
            for it in bag:
                if it.get('slot') in exclude_slots:            # món đang chờ nộp -> giữ
                    continue
                if it.get('genre') != 6:                       # chỉ cất consumable/stackable g6 (giữ gear khác genre)
                    continue
                if it.get('particular') in self.BAG_KEEP_PARTICULARS:   # thiết yếu -> giữ
                    continue
                if it.get('lockstate'):                        # khoá -> không cất (không giao dịch được)
                    continue
                idx = it.get('index')
                if idx is None:
                    continue
                try:
                    self.game_bot.send_gs('eItemLocationRequest', itemIndex=int(idx), itemLocation=3)
                    moved += 1
                    time.sleep(0.3)
                except Exception:
                    pass
                if occ - moved <= threshold - 5:               # giải phóng ~5 ô là đủ
                    break
            if moved:
                self._chat(f"📦 Túi gần đầy ({occ} ô) → cất {moved} món vào KHO (giữ đồ thiết yếu/khoá). "
                           f"Sẽ lấy lại từ kho khi giao thủ quỹ.")
        except Exception as e:
            logger.info(f"[bag_full] {e}")

    def _retrieve_giveset_from_storage(self):
        """Trước khi giao thủ quỹ: LẤY LẠI đồ give-set đang ở KHO (location 3) về TÚI (eItemLocationRequest
        itemLocation=2) để giao. Trả số món đã rút. (đồ give-set có thể đã bị _stash_full_bag cất vào kho.)"""
        if not self.game_bot_connected:
            return 0
        try:
            from core import treasurer as _T
            parts = _T.give_particulars(_T.load_config().get('give_names'))
            in_kho = [it for it in (self.game_bot.dump_bag_items() or {}).get('items', [])
                      if it.get('location') == 3 and it.get('particular') in parts and not it.get('lockstate')]
            n = 0
            for it in in_kho[:16]:
                idx = it.get('index')
                if idx is None:
                    continue
                try:
                    self.game_bot.send_gs('eItemLocationRequest', itemIndex=int(idx), itemLocation=2)
                    n += 1
                    time.sleep(0.3)
                except Exception:
                    pass
            if n:
                self._chat(f"📤 Lấy {n} món give-set từ kho về túi để giao thủ quỹ.")
                time.sleep(0.8)
            return n
        except Exception as e:
            logger.info(f"[retrieve_giveset] {e}")
            return 0

    # Thợ rèn theo map (seed Biện Kinh 37=1722 — bắt gói live; thành khác cần bổ sung node khi gặp).
    SMITH_NPC_BY_MAP = {37: "1722"}

    def _repair_all_equipped(self):
        """SỬA TẤT CẢ trang bị đang mặc ở thợ rèn (packet thuần — verify gói live 2026-06-11):
        eNpcDialogue(thợ rèn) -> eNpcSelect(1) -> eNpcSelect(1) -> eNpcSelect() -> server hồi độ bền (op233).
        Gọi TRƯỚC khi lên bãi cày (mặc định, theo user). Node thợ rèn SAI thành -> no-op vô hại (log)."""
        if not self.game_bot_connected:
            return
        try:
            mid = (self.game_bot.rpc.get_player_info() or {}).get('mapId')
            smith = self.SMITH_NPC_BY_MAP.get(int(mid)) if mid is not None else None
            smith = smith or "1722"
            if hasattr(self.game_bot, 'recv_buffer'):
                self.game_bot.recv_buffer = []
            self.game_bot.send_gs('eNpcDialogue', npcId=str(smith)); time.sleep(1.0)
            self.game_bot.send_gs('eNpcSelect', selectIndex=1); time.sleep(0.8)
            self.game_bot.send_gs('eNpcSelect', selectIndex=1); time.sleep(0.8)
            self.game_bot.send_gs('eNpcSelect'); time.sleep(0.5)
            # verify: server trả op233 (eSyncItemDurability) = đã sửa. Poll ~2s.
            repaired = False; t0 = time.time()
            while time.time() - t0 < 2.0:
                for p in (self.game_bot.poll_recv() or []):
                    if p.get('opcode') == 233:
                        repaired = True
                if repaired:
                    break
                time.sleep(0.2)
            self._clear_popups("đóng thợ rèn")
            if repaired:
                self._chat("🔧 Đã sửa tất cả trang bị đang mặc (trước khi lên bãi).")
            else:
                logger.info(f"[REPAIR] gửi sửa-all (thợ rèn {smith}, map {mid}) — chưa thấy op233 "
                            f"(node thợ rèn thành này có thể khác).")
        except Exception as e:
            logger.info(f"[REPAIR] lỗi: {e}")

    def _prep_for_dochi_travel(self):
        """Chuẩn bị Ở THÀNH trước khi lên động: SỬA ALL trang bị + mua Thổ Địa Phù (thiết yếu) + thuốc, RỒI cất
        bạc giữ 1000. Trả số TDP trong túi (0 = KHÔNG nên lên động). Gọi lúc đầu + sau khi CHẾT."""
        import json as _json
        try:
            _tcfg = _json.load(open(self.game_bot.TDP_CFG_PATH, encoding="utf-8"))
        except Exception:
            _tcfg = {}
        _tqty = int(_tcfg.get("qty", 4) or 4)
        _tcost = int(_tcfg.get("cost_per", 1000) or 1000)
        ntdp = 0
        try:
            if self._ensure_money(_tqty * _tcost):   # thiếu -> rút kho; (sau khi cất bạc, tiền nằm ở kho)
                ntdp = self.game_bot.buy_tdp()
                logger.info(f"[ĐỒ CHÍ] Thổ Địa Phù trong túi: {ntdp}.")
            else:
                self._chat("💰 Không đủ tiền mua Thổ Địa Phù.")
        except Exception as e:
            logger.error(f"[TDP] mua lỗi: {e}")
            try:
                ntdp = self.game_bot.count_tdp_in_bag()
            except Exception:
                ntdp = 0
        self._buy_potions_before_dochi()       # thuốc (tùy chọn) — mua SAU TDP
        self._repair_all_equipped()            # SỬA ALL trang bị TRƯỚC khi lên bãi (mặc định, theo user)
        self._stash_money_keep(1000)           # cất bạc giữ 1000 TRƯỚC khi lên động (chống mất khi bị giết)
        return ntdp

    def _buy_potions_before_dochi(self):
        """Mua sẵn thuốc TRƯỚC khi THP đi cày đồ chí/mật chí (theo lựa chọn trên UI).
        Đọc config {name, shopkey, itemindex, qty}. qty<=0 / chưa cấu hình -> BỎ QUA (không chặn NV).
        Mua remote theo shopkey (không cần đứng đúng thành). Verify bằng tổng stack trong túi tăng.
        Server có thể chỉ cộng 1 stack/lần mua -> nếu mua 1 phát không đủ thì lặp tới khi đủ qty."""
        import json as _json
        try:
            cfg = _json.load(open(self.POTION_CFG_PATH, encoding="utf-8"))
        except Exception:
            cfg = None
        if not cfg or cfg.get("itemindex") is None or not cfg.get("shopkey"):
            return   # chưa chọn thuốc trên UI -> bỏ qua im lặng
        qty = int(cfg.get("qty", 0) or 0)
        if qty <= 0:
            return
        name = cfg.get("name", "thuốc"); shopkey = cfg["shopkey"]; idx = int(cfg["itemindex"])
        part = cfg.get("particular")

        def _count_potion():
            """Đếm SỐ thuốc loại này (theo particular = file id) trong TÚI. None nếu chưa biết particular."""
            if part is None:
                return None
            try:
                d = self.game_bot.dump_bag_items()
                return sum((it.get("stack", 1) or 1) for it in (d.get("items", []) if d and d.get("ok") else [])
                           if it.get("genre") == 6 and it.get("particular") == part and it.get("location") == 2)
            except Exception:
                return None

        have = _count_potion()
        # MUA BÙ tới ĐÚNG qty (max), KHÔNG vượt: có 30/50 -> mua 20; có >=50 -> khỏi mua.
        if have is not None and have >= qty:
            self._chat(f"💊 Đã có {have} {name} (>= {qty}) → khỏi mua.")
            return
        need = (qty - have) if have is not None else qty
        if need <= 0:
            return
        # Thuốc RẺ (~1000 lượng/bình, vd 50 Thất Khiếu ≈ 5 vạn). Ước theo cost_per config (mặc định 1200,
        # có đệm nhẹ). Mua thuốc là TÙY CHỌN -> optional=True: thiếu thì BỎ QUA, KHÔNG tô đỏ/PENDING.
        cost_per = int(cfg.get("cost_per", 1200) or 1200)
        if not self._ensure_money(need * cost_per, optional=True):
            self._chat(f"💰 Không đủ tiền mua {need} {name} (~{fmt_money(need*cost_per)}) — bỏ qua, vẫn đi cày.")
            return
        self._chat(f"💊 {name}: có {have if have is not None else '?'}/{qty} → mua thêm {need}...")
        try:
            self.game_bot.buy_item_remote(shopkey, idx, need)   # mua LÔ qty=need (bù, KHÔNG vượt qty)
        except Exception as e:
            logger.error(f"[POTION] mua lỗi: {e}")
            return
        time.sleep(1.5)
        after = _count_potion()
        if after is not None and have is not None:
            self._chat(f"💊 Đã mua thêm {after - have} {name} (giờ {after}/{qty}).")
        else:
            self._chat(f"💊 Đã gửi lệnh mua {need} {name} (chưa verify được — thiếu particular).")

    def _buy_and_get_key(self, shopkey, itemindex, qty=1):
        """Mua remote 1 itemindex (đứng im), trả _key MỚI trong rương (= itemId GiveBox) hoặc None.
        _key đọc qua dump_bag_items (KHÔNG dùng get_bag_slots = vị trí ô)."""
        keys_before = set()
        dump_b = self.game_bot.dump_bag_items()
        if dump_b and dump_b.get("ok"):
            keys_before = {it.get("slot") for it in dump_b.get("items", [])}
        if hasattr(self.game_bot, 'recv_buffer'):
            self.game_bot.recv_buffer = []
        self.game_bot.buy_item_remote(shopkey, itemindex, qty)
        # CHỜ THÍCH NGHI (tăng tốc): poll túi tới khi món MỚI vào rương -> BREAK NGAY (thường ~0.7s), tối đa 2.2s.
        # Thay cho 1.0 + 1.5(log) + 4×0.7 cứng (~5.3s) -> nhanh hơn nhiều khi server phản hồi nhanh, vẫn bền nếu chậm.
        resp_ops = []
        t0 = time.time()
        while time.time() - t0 < 2.2:
            for p in (self.game_bot.poll_recv() or []):
                resp_ops.append(p.get('opcode'))
            dump_a = self.game_bot.dump_bag_items()
            if dump_a and dump_a.get("ok"):
                new_keys = {it.get("slot") for it in dump_a.get("items", [])} - keys_before
                if new_keys:
                    logger.info(f"[BUY] idx={itemindex} OK vào rương sau {time.time()-t0:.1f}s, resp_ops={resp_ops[:6]}")
                    return list(new_keys)[0]
            time.sleep(0.3)
        logger.info(f"[BUY] idx={itemindex} KHÔNG vào rương (2.2s), resp_ops={resp_ops[:8]}")
        return None

    def _money_info(self):
        """Đọc bạc CHUẨN qua method PlayerMain (getMoney RPC): {bagarate, storage}.
        Trả (carried, storage) int — None nếu đọc hụt. (offset 0x50 cũ hay trả 3 = SAI nên bỏ.)"""
        try:
            m = self.game_bot.rpc.get_money()
        except Exception:
            m = None
        if m and m.get('ok'):
            try:
                bag = int(m['bagarate']) if m.get('bagarate') is not None else None
            except Exception:
                bag = None
            try:
                sto = int(m['storage']) if m.get('storage') is not None else None
            except Exception:
                sto = None
            return bag, sto
        return None, None

    def _carried_money(self):
        """Bạc MANG THEO (GetBagarateMoney). None nếu đọc hụt -> KHÔNG đoán 'nghèo' rồi rút bừa."""
        return self._money_info()[0]

    def _ensure_money(self, need, optional=False):
        """Đảm bảo bạc MANG THEO (túi) >= need TRƯỚC khi mua/tiêu tiền.
        - Túi đủ -> True.
        - Túi thiếu nhưng túi+kho đủ -> RÚT từ Tiền Trang cho đủ (+đệm), re-check -> True.
        - TỔNG (túi+kho) KHÔNG đủ + optional=False (chi BẮT BUỘC) -> tô ĐỎ tên + PENDING -> False.
        - TỔNG KHÔNG đủ + optional=True (mua TÙY CHỌN, vd thuốc) -> CHỈ bỏ qua, KHÔNG PENDING -> False.
        - Đọc hụt bạc -> coi như đủ (True), KHÔNG chặn (user thường giữ sẵn nhiều bạc)."""
        need = int(need)
        carried, storage = self._money_info()
        if carried is None:
            return True                      # đọc hụt -> không chặn
        if carried >= need:
            return True
        total = carried + (storage or 0)
        if total < need:                     # túi + kho vẫn KHÔNG đủ
            # THỦ QUỸ: thiếu tiền (mua VẬT PHẨM bắt buộc HOẶC MÁU/thuốc tùy chọn) -> tới thủ quỹ nhận tiền
            # (theo ngân lượng config, 1 LẦN/NV) rồi re-check. Áp dụng cho CẢ optional lẫn không (logic 1).
            # Mua remote (không phụ thuộc vị trí) nên nhận tiền xong cày/mua tiếp được.
            try:
                from core import treasurer as _T
                qkey = id(self.current_quest)
                if (_T.treasurer_device() and not _T.is_treasurer_device(self.device_id) and _T.read_info()
                        and getattr(self, '_money_errand_qkey', None) != qkey):
                    self._money_errand_qkey = qkey
                    self._chat(f"💰 Thiếu tiền → tới thủ quỹ nhận {_T.give_money()//10000} vạn…")
                    self._just_did_money_trip = True   # ĐÃ di chuyển tới thủ quỹ → sạp cid/idx cũ STALE: caller phải RE-SCAN
                    if self._do_treasurer_errand('money'):
                        c3, _ = self._money_info()
                        if c3 is not None and c3 >= need:
                            return True
            except Exception as e:
                logger.error(f"[ensure_money treasurer] {e}")
            if optional:
                # mua tùy chọn (thuốc/máu) + thủ quỹ vẫn không đủ -> BỎ QUA, KHÔNG tô đỏ/PENDING.
                return False
            self._need_help(f"💰 THIẾU TIỀN: cần {fmt_money(need)} nhưng chỉ có {fmt_money(total)} "
                            f"(túi {fmt_money(carried)} + kho {fmt_money(storage or 0)}). "
                            f"Cần giao dịch/bán đồ để có bạc.")
            return False
        # túi+kho đủ -> rút từ kho cho đủ (+ đệm 1 vạn), không vượt quá kho
        want = need - carried + 10000
        amt = min(want, storage)
        self._chat(f"Bạc túi {fmt_money(carried)} < cần {fmt_money(need)} → rút {fmt_money(amt)} "
                   f"từ Tiền Trang (kho {fmt_money(storage)})...")
        sto_before = storage
        try:
            self.game_bot.send_gs('eSendStorageMoney', moneyToStorage=-int(amt))
        except Exception:
            pass
        # POLL tới ~6s thay vì recheck-0.8s-một-lần: bạc kho→túi có ĐỘ TRỄ (client cập nhật GetBagarateMoney
        # SAU khi nhận+xử lý gói server trả; lag/đông người càng trễ). Đủ tiền giữa chừng -> True NGAY (hết
        # PENDING oan kiểu "chết vài lần"). Nếu ~2.5s kho CHƯA tụt = gói rút bị bỏ → GỬI LẠI 1 lần.
        c2, sto2 = carried, storage
        sent_retry = False
        for i in range(12):
            if self._stopping():
                return False
            time.sleep(0.5)
            c2, sto2 = self._money_info()
            if c2 is not None and c2 >= need:
                return True
            if (not sent_retry and i >= 4 and sto2 is not None and sto_before is not None
                    and sto2 >= sto_before):                  # kho không tụt sau ~2.5s -> gửi lại lệnh rút
                sent_retry = True
                self._chat("💰 Kho chưa tụt sau khi rút → gửi lại lệnh rút 1 lần…")
                try:
                    self.game_bot.send_gs('eSendStorageMoney', moneyToStorage=-int(amt))
                except Exception:
                    pass
        # hết poll vẫn thiếu -> LOG kho trước→sau để biết TIMING (kho đã tụt, bạc chưa vào) hay SERVER TỪ CHỐI
        # (kho không tụt) thay vì đoán mò, rồi mới PENDING.
        rejected = (sto2 is not None and sto_before is not None and sto2 >= sto_before)
        self._need_help(f"💰 Rút bạc xong VẪN thiếu (túi {fmt_money(c2)} < cần {fmt_money(need)}; "
                        f"kho {fmt_money(sto_before)}→{fmt_money(sto2)}). "
                        + ("Kho KHÔNG tụt = server TỪ CHỐI lệnh rút (cần xem context Tiền Trang)."
                           if rejected else "Kho ĐÃ tụt nhưng bạc chưa vào túi (trễ/lag).")
                        + " Cần giao dịch để có bạc.")
        return False

    RIU_SIG_PATH = "data/output/datau_riu_item.json"
    RIU_COUNT_PATH = "data/output/riu_count.json"   # đếm rìu PERSIST theo account/ngày (sống qua restart)
    RIU_PARTICULAR = 33   # 'Dã Tẩu Hoàn Thành Lệnh' = item_magicscript particular 33 (định danh trong rương)
    RIU_DAILY_CAP = 15    # dùng rìu đủ ngần này lần (1 account) → coi như hết NV ngày → giao thủ quỹ + đổi acc

    def _riu_count_key(self):
        """Khoá đếm rìu theo ACCOUNT (acc trong queue → player_name → device)."""
        acc = ''
        try:
            if 0 <= self.account_index < len(self.account_queue):
                acc = self.account_queue[self.account_index].get('acc') or ''
        except Exception:
            pass
        return acc or self.player_name or self.device_id

    def _riu_count_today(self):
        """Số lần đã dùng rìu HÔM NAY của account hiện tại (persist — KHÔNG mất khi restart UI)."""
        try:
            data = self._read_json(self.RIU_COUNT_PATH) or {}
            return int((data.get(self._today_str()) or {}).get(self._riu_count_key(), 0))
        except Exception:
            return 0

    def _bump_riu_count(self):
        """+1 đếm rìu hôm nay (atomic, nhiều cửa sổ ghi chung file). Trả số mới."""
        try:
            with _SHARED_FILE_LOCK:
                data = self._read_json(self.RIU_COUNT_PATH) or {}
                day = self._today_str(); key = self._riu_count_key()
                day_map = data.get(day) or {}
                day_map[key] = int(day_map.get(key, 0)) + 1
                data[day] = day_map
                _atomic_write_json(self.RIU_COUNT_PATH, data)
                return day_map[key]
        except Exception as e:
            logger.error(f"[riu] bump count lỗi: {e}")
            return self._riu_count_today()

    def _load_riu_sig(self):
        """Signature (g/d/p) của rìu ĐÃ HỌC (sniff lúc bấm Dùng). None nếu chưa học."""
        try:
            import json as _j
            with open(self.RIU_SIG_PATH, encoding="utf-8") as f:
                d = _j.load(f)
            return d if isinstance(d, dict) and d else None
        except Exception:
            return None

    def _save_riu_sig(self, riu):
        """HỌC signature rìu (genre/detail/particular) khi đã xác nhận đúng rìu (dùng -> ra 245) -> lần sau
        match CHÍNH XÁC, hết nhầm với đồ Tống Kim trùng particular 33."""
        try:
            import json as _j
            sig = {k: riu.get(k) for k in ("genre", "detail", "particular") if riu.get(k) is not None}
            if sig.get("particular") == self.RIU_PARTICULAR:
                with open(self.RIU_SIG_PATH, "w", encoding="utf-8") as f:
                    _j.dump(sig, f, ensure_ascii=False)
                logger.info(f"[RIU] đã HỌC signature rìu: {sig}")
        except Exception as e:
            logger.info(f"[RIU] lưu sig lỗi: {e}")

    def _find_riu_in_bag(self, items):
        """Tìm rìu trong rương. RÌU THẬT (verify live qua log) = genre 6, detail 1, **particular 33** — và
        particular 33 trong túi DUY NHẤT là rìu (KHÔNG trùng món khác). -> chỉ cần match particular==33.
        (BÀI HỌC: từng GIẢ ĐỊNH rìu genre 0 + loại genre 6 -> loại nhầm chính con rìu -> 'hết rìu' giả ->
        hoàn thành sai + đổi account. Rìu Ở genre 6 — TUYỆT ĐỐI không loại genre 6.)"""
        cands = [it for it in (items or []) if it.get("particular") == self.RIU_PARTICULAR]
        if cands:
            logger.info("[RIU] ứng viên particular=33 (rìu): " +
                        ", ".join(f"slot{c.get('slot')}(g{c.get('genre')},d{c.get('detail')})" for c in cands))
        return cands[0] if cands else None

    def _use_datau_riu(self):
        """WORKFLOW ĐÚNG (user): chuột phải DÙNG rìu -> mở Dã Tẩu (chọn dt) -> nhấn 'Đã hoàn thành nv'
        -> nhận thưởng. KHÁC turn-in thường: rìu đã thoả điều kiện nên KHÔNG cần GiveBox/nộp đồ.
           Trả STATUS: 'ok' (xong+thưởng) | 'no_axe' (hết rìu) | 'max' (đạt giới hạn dùng rìu hôm nay)
           | 'fail' (lỗi khác)."""
        if not self.game_bot_connected:
            self._chat("Chưa kết nối Frida — không dùng rìu được.")
            return 'fail'
        self._last_riu_frames = []            # reset để tích luỹ frames của ĐÚNG lượt dùng rìu này
        dump = self.game_bot.dump_bag_items()
        items = dump.get("items", []) if dump and dump.get("ok") else []
        riu = self._find_riu_in_bag(items)
        if not riu:
            self._chat("⚠️ Không thấy 'Dã Tẩu Hoàn Thành Lệnh' (rìu) trong rương (hết rìu).")
            return 'no_axe'
        key = riu.get("slot")
        if key is None:
            return 'fail'
        # 1) CHUỘT PHẢI DÙNG rìu (tiêu hao 1). Server thường TỰ hoàn thành NV + bắn 245 NGAY.
        self._chat(f"🪓 Dùng rìu (itemindex {key})...")
        if hasattr(self.game_bot, 'recv_buffer'):
            self.game_bot.recv_buffer = []
        self.game_bot.send_gs('ePlayerUserItem', itemindex=int(key))
        # 2) BẮT 245 NGAY sau khi dùng (TRƯỚC khi đụng dialog — open_datau XOÁ buffer nên không gọi vội).
        award_hex = self._capture_award_245(3.0)
        if award_hex:
            self._save_riu_sig(riu)   # dùng -> ra 245 NGAY = item này ĐÚNG là rìu -> HỌC sig (lần sau exact)
        # 3) Chưa ra thưởng -> thử workflow tay: mở Dã Tẩu (chọn dt) + nhấn 'Đã hoàn thành nv'.
        if not award_hex:
            self._chat("…chưa thấy thưởng ngay, thử mở Dã Tẩu + nhấn 'Đã hoàn thành nv'.")
            self.open_datau()
            self._select_pkt()   # 'Đã hoàn thành nv' (nút chính)
            award_hex = self._capture_award_245(3.0)
        if not award_hex:
            self.npc_interact.dismiss_dialog()
            self._datau_dialog_open = False
            if self._riu_response_says_max():
                self._chat("🪓 Rìu ĐÃ ĐẠT GIỚI HẠN dùng hôm nay (max) → sẽ giao đồ thủ quỹ + đổi account.")
                return 'max'
            # Server MỞ GIVEBOX (126) thay vì trả 245 = rìu KHÔNG hoàn thành được NV này (đã dùng NHẦM item
            # trùng particular 33, hoặc rìu không áp cho loại NV này) -> đừng tưởng lỗi mạng.
            saw_givebox = any(op == 126 for op, _ in (getattr(self, '_last_riu_frames', None) or []))
            if saw_givebox:
                # Rìu = p33 (đã verify DUY NHẤT trong túi) → dùng xong server MỞ GiveBox (không trả 245) =
                # rìu KHÔNG hoàn thành được NV này: hầu hết do ĐÃ ĐẠT GIỚI HẠN RÌU hôm nay (server không cho
                # nữa) → coi như hết rìu ngày → giao đồ thủ quỹ + đổi account (KHÔNG PENDING oan, KHÔNG tự hủy).
                self._chat("🪓 Dùng rìu xong server MỞ GiveBox (không trả thưởng) = rìu đã hết tác dụng "
                           "(thường do ĐẠT GIỚI HẠN rìu hôm nay) → giao đồ thủ quỹ + đổi account.")
                return 'max'
            self._chat("⚠️ Dùng rìu xong KHÔNG bắt được 245 (cũng không mở GiveBox) → lỗi tạm/mạng. "
                       "Đứng chờ — KHÔNG tự hủy.")
            return 'fail'
        self._chat("✅ Rìu hoàn thành NV → có bảng thưởng 245.")
        try:
            return 'ok' if self._select_reward(prefetched_hex=award_hex) else 'fail'
        except Exception as e:
            logger.error(f"[RIU] select_reward lỗi: {e}")
            return 'fail'

    def _capture_award_245(self, secs=3.0):
        """Gom mọi gói server trả trong `secs`, TÁCH FRAME (server hay gộp 124+245) -> trả hex gói 245
        đầu tiên, hoặc None. Ghi dump để chẩn đoán."""
        from core.equip_matcher import split_frames
        seen = []
        t0 = time.time()
        while time.time() - t0 < secs:
            for p in (self.game_bot.poll_recv() or []):
                seen.append((p.get('opcode'), p.get('hex', '')))
            time.sleep(0.1)
        frames = []
        for op, hx in seen:
            sub = split_frames(hx)
            frames.extend(sub if sub else [(op, hx)])
        # TÍCH LUỸ (không ghi đè): _use_datau_riu gọi 2 lần (trước & sau open_datau) — gói "đã dùng hết"
        # ở lần ĐẦU sẽ mất nếu ghi đè. _use_datau_riu reset list về [] ở đầu mỗi lần dùng rìu.
        self._last_riu_frames = (getattr(self, '_last_riu_frames', None) or []) + frames
        try:
            with open(f"data/output/riu_response_dump_{self.device_id.replace(':','_')}.txt", "a", encoding="utf-8") as f:
                f.write(f"--- ops={[op for op,_ in frames]} ---\n")
                # GHI TEXT các gói thông báo (133 chat / 247 attention / 251 live) để biết server nói gì khi rìu fail
                for op, hx in frames:
                    if op in (133, 247, 251):
                        try:
                            bb = bytes.fromhex(hx)[6:]
                            t8 = bb.decode('utf-8', 'ignore'); t16 = bb.decode('utf-16-le', 'ignore')
                            t = t8 if sum(c.isprintable() for c in t8) >= sum(c.isprintable() for c in t16) else t16
                            t = ''.join(c for c in t if c.isprintable()).strip()
                            if t:
                                f.write(f"    [op{op}] {t[:140]!r}\n")
                        except Exception:
                            pass
        except Exception:
            pass
        return next((hx for op, hx in frames if op == 245), None)

    def _riu_response_says_max(self):
        """Quét các gói server vừa trả khi dùng rìu (247 eAttention2Player / 133 chat) -> có thông báo
        ĐẠT GIỚI HẠN dùng rìu hôm nay không? (để biết 'max' -> giao đồ + đổi account thay vì PENDING)."""
        import re
        KW = ('dùng hết', 'dung het', 'giới hạn', 'gioi han', 'hết lượt', 'het luot', 'hết số lần',
              'hôm sau', 'hom sau', 'tối đa', 'toi da', 'không thể dùng thêm')
        for op, hx in (getattr(self, '_last_riu_frames', None) or []):
            # quét MỌI opcode (thông báo 'đã dùng hết X lượt' có thể ở 247/133/251/...)
            try:
                b = bytes.fromhex(hx)[6:]
            except Exception:
                continue
            # rút chuỗi UTF-8 thô + UTF-16
            txt = ''
            try:
                txt += b.decode('utf-8', 'ignore').lower()
            except Exception:
                pass
            try:
                txt += ' ' + b.decode('utf-16-le', 'ignore').lower()
            except Exception:
                pass
            if any(k in txt for k in KW):
                return True
        return False

    def _handle_execute_buy(self):
        q = self.current_quest
        from core import npc_shop
        qtext = q.clean_text or q.raw_text or ""
        self._chat(f"NV MUA SHOP NPC: {q.item_count}x {q.item_name}")

        # Suy shopkey theo THÀNH/THÔN trong quest. KHÔNG quét sạp người chơi.
        shopkey = npc_shop.resolve_shopkey(qtext, q.item_name)
        if not shopkey:
            self._chat("Quest không nêu rõ thành/thôn -> tìm ở sạp người chơi.")
            self._goto_state(BotState.EXECUTE_FIND_EQUIP)
            return
        town = npc_shop.find_town(qtext)
        self._chat(f"→ Shop: {shopkey} ({town[0] if town else '?'})")
        if not self.game_bot_connected:
            self._chat("Chưa kết nối Frida.")
            self._goto_state(BotState.TRAINING)
            return

        # MUA SHOP (op148) BỊ CHẶN ở ĐỘNG/khu chiến đấu (server check map type) -> mua "không vào rương".
        # Nếu NV mua mà nhân vật đang ở động -> brute 22 món đều trượt -> PENDING ĐỨNG IM (đúng bug user báo:
        # "ở động không mua được nên phù về"). -> VỀ THÀNH TRƯỚC khi mua (mua remote OK ở BẤT KỲ thành nào,
        # không check khoảng cách). KHÔNG tự hủy NV nếu về thành fail.
        if not self._in_town():
            self._chat("⛏️ Đang ở động/khu chiến đấu — server chặn mua shop. Về thành trước khi mua...")
            if not self._recall_to_town():
                self._need_help("NV mua đồ nhưng đang ở động, về thành thất bại. Đưa nhân vật về thành rồi "
                                "bật lại Auto (KHÔNG tự hủy).")
                self._goto_state(BotState.TRAINING)
                return
            time.sleep(2.0)
            if self._stopping(): return
            if not self._in_town():
                self._need_help("NV mua đồ: đã phù về nhưng vẫn ở động. Cần bạn xem giúp (KHÔNG tự hủy).")
                self._goto_state(BotState.TRAINING)
                return
            self._chat("✅ Đã về thành — tiến hành mua.")

        is_horse = shopkey.startswith("trai.ngua")
        # NGỰA: trại ngựa chia theo HỆ (trai.ngua.0..4), KHÔNG theo thành. resolve_shopkey suy theo town-index
        # nên SAI hệ (vd Phượng Tường->trai.ngua.1=Mộc, trong khi 'Liệt Bạch Mã'=Kim=trai.ngua.2).
        # -> Tra shopkey ĐÚNG theo TÊN NGỰA trong shop_dict (mỗi tên ngựa chỉ ở 1 shop hệ).
        if is_horse:
            live0 = npc_shop.find_in_live_dict(q.item_name)
            if live0:
                if live0[0] != shopkey:
                    self._chat(f"NV ngựa: '{q.item_name}' thuộc hệ ở shop {live0[0]} (không phải {shopkey} theo thành) → sửa.")
                shopkey = live0[0]
        # MỞ SHOP TƯƠI TRƯỚC: server TIÊM món quest (đúng hệ) vào CUỐI shop, CHỈ thấy khi mở lúc có quest.
        # (Bug cũ: khớp TÊN trên data cũ -> mua nhầm 'Phi Đao hệ Mộc' (base) thay vì 'hệ Thổ' = món cuối.)
        ctx = npc_shop.load_shop_context(shopkey)
        if ctx:
            self._chat(f"Mở shop REMOTE đọc TƯƠI (context đã học)...")
            self.game_bot.open_shop_remote(ctx)
        else:
            self._chat("Mở shop LIVE đọc TƯƠI (cần nhân vật đứng ở NPC; sẽ học context cho lần sau)...")
            self.game_bot.open_shop_read()
        time.sleep(1.5)
        self.game_bot.poll_recv()   # để frida cập nhật shop_dict.json (món cuối = món quest tiêm vào)

        # MÓN CUỐI TƯƠI: đọc max itemindex RAW từ gói shop 119 vừa nhận (KHÔNG qua file/tên -> không bị
        # mất món quest tiêm vào). Đây là ứng viên ĐÚNG NHẤT (manh mối Dã Tẩu user xác nhận).
        fresh_last = None
        all_idxs = []   # TẤT CẢ itemindex trong shop (để brute hết ≤20 món nếu ứng viên ưu tiên trượt)
        try:
            hx = getattr(self.game_bot, 'last_shop_hex', '')
            ht = getattr(self.game_bot, 'last_shop_hex_t', 0)
            if hx and (time.time() - ht) < 8:
                from features.bot.shop_parser import parse_shop_indices
                pr = parse_shop_indices(hx)
                if pr:
                    sk2, idxs = pr
                    # CHỐNG MỞ NHẦM SHOP: open_shop_remote dùng TOẠ ĐỘ theo map; nếu nhân vật KHÔNG ở
                    # đúng map của shop, toạ độ trúng NPC khác -> sk2 KHÁC shopkey resolve (vd di-bảo).
                    # -> KHÔNG ghi đè shopkey + KHÔNG dùng idx shop nhầm (sẽ brute remote theo shopkey ĐÚNG).
                    same_class = sk2 and sk2.split('.')[:3] == shopkey.split('.')[:3]
                    if sk2 and not is_horse and not same_class:
                        self._chat(f"⚠️ Mở REMOTE ra NHẦM shop '{sk2}' (≠ '{shopkey}') — nhân vật không ở đúng "
                                   f"map. Bỏ qua shop nhầm, mua REMOTE theo shopkey ĐÚNG.")
                    else:
                        if sk2 and not is_horse:
                            shopkey = sk2
                        if not is_horse or sk2 == shopkey:
                            all_idxs = list(idxs)
                            fresh_last = (min(idxs) if is_horse else max(idxs))
                            self._chat(f"Shop TƯƠI {sk2}: {len(idxs)} món (idx {idxs[0]}..{idxs[-1]}) → "
                                       f"{'con đầu' if is_horse else 'MÓN CUỐI'} = idx {fresh_last}.")
        except Exception as e:
            logger.error(f"[EXECUTE_BUY] parse shop tươi lỗi: {e}")
        # Fallback all_idxs từ catalog shop_index nếu chưa có shop tươi (vd mở nhầm shop -> đã bỏ).
        cat_max = 0
        try:
            sh = npc_shop.load_shop_index().get(shopkey, {})
            cat_idxs = [it.get("itemindex") for it in sh.get("items", []) if it.get("itemindex")]
            if cat_idxs:
                cat_max = max(cat_idxs)
            if not all_idxs:
                all_idxs = list(cat_idxs)
        except Exception:
            pass
        # MÓN NV được server TIÊM vào CUỐI shop (chỉ thấy khi mở shop ĐÚNG lúc có quest). Khi không đọc
        # được shop tươi (vd mở nhầm map), brute REMOTE các idx VƯỢT catalog (max+1..max+6) theo shopkey
        # ĐÚNG — buy_item_remote mua theo key, server tự kiểm shop có món NV. Ưu tiên các idx này TRƯỚC.
        injected = []
        if not is_horse and cat_max:
            injected = [cat_max + k for k in range(1, 7)]
            for c in injected:
                if c not in all_idxs:
                    all_idxs.append(c)

        # Hệ (element) của món — để học/khớp vũ khí 'hệ X' (hệ KHÔNG có trong data shop).
        import re as _re
        em = _re.search(r"hệ\s+([^\s,\.\]]+)", qtext.lower())
        elem = (getattr(q, "element", "") or (em.group(1) if em else "")).lower().strip()

        # ỨNG VIÊN THEO ƯU TIÊN: (0) MUA TAY gần đây (≤180s, user vừa mua đúng món) -> CHÍNH XÁC nhất cho
        # vũ khí có hệ; (1) đã HỌC (tên|hệ); (2) món cuối tươi/file; (3) khớp tên; (4) hết shop.
        try_list = []
        manual_idx = None
        try:
            lb = getattr(self.game_bot, 'last_shop_buy', None)
            if lb and (time.time() - lb.get('ts', 0)) < 180:
                # ưu tiên đúng shopkey; nếu khác hạng nhưng cùng loại vũ khí (thành↔thành) vẫn dùng idx
                if lb.get('shopkey', '').split('.')[:2] == shopkey.split('.')[:2]:
                    manual_idx = lb.get('itemindex')
                    if manual_idx is not None:
                        self._chat(f"Dùng món bạn VỪA MUA TAY (idx {manual_idx} ở {lb.get('shopkey')}) làm ứng viên #1.")
                        try_list.append(manual_idx)
        except Exception:
            pass
        learned_hit = npc_shop.find_itemindex(shopkey, q.item_name, element=elem)
        if learned_hit and learned_hit[1].get("learned"):
            self._chat(f"📚 '{q.item_name}'{f' (hệ {elem})' if elem else ''} ĐÃ HỌC trước đó = idx {learned_hit[0]} "
                       f"ở {shopkey} → MUA THẲNG (không dò).")
            if learned_hit[0] not in try_list:
                try_list.append(learned_hit[0])
        else:
            self._chat(f"🔍 '{q.item_name}'{f' (hệ {elem})' if elem else ''} CHƯA học ở {shopkey} → phải DÒ ứng viên.")
        if fresh_last is not None and fresh_last not in try_list:
            try_list.append(fresh_last)
        pick = npc_shop.first_itemindex(shopkey) if is_horse else npc_shop.last_itemindex(shopkey)
        if pick and pick[0] not in try_list:
            try_list.append(pick[0])
        nm = learned_hit or npc_shop.find_itemindex(shopkey, q.item_name, element=elem)
        if nm and nm[0] not in try_list:
            try_list.append(nm[0])
        live = npc_shop.find_in_live_dict(q.item_name, prefer_shopkey=shopkey)
        if live and live[1] not in try_list:
            try_list.append(live[1])
        for c in npc_shop.candidate_itemindexes(shopkey, q.item_name):
            if c not in try_list:
                try_list.append(c)
        # NGỰA: thử từ idx NHỎ->LỚN (con rẻ trước); đồ thường: thử từ idx LỚN->NHỎ (món cuối hay là món NV).
        for c in (sorted(all_idxs) if is_horse else sorted(all_idxs, reverse=True)):
            if c not in try_list:
                try_list.append(c)
        learned_exact = False   # luôn verify bằng nộp-khớp (245); học lại idx thắng
        if not try_list:
            self._need_help(f"Chưa đọc được shop {shopkey} (mở shop này 1 lần khi có quest) và không suy "
                            f"được ứng viên cho '{q.item_name}'. Cần bạn xem giúp (KHÔNG tự hủy).")
            self._goto_state(BotState.TRAINING)
            return
        self._chat(f"Thử THẲNG TỚI KHI ĐÚNG ({len(try_list)} món, ưu tiên: {try_list[:4]}...). Trúng sẽ HỌC.")

        # KIỂM TIỀN trước khi mua: thiếu thì rút kho; túi+kho vẫn thiếu -> đỏ tên + báo, DỪNG (không mua bừa).
        # Đồ NV (tạp hóa/thợ rèn + NGỰA NỘP NV) đều RẺ: ngựa NV ~1 vạn (KHÁC ngựa cưỡi đắt), đồ thường vài
        # trăm–vài nghìn. Gate = SÁT giá thật để account NGHÈO (1.x vạn) KHÔNG bị chặn oan (cũ 2 vạn/5k quá cao).
        # config_money_gate.json có thể override {horse, item} nếu server giá khác.
        money_gate = 12000 if is_horse else 3000
        try:
            import json as _json
            _mg = _json.load(open("data/output/money_gate.json", encoding="utf-8"))
            money_gate = int(_mg.get("horse", 12000) if is_horse else _mg.get("item", 3000))
        except Exception:
            pass
        if not self._ensure_money(money_gate):
            self._goto_state(BotState.TRAINING)
            return

        # THỬ từng ứng viên (HẾT shop ≤22 món để chắc chắn tìm + học đúng món; nghỉ giữa lần tránh dồn Frida):
        # mua -> _key -> nộp -> verify(245). Đúng thì HỌC + xong.
        for itemindex in try_list[:22]:
            if self._stopping(): return
            try:
                _key = self._buy_and_get_key(shopkey, itemindex, q.item_count)
                if _key is None:
                    self._chat(f"  idx {itemindex}: mua xong không thấy vào rương → thử cái khác.")
                    time.sleep(0.5)   # giảm 1.5->0.5: tăng tốc thử ứng viên
                    continue
                self.target_givebox_slot = _key
                ok = self._datau_complete(_key)
            except Exception as e:
                logger.error(f"[EXECUTE_BUY] thử idx {itemindex} lỗi: {e}")
                self.npc_interact.dismiss_dialog()
                time.sleep(0.5)
                continue
            if ok:
                if not learned_exact:
                    npc_shop.save_learned(q.item_name, shopkey, itemindex, element=elem)
                    self._chat(f"🧠 ĐÃ HỌC: '{q.item_name}'{f' (hệ {elem})' if elem else ''} = idx {itemindex} ở {shopkey} (auto lần sau).")
                self._chat("✅ TRẢ NV THÀNH CÔNG.")
                self._on_quest_completed()
                self.current_quest = None
                self.target_givebox_slot = -1
                self._goto_state(BotState.IDLE_PRECHECK)
                return
            self._chat(f"  idx {itemindex}: nộp không khớp (sai món) → BÁN LẠI món nhầm + thử ứng viên khác.")
            # BÁN LẠI món mua nhầm để KHÔNG làm đầy rương (tránh Dã Tẩu từ chối giao NV vì full).
            try:
                self.game_bot.send_gs('eShopSellItem', itemid=int(_key))
            except Exception:
                pass
            self.npc_interact.dismiss_dialog()
            time.sleep(0.6)   # nghỉ ngắn tránh dồn Frida (giảm 1.5->0.6: tăng tốc)

        # KHÔNG tự hủy NV (cấm). Báo cần trợ giúp rồi ĐỨNG chờ.
        self._need_help(f"Đã thử {min(22,len(try_list))} món trong shop, chưa trả được '{q.item_name}'. "
                        f"Cần bạn xem giúp (KHÔNG tự hủy).")
        self.target_givebox_slot = -1
        self._goto_state(BotState.TRAINING)

    def _use_than_hanh_phu(self) -> bool:
        """ĐÃ VÔ HIỆU HOÁ: bot TUYỆT ĐỐI KHÔNG tap THP. Tap THP 'Nv Dã Tẩu' (640,242) = dịch chuyển
        tới MAP NHIỆM VỤ (thường là ĐỘNG/map 3x) -> kéo nhân vật đi lạc. User THP bằng tay, bot không đụng."""
        logger.info("[THP] Bỏ qua — bot KHÔNG tự dùng THP (tránh teleport tới động). User tự THP nếu cần.")
        return False

    def _navigate_xa_phu_to_map(self, target_map: str, quest_text: str = ""):
        logger.info("[THP] _navigate_xa_phu_to_map vô hiệu hoá (tránh teleport tới động).")
        return False

    def _navigate_thp_to_city(self, target_city: str) -> bool:
        logger.info("[THP] _navigate_thp_to_city vô hiệu hoá (tránh tap nhầm teleport).")
        return False

    def _handle_execute_combat(self):
        # NV đánh quái / tìm đồ chí-mật chí: THP→động → autoplay game cày → đủ → THP→TD → nộp.
        self._grind_dochi_quest()

    def _handle_execute_find_item(self):
        # Tìm mật chí/đồ chí = cũng cày quái trong động → dùng chung luồng.
        self._grind_dochi_quest()

    # ---- ĐỒ CHÍ / MẬT CHÍ: cày bằng AUTOPLAY game, theo dõi tiến độ qua QUEST TRACKER (il2cpp) ----
    def _read_dochi_acc(self, required: int, loai_want: str = 'đồ chí'):
        """IT-PRO realtime: SNIFF gói op=48 'đã nhặt được một thần bí <ĐỒ CHÍ|MẬT CHÍ> tổng tích lũy <N>'.
        Đồ chí và mật chí là 2 LOẠI RIÊNG, mỗi loại có MESSAGE riêng. ĐẾM SỐ message ĐÚNG LOẠI của NV này
        (loai_want) theo N phân biệt -> mỗi N = 1 pickup. NV mật chí phải đếm 'mật chí', KHÔNG đếm 'đồ chí'
        (và ngược lại) — nếu không sẽ 2/2 ảo còn town 0/2. Trả LIST N (đúng loại) trong DRAIN này."""
        try:
            res = self.game_bot.rpc.get_op48() or {}
            items = res.get('items') or []
        except Exception:
            return []
        import re as _re
        ns = []
        for hx in items:
            try:
                raw = bytes.fromhex(hx)
                op = raw[4] | (raw[5] << 8)
                txt = raw[6:].decode('utf-8', 'ignore')
            except Exception:
                continue
            if op != 48:
                continue
            tl = _re.sub(r'<[^>]*>', '', txt).lower()   # STRIP rich-text <color=...>
            if 'tích lũy' not in tl or ('đồ chí' not in tl and 'mật chí' not in tl):
                continue
            loai = 'mật chí' if 'mật chí' in tl else 'đồ chí'
            m = _re.search(r'tích\s*lũy\s*(\d+)', tl)
            logger.info(f"[ĐỒ CHÍ][raw48] loại={loai} (cần {loai_want}) N={m.group(1) if m else '?'}")
            if loai == loai_want and m:   # CHỈ đếm message ĐÚNG LOẠI của NV
                ns.append(int(m.group(1)))
        return ns

    def _read_dochi_ui(self, required: int, loai_want: str):
        """ĐỌC TỪ DATA ĐÃ LOAD (verified 2026-06-09): text TRACKER NV bền vững trên màn hình (TMP, KHÔNG phải
        NpcDialogInfiPc — cái đó rỗng lúc cày) = 'Nhiệm vụ thứ N... X/Y quyển Thần bí <đồ chí|mật chí>'.
        CÓ CẢ LOẠI lẫn X/Y, CẬP NHẬT LIVE -> tiến độ TUYỆT ĐỐI + ĐÚNG LOẠI (op=48 generic không phân biệt).
        Quét qua dump_quest_texts (mọi TMP chứa 'quyển/thần bí'). Trả X nếu khớp loai_want + Y==required."""
        import re as _re
        # (0) NGUỒN CHÍNH (verified live 2026-06-14): đọc THẲNG item 'Dã Tẩu' trong tracker NV trái
        #     (QuestItem(Clone) -> QuestContent). LUÔN hiện bất kể kênh 1/2/3 -> KHỎI cần chuyển kênh.
        #     Content khi làm NV đồ chí = 'Nhiệm vụ thứ N... X/Y quyển Thần bí <đồ chí|mật chí>'.
        try:
            rt = self.game_bot.rpc.read_datau_tracker() or {}
            # Quét CONTENT của item Dã Tẩu TRƯỚC, rồi MỌI item tracker (all) — title đôi khi KHÔNG nhận ra là
            # 'Dã Tẩu' (tên NV hiển thị khác) nên datau_content=None; tiến độ 'X/Y quyển Thần bí' vẫn nằm trong
            # content item khác -> quét hết cho chắc (bền hơn, vẫn lọc đúng loại + Y==required).
            blobs = [rt.get('datau_content') or '']
            blobs += [(it.get('content') or '') for it in (rt.get('all') or [])]
            for raw in blobs:
                cl = _re.sub(r'<[^>]*>', '', raw).lower()
                if 'thần bí' in cl and loai_want in cl:
                    m = _re.search(r'(\d+)\s*/\s*(\d+)', cl)
                    if m and int(m.group(2)) == required:
                        logger.info(f"[ĐỒ CHÍ][tracker] {loai_want} {m.group(1)}/{m.group(2)} (tracker NV, không cần kênh)")
                        return int(m.group(1))
        except Exception:
            pass
        # (1) FALLBACK: quét mọi TMP chứa 'quyển/thần bí' (nếu tracker item chưa đọc được).
        try:
            r = self.game_bot.rpc.dump_quest_texts() or {}
            texts = r.get('texts') or []
        except Exception:
            return None
        for t in texts:
            tl = _re.sub(r'<[^>]*>', '', str(t)).lower()
            if 'thần bí' not in tl or loai_want not in tl:
                continue
            m = _re.search(r'(\d+)\s*/\s*(\d+)', tl)
            if m and int(m.group(2)) == required:
                logger.info(f"[ĐỒ CHÍ][ui] {loai_want} {m.group(1)}/{m.group(2)} (tracker)")
                return int(m.group(1))
        return None

    def _read_dochi_progress(self, required: int):
        """Đọc X (đồ chí đã có) TRONG ĐỘNG — CHỈ đọc từ MEMORY/GÓI, KHÔNG query Dã Tẩu.
        Động KHÔNG có Dã Tẩu → tuyệt đối KHÔNG open_datau ở đây (sẽ quét NPC gần → nói chuyện NPC lạ).
        None nếu chưa đọc được (loop ở _grind_dochi_quest sẽ thử lại, không gây nhiễu)."""
        import re as _re
        KW = ('chí', 'quyển', 'Thần', 'tìm giúp', 'đồ')
        # (0) REALTIME: text dialog 'X/Y' do HOOK Open chụp NGAY lúc server push (mỗi lần nhặt tấm).
        #     Nhẹ nhất (chỉ đọc global, KHÔNG gc.choose) + tức thì. Ưu tiên cao nhất.
        try:
            rt = self.game_bot.rpc.get_last_dialog_text()
            if rt and rt.get('ok'):
                txt = rt.get('text') or ''
                m = _re.search(r'(\d+)\s*/\s*(\d+)', txt)
                if m and int(m.group(2)) == required and any(k in txt for k in KW):
                    logger.info(f"[ĐỒ CHÍ][read][realtime] {txt[:60]!r}")
                    return int(m.group(1))
        except Exception:
            pass
        # (1) readQuestTracker: dialog NPC qua PopUpCanvas.instance (static) -> không gc.choose.
        try:
            r = self.game_bot.rpc.read_quest_tracker()
        except Exception as e:
            logger.info(f"[ĐỒ CHÍ][read] read_quest_tracker lỗi: {e}")
            r = None
        if r and r.get('ok'):
            items = r.get('items') or []
            # m_text dialog là RICH-TEXT TMP: số "17/15" bị bọc tag màu (vd '17</color>/<color>15') ->
            # regex \d+/\d+ trượt. PHẢI strip tag <...> trước khi match.
            def _strip(s):
                return _re.sub(r'<[^>]*>', '', s or '')
            logged = [(it.get('key'), _strip(it.get('content') or it.get('title') or '')[:60]) for it in items]
            logger.info(f"[ĐỒ CHÍ][read] tracker {len(items)} item, diag={r.get('diag')} | {logged}")
            for it in items:
                blob = _strip(f"{it.get('title','')} {it.get('content','')}")
                m = _re.search(r'(\d+)\s*/\s*(\d+)', blob)
                if m and int(m.group(2)) == required and any(k in blob for k in KW):
                    return int(m.group(1))
        elif r:
            logger.info(f"[ĐỒ CHÍ][read] tracker fail: {r.get('error')} diag={r.get('diag')}")
        # ⚠️ ĐÃ BỎ fallback read_quest_progress (quét TMP bằng gc.choose -> STOP-THE-WORLD đơ game).
        #    readQuestTracker (PopUpCanvas, không gc.choose) đã đủ đọc 'X/15'.
        return None   # đọc memory chưa ra -> loop sẽ thử lại (KHÔNG query Dã Tẩu, KHÔNG gc.choose)

    def _read_dochi_via_datau(self, required: int):
        """Đọc X qua QUERY Dã Tẩu (open_datau) — chỉ dùng KHI Ở THÀNH (có Dã Tẩu)."""
        import re as _re
        pkts = self.open_datau()
        if not pkts:
            return None
        from core.quest import parse_quest_dialog
        for p in pkts:
            try:
                body = bytes.fromhex(p['hex'])[6:]
                q = parse_quest_dialog(body, opcode=p.get('opcode', 124))
            except Exception:
                continue
            ct = (getattr(q, 'clean_text', '') or '') if q else ''
            m = _re.search(r'(\d+)\s*/\s*(\d+)', ct)
            if m and int(m.group(2)) == required:
                return int(m.group(1))
        return None

    def _dochi_quest_from_memory(self):
        """Đọc dump_quest_texts (TMP trên màn — KHÔNG query Dã Tẩu) tìm NV ĐỒ CHÍ/MẬT CHÍ đang có dạng
        'Nhiệm vụ thứ N ... X/Y quyển Thần bí <đồ chí|mật chí>'. Trả QuestInfo dựng lại (clean_text + quest_number
        + target_map), hoặc None. Nhiều dòng (có NV cũ sót) -> chọn NV số LỚN NHẤT (mới nhất)."""
        import re as _re
        try:
            r = self.game_bot.rpc.dump_quest_texts() or {}
            texts = r.get('texts') or []
        except Exception:
            return None
        best = None  # (qno, full_text)
        for t in texts:
            low = (t or '').lower()
            if 'quyển' not in low or 'thần bí' not in low:
                continue   # CHỈ NV đồ chí/mật chí (loại cày trong động)
            if not _re.search(r'(\d+)\s*/\s*(\d+)\s*quyển\s*thần\s*bí', low):
                continue
            mn = _re.search(r'nhiệm vụ thứ\s*(\d+)', low)
            qno = int(mn.group(1)) if mn else 0
            if best is None or qno > best[0]:
                best = (qno, t)
        if not best:
            return None
        from core.quest import QuestInfo
        qno, full = best
        low = full.lower()
        loai = 'mật chí' if 'mật chí' in low else 'đồ chí'
        md = _re.search(r'đến\s+(.+?động)\s+tìm', low)   # tên động (target_map, để nộp/tham chiếu)
        q = QuestInfo()
        q.quest_number = qno
        q.clean_text = full
        q.raw_text = full
        q.item_name = f"Thần bí {loai}"     # item_name != '' -> is_valid = True
        q.target_map = (md.group(1).strip() if md else '')
        q.opcode = 124
        return q

    def _resume_grind_in_dong(self):
        """Đang Ở ĐỘNG + đã có NV đồ chí/mật chí (current_quest dựng từ memory) -> cày TẠI CHỖ:
        KHÔNG recall/mua TDP/travel (đã ở động rồi). autoplay + monitor -> đủ -> nộp. Giải quyết lỗi loạn
        khi tắt/bật Auto giữa lúc đang cày trong động (trước đây đi query Dã Tẩu trong động)."""
        import re as _re
        q = self.current_quest
        text = (getattr(q, 'clean_text', '') or '')
        m = _re.search(r'(\d+)\s*/\s*(\d+)', text)
        if not m:
            self._goto_state(BotState.MOVE_TO_DATAU); return   # không parse được -> rơi về flow cũ
        cur, required = int(m.group(1)), int(m.group(2))
        self._dochi_loai = 'mật chí' if 'mật chí' in text.lower() else 'đồ chí'
        if cur >= required:
            self._chat(f"✅ NV {self._dochi_loai} đã đủ ({cur}/{required}) → về thành nộp.")
            self._turn_in_dochi(thp_home_first=True, required=required); return
        self._chat(f"⚔️ (Tiếp tục trong động) {self._dochi_loai} {cur}/{required} → bật auto cày tới đủ.")
        # BẬT AUTO TRƯỚC rồi buff SAU (char đang đánh, không đứng im chịu chết lúc nhận buff remote).
        if not self.game_bot.start_autoplay(arm=False):
            self._chat(self._autoplay_fail_msg())
        try: self._maybe_receive_buff(force=True)
        except Exception: pass
        outcome = self._monitor_dochi_grind(required, cur, self._dochi_loai)   # 'done' | 'check'
        self.game_bot.stop_autoplay()
        if not self.game_bot_connected:
            return
        if outcome == 'done':   # kẹt đọc đã xử lý TRONG monitor (hỏi Dã Tẩu remote từ động), không còn 'verify'
            self._turn_in_dochi(thp_home_first=True, required=required)
        else:
            self._need_help("Đồ chí (tiếp trong động) dừng bất thường (auto tắt/mất kết nối?). "
                            "Kiểm tra rồi Resume. KHÔNG tự hủy.")

    def _record_tlh_gain(self):
        """Ghi nhận MỌI lần Thiết La Hán (particular 2) VÀO TÚI — mọi nguồn (thưởng/đồ-chí/nhặt) → tracker
        'tlh_gain' để thống kê đếm ĐỦ từ log, KHÔNG phụ thuộc giao thủ quỹ (char lỗi vẫn tính). Throttle ~15s.
        Mốc reset khi đổi account (player_name='' → _tlh_seen=None) để không tính TLH có sẵn của acc mới."""
        if not self.game_bot_connected:
            return
        now = time.time()
        if now - getattr(self, '_tlh_chk_ts', 0) < 15:
            return
        self._tlh_chk_ts = now
        try:
            d = self.game_bot.dump_bag_items()
            if not d or not d.get('ok'):
                return
            cur = sum((x.get('stack') or 1) for x in d.get('items', [])
                      if x.get('particular') == 2 and x.get('location') == 2)
        except Exception:
            return
        prev = getattr(self, '_tlh_seen', None)
        self._tlh_seen = cur
        if prev is None:
            return                                  # baseline (mới login) — KHÔNG log đồ có sẵn
        if cur > prev:                              # TÚI tăng = vừa nhận thêm TLH → log delta
            try:
                tracker.record(self.device_id, "tlh_gain", char=self.player_name, qty=cur - prev)
            except Exception:
                pass

    def _grind_dochi_quest(self):
        import re as _re
        q = self.current_quest
        text = (getattr(q, 'clean_text', '') or getattr(q, 'raw_text', '') or '')
        m = _re.search(r'(\d+)\s*/\s*(\d+)', text)
        if not m:
            self._need_help(f"NV đồ chí nhưng KHÔNG đọc được X/N từ: {text[:60]!r}. Đứng chờ (KHÔNG tự hủy).")
            self._goto_state(BotState.TRAINING)
            return
        cur, required = int(m.group(1)), int(m.group(2))
        # LOẠI quyển: 'mật chí' hay 'đồ chí' — gói op=48 lúc nhặt CÓ PHÂN BIỆT 2 loại. Monitor PHẢI đếm ĐÚNG
        # loại của NV này (NV mật chí mà đếm đồ chí -> 2/2 ảo, town 0/2). Lấy từ text quest.
        self._dochi_loai = 'mật chí' if 'mật chí' in text.lower() else 'đồ chí'
        self._dochi_autoclaimed = False   # reset cờ "đã nhận thưởng tại động" cho NV đồ-chí mới

        # XOÁ text dialog 'X/Y' CŨ (từ NV đồ chí trước) để pre-check KHÔNG đọc nhầm -> tưởng đủ -> bỏ cày/mua TDP.
        try:
            self.game_bot.rpc.clear_dialog_text()
        except Exception:
            pass

        # KHÔNG dùng pre-check memory (hook dialog hay đọc STALE 'X/N' của NV CŨ -> tưởng đủ -> nộp sai 0/N).
        # Tin 'cur' từ TEXT QUEST (do Dã Tẩu vừa trả ở READ_QUEST = tiến độ THẬT của NV này).
        # ĐÃ ĐỦ sẵn (text quest báo cur>=required) -> nộp luôn; còn lại -> đi cày.
        if cur >= required:
            self._chat(f"✅ NV {self._dochi_loai} đã đủ ({cur}/{required}) -> về thành nộp luôn.")
            self._turn_in_dochi(thp_home_first=True, required=required)
            return

        logger.info(f"[ĐỒ CHÍ] NV {self._dochi_loai}: cần {required} (đang {cur}). Đi động cày.")

        # 0a) ĐẢM BẢO Ở THÀNH trước khi mua + Xa Phu: ĐỘNG (khu chiến đấu) CHẶN mua shop VÀ Xa Phu không
        #     gọi được từ động. Nếu char đang ở động (round trước) -> về thành (TDP/THP) trước.
        if not self._in_town():
            self._chat("📍 Đang ở động/field → về thành trước (để mua TDP/thuốc + gọi Xa Phu).")
            self._recall_to_town()
            if self._isleep(6): return

        # VÒNG TỰ-HỒI: mỗi vòng = (Ở THÀNH) chuẩn bị TDP+thuốc+CẤT BẠC giữ 1000 → lên động → cày → đủ thì nộp.
        # CHẾT khi cày (quái/người chơi) -> hồi sinh ở THÀNH -> vòng sau TỰ mua lại máu+phù + lên lại động
        # (như flow đi cày bình thường), tối đa 3 lần chết liên tiếp thì PENDING (đồ yếu/động mạnh).
        target_map = getattr(q, 'target_map', '') or ''
        deaths = 0
        rnd = 0
        while True:   # CÀY MÃI tới khi đủ (không cap vòng/cap chết) — chỉ dừng khi hết TDP/bạc/không tới được động
            rnd += 1
            if not self.game_bot_connected or self._stopping():   # tắt Auto (pause) giữa chừng → THOÁT NGAY (resumable)
                return
            # PREP Ở THÀNH (đầu vòng / sau khi chết char đã ở thành). Lỡ còn ở động -> về thành trước.
            if not self._in_town():
                self._chat("📍 Đang ở động/field → về thành trước (mua TDP/thuốc + gọi Xa Phu).")
                self._recall_to_town()
                if self._isleep(6): return
            if self._stopping(): return
            ntdp = self._prep_for_dochi_travel()   # mua TDP + thuốc, RỒI cất bạc giữ 1000
            if self._stopping(): return
            if not ntdp or ntdp <= 0:
                self._need_help("Không có Thổ Địa Phù trong túi (mua hụt/hết bạc) → KHÔNG lên động (tránh kẹt). "
                                "Mua TDP ở Tạp Hóa rồi bấm Resume.")
                return
            # LÊN ĐỘNG
            if not self._travel_to_dochi_map(target_map):
                if self._stopping(): return   # travel fail có thể do pause cắt giữa Xa Phu → thoát êm, không PENDING
                self._need_help(f"Không tới được động '{target_map}' (Xa Phu + THP fail). Xử lý xong bấm Resume.")
                return
            # BẬT AUTO NHANH NHẤT khi vào động: trước đây chờ CỨNG 6s teleport + đóng popup RỒI mới bật auto →
            # char đứng im ~6s giữa quái → bị giết. Giờ: SPAM gói 140 (nhẹ, KHÔNG crash, guid hợp lệ) NGAY +
            # lặp ~0.6s trong lúc map load → auto engage TỨC THÌ lúc char vào world; arm=True (bấm nút) 1 lần ở
            # ~1.5s (đủ để object Auto đã load). Đóng popup + buff để SAU (char đã đánh, không đứng chết).
            # <1.5s: gói 140 nhẹ (char chưa load xong, nút Auto chưa có). ≥1.5s: BẤM NÚT (arm=True) LẶP mỗi vòng —
            # nút chỉ xuất hiện sau khi cave load xong, lặp arm (FindObjectsOfTypeAll, KHÔNG crash) để bấm được
            # NGAY KHOẢNH KHẮC nút có → char đánh sớm nhất, không đứng chờ.
            armed = False; _t0 = time.time()
            while time.time() - _t0 < 5.0:
                if self._stopping(): return
                if time.time() - _t0 >= 1.5:
                    armed = self.game_bot.start_autoplay() or armed   # arm=True (bấm nút) — lặp tới khi nút load
                else:
                    self.game_bot.start_autoplay(arm=False)           # gói 140 nhẹ — engage server-side sớm
                if self._isleep(0.6): return
            if armed:
                logger.info(f"[ĐỒ CHÍ] Auto game ON nhanh — cày (vòng {rnd}).")
            else:
                self._chat(self._autoplay_fail_msg())
            # ĐÓNG popup Xa Phu (che panel quest-tracker) SAU khi auto đã chạy — char đang đánh, không đứng im.
            self._clear_popups("sau Xa Phu vào động — đóng popup che màn")
            try: self._maybe_receive_buff(force=True)   # buff SAU (NPC remote, char vẫn auto-đánh)
            except Exception: pass

            outcome = self._monitor_dochi_grind(required, cur, self._dochi_loai)   # 'done' | 'died' | 'check'
            self.game_bot.stop_autoplay()
            if not self.game_bot_connected:
                return
            if outcome == 'done':   # kẹt đọc đã xử lý TRONG monitor (hỏi Dã Tẩu remote từ động), không còn 'verify'
                self._turn_in_dochi(thp_home_first=True, required=required)
                return
            if outcome == 'died':
                deaths += 1
                self._chat(f"💀 Nhân vật CHẾT (hồi sinh ở thành) — lần {deaths}. Mua lại máu+phù, cất bạc rồi lên lại động (CÀY MÃI).")
                continue   # KHÔNG cap số lần chết -> cứ lên lại động cày tiếp
            if outcome == 'stuck':
                # KẸT TOẠ ĐỘ (bug game): về thành (TĐP teleport = thoát kẹt) rồi vòng sau LÊN LẠI động vị trí mới.
                self._chat("🧯 Thoát kẹt: về thành rồi lên lại động (vị trí mới).")
                self._recall_to_town()
                if self._isleep(6): return
                continue   # re-prep + re-enter động (như flow chết) → char ở vị trí mới, hết kẹt
            # PAUSE (tắt Auto nhanh) cũng làm grind thoát qua _stopping() -> KHÔNG phải lỗi, KHÔNG PENDING:
            # chỉ return im, bật Auto lại sẽ re-enter chạy tiếp.
            if getattr(self, '_auto_paused', False) or self._stopping():
                return
            # 'check' (bất thường: auto tắt/mất kết nối) -> báo + dừng, KHÔNG tự hủy NV.
            self._need_help("Đồ chí dừng bất thường (auto tắt/mất kết nối?) — KHÔNG tự về ping Dã Tẩu. Kiểm tra rồi Resume.")
            return

    def _travel_to_dochi_map(self, target_map):
        """Tới động NV: ưu tiên Xa Phu (route theo target_map), fallback THP. Trả True nếu đi được."""
        if target_map and self.game_bot.xaphu_route_for(target_map):
            logger.info(f"[ĐỒ CHÍ] Xa Phu → {target_map}.")
            if self.game_bot.xaphu_travel(target_map):
                return True
            self._chat("⚠️ Xa Phu không đổi map → thử THP.")
        else:
            self._chat(f"(Không có route Xa Phu cho '{target_map}') → THP.")
        return bool(self.game_bot.thp_to_datau())

    # 15 map THÀNH/THÔN (id KHÔNG lỗi font như tên đọc runtime) — nguồn ĐÁNG TIN nhất để phân biệt thành↔động.
    # 7 thành: Phượng Tường(1) Thành Đô(11) Đại Lý(162) Biện Kinh(37) Tương Dương(78) Dương Châu(80) Lâm An(176)
    # 8 thôn: Ba Lăng(53) Giang Tân(20) Long Môn(121) Long Tuyền(174) Đạo Hương(101) Vĩnh Lạc(99) Chu Tiên(100) Thạch Cổ(153)
    TOWN_MAP_IDS = {1, 11, 20, 37, 53, 78, 80, 99, 100, 101, 121, 153, 162, 174, 176}

    def _in_town(self):
        """True nếu ở THÀNH/THÔN (mua shop + Xa Phu được). False nếu ở ĐỘNG/khu chiến đấu (chặn mua).
        CHỐT CHẶN = MAP-SET (id không lỗi font). Tên map runtime hay HỎNG FONT (vd 'Băng Hà động'->'BớNG Hà ừụng')
        nên check substring 'động' trượt -> dùng map-set 15 thành/thôn làm trọng tài chính, tên chỉ là phụ."""
        try:
            mid = (self.game_bot.rpc.get_player_info() or {}).get('mapId')
            mid = int(mid)
        except Exception:
            mid = None
        if mid is None:
            return True   # đọc hụt -> coi như thành (KHÔNG chặn oan)
        # CHỐT CHẶN MẠNH NHẤT — check TRƯỚC mọi thứ: id thuộc bộ thành/thôn -> CHẮC CHẮN THÀNH.
        # (6 thành cat=1 PT/TĐ/ĐL/BK/DC/LA CÓ route Xa Phu nên nếu check route trước sẽ nhầm thành=động -> recall oan.)
        if mid in self.TOWN_MAP_IDS:
            return True
        name = ''
        try:
            from database.db_manager import db as _db
            name = _db.get_map_name(mid) or ''
        except Exception:
            pass
        nl = name.lower()
        # (1) tên rõ là hang động (font OK) -> khu chiến đấu.
        if any(k in nl for k in ('động', 'quật', 'địa biểu', 'địa đạo', 'huyệt', 'cảnh kỹ trường', 'la hán trận')):
            logger.info(f"[in_town] map {mid} '{name}' chứa từ khoá hang -> NOT town")
            return False
        try:
            if name and self.game_bot.xaphu_route_for(name):
                logger.info(f"[in_town] map {mid} '{name}' = động (Xa Phu route) -> NOT town")
                return False
        except Exception:
            pass
        # (3) tên đọc được & rõ là thành/thôn (chưa có trong set, vd Kinh Châu) -> THÀNH.
        if name and any(k in nl for k in ('thành', 'phủ', 'huyện', 'trấn', 'thôn', 'châu', 'kinh')):
            logger.info(f"[in_town] map {mid} '{name}' có từ khoá thành/thôn (ngoài set) -> town")
            return True
        # (4) map LẠ + tên lỗi font/không rõ -> coi là ĐỘNG (flow đồ chí: recall về thành an toàn hơn).
        logger.info(f"[in_town] map {mid} '{name}' không thuộc town-set & tên không rõ -> coi NOT town (động)")
        return False

    # Context shop BÁN theo thành (mapId -> eStringData NPC thợ rèn). BK(37)=tho.ren.thanh.thi.2.
    _SELL_SHOP_CTX = {37: "2|99408|81944|4"}

    def _maybe_cleanup_loot(self):
        """Nếu bật loot_config + đang ở THÀNH: bán đồ nhặt genre0 + cất trang sức/đồ-NV vào kho (sau Xa Phu về)."""
        try:
            from core import loot_config as _lc
            if not _lc.is_enabled():
                return
        except Exception:
            return
        if not self._in_town():
            return
        try:
            mid = (self.game_bot.rpc.get_player_info() or {}).get('mapId')
        except Exception:
            mid = None
        ctx = self._SELL_SHOP_CTX.get(mid)
        self._chat("🧹 Dọn túi: bán đồ nhặt + cất trang sức/đồ NV vào kho...")
        try:
            rep = self.game_bot.cleanup_bag_loot(shop_context=ctx, log=lambda m: logger.info(m))
            self._chat(f"🧹 Đã bán {len(rep.get('sold', []))}, cất kho {len(rep.get('deposited', []))}"
                       + (f", lỗi {len(rep['fail'])}" if rep.get('fail') else "") + ".")
        except Exception as e:
            self._chat(f"🧹 Dọn túi lỗi: {e}")

    def _recall_to_town(self):
        """Về thành (theo cấu hình) + (nếu bật) DỌN TÚI tại thành. Trả True nếu về được."""
        ok = self._do_recall_impl()
        if ok:
            self._maybe_cleanup_loot()
        return ok

    def _do_recall_impl(self):
        """Về thành theo cấu hình (tab Dã tẩu): 'xaphu' = Xa Phu về Biện Kinh (giờ gọi được tại động),
        'tdp' (mặc định) = Thổ Địa Phù. Cả hai đều fallback sang cái còn lại + THP. Trả True nếu về được."""
        try:
            from core import recall_config as _rc
            method = _rc.get_method()
            city = _rc.XAPHU_CITY
        except Exception:
            method, city = "tdp", "Biện Kinh"
        if method == "xaphu":
            self._chat(f"🐎 Về thành bằng Xa Phu → {city}...")
            try:
                if self.game_bot.xaphu_recall_to_city(city):   # menu FIELD: eNpcSelect(0)->dest-index thành
                    return True
            except Exception as e:
                logger.error(f"[recall] Xa Phu lỗi: {e}")
            self._chat("Xa Phu không về được → fallback Thổ Địa Phù.")
        else:
            self._chat("🧧 Bay về thành (Thổ Địa Phù)...")
        if self.game_bot.tho_dia_phu_recall():
            return True
        # TĐP fail: KHÔNG fallback Xa Phu (user chốt LUÔN TĐP) → chỉ THP về thành.
        self._chat("TDP không bay được → thử THP về thành.")
        return bool(self.game_bot.thp_to_tuong_duong())

    def _read_dochi_via_datau(self, required, loai_want):
        """ĐỌC tiến độ đồ/mật chí bằng QUERY Dã Tẩu REMOTE — gọi NGAY TRONG ĐỘNG (server KHÔNG check khoảng
        cách; open_datau dùng node thành cùng vùng), nhân vật KHÔNG di chuyển / KHÔNG về thành. Trả X (đúng
        loại + Y==required) hoặc None nếu không ra (node chưa học/câm)."""
        import re as _re
        try:
            pkts = self.open_datau() or []
        except Exception as e:
            logger.info(f"[ĐỒ CHÍ][datau-remote] open_datau lỗi: {e}")
            return None
        try:
            from core.quest import parse_quest_dialog
        except Exception:
            return None
        from core.equip_matcher import split_frames
        result = None
        for p in pkts:
            for op, hx in (split_frames(p.get('hex', '')) or [(p.get('opcode', 124), p.get('hex', ''))]):
                if not hx:
                    continue
                try:
                    q = parse_quest_dialog(bytes.fromhex(hx)[6:], opcode=op)
                    cl = (getattr(q, 'clean_text', '') or '').lower()
                except Exception:
                    continue
                if 'thần bí' not in cl or loai_want not in cl:
                    continue
                m = _re.search(r'(\d+)\s*/\s*(\d+)', cl)
                if m and int(m.group(2)) == required:
                    result = int(m.group(1)); break
            if result is not None:
                break
        # ⚠️ BUG NGHIÊM TRỌNG (user 16:58): server TỰ HOÀN THÀNH đồ chí NGAY khi mở Dã Tẩu lúc ĐỦ TẤM -> bắn 245
        # NGAY TẠI ĐỘNG. Trước đây hàm này chỉ đọc số rồi dismiss + XOÁ recv_buffer -> VỨT MẤT 245 -> về thành nộp
        # lại thì NV đã xong, 245 không còn -> MẤT THƯỞNG. FIX: nếu đã đủ tấm, QUÉT 245 trong gói vừa mở + lô poll
        # mới, có thì NHẬN THƯỞNG NGAY TẠI ĐỘNG (eAwardSelectionAnswer gửi remote OK) + đánh dấu đã claim để
        # _turn_in_dochi KHỎI bấm hoàn thành lại (đã xong) — khỏi mất thưởng.
        # ⚠️ LUÔN NHẬN THƯỞNG 245 NẾU CÓ — KHÔNG gate theo result (text tiến độ có thể None/chưa cập nhật khi
        #    245 đã hiện; gate cũ → bỏ qua claim → _clear_popups đóng mất bảng thưởng = MẤT TIỀN). Claim TRƯỚC
        #    mọi dismiss/clear.
        self._claim_award_if_present(pkts)
        # ĐÃ MỞ Dã Tẩu -> PHẢI ĐÓNG popup (đừng để chồng chéo, vì query lặp mỗi ~5 phút khi cày).
        try:
            self.npc_interact.dismiss_dialog()
            self._clear_popups("sau hỏi Dã Tẩu remote từ động")
            self._datau_dialog_open = False
            if hasattr(self.game_bot, 'recv_buffer'):
                self.game_bot.recv_buffer = []
        except Exception:
            pass
        return result

    def _focus_dochi_quest(self):
        """Gửi eQuestClick(key) = replicate TAP ô NV trên thanh tracker. Server chỉ đếm tấm thần bí cho NV đang
        'track'; nhận NV bằng packet không auto-track -> phải focus. key lấy từ gói op124 (eQuestInfo field1,
        do parse_quest_dialog bắt vào quest_id); fallback 'nhiem.vu.da.tau' (key dialog Dã Tẩu cố định)."""
        try:
            key = getattr(self.current_quest, 'quest_id', '') or 'nhiem.vu.da.tau'
            self.game_bot.send_gs('eQuestClick', key=key)
            logger.info(f"[ĐỒ CHÍ] focus NV (eQuestClick key={key!r}) -> server bắt đầu đếm tấm")
        except Exception as e:
            logger.info(f"[ĐỒ CHÍ] focus NV lỗi: {e}")

    def _read_dochi_via_click(self, required, loai_want):
        """REPLICATE 'click vào ô NV (1)': gửi eQuestClick(key) → server ĐẨY LẠI eQuestInfo(op124) chứa
        'X/Y quyển Thần bí <loại>' CẬP NHẬT (kể cả tấm ĐỒNG ĐỘI nhặt — thứ op48 local KHÔNG thấy). Đọc 124 từ
        buffer → X. NHẸ hơn open_datau NHIỀU (chỉ 1 packet, KHÔNG mở Dã Tẩu/dò 13 node). Trả X hoặc None
        (server không đẩy 124 khớp → caller fallback open_datau)."""
        import re as _re
        from core.equip_matcher import split_frames
        from core.quest import parse_quest_dialog
        key = getattr(self.current_quest, 'quest_id', '') or 'nhiem.vu.da.tau'
        try:
            if hasattr(self.game_bot, 'recv_buffer'):
                self.game_bot.recv_buffer = []
            self.game_bot.send_gs('eQuestClick', key=key)
        except Exception:
            return None
        t0 = time.time()
        while time.time() - t0 < 1.5:
            for p in (self.game_bot.poll_recv() or []):
                for op, hx in (split_frames(p.get('hex', '')) or [(p.get('opcode'), p.get('hex', ''))]):
                    if op == 124 and hx:
                        try:
                            q = parse_quest_dialog(bytes.fromhex(hx)[6:], opcode=124)
                            cl = (getattr(q, 'clean_text', '') or '').lower()
                        except Exception:
                            continue
                        if 'thần bí' in cl and loai_want in cl:
                            m = _re.search(r'(\d+)\s*/\s*(\d+)', cl)
                            if m and int(m.group(2)) == required:
                                return int(m.group(1))
            time.sleep(0.12)
        return None

    def _autoplay_is_stuck(self):
        """True nếu MÀN HÌNH đang có dòng autoplay 'Tiếp cận mục tiêu không thành công… thoát khỏi vị trí đứng'
        = char KẸT toạ độ (user chỉ đây là dấu hiệu kẹt thật). Đọc TMP qua RPC find_tmp_text (nhẹ, chỉ tìm cụm)."""
        try:
            r = self.game_bot.rpc.find_tmp_text("thoát khỏi vị trí") or {}
            return bool(r.get('found'))
        except Exception:
            return False

    def _sniff_dochi_pushed(self, pkts, required, loai_want):
        """Quét text MỌI gói VỪA NHẬN (poll_recv, đã gộp dialogBuffer) tìm 'X/Y quyển Thần bí <loại>' (Y==required)
        → trả X cao nhất. None nếu không có. Đây là tiến độ server ĐẨY realtime (kể cả tấm ĐỒNG ĐỘI — op48 local
        ko thấy). Quét theo TEXT bất kể opcode (124/126/…) cho chắc — click ô NV chỉ render text, KHÔNG gửi gói."""
        if not pkts:
            return None
        import re as _re
        best = None
        for p in pkts:
            hx = p.get('hex', '')
            if not hx:
                continue
            try:
                raw = bytes.fromhex(hx)[6:]
                # bỏ qua nhanh nếu không chứa 'quyển' (lọc op9/op54 vị trí — đỡ regex thừa)
                if b'quy\xe1\xbb\x83n' not in raw and b'Th\xe1\xba\xa7n' not in raw:
                    continue
                txt = _re.sub(r'<[^>]*>', '', raw.decode('utf-8', 'ignore')).lower()
            except Exception:
                continue
            if 'thần bí' in txt and loai_want in txt:
                m = _re.search(r'(\d+)\s*/\s*(\d+)', txt)
                if m and int(m.group(2)) == required:
                    v = int(m.group(1))
                    if best is None or v > best:
                        best = v
        return best

    def _parse_remaining_quests(self, pkts):
        """Đọc 'Hôm nay còn N nhiệm vụ chưa hoàn thành' từ bảng Dã Tẩu (op124/125/126).
        N = tổng NV còn lại HÔM NAY. So N TRƯỚC/SAU khi nộp: N GIẢM = NV ĐÃ HOÀN THÀNH — đây là CHÂN LÝ
        của 'bảng nhiệm vụ', KHÔNG phụ thuộc bắt gói 245 (245 hay rớt do eStringData flood ở thành đông →
        PENDING oan dù NV đã xong). Trả int hoặc None nếu không thấy."""
        if not pkts:
            return None
        import re as _re
        from core.equip_matcher import split_frames
        from core.quest import parse_quest_dialog
        best = None
        for p in pkts:
            if isinstance(p, dict):
                hx0 = p.get('hex', ''); op0 = p.get('opcode')
            elif isinstance(p, (list, tuple)) and len(p) >= 2:
                op0, hx0 = p[0], p[1]
            else:
                continue
            for op, hx in (split_frames(hx0) or [(op0, hx0)]):
                if op not in (124, 125, 126) or not hx:
                    continue
                try:
                    q = parse_quest_dialog(bytes.fromhex(hx)[6:], opcode=op)
                    cl = (getattr(q, 'clean_text', '') or '').lower()
                except Exception:
                    continue
                m = _re.search(r'còn\s*(\d+)\s*nhiệm\s*vụ', cl)
                if m:
                    v = int(m.group(1))
                    best = v if best is None else min(best, v)
        return best

    def _claim_award_if_present(self, extra_pkts=None, dochi=True):
        """Quét 245 (eAwardSelectionAsk) ở extra_pkts + poll mới + recv_buffer → nếu CÓ thì NHẬN THƯỞNG NGAY
        (eAwardSelectionAnswer). Trả True nếu đã nhận. Dùng để KHÔNG mất bảng thưởng (popup-clear / eNpcSelect
        đóng/huỷ mất). KHÔNG mở Dã Tẩu, KHÔNG gửi eNpcSelect ở đây.
        dochi=True: set cờ _dochi_autoclaimed + _on_quest_completed (NV đồ-chí). dochi=False: CHỈ nhặt thưởng
        (lưới an toàn ở _clear_popups), KHÔNG đụng bookkeeping (tránh đếm nhầm ở flow khác)."""
        if dochi and getattr(self, '_dochi_autoclaimed', False):
            return False
        if getattr(self, '_claiming_award', False):   # chống đệ quy (_select_reward → _clear_popups → lại vào đây)
            return False
        self._claiming_award = True
        try:
            from core.equip_matcher import split_frames
            pool = list(extra_pkts or [])
            try: pool += list(self.game_bot.poll_recv() or [])
            except Exception: pass
            pool += list(getattr(self.game_bot, 'recv_buffer', []) or [])
            award_hex = None
            for p in pool:
                for op, hx in (split_frames(p.get('hex', '')) or [(p.get('opcode'), p.get('hex', ''))]):
                    if op == 245 and hx:
                        award_hex = hx; break
                if award_hex: break
            if not award_hex:
                return False
            logger.info("[ĐỒ CHÍ] 🎁 Bắt được bảng thưởng 245 → NHẬN NGAY (chống mất thưởng).")
            self._select_reward(prefetched_hex=award_hex)
            if dochi:
                self._dochi_autoclaimed = True
                try: self._on_quest_completed()
                except Exception: pass
            return True
        except Exception as e:
            logger.info(f"[ĐỒ CHÍ] _claim_award_if_present lỗi: {e}")
            return False
        finally:
            self._claiming_award = False

    def _confirm_dochi_done_via_datau(self, required, loai_want):
        # CHỐNG MẤT THƯỞNG: nếu 245 đã hiện tại động (server tự hoàn thành) thì NHẬN NGAY, TUYỆT ĐỐI không mở
        # Dã Tẩu (open_datau gửi eNpcSelect = huỷ bảng thưởng đang mở). Có 245 = chắc chắn done.
        if self._claim_award_if_present():
            return 'done'
        """XÁC NHẬN 'đã đủ tấm' bằng Dã Tẩu REMOTE (chân lý) TRƯỚC khi bay về nộp — tránh tin số realtime
        (op48/nhấn NV/sniff) chạy TRƯỚC server rồi về nộp hụt -> PENDING không có 245.
        Trả:
          'done'  = Dã Tẩu xác nhận >= required (đã auto-claim 245 tại động trong _read_dochi_via_datau).
          int (<required) = số THẬT server đang ghi nhận -> caller đồng bộ baseline + cày tiếp.
          None    = Dã Tẩu CÂM (node chưa nhả) -> caller KHÔNG bay (thử lại vòng sau)."""
        xq = self._read_dochi_via_datau(required, loai_want)
        if xq is None:
            logger.info("[ĐỒ CHÍ] realtime báo đủ nhưng Dã Tẩu CÂM -> chưa xác nhận, cày tiếp (không bay).")
            return None
        if xq >= required:
            logger.info(f"[ĐỒ CHÍ] Dã Tẩu XÁC NHẬN {xq}/{required} -> ĐỦ, done.")
            return 'done'
        logger.info(f"[ĐỒ CHÍ] Dã Tẩu THẬT {xq}/{required} < realtime -> baseline lệch, cày tiếp.")
        return xq

    def _monitor_dochi_grind(self, required: int, x0: int = 0, loai_want: str = 'đồ chí'):
        """Cày trong động + đọc tiến độ REALTIME bằng SNIFF gói op=48 ĐÚNG LOẠI (đồ chí / mật chí) của NV.
        X = x0 + số message đúng loại (N phân biệt). KHÔNG ping Dã Tẩu/UI. POLL ~2s, chat mỗi tấm.
        Trả 'done' khi X>=required; 'check' khi ~7 phút không tăng -> về thành xác nhận."""
        last_logged = -1
        X = x0
        last_change_t = time.time()      # lần cuối số tấm "đổi" (reset cả khi hỏi Dã Tẩu) — dùng cho nhịp query
        max_x_seen = x0                  # X CAO NHẤT từng thấy (tiến độ THẬT)
        last_progress_t = time.time()    # lần cuối X THỰC SỰ TĂNG — KHÔNG reset bởi query → dò KẸT toạ độ chuẩn
        last_click_read = 0.0            # lần cuối 'nhấn NV' (eQuestClick) đọc tiến độ nhẹ — thay open_datau nặng
        pushed_x = x0                    # X cao nhất bắt được từ gói op124 SERVER ĐẨY (realtime, kể cả tấm đồng đội)
        last_stuck_chk = 0.0             # nhịp dò text autoplay-kẹt
        stuck_since = None               # mốc lần đầu thấy dòng 'thoát khỏi vị trí đứng' (autoplay đang kẹt)
        STUCK_RECOVER_SECS = 360         # 6 phút KHÔNG tăng tấm thật = char kẹt toạ độ/hết quái → về thành thoát kẹt
        last_arm_t = 0.0                 # lần cuối gửi gói 140 giữ auto
        last_strong_arm = 0.0            # lần cuối bật-lại-auto mạnh (arm=True) khi lâu chưa rớt
        ns_seen = set()                  # SET các N message ĐÚNG LOẠI thấy trong vòng này -> đếm distinct
        grind_start = time.time()        # mốc bắt đầu cày — để bỏ qua ~10s đầu khi dò CHẾT (mapId còn stale)
        last_death_chk = 0.0
        # XẢ SẠCH buffer op=48 tồn dư (từ NV/vòng trước) -> chỉ đếm pickup PHÁT SINH trong vòng này.
        try:
            self.game_bot.rpc.get_op48()
        except Exception:
            pass
        # FOCUS NV (= tap ô NV trên thanh tracker): server CHỈ đếm tấm cho NV đang "track". Nhận NV bằng packet
        # KHÔNG auto-track -> nhặt 100 tấm cũng ko tính (op48 câm + tracker 0/Y) tới khi click tay. Gửi eQuestClick
        # (key) để focus NV -> đếm chạy KHÔNG cần click. Gửi ngay + lặp lại định kỳ (cùng nhịp 20s với arm auto).
        self._focus_dochi_quest()
        while self.game_bot_connected and not self._stopping() and not self.paused:
            now = time.time()
            self._hb_ts = now            # nhịp tim: mỗi vòng cày = luồng còn chạy (watchdog không kill grinder xui)
            self._record_tlh_gain()      # ghi MỌI lần TLH vào túi (đồ-chí/nhặt/thưởng) → thống kê đếm đủ từ log
            # AUTO-NHẶT + AUTO-PT NGAY TRONG VÒNG CÀY: tick top bị block khi cày (while này chiếm luồng) nên PHẢI
            # gọi ở đây mới nhặt được lúc đang cày. poll_recv() để recv_buffer có op54 mới (op48 đồ-chí dùng
            # buffer RIÊNG get_op48 → KHÔNG bị ảnh hưởng).
            try:
                _rpkts = self.game_bot.poll_recv() or []
            except Exception:
                _rpkts = []
            # SNIFF op124 (eQuestInfo) SERVER PUSH realtime: click "1" KHÔNG gửi gói (client-side) → tiến độ tới
            # client qua gói 124 server ĐẨY (kể cả tấm ĐỒNG ĐỘI — op48 local ko thấy). poll_recv đã gộp dialogBuffer
            # (chứa 124) → parse 'X/Y quyển Thần bí <loại>' NGAY = realtime, KHỎI click/khỏi mở Dã Tẩu.
            try:
                _xp = self._sniff_dochi_pushed(_rpkts, required, loai_want)
                if _xp is not None and _xp > pushed_x:
                    pushed_x = _xp
                    _src = "kể cả tấm đồng đội" if getattr(self, '_joined_team', None) else "tiến độ THẬT server"
                    logger.info(f"[ĐỒ CHÍ] gói server-push: {_xp}/{required} (realtime, {_src})")
            except Exception: pass
            # 🎁 BẢNG THƯỞNG 245 HIỆN NGAY TẠI ĐỘNG (server tự hoàn thành đồ chí khi đủ tấm): PHẢI nhận NGAY
            #    trong vòng cày — TRƯỚC khi _clear_popups định kỳ / eNpcSelect đóng/huỷ mất (bug "bảng thưởng
            #    hiện rồi auto tắt, không nhận"). Quét cả _rpkts + recv_buffer.
            if self._claim_award_if_present(_rpkts):
                return 'done'
            try: self._auto_pickup_ground()
            except Exception: pass
            try: self._auto_accept_party()
            except Exception: pass
            try: self._auto_attack_caster()    # caster_skill_id>0 mới chạy (invoke DoSkill tự đánh)
            except Exception: pass
            # PHÁT HIỆN CHẾT: đang cày trong động mà mapId thành THÀNH = bị giết -> hồi sinh ở thành.
            # Bỏ qua ~10s đầu (mapId vừa vào động có thể còn báo thành cũ); check mỗi ~3s (đỡ tốn RPC).
            if now - grind_start > 10 and now - last_death_chk > 3:
                last_death_chk = now
                if self._in_town():
                    logger.info("[ĐỒ CHÍ] mapId=THÀNH giữa lúc cày -> nhân vật ĐÃ CHẾT (hồi sinh ở thành) -> 'died'.")
                    return 'died'
            if now - last_arm_t > 20:    # giữ auto = gói 140 mỗi ~20s
                self.game_bot.start_autoplay(arm=False)
                self._focus_dochi_quest()    # giữ NV được "track" (server mới đếm tấm) — cùng nhịp với arm auto
                # ⚠️ NHẬN THƯỞNG TRƯỚC KHI ĐÓNG POPUP: nếu bảng thưởng 245 đang mở mà _clear_popups đóng = MẤT
                #    THƯỞNG. Claim trước; nếu nhận được → done luôn (khỏi đóng).
                if self._claim_award_if_present():
                    return 'done'
                # ĐÓNG POPUP ĐỊNH KỲ lúc cày: popup túi / "về thành dưỡng sức" (StandardConfirmPc) hiện GIỮA chừng
                # che màn + chặn auto. Đóng mỗi 20s (user: tắt toàn bộ popup khi đánh quái trong động).
                try: self._clear_popups("định kỳ lúc cày")
                except Exception: pass
                last_arm_t = now
            # NGUỒN CHÍNH: đọc text panel nhiệm vụ (tuyệt đối + ĐÚNG LOẠI). Fallback: đếm op=48 (generic, có
            # thể lẫn loại) nếu panel không đọc được.
            ui = self._read_dochi_ui(required, loai_want)
            # LUÔN tích lũy op=48 (pickup realtime) SONG SONG — tracker UI có thể ĐỨNG YÊN (freeze 0/Y khi NV
            # chưa được "track" tay), nếu để ui (≠None) đè thì op48 bị bỏ -> X kẹt 0 -> đánh 100 tấm cũng ko về
            # nộp (bug "phải click ô NV trên tracker mới đếm"). Lấy MAX(tracker, op48) -> nguồn nào chạy thì theo.
            for n in (self._read_dochi_acc(required, loai_want) or []):
                ns_seen.add(n)
            X_acc = x0 + len(ns_seen)
            X = max(ui if ui is not None else 0, X_acc, pushed_x)   # +pushed_x: gói 124 server đẩy (kể cả tấm đồng đội)
            if X != last_logged:         # TẤM ĐỔI -> log NGAY (realtime mỗi tấm)
                self._chat(f"⚔️ {loai_want.capitalize()}: {X}/{required}")
                last_logged = X
                last_change_t = now
            if X > max_x_seen:           # TIẾN ĐỘ THẬT tăng (không phải reset do query) -> char đang đánh OK
                max_x_seen = X
                last_progress_t = now
            if X >= required:
                # ⚠️ KHÔNG tin số REALTIME (op48/nhấn NV/sniff) để bay về nộp NGAY: op48 đếm 'tích lũy' có thể
                # CHẠY TRƯỚC tiến độ THẬT của server (pickup trước khi NV được track / lẫn loại / tấm đồng đội
                # đếm lệch). Bay về lúc server CHƯA đủ -> mở Dã Tẩu ở thành KHÔNG auto-complete -> KHÔNG có 245
                # -> PENDING "không nhận bảng thưởng" (đây CHÍNH là bug user gặp liên tục). FIX: trước khi 'done',
                # XÁC NHẬN bằng Dã Tẩu REMOTE (chân lý, lại auto-claim 245 NGAY tại động nếu thật đủ — khỏi race
                # recall mất thưởng). Server <đủ -> reset baseline = số THẬT, cày tiếp.
                _c = self._confirm_dochi_done_via_datau(required, loai_want)
                if _c == 'done':
                    return 'done'
                if isinstance(_c, int):           # server trả số THẬT < required -> đồng bộ lại baseline
                    x0 = _c; ns_seen.clear(); pushed_x = _c; max_x_seen = _c
                    X = _c; last_logged = _c; last_change_t = now
                    self._chat(f"⚠️ Realtime báo đủ nhưng Dã Tẩu THẬT chỉ {_c}/{required} → cày tiếp (không bay nhầm).")
                    self.game_bot.start_autoplay(arm=False); last_arm_t = now
                # _c == None (Dã Tẩu câm): KHÔNG bay (tránh PENDING) — vòng sau thử lại; bám realtime tiếp.
            # 'NHẤN NV' (eQuestClick) MỖI 15s — replicate click ô NV: server đẩy 124 'X/Y' cập nhật (kể cả tấm
            # đồng đội). NHẸ (1 packet) → bám tiến độ realtime mà KHÔNG cần open_datau nặng. Đây là cái user muốn.
            if now - last_click_read > 15:
                last_click_read = now
                xqc = self._read_dochi_via_click(required, loai_want)
                if xqc is not None:
                    if xqc != last_logged:
                        self._chat(f"⚔️ {loai_want.capitalize()}: {xqc}/{required} (nhấn NV)")
                        last_logged = xqc
                    X = xqc
                    x0 = xqc; ns_seen.clear()       # baseline op48 = số thật → vòng sau không tụt
                    last_change_t = now
                    if X > max_x_seen:
                        max_x_seen = X; last_progress_t = now
                    if X >= required:
                        _c = self._confirm_dochi_done_via_datau(required, loai_want)
                        if _c == 'done':
                            return 'done'
                        if isinstance(_c, int):
                            x0 = _c; ns_seen.clear(); pushed_x = _c; max_x_seen = _c
                            X = _c; last_logged = _c; last_change_t = now
                            self.game_bot.start_autoplay(arm=False); last_arm_t = now
            # THOÁT KẸT TOẠ ĐỘ — dò bằng ĐÚNG dòng autoplay "Tiếp cận mục tiêu không thành công… thoát khỏi vị trí
            # đứng" (user chỉ: đây MỚI là dấu hiệu kẹt thật, KHÔNG phải '6 phút không tăng tấm'). Autoplay tự thử
            # thoát; nếu dòng này CÒN sau ~25s = thoát không được = kẹt thật → về thành (TĐP) + lên lại động.
            if now - last_stuck_chk > 6:
                last_stuck_chk = now
                if self._autoplay_is_stuck():
                    if stuck_since is None:
                        stuck_since = now
                        logger.info("[ĐỒ CHÍ] thấy autoplay 'thoát khỏi vị trí đứng' — theo dõi 25s xem có tự thoát…")
                    elif now - stuck_since > 25:
                        self._chat("🧯 KẸT (autoplay không thoát được vị trí >25s) → về thành rồi lên lại động.")
                        return 'stuck'
                else:
                    stuck_since = None        # hết dòng kẹt = autoplay đã thoát → reset
            # KẸT KHÔNG TĂNG tấm (≥2 phút): focus NV (eQuestClick) đôi khi trượt ở 1 vài cửa sổ -> op48 câm +
            # tracker đứng 0 dù THỰC TẾ char đang nhặt (user: "Chu Nguyệt 0/8 nhưng hỏi Dã Tẩu ra 2/8"). KHÔNG về
            # thành (phí TĐP) — server KHÔNG check khoảng cách nên HỎI Dã Tẩu REMOTE NGAY TRONG ĐỘNG đọc số THẬT:
            # đủ -> nộp; chưa đủ -> lấy số thật + RE-FOCUS NV rồi cày tiếp. Hạ 5p->2p để cửa sổ kẹt hồi nhanh.
            # NHỊP HỎI DÃ TẨU ĐỘNG THEO TỔ ĐỘI: ở ĐỘI thì đồng đội nhặt tấm → server tính chung NHƯNG gói op48
            # "đã nhặt… tích lũy" gửi cho NGƯỜI NHẶT, KHÔNG tới client này → op48 local đếm 0 (user: "phải click 1
            # mới nhận"). Nguồn THẬT duy nhất khi ở đội = hỏi Dã Tẩu → hỏi DÀY hơn (50s) để bám tiến độ + nộp sớm.
            # SOLO (op48 đếm chuẩn) → 120s, khỏi spam Dã Tẩu.
            _q_int = 50 if getattr(self, '_joined_team', None) else 120
            if now - last_change_t > _q_int:
                logger.info(f"[ĐỒ CHÍ] {int(now-last_change_t)}s không tăng (đang đọc {X}/{required}, "
                            f"{'ĐỘI' if getattr(self,'_joined_team',None) else 'solo'}) -> hỏi Dã Tẩu REMOTE từ động.")
                self._focus_dochi_quest()         # RE-FOCUS NV (cửa sổ này focus có thể đã trượt -> đó là lý do kẹt)
                xq = self._read_dochi_via_datau(required, loai_want)
                if xq is not None:
                    if xq != last_logged:
                        self._chat(f"⚔️ {loai_want.capitalize()}: {xq}/{required} (hỏi Dã Tẩu từ xa)")
                        last_logged = xq
                    X = xq
                    if X >= required:
                        return 'done'
                    # ĐẶT LẠI baseline op48 = số THẬT để vòng sau X=max(tracker,op48) KHÔNG tụt về 0 (flip-flop
                    # "2/8 rồi lại 0/8"): x0 thành xq, xoá ns_seen -> pickup mới cộng dồn TỪ xq trở đi.
                    x0 = xq
                    ns_seen.clear()
                    last_change_t = now            # có số THẬT (chưa đủ) -> reset, cày tiếp KHÔNG về thành
                else:
                    last_change_t = now - 300 + 90  # query chưa ra (node câm) -> thử lại sau ~90s, đừng spam
                    logger.info("[ĐỒ CHÍ] hỏi Dã Tẩu từ động chưa ra -> cày tiếp, thử lại ~90s.")
                self.game_bot.start_autoplay(arm=False); last_arm_t = now   # mở Dã Tẩu có thể ngắt auto -> bật lại
            # LÂU KHÔNG TĂNG = đánh không rớt (xui) -> CỨ CÀY TIẾP, chỉ bật lại auto định kỳ (phòng auto tắt).
            # KHÔNG về thành ping Dã Tẩu nữa (đã bỏ — tiến độ đọc realtime, ping Dã Tẩu vô nghĩa + tốn TDP).
            if now - last_change_t > 180 and now - last_strong_arm > 180:
                # CHỈ gửi gói 140 (arm=False) — TUYỆT ĐỐI không arm=True (il2cpp gc.choose = đơ/crash game khi
                # re-arm định kỳ; đã gây crash Láo Là Bem). Gói 140 đủ giữ/bật lại auto.
                self.game_bot.start_autoplay(arm=False); last_arm_t = now; last_strong_arm = now
                logger.info("[ĐỒ CHÍ] lâu chưa rớt -> bật lại auto (gói 140), cày tiếp (KHÔNG về thành).")
            for _ in range(4):                          # poll ~2s để bắt đổi tấm sát realtime
                if not self.game_bot_connected:
                    return 'check'                      # mất kết nối -> báo lên (KHÔNG phải tín hiệu về thành)
                time.sleep(0.5)
        return 'check'

    def _turn_in_dochi(self, thp_home_first: bool = True, required: int = 0):
        """Nộp NV đồ chí: (tuỳ chọn VỀ THÀNH) -> kiểm tra X/required (ở thành, qua Dã Tẩu) ->
        nếu đủ thì claim 'Đã hoàn thành' -> 245 -> thưởng; chưa đủ thì báo (KHÔNG tự hủy).
        VỀ THÀNH: ưu tiên Thổ Địa Phù (túi); fallback THP."""
        # ĐÃ CLAIM Ở ĐỘNG: _read_dochi_via_datau thấy đủ tấm → server tự hoàn thành + đã nhận 245 NGAY tại động.
        # NV ĐÃ XONG → KHỎI về thành bấm hoàn thành lại (bấm lại = đụng NV kế / vô nghĩa). Dọn cờ + qua NV kế.
        if getattr(self, '_dochi_autoclaimed', False):
            self._dochi_autoclaimed = False
            self._chat("✅ Đồ chí đã nộp + nhận thưởng NGAY tại động (server tự hoàn thành) — qua NV kế.")
            self.current_quest = None
            self._goto_state(BotState.IDLE_PRECHECK)
            return
        # ĐÃ Ở THÀNH RỒI -> KHỎI recall. Chỉ recall khi đang ở ĐỘNG (theo cấu hình Xa Phu/TĐP).
        if thp_home_first and not self._in_town():
            if not self._recall_to_town():
                self._need_help("Không về thành được (Xa Phu/TDP/THP đều fail). Đứng chờ (KHÔNG tự hủy).")
                self._goto_state(BotState.TRAINING)
                return
            if self._isleep(6): return
        # Ở thành: MỞ Dã Tẩu 1 LẦN, đọc tiến độ TỪ CHÍNH gói mở (KHÔNG mở lại — mở 2 lần reset dialog
        # về menu gốc nên 'Đã hoàn thành' không tới nơi -> không ra 245). Giữ dialog mở rồi nộp luôn.
        import re as _re
        pkts = self.open_datau()
        n_before = self._parse_remaining_quests(pkts)   # 'còn N nhiệm vụ' TRƯỚC nộp (bảng = chân lý khi mất 245)
        if not pkts:
            # Dã Tẩu CÂM TẠM sau khi bán đồ/đổi map (server còn dialog shop chưa nhả) — node KHÔNG sai, tự hồi
            # sau ~30-60s. ĐỪNG PENDING ngay (trước đây thử 1 lần → kẹt oan). Retry vài lần rồi mới báo.
            for _i in range(5):
                if self._stopping() or not self.game_bot_connected:
                    return
                self._chat(f"⏳ Dã Tẩu chưa phản hồi (vừa bán đồ/đổi map?) — thử lại {_i+1}/5 sau 14s…")
                if self._isleep(14):
                    return
                pkts = self.open_datau()
                if pkts:
                    self._chat("✅ Dã Tẩu đã phản hồi, tiếp tục nộp đồ chí.")
                    break
            if not pkts:
                self._need_help("Không mở được Dã Tẩu ở thành để nộp đồ chí (đã retry ~70s). Đứng chờ (KHÔNG tự hủy).")
                self._goto_state(BotState.TRAINING)
                return
        if n_before is None:
            n_before = self._parse_remaining_quests(pkts)   # retry mới ra pkts -> đọc lại N
        if required > 0:
            X = None
            from core.quest import parse_quest_dialog
            for p in pkts:
                try:
                    q = parse_quest_dialog(bytes.fromhex(p['hex'])[6:], opcode=p.get('opcode', 124))
                    m = _re.search(r'(\d+)\s*/\s*(\d+)', (getattr(q, 'clean_text', '') or ''))
                    if m and int(m.group(2)) == required:
                        X = int(m.group(1)); break
                except Exception:
                    continue
            if X is not None:
                logger.info(f"[ĐỒ CHÍ] Tiến độ (ở thành): {X}/{required}")
                if X < required:
                    # Town (Dã Tẩu) = CHÂN LÝ. Chưa đủ -> CÀY TIẾP, KHÔNG cap (user: đánh mãi tới khi đủ).
                    self._dochi_last_town_x = X
                    logger.info(f"[ĐỒ CHÍ] Town {X}/{required} chưa đủ → cày tiếp (KHÔNG cap số vòng).")
                    self.current_quest = None
                    self._goto_state(BotState.IDLE_PRECHECK)
                    return
        self._chat("📨 Nộp NV đồ chí + nhận thưởng...")
        from core.equip_matcher import split_frames
        from core.quest import parse_quest_dialog

        def _scan_245_in_buffer(extra_pkts=None):
            """Quét gói ĐÃ về (open pkts + recv_buffer) tìm 245. wait_for_packet GIỮ gói không khớp nên
            245 do server TỰ hoàn thành đồ chí (khi mở Dã Tẩu lúc đủ tấm) vẫn còn trong buffer.
            QUAN TRỌNG: ở thành ĐÔNG NGƯỜI (Biện Kinh...), eStringData(9) vị trí người khác SPAM hàng trăm
            gói/giây -> recv_buffer (cap 1000, game_bot.poll_recv) BỊ ĐẨY TRÀN -> 245 bị evict TRƯỚC khi quét
            (đây là lý do GST Muội Yêu ở thành đông cứ PENDING 'không nhận 245' dù server CÓ trả). Vì vậy quét
            cả GIÁ TRỊ TRẢ VỀ của poll_recv (lô vừa đọc, CHƯA bị cap) chứ không chỉ recv_buffer đã cap."""
            pool = list(extra_pkts or [])
            fresh = self.game_bot.poll_recv()               # lô gói VỪA đọc (chưa bị cap-1000 cắt) -> quét TRƯỚC
            pool += list(fresh or [])
            pool += list(getattr(self.game_bot, 'recv_buffer', []) or [])
            for p in pool:
                for op, hx in (split_frames(p.get('hex', '')) or [(p.get('opcode'), p.get('hex', ''))]):
                    if op == 245:
                        return hx
            return None

        # (A) Server hay TỰ hoàn thành đồ chí NGAY khi mở Dã Tẩu (đủ tấm) -> 245 đã nằm trong gói mở/buffer.
        #     KHÔNG xoá recv_buffer (bug cũ: xoá -> mất 245 auto-complete). Quét buffer TRƯỚC.
        award_hex = _scan_245_in_buffer(pkts)
        if award_hex:
            logger.info("[ĐỒ CHÍ] 245 đã có sẵn khi mở Dã Tẩu (server tự hoàn thành đồ chí).")
        else:
            # 245 auto-complete có thể đến TRỄ vài giây -> chờ bắt TRƯỚC khi bấm select (kẻo select lỡ
            # nhảy sang NV kế). Quét cả buffer + gói mới trong ~2s.
            t0 = time.time()
            while time.time() - t0 < 2.0 and not award_hex:
                award_hex = _scan_245_in_buffer()
                if award_hex:
                    logger.info("[ĐỒ CHÍ] 245 auto-complete đến (chờ sau khi mở).")
                    break
                time.sleep(0.2)
        # (B) Chưa auto-complete -> bấm NÚT CHÍNH (eNpcSelect rỗng = 'Đã hoàn thành') tối đa 3 lần.
        #     TUYỆT ĐỐI KHÔNG gửi index 1 (=‘Ta muốn hủy nv’). KHÔNG xoá buffer giữa chừng.
        dochi_num = getattr(self.current_quest, 'quest_number', 0) or 0   # số NV đồ chí đang nộp (vd 18)
        advanced = False   # dialog đã NHẢY sang NV khác = đồ chí ĐÃ NỘP (dù 245 bị mất/tự trao)
        for step in range(3):
            if self._stopping(): break
            if award_hex:
                break
            self._select_pkt()
            seen = []
            t0 = time.time()
            while time.time() - t0 < 2.5:
                for p in (self.game_bot.poll_recv() or []):
                    seen.append((p.get('opcode'), p.get('hex', '') or ''))
                time.sleep(0.1)
            frames = []
            for op, hx in seen:
                sub = split_frames(hx)
                frames.extend(sub if sub else [(op, hx)])
            award_hex = next((hx for op, hx in frames if op == 245), None)
            dlg_texts = []
            for op, hx in frames:
                if op in (124, 125, 126):
                    try:
                        q = parse_quest_dialog(bytes.fromhex(hx)[6:], opcode=op)
                        ct = (getattr(q, 'clean_text', '') or '')[:70]
                        if ct:
                            dlg_texts.append(f"{op}:{ct!r}")
                        # dialog hiện quest_number KHÁC NV đồ chí -> server đã hoàn thành đồ chí, chào NV kế.
                        qn = getattr(q, 'quest_number', 0) or 0
                        if qn and dochi_num and qn != dochi_num:
                            advanced = True
                    except Exception:
                        pass
            ops_summary = {}
            for op, _ in frames:
                ops_summary[op] = ops_summary.get(op, 0) + 1
            logger.info(f"[ĐỒ CHÍ] nộp bước {step}: 245={'CÓ' if award_hex else 'không'} | "
                        f"advanced={advanced}(NV{dochi_num}->khác) | ops={ops_summary} | dialog={dlg_texts}")
            if advanced and not award_hex:
                break   # đồ chí đã nộp xong (dialog nhảy NV kế) -> dừng bấm, không cần 245
        if award_hex:
            try:
                self._select_reward(prefetched_hex=award_hex)
            except Exception as e:
                logger.error(f"[ĐỒ CHÍ] chọn thưởng lỗi: {e}")
            self._chat("✅ Hoàn thành NV đồ chí + nhận thưởng.")
            self._dochi_regrind = 0; self._dochi_last_town_x = -1   # reset cho NV đồ chí kế
            self._on_quest_completed()
            self.current_quest = None
            self._goto_state(BotState.IDLE_PRECHECK)
        elif advanced:
            # KHÔNG bắt được 245 nhưng dialog đã nhảy sang NV kế = đồ chí ĐÃ NỘP THÀNH CÔNG (thưởng tự trao
            # hoặc gói 245 bị rớt do lossy). KHÔNG báo lỗi/PENDING oan, KHÔNG nộp lại (sẽ kẹt ở NV kế).
            self._chat("✅ Đồ chí đã nộp (dialog nhảy sang NV kế; gói thưởng 245 không bắt được — bỏ qua).")
            self._dochi_regrind = 0; self._dochi_last_town_x = -1   # reset cho NV đồ chí kế
            self._on_quest_completed()
            self.current_quest = None
            self._goto_state(BotState.IDLE_PRECHECK)
        else:
            # CHƯA xác nhận (245 + dialog đều MẤT do recv flood ở thành đông) → ĐỌC LẠI Dã Tẩu LIVE (đúng như
            # Resume tay) để xem NV đã NHẢY chưa. Nếu quest_number đổi = đồ chí ĐÃ NỘP XONG → tiếp tục, KHÔNG
            # PENDING OAN (đây là bug "không trả được đồ → resume là xong"). Chỉ PENDING khi đọc lại VẪN chưa nhảy.
            verified = False
            verify_reason = ""
            try:
                reb = self.open_datau()
                time.sleep(0.5)
                pool = list(reb or []) + list(self.game_bot.poll_recv() or []) + list(getattr(self.game_bot, 'recv_buffer', []) or [])
                for p in pool:
                    for op, hx in (split_frames(p.get('hex', '')) or [(p.get('opcode'), p.get('hex', ''))]):
                        if op in (124, 125, 126):
                            try:
                                q2 = parse_quest_dialog(bytes.fromhex(hx)[6:], opcode=op)
                                qn2 = getattr(q2, 'quest_number', 0) or 0
                                if qn2 and dochi_num and qn2 != dochi_num:
                                    verified = True; verify_reason = f"NV nhảy khỏi NV{dochi_num}"
                            except Exception:
                                pass
                # BẢNG NHIỆM VỤ = CHÂN LÝ: 'còn N nhiệm vụ' GIẢM so n_before = đồ chí ĐÃ NỘP (dù 245 + quest_number
                # đều mất do flood). Đây là tín hiệu chung với nộp đồ thường — bắt được nhiều ca PENDING oan.
                if not verified:
                    n_after = self._parse_remaining_quests(pool)
                    if n_before is not None and n_after is not None and n_after < n_before:
                        verified = True; verify_reason = f"bảng NV còn {n_before}→{n_after} giảm"
            except Exception as e:
                logger.error(f"[ĐỒ CHÍ] đọc lại xác minh lỗi: {e}")
            if verified:
                self._chat(f"✅ Đồ chí ĐÃ nộp xong ({verify_reason}; 245 mất do flood) — KHÔNG PENDING oan.")
                self._dochi_regrind = 0; self._dochi_last_town_x = -1
                self._on_quest_completed()
                self.current_quest = None
                self._goto_state(BotState.IDLE_PRECHECK)
            else:
                # Đọc lại VẪN chưa nhảy → nộp thật sự chưa xong. Bỏ cache (Resume đọc LIVE, không nộp lại quest cũ).
                self.current_quest = None
                self._need_help("KHÔNG nhận được bảng thưởng (245) khi nộp đồ chí. Đứng chờ kiểm tra (KHÔNG tự hủy).")
                self._goto_state(BotState.TRAINING)

    def _handle_training(self):
        # Kiểm tra packet để tìm xem nhiệm vụ đã hoàn thành chưa
        time.sleep(1)
        # ❌ ĐÃ BỎ get_monster_count(): RPC này dùng OFFSET 32-bit CỨNG + RVA cứng trên runtime 64-bit
        #    -> đọc con trỏ RÁC -> ACCESS VIOLATION trên thread game -> TREO/KHỰNG cửa sổ game (nặng khi
        #    chạy nhiều account). 'Radar' chỉ để log, không cần thiết -> bỏ hẳn.
        if self.game_bot_connected:
            pkts = self.game_bot.poll_recv()
            if pkts:
                for p in pkts:
                    if p.get('opcode') == 54:
                        from core.quest import parse_opcode54
                        import binascii
                        try:
                            # Chuyển hex string thành bytes
                            body = binascii.unhexlify(p.get('hex', ''))
                            q = parse_opcode54(body)
                            if q and q.is_valid:
                                logger.info(f"[TRAINING] Cập nhật tiến độ nhiệm vụ: {q.clean_text}")
                                # Nếu số lượng cần tìm = 0 (tức là đã xong, kiểu 2/2) hoặc text chứa 'hoàn thành'
                                import re
                                match = re.search(r'(\d+)/(\d+)', q.clean_text)
                                is_done = False
                                if match and match.group(1) == match.group(2):
                                    is_done = True
                                elif "hoàn thành" in q.clean_text.lower():
                                    is_done = True
                                    
                                if is_done:
                                    self._chat("Tuyệt vời! Nhiệm vụ đã hoàn thành. Về thành báo cáo ngay!")
                                    self._goto_state(BotState.REWARD)
                                    return
                        except Exception as e:
                            pass
        else:
            if self._isleep(4): return

    # ==================== THỦ QUỸ (treasurer) ====================
    def _handle_treasurer_mode(self):
        """Cửa sổ THỦ QUỸ: đứng yên (tắt auto) + công bố cid/map/toạ độ ra file + tự NHẬN invite trade
        (gói 151) từ worker -> hoàn tất giao dịch (cấp 20 vạn nếu request 'money'; thu đồ worker bỏ vào).
        KHÔNG làm Dã Tẩu. recv hook bắt được 151 vì bot đang chạy (đã có traffic lúc login/định vị)."""
        from core import treasurer as _T
        if not self.game_bot_connected:
            time.sleep(1.0); return
        if self._stopping(): return   # tắt/pause Auto → ngừng nhận invite/phục vụ (giao dịch đang chạy thì để chạy nốt)
        # 1) đứng yên 1 lần
        if not getattr(self, '_treasurer_idle_done', False):
            self._treasurer_idle_done = True
            try:
                self.game_bot.stop_autoplay()
            except Exception:
                pass
            self._chat("💰 THỦ QUỸ sẵn sàng — đứng yên, chờ worker tới giao dịch.")
        # 2) công bố vị trí/cid ra file (throttle 5s) để worker biết đường tới
        now = time.time()
        if now - getattr(self, '_treasurer_info_ts', 0) > 5:
            self._treasurer_info_ts = now
            try:
                pi = self.game_bot.rpc.get_player_info() or {}
                _T.write_info(pi.get('cid'), pi.get('name'), pi.get('mapId'), pi.get('mapX'), pi.get('mapY'))
            except Exception:
                pass
        # 3) bắt invite trade (151) -> phục vụ.
        # ⚠️ tick() đã gọi poll_recv() (parse map op7/8) -> NUỐT gói mới vào recv_buffer TRƯỚC handler.
        # Nếu ở đây lại poll_recv() thì chỉ nhận gói MỚI HƠN -> LỠ gói 151 -> không accept (bug "không đồng ý được").
        # => đọc 151 TỪ recv_buffer (tích luỹ), rồi XOÁ các 151 đã đọc để khỏi phục vụ lặp.
        try:
            self.game_bot.poll_recv()                       # kéo nốt gói còn trong JS vào buffer
            buf = getattr(self.game_bot, 'recv_buffer', []) or []
            inv = [p for p in buf if p.get('opcode') == 151]
            if inv:
                self.game_bot.recv_buffer = [p for p in buf if p.get('opcode') != 151]
        except Exception:
            inv = []
        if inv:
            iv = self.game_bot.parse_trade_invite(inv[-1].get('hex', ''))
            if iv.get('cid'):
                self._chat(f"💰 Nhận lời mời giao dịch (cid {iv['cid']}) → chấp nhận.")
                self._treasurer_serve(iv['cid'], iv.get('name') or '')
            else:
                self._chat("💰 Bắt được gói mời (151) nhưng KHÔNG đọc được cid → bỏ qua.")
        time.sleep(0.5)

    def _bag_count_by_particular(self):
        """{particular: số lượng} các item trong túi (location==2) — để diff trước/sau giao dịch."""
        out = {}
        try:
            for it in (self.game_bot.dump_bag_items() or {}).get('items', []):
                if it.get('location') == 2:
                    p = it.get('particular')
                    out[p] = out.get(p, 0) + 1
        except Exception:
            pass
        return out

    def _tlog(self, msg):
        """Ghi log THỦ QUỸ (panel riêng tab Thủ quỹ) + chat thường."""
        self._chat(msg)
        if getattr(self, 'ui_treasurer_log', None):
            try:
                self.ui_treasurer_log(msg)
            except Exception:
                pass

    def _bag_sig_count(self):
        """{(genre,detail,particular): SỐ LƯỢNG THẬT} item trong TÚI (location==2) — để diff phân loại trước/sau.
        ⚠️ Cộng theo `stack` (KHÔNG +1/ô): đồ STACK được (vd Thiết La Hán) — 3 cái vào 1 ô stack=3, nếu đếm
        +1/ô sẽ ra 1 (bug: 'giao 3 TLH chỉ báo 1'). Đồ không stack thì stack=1 → +1 như cũ."""
        out = {}
        try:
            for it in (self.game_bot.dump_bag_items() or {}).get('items', []):
                if it.get('location') == 2:
                    k = (it.get('genre'), it.get('detail'), it.get('particular'))
                    out[k] = out.get(k, 0) + max(1, int(it.get('stack', 1) or 1))
        except Exception:
            pass
        return out

    def _treasurer_serve(self, worker_cid, worker_name=''):
        """Hoàn tất 1 giao dịch với worker: accept -> (chờ worker bỏ đồ) -> cấp tiền nếu 'money' -> lock ->
        chờ chống lừa -> confirm. Gửi event có cấu trúc lên UI (Nhận/Giao). Lỗi -> cancel (không kẹt).
        DEDUP: KHÔNG phục vụ lại cùng 1 worker trong 60s (worker retry 3 lần -> tránh cấp tiền/log 3 lần)."""
        from core import treasurer as _T
        if self._stopping(): return   # tắt/pause Auto TRƯỚC khi bắt đầu giao dịch (KHÔNG ngắt giữa lock↔confirm — rule atomic)
        who = worker_name or f"cid {worker_cid}"
        now = time.time()
        served = getattr(self, '_treasurer_served', None)
        if served is None:
            served = self._treasurer_served = {}
        if now - served.get(str(worker_cid), 0) < 60:
            self._chat(f"💰 {who} vừa được phục vụ (<60s) → bỏ qua lời mời lặp (tránh giao 2 lần).")
            return
        try:
            before = self._bag_sig_count()
            self._chat(f"💰 {who} mời giao dịch → chấp nhận.")
            self.game_bot.trade_accept(worker_cid)
            req = _T.get_request(worker_cid) or {}
            _T.set_request_status(worker_cid, 'trading')
            rtype = req.get('type')
            is_money = (rtype == 'money')
            give_amt = _T.give_money()                 # ngân lượng cấp/lần (config, mặc định 20 vạn)
            # ⚠️ ĐỒNG BỘ: thủ quỹ ADD (tiền/đồ — thay đổi khung) phải XONG TRƯỚC khi 2 bên lock; rồi thủ quỹ CHỜ
            # cho worker lock TRƯỚC (mọi add SAU lock = reset lock cả 2 → trade fail). Thủ quỹ lock SAU.
            if is_money:
                # MONEY: worker KHÔNG bỏ đồ -> lock NHANH (~t4). Thủ quỹ add tiền (xong trước khi worker lock)
                # rồi chờ NGẮN rồi lock -> 2 bên cùng lock sớm -> đủ thời gian chống-lừa trước khi confirm.
                self.game_bot.trade_add_cash(give_amt)
                time.sleep(4.0)                   # đủ để worker lock (worker lock ~t4) rồi thủ quỹ lock theo
            elif rtype == 'tongkim':
                # CẤP ITEM điểm tích luỹ Tống Kim: thủ quỹ tìm item Tống Kim trong túi MÌNH rồi add vào trade
                # (giống cấp tiền — add trước, worker lock, thủ quỹ lock sau). qty từ request (mặc định 1).
                qty = int(req.get('qty') or 1)
                n = self._treasurer_add_tongkim_items(qty)
                self._chat(f"🎟️ Cấp {n}/{qty} vật phẩm Tống Kim cho {who}.")
                time.sleep(4.0)
            else:
                # DEPOSIT: worker bỏ 8 món (~5s) rồi mới lock (~t8.8) -> thủ quỹ chờ LÂU hơn rồi lock sau.
                time.sleep(9.0)
            self.game_bot.trade_lock()            # ĐỒNG Ý (sau khi worker đã lock, khung ổn định)
            time.sleep(7.0)                       # độ trễ chống lừa ('đợi vài giây')
            self.game_bot.trade_confirm()         # XÁC NHẬN
            time.sleep(3.0)
            _T.set_request_status(worker_cid, 'done')
            served[str(worker_cid)] = time.time()  # đánh dấu đã phục vụ (chống phục vụ lại trong 60s)
            # PHÂN LOẠI item NHẬN theo PARTICULAR (KHÔNG theo genre/detail — MỌI đồ magicscript+Tống Kim đều
            # g6/d1, chỉ khác particular; phân theo g,d sẽ gộp NHẦM Thiết La Hán p2 vào "Lắc"). Thiết La Hán=p2;
            # tên có "Tống Kim" -> gộp nhóm "Lắc"; còn lại -> tên thật (particular_to_name).
            after = self._bag_sig_count()
            received = {}
            for (g, dt, p), n in after.items():
                d = n - before.get((g, dt, p), 0)
                if d <= 0:
                    continue
                if p == 2:
                    key = "Thiết la hán"
                else:
                    nm = _T.particular_to_name(p) or f"item #{p}"
                    key = "Lắc" if ("tống kim" in nm.lower() or "tong kim" in nm.lower()) else nm
                received[key] = received.get(key, 0) + d
            ev = {"who": who, "received": received, "money_van": (give_amt // 10000 if is_money else 0)}
            # gửi event có cấu trúc lên UI (format Nhận/Giao + đếm TLH); fallback _tlog text nếu chưa hook.
            if getattr(self, 'ui_treasurer_tx', None):
                try:
                    self.ui_treasurer_tx(ev)
                except Exception:
                    pass
            else:
                if is_money:
                    self._tlog(f"💰 Giao {give_amt//10000} vạn cho {who}.")
                if received:
                    self._tlog(f"📦 Nhận {received} từ {who}.")
            # LUÔN gộp toàn bộ đồ trong túi thủ quỹ sau MỖI giao dịch (đồ nhận từ nhiều worker dồn lại
            # -> không gộp thì rương thủ quỹ đầy nhanh). eItemJoin an toàn (gộp đồ cùng loại). 'money' cũng gộp.
            self._stack_bag_items()
        except Exception as e:
            logger.error(f"[treasurer] serve {worker_cid} lỗi: {e}")
            try:
                self.game_bot.trade_cancel()
            except Exception:
                pass
        finally:
            # MỖI khi gd xong (thành công HAY lỗi) -> dọn sạch lời mời gd còn tồn để thủ quỹ không bị
            # "full" popup mời chồng nhau -> lỗi giao dịch các lần sau. (yêu cầu user 2026-06-15)
            self._treasurer_clear_invites()

    def _treasurer_clear_invites(self):
        """Dọn lời mời gd TỒN trong recv_buffer sau khi 1 gd kết thúc (worker khác mời lúc thủ quỹ đang bận →
        151 dồn vào buffer → tick sau phục vụ stale). CHỈ xoá gói 151 trong buffer — TUYỆT ĐỐI KHÔNG gửi
        eTradeFinishCancel(163) ở đây.
        ⚠️ BUG 2026-06-15: trước có gọi trade_cancel(163) sau MỖI gd (kể cả thành công) → 163 bắn ~3s sau
        confirm, tới server lúc giao dịch CHƯA finalize (cần CẢ 2 bên confirm) → HỦY luôn gd → tiền/đồ KHÔNG
        chuyển = 'thủ quỹ không gd được với ai'. Swap KHÔNG đảm bảo xong trong 3s nên 163 ở đây luôn nguy hiểm.
        → Bỏ hẳn. Huỷ chỉ làm ở nhánh LỖI của _treasurer_serve (đúng ngữ cảnh)."""
        try:
            buf = getattr(self.game_bot, 'recv_buffer', []) or []
            n = sum(1 for p in buf if p.get('opcode') == 151)
            if n:
                self.game_bot.recv_buffer = [p for p in buf if p.get('opcode') != 151]
                logger.info(f"[treasurer] dọn {n} lời mời gd tồn trong buffer sau giao dịch")
        except Exception:
            pass

    # Vật phẩm "Phiếu Tích Lũy Tống Kim" (dùng → quy đổi 3500 điểm tích luỹ Tống Kim) = g6/d1/**p89**
    # (XÁC ĐỊNH 2026-06-12 bằng probe cất-kho: túi 2→1 + kho xuất hiện p89). Đây là item NV "nâng điểm" tiêu.
    # (Lắc Tống Kim 42/44/48/50/51 là đồ KHÁC — worker NỘP, không phải phiếu này.)
    TONGKIM_PARTICULARS = {89}

    def _treasurer_add_tongkim_items(self, qty):
        """Thủ quỹ tìm vật phẩm Tống Kim trong TÚI mình (location 2, g6, particular thuộc TONGKIM_PARTICULARS)
        và add vào trade tối đa `qty` cái. Trả số đã add. (gói trade_add_item đã verify ở luồng nộp đồ.)"""
        if not self.game_bot_connected:
            return 0
        added = 0
        try:
            dump = self.game_bot.dump_bag_items() or {}
            cands = [it for it in dump.get('items', [])
                     if it.get('location') == 2 and it.get('genre') == 6
                     and it.get('particular') in self.TONGKIM_PARTICULARS]
            for it in cands:
                if added >= qty:
                    break
                idx = it.get('index')
                if idx is None:
                    continue
                try:
                    self.game_bot.trade_add_item(int(idx))
                    added += 1
                    time.sleep(0.6)
                except Exception:
                    pass
            if added < qty:
                self._tlog(f"⚠️ Thủ quỹ chỉ còn {added}/{qty} vật phẩm Tống Kim trong túi (hết hàng?).")
        except Exception as e:
            logger.error(f"[treasurer] add tongkim items lỗi: {e}")
        return added

    def _handle_tongkim_points(self):
        """NV 'nâng điểm tích luỹ Tống Kim': đảm bảo có Phiếu Tích Lũy Tống Kim (p89) → dùng 1 phiếu (+3500đ,
        1 cái LUÔN đủ — user chốt) → trả NV (mở Dã Tẩu; NV 'đạt ngưỡng' nên server tự hoàn thành khi đủ điểm →
        245, giống đồ chí). Thiếu phiếu → xin thủ quỹ; vẫn không có → PENDING (KHÔNG tự hủy).
        ⚠️ Bước turn-in tái dùng pattern đồ chí — CẦN 1 lần verify trên NV thật; chưa bắt 245 thì PENDING (an toàn)."""
        from core import treasurer as _T
        from core.equip_matcher import split_frames
        if not self.game_bot_connected:
            self._goto_state(BotState.TRAINING); return

        def _phieu_idx():
            for it in (self.game_bot.dump_bag_items() or {}).get('items', []):
                if it.get('location') == 2 and it.get('genre') == 6 \
                        and it.get('particular') in self.TONGKIM_PARTICULARS:
                    return it.get('index')
            return None

        idx = _phieu_idx()
        if idx is None:
            if _T.read_info():                       # thủ quỹ online → đi xin 1 phiếu
                self._chat("🎟️ Không có Phiếu Tích Lũy Tống Kim → tới thủ quỹ nhận.")
                self._do_treasurer_errand('tongkim')
                idx = _phieu_idx()
            if idx is None:
                self._need_help("Không có Phiếu Tích Lũy Tống Kim (túi trống + thủ quỹ offline/hết hàng). "
                                "Đứng chờ — KHÔNG tự hủy.")
                self._goto_state(BotState.TRAINING); return

        self._chat(f"🎟️ Dùng 1 Phiếu Tích Lũy Tống Kim (ô {idx}) → +3500 điểm.")
        self.game_bot.use_item(int(idx))
        time.sleep(2.0)

        # Trả NV: mở Dã Tẩu, gom 245 (server tự hoàn thành khi đủ điểm); chưa có thì bấm 'Đã hoàn thành' ≤3 lần.
        self._chat("📨 Mở Dã Tẩu trả NV nâng điểm…")
        pkts = self.open_datau() or []
        def _find_245(extra):
            pool = list(extra or []) + list(self.game_bot.poll_recv() or []) \
                + list(getattr(self.game_bot, 'recv_buffer', []) or [])
            for p in pool:
                for op, hx in (split_frames(p.get('hex', '')) or [(p.get('opcode'), p.get('hex', ''))]):
                    if op == 245:
                        return hx
            return None
        award_hex = _find_245(pkts)
        for _ in range(3):
            if self._stopping(): break
            if award_hex:
                break
            self._select_pkt()
            t0 = time.time(); seen = []
            while time.time() - t0 < 2.5:
                seen.extend(self.game_bot.poll_recv() or [])
                time.sleep(0.1)
            award_hex = _find_245(seen)

        if award_hex:
            try:
                self._select_reward(prefetched_hex=award_hex)
            except Exception as e:
                logger.error(f"[TONGKIM] chọn thưởng lỗi: {e}")
            self._chat("✅ Hoàn thành NV nâng điểm tích luỹ Tống Kim + nhận thưởng.")
            self._on_quest_completed()
            self.current_quest = None
            self._goto_state(BotState.IDLE_PRECHECK)
        else:
            self._need_help("Đã dùng phiếu nhưng chưa bắt 245 trả NV nâng điểm (kiểm tra game — có thể đã xong, "
                            "hoặc cần điều chỉnh bước trả). KHÔNG tự hủy.")
            self._goto_state(BotState.TRAINING)

    # NV "nâng cấp điểm <stat>": map tên stat -> (field gói eAddPropField, key đọc từ getCharStats).
    # eAddPropField: power=Sức Mạnh, inside=Nội Công, outer=Sinh Khí, agility=Thân Pháp (verify từ protocol +
    # struct Character live: agility=25 đúng là Thân Pháp thấp). Cộng điểm KHÔNG hồi lại -> map phải chuẩn.
    NANG_TT_MAP = {
        "sức mạnh": ("power", "power"),
        "nội công": ("inside", "inside"),
        "sinh khí": ("outer", "outer"),
        "thân pháp": ("agility", "agility"),
    }

    def _parse_nang_thuoc_tinh(self, q):
        """Nhận diện NV 'Hãy nâng cấp điểm <stat> của bản thân lên ít nhất N điểm(+M)'.
        Trả (stat_key, field, target_N, add_M) hoặc None nếu không phải loại này."""
        import re as _re
        txt = (getattr(q, 'clean_text', '') or getattr(q, 'raw_text', '') or '')
        low = txt.lower()
        if "nâng cấp điểm" not in low:
            return None
        stat = next((s for s in self.NANG_TT_MAP if s in low), None)
        if not stat:
            return None
        field = self.NANG_TT_MAP[stat][0]
        mN = _re.search(r'ít nhất\s+(\d+)\s*điểm', low)
        mM = _re.search(r'\(\+\s*(\d+)\s*\)', low)
        target = int(mN.group(1)) if mN else 0
        add = int(mM.group(1)) if mM else 1     # mặc định +1 nếu không parse được dấu (+M)
        return (stat, field, target, add)

    def _handle_nang_thuoc_tinh(self, stat, field, target_N, add_M):
        """TỰ làm NV nâng điểm thuộc tính: đọc stat hiện tại + leftProp -> cộng đúng (+M) điểm vào đúng stat bằng
        eAddPropField -> verify stat tăng -> trả NV (đạt-ngưỡng: open_datau -> bắt 245 -> chọn thưởng).
        Thiếu điểm tiềm năng (leftProp<M) -> PENDING (KHÔNG tự hủy). Cộng điểm KHÔNG undo nên: chỉ cộng khi
        CHƯA đạt N, và cộng ĐÚNG field đã map."""
        from core.equip_matcher import split_frames
        if not self.game_bot_connected:
            self._goto_state(BotState.TRAINING); return
        self._chat(f"📂 Loại NV: Nâng điểm {stat} ≥{target_N} (+{add_M}) → tự cộng điểm tiềm năng.")

        def _stats():
            try:
                r = self.game_bot.rpc.get_char_stats() or {}
                return r if r.get('ok') else None
            except Exception:
                return None

        st = _stats()
        if not st:
            self._need_help("Không đọc được điểm thuộc tính (getCharStats fail) → KHÔNG cộng mù. Đứng chờ.")
            self._goto_state(BotState.TRAINING); return
        cur = int(st.get(field) or 0)
        left = int(st.get('leftProp') or 0)
        # đã đủ rồi -> trả luôn (không cộng thừa)
        if cur >= target_N:
            self._chat(f"✅ {stat} hiện {cur} ≥ {target_N} (đã đủ) → trả NV luôn.")
        else:
            need = add_M                                  # user chốt: cộng ĐÚNG (+M) ghi trong NV
            if left < need:
                self._need_help(f"NV nâng {stat} ≥{target_N}: cần +{need} điểm nhưng chỉ còn {left} điểm tiềm năng "
                                f"(leftProp). Lên cấp để có điểm rồi Resume. KHÔNG tự hủy.")
                self._goto_state(BotState.TRAINING); return
            self._chat(f"➕ Cộng {need} điểm {stat} ({field}): {cur}→{cur+need} (leftProp {left}→{left-need}).")
            self.game_bot.send_gs('eAddPropField', **{field: int(need)})
            time.sleep(1.5)
            st2 = _stats()
            new = int((st2 or {}).get(field) or cur) if st2 else cur
            if st2 and new <= cur:
                self._need_help(f"Đã gửi eAddPropField({field}={need}) nhưng {stat} không tăng ({cur}→{new}). "
                                f"Kiểm tra (sai field? hết điểm?). KHÔNG tự hủy, KHÔNG cộng lại.")
                self._goto_state(BotState.TRAINING); return
            self._chat(f"✔️ {stat} đã tăng {cur}→{new}.")

        # TRẢ NV (đạt-ngưỡng giống đồ chí/Tống Kim): mở Dã Tẩu -> server tự hoàn thành -> 245.
        self._chat("📨 Mở Dã Tẩu trả NV nâng điểm thuộc tính…")
        _qno = getattr(self.current_quest, 'quest_number', 0) or 0
        pkts = self.open_datau() or []
        # Dã Tẩu CÂM TẠM (vừa cộng điểm/đổi map) → retry vài lần thay vì PENDING oan (như flow đồ chí).
        if not pkts:
            for _i in range(4):
                if self._stopping() or not self.game_bot_connected:
                    self._goto_state(BotState.TRAINING); return
                self._chat(f"⏳ Dã Tẩu chưa phản hồi — thử lại {_i+1}/4 sau 12s…")
                if self._isleep(12):
                    self._goto_state(BotState.TRAINING); return
                pkts = self.open_datau() or []
                if pkts:
                    break

        def _find_245(extra):
            pool = list(extra or []) + list(self.game_bot.poll_recv() or []) \
                + list(getattr(self.game_bot, 'recv_buffer', []) or [])
            for p in pool:
                for op, hx in (split_frames(p.get('hex', '')) or [(p.get('opcode'), p.get('hex', ''))]):
                    if op == 245:
                        return hx
            return None

        award_hex = _find_245(pkts)
        for _ in range(3):
            if self._stopping(): break
            if award_hex:
                break
            self._select_pkt()
            t0 = time.time(); seen = []
            while time.time() - t0 < 2.5:
                seen.extend(self.game_bot.poll_recv() or [])
                time.sleep(0.1)
            award_hex = _find_245(seen)

        if award_hex:
            try:
                self._select_reward(prefetched_hex=award_hex)
            except Exception as e:
                logger.error(f"[NANG_TT] chọn thưởng lỗi: {e}")
            self._chat(f"✅ Hoàn thành NV nâng điểm {stat} + nhận thưởng.")
            self._on_quest_completed()
            self.current_quest = None
            self._goto_state(BotState.IDLE_PRECHECK)
            return
        # KHÔNG bắt được 245 qua _find_245: THỬ NHẬN THƯỞNG ROBUST (quét rộng recv_buffer + poll, KHÔNG bấm
        # select nữa kẻo dismiss bảng) — chống bỏ sót bảng thưởng đang mở (bug "bảng thưởng hiện mà bỏ qua").
        if self._claim_award_if_present(dochi=False):
            self._chat(f"✅ Hoàn thành NV nâng điểm {stat} + nhận thưởng (claim robust).")
            self._on_quest_completed()
            self.current_quest = None
            self._goto_state(BotState.IDLE_PRECHECK)
            return
        # Vẫn không có 245: có thể server ĐÃ hoàn thành (245 mất thật do flood) — kiểm dialog ĐÃ NHẢY NV kế chưa.
        # NV không còn = ĐÃ XONG (đừng PENDING oan); còn nguyên = thật sự chưa trả → PENDING.
        if _qno and not self._datau_quest_still_active(_qno):
            self._chat(f"✅ NV nâng điểm {stat} đã xong (dialog nhảy NV kế; 245 mất do flood — bỏ qua).")
            self._on_quest_completed()
            self.current_quest = None
            self._goto_state(BotState.IDLE_PRECHECK)
            return
        self._need_help(f"Đã cộng điểm {stat} nhưng chưa trả được NV (Dã Tẩu câm / chưa bắt 245). "
                        f"KHÔNG tự hủy — kiểm tra rồi Resume.")
        self._goto_state(BotState.TRAINING)

    def request_go_treasurer(self, reason='deposit'):
        """Đặt cờ + chuyển sang GO_TREASURER. reason: 'deposit' (giao đồ) | 'money' (nhận 20 vạn) |
        'tongkim' (nhận vật phẩm điểm tích luỹ Tống Kim)."""
        self._treasurer_reason = reason
        self._goto_state(BotState.GO_TREASURER)

    def _handle_go_treasurer(self):
        """State wrapper: chạy errand tới thủ quỹ rồi về IDLE_PRECHECK (dùng khi trigger qua state)."""
        reason = getattr(self, '_treasurer_reason', 'deposit')
        self._do_treasurer_errand(reason)
        self._goto_state(BotState.IDLE_PRECHECK)

    TREASURER_NEAR_TILES = 6   # minimap ô: invite/add-item ĐÃ chạy được ở 3 ô (server cho trade) nên cự ly
                               # trade thoải mái; để 6 (thay vì 4 quá sát khiến re-walk bỏ cuộc ngay ở ~4 ô).
    TREASURER_ARRIVE_STEPS = 8 # khi KHÔNG đọc được vị trí mình: số nhịp walk_to (×2s) tiếp tục đi SAU khi thủ
                               # quỹ vào tầm nhìn, để hội tụ SÁT ô thủ quỹ trước khi trade (tránh trade từ xa).

    def _own_pos_minimap(self):
        """(cx, cy, mapId) toạ độ MINIMAP của CHÍNH MÌNH. get_player_info mapX/mapY = WORLD (5 số) -> //256.
        None nếu đọc hụt. (Cả codebase tin get_player_info mapX/mapY là vị trí mình — xem walk_to game_bot.py:1301.)"""
        try:
            pi = self.game_bot.rpc.get_player_info() or {}
            mx, my = pi.get('mapX'), pi.get('mapY')
            if not mx or not my:
                return None
            return int(mx) // 256, int(my) // 256, pi.get('mapId')
        except Exception:
            return None

    def _treasurer_in_sight(self, t_cid):
        """cid thủ quỹ CÓ trong near-players của worker không (GetNearPlayers — đọc thẳng dictionary PlayerMain
        của CHÍNH worker, recv-độc-lập, ĐÁNG TIN). True = thủ quỹ đang trong tầm nhìn worker = đủ gần để trade."""
        try:
            r = self.game_bot.rpc.get_near_players() or {}
            return str(t_cid) in {str(p.get('id')) for p in (r.get('players') or [])}
        except Exception:
            return None   # đọc hụt -> không kết luận

    def _walk_to_treasurer_until_near(self, gx, gy, t_map, t_cid, max_iters=20):
        """Đi bộ tới khi SÁT thủ quỹ. 'Tới sát' = cid thủ quỹ XUẤT HIỆN trong near-players của worker
        (GetNearPlayers) + đã đi tới đúng ô thêm vài nhịp cho sát tầm trade.
        ⚠️ KHÔNG đọc toạ độ mình nữa: get_player_info mapX/mapY (opcode 9) = 0 khi đứng / lẫn entity khác,
        readPositionFromMemory crash 64-bit -> gate cũ tưởng-gần-mà-xa -> invite từ xa -> gd lỗi. near-list
        đọc PlayerMain của chính worker nên đáng tin (verify live: cid thủ quỹ 103176 hiện trong near-list)."""
        # near-players (AOI) THẤY thủ quỹ từ XA (chục ô) → nếu trade ngay là CÁCH XA → lỗi k/c. Vì vậy sau khi
        # thủ quỹ vào tầm nhìn, ĐI TIẾP cho sát: (a) nếu đọc được vị trí mình + đã ≤ NEAR ô → trade ngay;
        # (b) không đọc được vị trí → đi thêm đủ ARRIVE_STEPS nhịp (GotoFindingPath nhắm đúng ô thủ quỹ, re-issue
        # mỗi 2s → hội tụ dần) rồi mới trade. approach NHỎ (30) để GotoFindingPath dừng SÁT hơn.
        near_streak = 0
        for i in range(max_iters):       # tối đa ~max_iters*2 giây
            if self._stopping(): return False
            try:
                self.game_bot.walk_to(gx, gy, approach=30)   # approach nhỏ → tiến sát ô thủ quỹ hơn
            except Exception:
                pass
            time.sleep(2.0)
            if not self._treasurer_in_sight(t_cid):
                near_streak = 0   # mất tầm nhìn / đọc hụt -> đi tiếp, CHƯA trade
                continue
            near_streak += 1
            if near_streak == 1:
                self._chat("💼 Thủ quỹ vào tầm nhìn → đi tiếp cho thật sát…")
            # (a) CÓ vị trí mình (đọc được, ≠0) → trade NGAY khi đã ≤ NEAR ô (sát thật).
            mp = self._own_pos_minimap()
            if mp and mp[0] and mp[1]:
                dist = max(abs(int(mp[0]) - int(gx)), abs(int(mp[1]) - int(gy)))
                if dist <= self.TREASURER_NEAR_TILES:
                    self._chat(f"💼 Đã tới sát thủ quỹ (cách ~{dist} ô) → giao dịch.")
                    return True
                continue   # còn xa → đi tiếp, đừng trade vội
            # (b) KHÔNG đọc được vị trí → đi thêm đủ nhịp cho hội tụ sát rồi mới trade.
            if near_streak >= self.TREASURER_ARRIVE_STEPS:
                self._chat(f"💼 Đã đi {near_streak} nhịp trong tầm nhìn thủ quỹ (tiến sát) → giao dịch.")
                return True
        self._chat(f"💼 CHƯA tới sát thủ quỹ sau ~{max_iters*2}s đi bộ → KHÔNG gửi giao dịch "
                   f"(tránh lỗi khoảng cách), lần sau giao tiếp.")
        return False

    def _do_treasurer_errand(self, reason='deposit'):
        """ĐỒNG BỘ: WORKER tới THỦ QUỸ giao item / nhận 20 vạn rồi TRẢ VỀ (KHÔNG đổi state) — gọi inline được.
        travel (Xa Phu) -> đi bộ tới toạ độ cố định (config) -> invite -> trade. Trả True nếu giao dịch OK.
        AN TOÀN: thủ quỹ offline / chưa cấu hình vị trí / fail -> trả False, KHÔNG kẹt, KHÔNG tự hủy NV."""
        from core import treasurer as _T
        if not self.game_bot_connected:
            return False
        if self._stopping(): return False
        info = _T.read_info()                 # cid thủ quỹ (đọc được dù pos=0)
        pos = _T.treasurer_pos()              # (map_id, gx, gy) cố định
        if not info or not info.get('cid') or not pos:
            self._chat("💼 Cần tới thủ quỹ nhưng thủ quỹ offline / chưa cấu hình vị trí → bỏ qua, chạy tiếp.")
            return False
        t_cid = info['cid']; t_map, gx, gy = pos
        t_town = _T.town_for_map(t_map)       # suy tên thành (Xa Phu) từ mapId — không cần nhập tay
        try:
            pi = self.game_bot.rpc.get_player_info() or {}
            my_cid, my_map = pi.get('cid'), pi.get('mapId')
        except Exception:
            my_cid, my_map = None, None
        if not my_cid:
            return False
        # ĐỪNG tự giao dịch với CHÍNH MÌNH (nếu vô tình worker==treasurer)
        if str(my_cid) == str(t_cid):
            return False
        _T.add_request(my_cid, reason)
        try:
            # 0) ĐÓNG SẠCH popup còn sót (Dã Tẩu/GiveBox/bảng xếp hạng...) TRƯỚC khi lên đường — không để
            #    chồng đống trên màn suốt lúc di chuyển tới thủ quỹ.
            self._clear_popups("trước khi tới thủ quỹ")
            # 1) tới đúng map thủ quỹ (Xa Phu) nếu khác — VERIFY ĐÃ TỚI ĐÚNG MAP trước khi đi bộ.
            #    (BUG cũ: Xa Phu xong KHÔNG kiểm map → đi nhầm sang Tương Dương vẫn tưởng Biện Kinh → đi bộ
            #     toạ độ thủ quỹ trong map SAI. Giờ poll mapId tới khi == t_map; không tới được → bỏ qua an toàn.)
            if t_map and my_map and my_map != t_map and t_town:
                arrived = False
                for _try in range(2):
                    if self._stopping(): return False
                    self._chat(f"💼 Tới thủ quỹ: Xa Phu sang {t_town} (map {t_map})…")
                    try:
                        self.game_bot.xaphu_travel(t_town)
                    except Exception:
                        pass
                    self._clear_popups("sau Xa Phu")   # Xa Phu mở menu hội thoại -> đóng kẻo chồng
                    cur = None
                    t0 = time.time()
                    while time.time() - t0 < 8:        # chờ mapId cập nhật sau khi dịch chuyển
                        if self._stopping(): return False
                        cur = (self.game_bot.rpc.get_player_info() or {}).get('mapId')
                        if cur == t_map:
                            arrived = True; break
                        time.sleep(1.0)
                    if arrived:
                        break
                    self._chat(f"💼 Sau Xa Phu đang ở map {cur} ≠ map thủ quỹ {t_map} ({t_town}) → thử lại.")
                if not arrived:
                    self._chat(f"💼 KHÔNG tới được map thủ quỹ {t_town}(map {t_map}) bằng Xa Phu (đang ở map khác) → "
                               f"bỏ qua giao thủ quỹ lần này (đồ giữ nguyên, KHÔNG đi bộ nhầm map). Chạy tiếp.")
                    return False
            # 2) đi bộ + CHỜ TỚI SÁT mới giao dịch. KHÔNG invite khi còn xa (server check k/c -> fail + user
            #    thấy "chưa đến đã gửi gd"). Tới sát fail -> bỏ qua AN TOÀN (đồ vẫn trong túi, lần sau giao).
            self._ensure_mounted()   # lên ngựa trước khi đi bộ tới thủ quỹ (nhận tiền/giao đồ) cho nhanh
            self._chat(f"💼 Đi bộ tới thủ quỹ ({gx},{gy})…")
            if not self._walk_to_treasurer_until_near(gx, gy, t_map, t_cid):
                return False
            # 3) giao dịch (worker side) — RETRY 3 lần (timing 2 máy hay lệch/flaky); mỗi lần lệch thì huỷ +
            #    đi lại CHO SÁT (verify khoảng cách) rồi MỚI invite tiếp — không bao giờ invite từ xa.
            ok = False
            for att in range(3):
                if self._stopping(): break
                ok = self._worker_trade_with_treasurer(t_cid, reason)
                if ok:
                    break
                self._chat(f"💼 Giao dịch lần {att+1}/3 chưa xong → huỷ, đi lại sát rồi thử lại.")
                try:
                    self.game_bot.trade_cancel()
                except Exception:
                    pass
                time.sleep(1.5)
                if not self._walk_to_treasurer_until_near(gx, gy, t_map, t_cid, max_iters=14):
                    break   # đi lại vẫn không sát -> dừng (đừng invite từ xa)
            if ok:
                self._tlog(f"✅ Đã {'nhận tiền từ' if reason=='money' else 'giao đồ cho'} thủ quỹ {info.get('name') or t_cid}.")
                if reason == 'deposit':
                    # đánh dấu ACCOUNT hiện tại ĐÃ NỘP thủ quỹ hôm nay (cho cột tab Tài khoản)
                    try:
                        q = getattr(self, 'account_queue', []) or []
                        idx = getattr(self, 'account_index', 0)
                        acc = q[idx].get('acc') if 0 <= idx < len(q) else None
                        if acc:
                            _T.mark_deposited(self.device_id, acc)
                    except Exception:
                        pass
            else:
                self._chat("💼 Giao dịch với thủ quỹ chưa xong sau 3 lần → chạy tiếp, đồ vẫn trong túi (lần sau giao tiếp).")
            return ok
        finally:
            _T.clear_request(my_cid)

    def _worker_trade_with_treasurer(self, t_cid, reason):
        """1 lượt trade phía WORKER: invite -> (deposit: bỏ item giao) -> lock -> CHỜ 6s -> confirm.
        Verify: 'money' -> bạc tăng; 'deposit' -> số item giao giảm. Fail -> cancel. Trả True nếu OK."""
        from core import treasurer as _T
        if self._stopping(): return False   # tắt/pause TRƯỚC khi mời gd (KHÔNG ngắt giữa lock↔confirm — rule atomic)
        try:
            gb = self.game_bot
            parts = _T.give_particulars(_T.load_config().get('give_names'))
            # DEPOSIT: give-set có thể đã bị cất KHO (do _stash_full_bag khi đầy rương) -> LẤY LẠI về túi trước khi giao.
            if reason == 'deposit':
                self._retrieve_giveset_from_storage()
            def _bag():
                return [it for it in (gb.dump_bag_items() or {}).get('items', []) if it.get('location') == 2]
            money0 = (gb.rpc.get_money() or {}).get('bagarate')
            give0 = [it for it in _bag() if _T.is_giveable(it, parts)] if reason == 'deposit' else []
            tk0 = sum(1 for it in _bag() if it.get('genre') == 6
                      and it.get('particular') in self.TONGKIM_PARTICULARS) if reason == 'tongkim' else 0

            t_invite = time.time()
            gb.trade_invite(t_cid)
            # CHỜ THỦ QUỸ CHẤP NHẬN: server mở giao dịch → gửi 153 (eTradeStart) cho worker. KHÔNG có 153 trong
            # ~6s = invite BỊ TỪ CHỐI (chưa đủ gần — server check k/c) HOẶC thủ quỹ chưa nhận → KHÔNG bỏ đồ/lock
            # (tránh "ở xa vẫn gd"). Trả False → errand đi lại SÁT hơn rồi thử lại; KHÔNG chạy tiếp khi GD chưa mở.
            started = gb.wait_for_packet((153, 'eTradeStart'), timeout=6.0)
            if not started:
                self._chat("💼 Mời giao dịch CHƯA được chấp nhận (chưa đủ gần / thủ quỹ bận) → bỏ lượt này, "
                           "sẽ đi sát hơn rồi thử lại (KHÔNG bỏ đồ khi GD chưa mở).")
                return False
            if reason == 'deposit':
                added = 0
                for it in give0[:8]:                          # tối đa 8 món/lượt cho an toàn
                    try:
                        gb.trade_add_item(int(it.get('index'))); added += 1; time.sleep(0.6)
                    except Exception:
                        pass
                self._chat(f"💼 Đã bỏ {added} món vào khung giao dịch.")
            # ⚠️ Bỏ HẾT đồ XONG mới lock (add sau lock = reset lock). KHÔNG add/đổi gì sau lock.
            # ĐỒNG BỘ 2 MÁY: thủ quỹ lock ~invite+10 (accept+9), anti-scam = confirm chỉ hợp lệ ≥6s sau khi
            # CẢ HAI lock. Worker ÍT MÓN lock rất sớm -> nếu confirm theo "lock+9" thì confirm QUÁ SỚM (trước
            # invite+16) -> fail. -> CONFIRM theo MỐC TUYỆT ĐỐI từ invite (~t17): ổn cho cả 1 lẫn 8 món.
            time.sleep(1.0)
            gb.trade_lock()                                   # ĐỒNG Ý (đã bỏ hết đồ)
            CONFIRM_AT = 17.0                                 # giây kể từ invite (khớp thủ quỹ lock~10 + 6s chống lừa)
            remain = CONFIRM_AT - (time.time() - t_invite)
            if remain > 0:
                time.sleep(remain)
            gb.trade_confirm(); time.sleep(3.0)               # XÁC NHẬN

            if reason == 'money':
                m1 = (gb.rpc.get_money() or {}).get('bagarate')
                return bool(m1 is not None and money0 is not None and m1 > money0)
            elif reason == 'tongkim':
                tk1 = sum(1 for it in _bag() if it.get('genre') == 6
                          and it.get('particular') in self.TONGKIM_PARTICULARS)
                return tk1 > tk0                                # nhận thêm item Tống Kim = OK
            else:
                give1 = [it for it in _bag() if _T.is_giveable(it, parts)]
                return len(give1) < len(give0)                 # đã giao bớt = OK
        except Exception as e:
            logger.error(f"[worker_trade] {e}")
            try:
                self.game_bot.trade_cancel()
            except Exception:
                pass
            return False

    def _stopping(self):
        """True nếu UI đã yêu cầu DỪNG Auto (_run_active=False set bởi _stop_bot). Vòng DÀI (walk/rảo/quét/cày)
        check để thoát NGAY khi tắt Auto. (ĐÃ REVERT pause: tắt Auto = dừng hẳn + nhả Frida như cũ, KHÔNG còn
        _auto_paused — sweep _stopping/_isleep vẫn giữ, chỉ kích hoạt khi DỪNG thật nên benign.)"""
        return not getattr(self, '_run_active', True)

    def _isleep(self, secs):
        """Sleep NGẮT ĐƯỢC: ngủ `secs` theo từng nhịp 0.3s, TRẢ True NGAY khi _stopping() (tắt/pause Auto) để
        caller thoát sớm. Dùng thay time.sleep ở các bước chờ DÀI trong flow → tắt Auto giữa chừng dừng trong
        ~0.3s thay vì đợi hết. Dùng: `if self._isleep(6): return`."""
        end = time.time() + float(secs)
        while time.time() < end:
            if self._stopping():
                return True
            time.sleep(min(0.3, max(0.0, end - time.time())))
        return self._stopping()

    # Các THÀNH đông sạp để TÌM ĐỒ NV (thứ tự ưu tiên). (tên Xa Phu, mapId, toạ độ GAME trung tâm Dã Tẩu/sạp).
    # Toạ độ verify live (user đứng tại chỗ → mapX/mapY //256): BK(37)=(216,193), TD(78)=(199,206),
    # Thành Đô(11)=(391,319) verify live 2026-06-14 (acc Sở Ngọc Cảnh đứng tại khu sạp).
    STALL_CITIES = [
        ("Biện Kinh",   37, (216, 193)),
        ("Tương Dương", 78, (199, 206)),
        # Thành Đô ĐÃ BỎ: thành 2 map (Xa Phu thả map 53, khu sạp ở map 11) → không hợp flow Xa-Phu-rồi-walk.
        ("Phượng Tường", 1, (201, 193)),
        ("Đại Lý",      162, (205, 201)),
        ("Dương Châu",   80, (216, 185)),
        # Lâm An (176) ĐÃ BỎ theo yêu cầu (tới Lâm An hay gây lỗi walk_to).
    ]

    XAPHU_RESERVE = 5000   # bạc TÚI tối thiểu giữ cho phí Xa Phu (đủ vài hop 300-500 lượng); thiếu → rút từ kho

    # QUÉT SẠP TOÀN MAP: 7 thành + 10 thôn (tên KHỚP menu Xa Phu trong xaphu_routes.json cat1/cat2).
    SCAN_ALL_DESTS = [
        "Biện Kinh", "Tương Dương", "Phượng Tường", "Đại Lý", "Dương Châu", "Thành Đô", "Lâm An",
        "Ba Lăng Huyện", "Giang Tân Thôn", "Long Môn Trấn", "Nam Nhạc Trấn", "Long Tuyền Thôn",
        "Đạo Hương Thôn", "Vĩnh Lạc Trấn", "Chu Tiên Trấn", "Thạch Cổ Trấn", "Tây Sơn Thôn",
    ]

    def _travel_thp(self, name):
        """Đi tới 1 thành/thôn bằng THP (Thần Hành Phù, item túi). Menu THP = MENU XA PHU (verified: Tương Dương
        [1,4] khớp cả hai) → tra (cat,idx) từ bảng Xa Phu rồi thp_select([cat,idx,None]). Item nên KHÔNG cần
        đứng cạnh NPC (tiện hơn Xa Phu — Xa Phu hay fail vì không tìm thấy npc của thành). Trả:
        'moved' (mapId đổi) | 'no_thp' (hết THP) | 'no_route' (không có trong menu) | 'fail' (không đổi map)."""
        if self.game_bot.find_thp_slot() is None:
            return 'no_thp'
        route = self.game_bot.xaphu_route_for(name)
        if not route:
            return 'no_route'
        cat, idx, _ = route
        try: mid0 = (self.game_bot.rpc.get_player_info() or {}).get('mapId')
        except Exception: mid0 = None
        if not self.game_bot.thp_select([cat, idx, None]):
            return 'no_thp'
        time.sleep(1.5)
        try: mid1 = (self.game_bot.rpc.get_player_info() or {}).get('mapId')
        except Exception: mid1 = None
        return 'moved' if (mid1 is not None and mid1 != mid0) else 'fail'

    # Tâm Dã Tẩu (sạp bu quanh) theo TÊN — minimap 3 số, 5 thành VERIFY LIVE (= STALL_CITIES). Tới đây là "success".
    DATAU_CENTERS_GAME = {
        "Biện Kinh": (216, 193), "Tương Dương": (199, 206), "Phượng Tường": (201, 193),
        "Đại Lý": (205, 201), "Dương Châu": (216, 185),
    }
    DATAU_LEARNED_PATH = "data/output/datau_centers_world.json"   # {tên: [wx,wy]} HỌC live cho thôn/thành còn lại
    DATAU_SEED_IDS = {"1425", "1723", "588", "1049", "1192", "396", "714", "716", "3447", "8746", "4099"}

    def _walk_world_until(self, wx, wy, near=450, timeout=18.0):
        """walk_to_world (MAIN-THREAD GotoFindingPath) tới (wx,wy) world, re-issue tới khi áp sát/hết giờ.
        Trả True nếu áp sát (trong `near`)."""
        wx, wy = int(wx), int(wy)
        self.game_bot.walk_to_world(wx, wy)
        t0 = time.time(); last = None; resent = 0
        while time.time() - t0 < timeout:
            if self._stopping():
                return False
            time.sleep(0.6)
            try:
                r = self.game_bot.rpc.get_player_info() or {}
                x, y = r.get("mapX"), r.get("mapY")
            except Exception:
                x = y = None
            if x and y and abs(x - wx) <= near and abs(y - wy) <= near:
                return True
            if last and abs((x or 0) - last[0]) < 15 and abs((y or 0) - last[1]) < 15 and resent < 5:
                self.game_bot.walk_to_world(wx, wy); resent += 1
            last = (x or 0, y or 0)
        return False

    def _goto_datau_area(self, name):
        """ĐI TỚI khu Dã Tẩu của thành/thôn `name` (sạp bu quanh = mục tiêu). Trả True nếu áp sát.
        1) toạ độ ĐÃ BIẾT (bảng minimap / đã học world) → walk thẳng.
        2) chưa biết → đọc NPC Dã Tẩu trong tầm (get_near_npcs_detail có x,y) khớp tên 'tẩu' hoặc id seed →
           walk tới + HỌC lưu toạ độ world cho lần sau."""
        g = self.DATAU_CENTERS_GAME.get(name)
        if g:
            return self._walk_world_until(g[0] * 256, g[1] * 256)
        learned = self._read_json(self.DATAU_LEARNED_PATH) or {}
        w = learned.get(name)
        if isinstance(w, list) and len(w) == 2:
            return self._walk_world_until(w[0], w[1])
        # chưa biết → tìm NPC Dã Tẩu live
        try:
            npcs = (self.game_bot.rpc.get_near_npcs_detail() or {}).get("npcs") or []
        except Exception:
            npcs = []
        def _pos(n): return isinstance(n.get("x"), (int, float)) and isinstance(n.get("y"), (int, float))
        target = next((n for n in npcs if _pos(n) and "tẩu" in (n.get("name") or "").lower()), None) \
            or next((n for n in npcs if _pos(n) and str(n.get("id")) in self.DATAU_SEED_IDS), None)
        if target:
            ok = self._walk_world_until(target["x"], target["y"])
            if ok:
                learned[name] = [int(target["x"]), int(target["y"])]
                self._write_json(self.DATAU_LEARNED_PATH, learned)
                self._chat(f"   📌 Học toạ độ Dã Tẩu {name} = ({target['x']},{target['y']}) (lần sau đi thẳng).")
            return ok
        return False

    def scan_all_stalls(self):
        """QUÉT SẠP TOÀN MAP (1 vòng): THP tới từng thành+thôn → grid_sweep quét sạp → gom vào
        stall_catalog.json (thư viện chung, scan_stalls merge=True tự ghi). Best-effort: map nào không
        tới/không quét được → LOG + bỏ qua (không crash). Tôn trọng _stopping() (tắt giữa chừng thoát êm).
        Đi bằng THP (Thần Hành Phù, item) cho tiện — KHÔNG cần đứng cạnh Xa Phu npc. ĐÂY KHÔNG phải flow Dã Tẩu."""
        from core.stall_shopper import grid_sweep, load_catalog, catalog_counts, publish_catalog
        dests = self.SCAN_ALL_DESTS
        ni0, ns0 = catalog_counts(load_catalog())
        self._chat(f"🛒 QUÉT SẠP TOÀN MAP (đi bằng THP): {len(dests)} điểm (7 thành + 10 thôn). "
                   f"Thư viện đang có {ns0} sạp / {ni0} món. Bắt đầu…")
        done = 0; skipped = []
        for i, name in enumerate(dests):
            if self._stopping():
                self._chat("🛒 Dừng theo yêu cầu (tắt).")
                return
            self._chat(f"🛒 [{i+1}/{len(dests)}] → {name} (THP)…")
            try:
                r = self._travel_thp(name)
            except Exception as e:
                r = 'fail'; self._chat(f"   ⚠️ THP '{name}' lỗi: {e}")
            if r == 'no_thp':
                self._chat("🛒 HẾT Thần Hành Phù (THP) trong túi → DỪNG quét (mua thêm THP rồi chạy lại).")
                return
            if r != 'moved':
                skipped.append(name)
                self._chat(f"   ↪️ Không tới được {name} ({r}) → bỏ qua (best-effort).")
                continue
            if self._stopping():
                return
            try:
                self._ensure_mounted()
            except Exception:
                pass
            try:
                ni_b, ns_b = catalog_counts(load_catalog())
                from core.stall_shopper import goto_dense_stalls
                # 1) ĐI THẲNG TỚI DÃ TẨU (sạp bu quanh = mục tiêu). Biết toạ độ → walk thẳng; chưa biết → tìm NPC + học.
                arrived = self._goto_datau_area(name)
                if arrived:
                    self._chat(f"   ✅ Đã tới khu Dã Tẩu {name} → quét sạp bu quanh.")
                else:
                    self._chat("   ⚠️ Chưa tới được Dã Tẩu (chưa biết toạ độ + không thấy NPC) → homing theo cụm sạp.")
                    goto_dense_stalls(self.game_bot, log=lambda m: self._chat(f"   {m}"))
                # 2) quét KỸ quanh đó bằng lưới NHỎ (bán kính 600, 3×3) — vét sạp bu quanh Dã Tẩu.
                grid_sweep(self.game_bot, radius=600, step=600, goto_timeout=6.0,
                           log=lambda m: self._chat(f"   {m}"))
                ni_a, ns_a = catalog_counts(load_catalog())
                publish_catalog()          # ĐẨY ra shared NGAY → máy khác (LinhDL) đọc được luôn
                done += 1
                self._chat(f"   ✅ {name}: +{ns_a - ns_b} sạp MỚI, +{ni_a - ni_b} món MỚI vào thư viện "
                           f"(tổng {ns_a} sạp / {ni_a} món; đã đẩy shared cho máy khác).")
            except Exception as e:
                skipped.append(name)
                self._chat(f"   ⚠️ Quét {name} lỗi: {e}")
        pi, ps = publish_catalog()         # publish lần cuối (chắc chắn shared có bản mới nhất)
        ni, ns = catalog_counts(load_catalog())
        self._chat(f"🛒 XONG 1 vòng: quét {done}/{len(dests)} điểm; thư viện {ns} sạp / {ni} món "
                   f"(+{ns - ns0} sạp MỚI / +{ni - ni0} món MỚI lần này; đã đẩy shared → LinhDL đọc khỏi quét)."
                   + (f" Bỏ qua: {', '.join(skipped)}." if skipped else ""))

    def _ensure_mounted(self):
        """LÊN NGỰA trước khi đi bộ trong thành (đi nhanh hơn). set_riding(True) là set TƯỜNG MINH (không toggle)
        → đã cưỡi thì giữ nguyên, đang dưới ngựa thì lên = idempotent, an toàn gọi mọi lúc. Không có horse/đủ cấp
        thì server bỏ qua. CHỈ gọi trong THÀNH (không đụng lúc cày động/autoplay)."""
        try:
            self.game_bot.set_riding(True)
            time.sleep(0.4)
        except Exception:
            pass

    def _goto_city_center(self, cityname, mapid, center):
        """Đưa char tới TRUNG TÂM (sạp đông) của 1 thành. TRẢ True nếu ĐÃ tới ĐÚNG map; False nếu KHÔNG tới được
        → caller PHẢI bỏ qua thành đó (KHÔNG walk_to toạ độ thành khác = đi loạn + KHÔNG rảo nhầm chỗ).
        THIẾU TIỀN Xa Phu → RÚT TỪ KHO (Tiền Trang) rồi đi (user: thiếu thì rút rương rồi đi)."""
        if not self.game_bot_connected or self._stopping():
            return False
        # TẮT autoplay TRƯỚC khi đi (auto-AI đang BẬT sẽ ĐÈ walk_to → char không tới tâm điểm quét, đứng/đi loạn).
        try:
            self.game_bot.stop_autoplay()
        except Exception:
            pass
        try:
            mid = (self.game_bot.rpc.get_player_info() or {}).get('mapId')
        except Exception:
            mid = None
        if mid != mapid:
            # RÚT bạc travel từ KHO về TÚI TRƯỚC khi đi (nếu túi thiếu). _ensure_money: túi đủ→no-op;
            # túi thiếu+kho đủ→rút kho; cả 2 hết→thử thủ quỹ→PENDING (chỉ khi THỰC SỰ hết sạch).
            try:
                self._ensure_money(self.XAPHU_RESERVE)
            except Exception:
                pass
            self._chat(f"🏙 → {cityname} (sạp đông)…")
            ok = False
            try:
                if self._in_town():
                    ok = bool(self.game_bot.xaphu_to_city_by_name(cityname))   # thành↔thành (chọn theo tên)
                if not ok:
                    ok = bool(self.game_bot.xaphu_recall_to_city(cityname))    # ở ĐỘNG → menu field recall
            except Exception as e:
                logger.error(f"[find] về {cityname} lỗi: {e}")
            time.sleep(2)
            # CHƯA tới đúng map → ĐỪNG walk_to(toạ độ thành khác) + ĐỪNG rảo nhầm thành.
            try:
                cur = (self.game_bot.rpc.get_player_info() or {}).get('mapId')
            except Exception:
                cur = None
            if cur != mapid:
                if getattr(self.game_bot, 'last_xaphu_no_money', False):
                    # đã rút kho ở trên mà VẪN thiếu = kho cũng hết → rút thêm tối đa rồi thử LẠI 1 lần.
                    self._chat(f"💰 Thiếu tiền Xa Phu sang {cityname} → rút thêm từ kho, thử lại…")
                    try:
                        self._ensure_money(self.XAPHU_RESERVE)
                        if self._in_town():
                            ok = bool(self.game_bot.xaphu_to_city_by_name(cityname))
                        time.sleep(2)
                        cur = (self.game_bot.rpc.get_player_info() or {}).get('mapId')
                    except Exception:
                        pass
                if cur != mapid:
                    self._chat(f"⚠️ Chưa sang được {cityname} (đang map {cur}) → bỏ qua thành này (không quét nhầm chỗ).")
                    return False
            # VỪA ĐỔI MAP (teleport) → instance PlayerMain cache có thể STALE → ép re-resolve để walk_to tới
            # tâm hoạt động (bug: tới Lâm An xong walk_to chết vì invoke vào instance cũ).
            try:
                self.game_bot._invalidate_player_main()
            except Exception:
                pass
        # ĐÃ ở đúng map → LÊN NGỰA (nếu chưa) cho đi nhanh, rồi đi tới trung tâm + verify áp sát.
        self._ensure_mounted()
        gx, gy = center
        self._chat(f"🏙 Đi tới trung tâm {cityname} ({gx},{gy}) để quét sạp…")
        t0 = time.time()
        arrived = False
        # ĐI TỚI KHI THỰC SỰ SÁT TÂM (timeout 70s — sau Xa Phu char hay đứng im ~15-30s (map/navmesh đang load,
        # walk chưa ăn) rồi mới đi; tâm xa như BK cần thêm thời gian. Tới sát (≤6 ô) break NGAY nên thành gần vẫn nhanh).
        while time.time() - t0 < 70 and self.game_bot_connected and not self.paused and not self._stopping():
            try:
                self.game_bot.walk_to(gx, gy, 90)
            except Exception:
                break
            self._isleep(3)
            try:
                pi = self.game_bot.rpc.get_player_info() or {}
                mx, my = pi.get('mapX') or 0, pi.get('mapY') or 0
                if mx and my and abs(mx // 256 - gx) <= 6 and abs(my // 256 - gy) <= 6:
                    self._chat(f"🏙 ✅ Tới trung tâm {cityname} ({mx//256},{my//256}).")
                    arrived = True
                    break
            except Exception:
                pass
        if not arrived:
            try:
                pi = self.game_bot.rpc.get_player_info() or {}
                self._chat(f"🏙 ⚠️ Chưa sát tâm {cityname} sau 45s (đang {(pi.get('mapX') or 0)//256},"
                           f"{(pi.get('mapY') or 0)//256}) — vẫn quét quanh đây.")
            except Exception:
                pass
        # GUARD cuối: lạc sang map khác (động/thành khác) → không quét nhầm.
        try:
            cur_mid = (self.game_bot.rpc.get_player_info() or {}).get('mapId')
            if cur_mid is not None and cur_mid != mapid:
                self._chat(f"⚠️ Đang ở map {cur_mid} ≠ {cityname}(map {mapid}) → bỏ qua, không quét nhầm chỗ.")
                return False
        except Exception:
            pass
        return True

    def _goto_bienkinh_datau_center(self):
        """(giữ tên cũ — dùng ở submit_equip) → thành ĐẦU trong STALL_CITIES (Biện Kinh)."""
        c = self.STALL_CITIES[0]
        self._goto_city_center(c[0], c[1], c[2])

    def _handle_execute_find_equip(self):
        """NV tìm 1 món trang bị cụ thể (Ngọc Bội cấp8 hệ Kim...): rương -> sạp người chơi -> mua -> nộp."""
        from core.stall_shopper import resolve_quest_target, find_in_bag, scan_stalls, find_in_stalls
        q = self.current_quest
        qtext = (q.clean_text or q.raw_text or "") if q else ""
        spec = resolve_quest_target(qtext)
        if not spec:
            # Fallback: khớp theo THUỘC TÍNH trong rương (vd "đồ có thuộc tính sinh lực").
            if self.game_bot_connected:
                try:
                    from core.equip_matcher import find_slot_for_quest
                    dump0 = self.game_bot.dump_bag_items()
                    items0 = dump0.get("items", []) if dump0 and dump0.get("ok") else []
                    ares = find_slot_for_quest(qtext, items0)
                    if ares.get("ok"):
                        self.target_givebox_slot = ares["slot"]
                        self._chat(f"✅ Khớp theo thuộc tính, có sẵn ở ô {ares['slot']}. Đi nộp Dã Tẩu.")
                        self._goto_state(BotState.REWARD); return
                except Exception as e:
                    logger.error(f"[FIND_EQUIP] attribute fallback lỗi: {e}")
            self._need_help("Chưa nhận diện được món cần tìm (theo tên lẫn thuộc tính) — cần bạn xem giúp.")
            self._goto_state(BotState.TRAINING); return
        self._chat(f"🔎 Cần: {spec['desc']} (g{spec['genre']} d{spec['detail']} p{spec['particular']} lv{spec['level']})")
        if not self.game_bot_connected:
            self._goto_state(BotState.TRAINING); return

        # 1) Có sẵn trong rương?
        dump = self.game_bot.dump_bag_items()
        items = dump.get("items", []) if dump and dump.get("ok") else []
        slot, _ = find_in_bag(items, spec)
        if isinstance(slot, int) and slot >= 0:
            self.target_givebox_slot = slot
            self._chat(f"✅ Đã có sẵn trong rương (ô {slot}). Đi nộp Dã Tẩu.")
            self._goto_state(BotState.REWARD); return

        # 1b) MÓN CÓ BÁN Ở NPC TẠP HÓA? (đồ phổ thông như Cát Ngoa, giày/áo cấp thấp) -> MUA REMOTE,
        #      khỏi lùng sạp người chơi (sạp chỉ có đồ hiếm/thuộc tính). Tra TÊN trong shop_dict.json (tên ĐÚNG).
        from core import npc_shop
        for cand_name in [q.item_name, spec.get("name", "")]:
            if not (cand_name or "").strip():
                continue
            live = npc_shop.find_in_live_dict(cand_name)
            if not live:
                continue
            live_sk, live_idx = live
            self._chat(f"📖 '{cand_name}' có bán ở NPC shop {live_sk} (idx {live_idx}) → MUA REMOTE thay vì lùng sạp.")
            try:
                _key = self._buy_and_get_key(live_sk, live_idx, q.item_count or 1)
            except Exception as e:
                logger.error(f"[FIND_EQUIP] mua NPC lỗi: {e}"); _key = None
            if _key is not None:
                self.target_givebox_slot = _key
                if self._datau_complete(_key):
                    self._chat("✅ TRẢ NV THÀNH CÔNG (mua ở NPC shop).")
                    self._on_quest_completed(); self.current_quest = None; self.target_givebox_slot = -1
                    self._goto_state(BotState.IDLE_PRECHECK); return
                # nộp không khớp -> bán lại món vừa mua, đi tiếp quét sạp
                self._chat("  Nộp không khớp → bán lại, chuyển sang quét sạp người chơi.")
                try: self.game_bot.send_gs('eShopSellItem', itemid=int(_key))
                except Exception: pass
                self.npc_interact.dismiss_dialog()
            break

        # 1c) CHỈ TRA THƯ VIỆN CHUNG (KHÔNG rảo/quét live nữa — theo yêu cầu user). Thư viện = stall_catalog gộp
        #     local + shared (máy khác + listener quét sẵn). Có món hợp giá → remote-buy tại chỗ.
        max_price = int(getattr(self, 'buy_threshold_van', 5)) * 10000  # vạn -> lượng
        def _match(cat):
            return find_in_stalls(cat, spec, max_price=max_price)
        self._arm_quest_change_watch()   # khởi tạo _quest_changed_flag (_cache_buy_loop dùng) + bắt user đổi NV
        slot2 = self._cache_buy_loop(_match, lambda items2: find_in_bag(items2, spec)[0], label="đồ cần")

        if slot2 is not None and slot2 >= 0:
            self.target_givebox_slot = slot2
            self._chat(f"✅ Mua xong từ thư viện (ô {slot2}). Đi nộp Dã Tẩu.")
            self._goto_state(BotState.REWARD)
            return
        # THƯ VIỆN KHÔNG CÓ → mặc định HỦY 100 TẤM ĐỒ CHÍ; không đủ tấm → PENDING báo người chơi.
        self._cancel_dochi_or_pending(f"'{spec['desc']}'")

    def _name_by_cid(self, cid):
        """cid -> TÊN người chơi qua eOpenPlayerInfo(169)->op170 (REMOTE, cùng server). Cache. None nếu hụt.
        (Tên đọc từ memory sạp hay rỗng -> dùng cách này: gửi cid lên server lấy OtherPlayerProperties.name.)"""
        cid = str(cid)
        cache = getattr(self, '_cid_name_cache', None)
        if cache is None:
            cache = self._cid_name_cache = {}
        if cid in cache:
            return cache[cid]
        name = None
        try:
            if hasattr(self.game_bot, 'recv_buffer'):
                self.game_bot.recv_buffer = []
            self.game_bot.poll_recv()
            self.game_bot.send_gs('eOpenPlayerInfoRequest', targetCid=cid)
            pkts = self.game_bot.wait_for_packet((170,), timeout=2.5)
            for p in (pkts or []):
                if p.get('opcode') == 170:
                    b = bytes.fromhex(p.get('hex', ''))[6:]
                    # op170 = {1: OtherPlayerProperties}; trong đó field2 = name (string). Quét tag 0x12 trong f1.
                    if b and b[0] == 0x0a:
                        f1 = b[2:2 + b[1]]
                        q = 0
                        while q < len(f1):
                            tag = f1[q]; q += 1
                            if tag == 0x12:   # field2, wire2 = name
                                ln = f1[q]; q += 1
                                name = f1[q:q + ln].decode('utf-8', 'ignore'); break
                            elif (tag & 7) == 2:   # field string/bytes khác -> nhảy qua
                                ln = f1[q]; q += 1 + ln
                            elif (tag & 7) == 0:   # varint -> nhảy qua
                                while q < len(f1) and f1[q] & 0x80: q += 1
                                q += 1
                            else:
                                break
                    break
        except Exception:
            pass
        cache[cid] = name
        return name

    def _stall_label(self, cid):
        """Nhãn sạp = TÊN người bán. Tên: ưu tiên get_near_salesmans (memory), rỗng -> OpenPlayerInfo(cid) remote.
        ĐÃ BỎ toạ độ (cho an toàn — đọc vị trí sạp từng làm crash game)."""
        nm = None
        try:
            res = self.game_bot.rpc.get_near_salesmans()
            for s in (res or {}).get('players', []):
                if s.get('id') == cid:
                    nm = s.get('name'); break
        except Exception:
            pass
        if not nm:
            nm = self._name_by_cid(cid)   # tên rỗng từ memory -> hỏi server theo cid
        return str(nm or cid)

    def _town_name(self):
        """Tên thành/map hiện đứng (cho log sạp). '?' nếu đọc hụt."""
        try:
            mid = (self.game_bot.rpc.get_player_info() or {}).get('mapId')
            from database.db_manager import db as _db
            return _db.get_map_name(mid) if mid else "?"
        except Exception:
            return "?"

    def _send_buy_capture207(self, cid, item_index, price, timeout=5.0):
        """Gửi lệnh mua sạp + BẮT op207 (isOk) — tín hiệu ĐÁNG TIN nhất (đọc rương hay trễ/sai sau
        giao dịch thủ quỹ + flood). Trả: True = server xác nhận MUA OK; False = server TỪ CHỐI
        (đã bán/đóng sạp); None = không thấy 207 (flood nuốt) → để caller đọc rương xác nhận."""
        if hasattr(self.game_bot, 'recv_buffer'):
            self.game_bot.recv_buffer = []
        self.game_bot.poll_recv()
        self.game_bot.send_gs("ePlayerStallBuyItemRequest", stallCid=str(cid),
                              itemIndex=item_index, itemMoney=price)
        end = time.time() + timeout
        res = None
        while time.time() < end:
            for p in (self.game_bot.poll_recv() or []):
                if p.get("opcode") == 207 or p.get("name") == "ePlayerStallBuyItemResponse":
                    try:
                        b = bytes.fromhex(p["hex"])[6:]
                        res = bool(len(b) >= 2 and b[0] == 0x08 and b[1] != 0)  # field1 isOk
                    except Exception:
                        res = None
                    break
            if res is not None:
                break
            time.sleep(0.25)
        # ĐÓNG SESSION SẠP NGAY SAU KHI MUA: mua sạp người chơi mở dialog sạp server-side; KHÔNG đóng → server
        # bận → mở Dã Tẩu nộp NV bị CÂM ~40-70s (user: "gọi Dã Tẩu rất chậm", 13 node dò 2 lượt). eNpcSelect rỗng
        # = đóng dialog server; rồi DRAIN ack tới khi yên → open_datau kế TRÚNG NGAY.
        try:
            self.game_bot.send_gs("eNpcSelect")
            quiet_t = time.time(); t0 = time.time()
            while time.time() - t0 < 3.0:
                if self.game_bot.poll_recv():
                    quiet_t = time.time()
                elif time.time() - quiet_t > 0.8:
                    break
                time.sleep(0.12)
        except Exception:
            pass
        return res

    def _verify_bought_slot(self, verify_fn, ok207, tries=5):
        """Sau khi mua: đọc rương CÓ RETRY (rương cập nhật trễ sau mua/giao dịch) để lấy slot.
        verify_fn(bag_items)->slot(int>=0)|<0. ok207: kết quả _send_buy_capture207 (False=từ chối → khỏi
        retry). Trả (slot, bag_items) — slot<0 nếu không thấy."""
        for _ in range(tries):
            time.sleep(1.0)
            dump2 = self.game_bot.dump_bag_items()
            items2 = dump2.get("items", []) if dump2 and dump2.get("ok") else []
            try:
                slot = verify_fn(items2)
            except Exception:
                slot = -1
            if isinstance(slot, int) and slot >= 0:
                return slot, items2
            if ok207 is False:        # server đã từ chối → đọc thêm vô ích
                break
        return -1, []

    def _cache_buy_loop(self, matcher, verify, label="món", learn=True, max_tries=15):
        """DÒ THƯ VIỆN CHUNG (stall_catalog.json) TRƯỚC khi đi quét live: acc khác có thể đã quét sẵn →
        remote-buy TẠI CHỖ, KHỎI di chuyển. Mỗi món ĐỤNG TỚI (mua dù được/hụt) → remove_item khỏi JSON
        (acc khác khỏi duyệt lại; entry hỏng tự sạch dần).
          matcher(catalog) -> (cid, itemIndex, price, item, ...) | None   (rẻ nhất trước)
          verify(bag_items) -> slot (int>=0 nếu đã vào rương) | <0
        Trả slot rương (>=0) nếu mua được, else -1."""
        from core.stall_shopper import load_catalog_merged, remove_item, catalog_counts
        ni, ns = catalog_counts(load_catalog_merged())   # GỘP local + shared (máy khác quét, vd vinh)
        self._chat(f"📚 Thư viện item (gộp máy): {ni} vật phẩm ({ns} sạp). Dò trước khi đi quét…")
        tries = 0
        while (self.game_bot_connected and not self._stopping() and not self.paused
               and not self._quest_changed_flag and tries < max_tries):
            found = matcher(load_catalog_merged())
            if not found:
                self._chat(f"📚 Thư viện không còn {label} khớp → chuyển sang quét live.")
                return -1
            tries += 1
            cid, item_index, price = found[0], found[1], found[2]
            item = found[3] if len(found) > 3 else None
            self._chat(f"📚 Thư viện có {label} ở sạp {self._stall_label(cid)} giá {fmt_money(price)} "
                       f"→ kiểm tiền + remote-buy tại chỗ (khỏi đi)…")
            if not self._ensure_money(price):
                # KHÔNG xoá khỏi cache: món vẫn còn trên sạp, chỉ là CHƯA đủ tiền (thủ quỹ xa/bận).
                # _ensure_money tự xử (đỏ tên/PENDING). Lần sau có tiền vẫn dùng lại entry này.
                return -1
            self._just_did_money_trip = False     # mua remote nên kệ vừa đi thủ quỹ hay chưa
            # MUA + bắt op207 (đáng tin) → đọc rương có RETRY (rương trễ sau giao dịch/flood).
            ok = self._send_buy_capture207(cid, item_index, price)
            slot, items2 = (-1, [])
            if ok is not False:
                slot, items2 = self._verify_bought_slot(verify, ok)
            ni, ns = remove_item(cid, item_index)     # ĐÃ gửi lệnh mua (server xử lý) → bỏ khỏi cache
            self._chat(f"   (đã bỏ {label} khỏi thư viện → còn {ni} vật phẩm / {ns} sạp)")
            if isinstance(slot, int) and slot >= 0:
                if learn and item is not None:
                    self._learn_magic(item, items2, slot)
                self._chat(f"✅ Mua từ THƯ VIỆN thành công (ô {slot}) — khỏi đi quét live.")
                return slot
            self._chat(f"   ❌ mua hụt (sạp đóng/đã bán) → thử {label} khớp kế trong thư viện…")
        return -1

    def _buy_stall_verify(self, found, spec):
        """Mua 1 món từ sạp người chơi theo cid (REMOTE, không cần gần), verify bằng rương.
        found = (cid, item_index, price, item). Trả slot trong rương (int) nếu mua được, else -1."""
        from core.stall_shopper import find_in_bag
        cid, item_index, price, _it = found
        self._chat(f"🛒 Phát hiện sạp người chơi {self._stall_label(cid)} ở {self._town_name()} "
                   f"bán giá {fmt_money(price)} → kiểm tiền + mua...")
        if not self._ensure_money(price):     # túi+kho không đủ -> đỏ tên + báo, bỏ mua món này
            return -1
        # SAU _ensure_money có thể ĐÃ đi THỦ QUỸ (char ở XA chỗ quét). KHÔNG re-scan ở chỗ thủ quỹ (xa BK →
        # không thấy sạp cũ = bug "không mua được"). Mua sạp người chơi KHÔNG check khoảng cách (remote OK,
        # verified) → MUA THẲNG cid GỐC remote. Seller đóng sạp thì mua hụt → -1, vòng find_equip quét lại sau.
        after_money_trip = bool(getattr(self, '_just_did_money_trip', False))
        if after_money_trip:
            self._just_did_money_trip = False
            # DIAG (2026-06-16): bug "lấy tiền xong không mua, rảo sạp tiếp". Log mapId HIỆN TẠI để biết worker có
            # bị Xa Phu kéo SANG THÀNH THỦ QUỸ không (cross-map → mua remote sạp thành cũ có thể fail).
            try:
                _mid = (self.game_bot.rpc.get_player_info() or {}).get('mapId')
            except Exception:
                _mid = '?'
            self._chat(f"   (vừa lấy tiền ở thủ quỹ → mua REMOTE sạp {self._stall_label(cid)} | worker đang ở mapId={_mid})…")
        # MUA + bắt op207 (tín hiệu đáng tin). Đọc rương có RETRY (sau giao dịch thủ quỹ rương cập nhật trễ
        # → tránh bug "tưởng mua hụt rồi bỏ sang thành khác" dù server đã trừ tiền + giao món).
        ok = self._send_buy_capture207(cid, item_index, price)
        self._chat(f"   [DIAG mua] sạp {self._stall_label(cid)} idx{item_index} giá {fmt_money(price)} "
                   f"→ op207={ok}{' (SAU lấy tiền)' if after_money_trip else ''}")
        if ok is False:
            self._chat("   ✗ Server TỪ CHỐI (sạp đã bán/đóng) → bỏ món này.")
            return -1
        slot2, items2 = self._verify_bought_slot(lambda it: find_in_bag(it, spec)[0], ok)
        if isinstance(slot2, int) and slot2 >= 0:
            self._learn_magic(_it, items2, slot2)   # học id->tên thuộc tính miễn phí
            return slot2
        if ok is True:
            self._chat("   ⚠️ Server báo MUA OK (207) nhưng chưa đọc thấy trong rương sau 5s — đọc lại ở bước nộp.")
        return -1

    def _learn_magic(self, stall_item, bag_items, slot):
        """Học MIỄN PHÍ id->tên thuộc tính: đối chiếu magic(số) của món vừa mua ở sạp
        với attribs(chuỗi) của chính nó trong túi. Ghi dồn magic_id_map.json."""
        try:
            from core.magic_learner import learn
            if not stall_item or not stall_item.get("magic"):
                return
            bag_it = next((b for b in (bag_items or []) if b.get("slot") == slot), None)
            if not bag_it or not bag_it.get("attribs"):
                return
            _, learned = learn(stall_item.get("magic"), bag_it.get("attribs"))
            if learned:
                self._chat(f"🧠 Học thuộc tính mới (id->tên): {learned}")
                logger.info(f"[LEARN] magic_id_map += {learned}")
        except Exception as e:
            logger.error(f"[LEARN] lỗi: {e}")

    def _retrieve_attr_from_kho(self, req):
        """Tìm trong KHO (location 3) 1 món khớp thuộc tính NV (đã cất sẵn bằng tính năng dọn túi) → LẤY RA TÚI
        (eItemLocationRequest loc 3→2). Trả True nếu lấy được. (find_matching_slot bỏ qua loc3 → phải tự duyệt.)"""
        if not req:
            return False
        try:
            from core.equip_matcher import item_matches
            dump = self.game_bot.dump_bag_items() or {}
            for it in (dump.get("items") or []):
                if it.get("location") == 3 and isinstance(it.get("slot"), int) \
                        and item_matches(it, req["attr_key"], req["min_value"]):
                    slot = it.get("slot")
                    self._chat(f"📦 Có sẵn trong KHO (ô {slot}, '{req['phrase']}') → lấy ra túi…")
                    self.game_bot.send_gs("eItemLocationRequest", itemIndex=slot, itemLocation=2)
                    time.sleep(1.0)
                    return True
        except Exception as e:
            logger.error(f"[submit_equip] lấy từ kho lỗi: {e}")
        return False

    def _handle_execute_submit_equip(self):
        """Nhiệm vụ 'nộp trang bị theo thuộc tính': KHO(cất sẵn) -> rương -> sạp -> set slot -> nộp."""
        from core.equip_matcher import find_slot_for_quest, parse_equip_requirement
        q = self.current_quest
        # GHÉP clean_text + raw_text: cụm "xem xong trả lại" có thể nằm ở raw mà clean đã cắt → nếu chỉ lấy
        # clean thì quest_returns_item KHÔNG bắt được → KHÔNG cho giao hoàng-kim/đồ-mặc (bug). Ghép cả 2 cho chắc.
        quest_text = ((getattr(q, 'clean_text', '') or '') + " " + (getattr(q, 'raw_text', '') or '')).strip() if q else ""

        req = parse_equip_requirement(quest_text)
        if req:
            logger.info(f"NV nộp trang bị: cần thuộc tính '{req['phrase']}' >= {req['min_value']}. Đang quét rương...")
        else:
            self._chat("Không trích được yêu cầu thuộc tính từ nhiệm vụ. Bỏ qua, đứng chờ.")
            self._goto_state(BotState.TRAINING)
            return

        if not self.game_bot_connected:
            self._chat("Chưa kết nối Frida nên không quét được rương. Đứng chờ.")
            self._goto_state(BotState.TRAINING)
            return

        dump = self.game_bot.dump_bag_items()
        if not dump or not dump.get("ok"):
            self._chat(f"Lỗi đọc rương: {dump.get('error') if dump else 'no data'}. Đứng chờ.")
            self._goto_state(BotState.TRAINING)
            return

        items = dump.get("items", [])
        result = find_slot_for_quest(quest_text, items)
        if not result.get("ok"):
            # LẤY TỪ KHO: loot feature đã cất 1 món/mỗi thuộc tính NV vào kho (loc 3) → lấy RA TÚI rồi nộp,
            # KHỎI quét sạp (đúng ý: cất sẵn để sau làm NV). find_matching_slot bỏ qua loc3 nên phải tự check.
            if self._retrieve_attr_from_kho(req):
                dump_k = self.game_bot.dump_bag_items() or {}
                items_k = dump_k.get("items", []) if dump_k.get("ok") else []
                result = find_slot_for_quest(quest_text, items_k)
                if result.get("ok"):
                    self._chat("📦 Đã lấy món từ KHO (cất sẵn) ra túi → nộp Dã Tẩu (khỏi quét sạp).")
        if not result.get("ok"):
            # CHẨN ĐOÁN lỗi "có đồ phù hợp nhưng báo không có": log MỌI món + attribs (type/value) trong túi/mặc
            # để soi vì sao không khớp (attrib type là id số chưa map? min_value? location?).
            try:
                from core.equip_matcher import quest_returns_item as _qri
                ak = req.get("attr_key"); mv = req.get("min_value"); ret = _qri(quest_text)
                brief = [{"slot": it.get("slot"), "loc": it.get("location"), "gold": bool(it.get("isGold")),
                          "g": it.get("genre"), "d": it.get("detail"),
                          "attribs": [(a.get("type"), a.get("value")) for a in (it.get("attribs") or [])]}
                         for it in items if it.get("location") in (1, 2)]
                logger.info(f"[SUBMIT_EQUIP][CHẨN ĐOÁN] cần '{ak}'>={mv} | trả-lại={ret} (cho giao mặc/hoàng-kim={ret}) "
                            f"| KHÔNG khớp. text={quest_text[:90]!r} | Túi/mặc={brief}")
            except Exception as e:
                logger.info(f"[SUBMIT_EQUIP][CHẨN ĐOÁN] log lỗi: {e}")
            # Không sở hữu sẵn (mặc/túi) -> TỰ QUÉT SẠP người chơi tìm món có thuộc tính khớp rồi mua.
            from core.stall_shopper import (scan_stalls, find_all_in_stalls_by_attr,
                                            load_magic_id_map, attr_name_match, merge_catalog)
            attr_key = req["attr_key"]; min_value = req["min_value"]
            id_map = load_magic_id_map()
            known = any(attr_name_match(attr_key, n) for n in id_map.values())
            if not known:
                # Thành thật: chưa học id của thuộc tính này -> không nhận diện được ở sạp (magic chỉ là id số).
                self._start_await_quest_change(
                    f"Không sở hữu sẵn '{req['phrase']}' (>= {min_value}); CHƯA học id thuộc tính "
                    f"'{attr_key}' nên chưa nhận diện ở sạp.")
                return
            max_price = int(getattr(self, 'buy_threshold_van', 5)) * 10000
            # Ghi NV đang làm → tự bắt user HUỶ/ĐỔI NV ngay trong lúc quét/rảo.
            self._arm_quest_change_watch()
            _ss = lambda: self._stopping() or self.paused or self._quest_changed_since_start()
            from core.stall_shopper import auto_roam_scan
            # BÁO CHI TIẾT mỗi lần quét: có mấy món ĐẠT thuộc tính (mọi giá), rẻ nhất bao nhiêu, mấy món hợp giá.
            def _report(spot):
                allm = find_all_in_stalls_by_attr(spot, attr_key, min_value, id_map, max_price=10**12, min_price=100)
                if not allm:
                    return f"0 món đạt '{req['phrase']}' >= {min_value}"
                ok = sum(1 for c in allm if c[2] <= max_price)
                return (f"{len(allm)} món đạt '{req['phrase']}' >= {min_value} "
                        f"(rẻ nhất {allm[0][2] // 10000}v; {ok} món hợp giá ≤{self.buy_threshold_van}v)")
            _mfn = lambda spot: find_all_in_stalls_by_attr(spot, attr_key, min_value, id_map,
                                                           max_price=max_price, min_price=100)
            _find = lambda cat: find_all_in_stalls_by_attr(cat, attr_key, min_value, id_map,
                                                           max_price=max_price, min_price=100)
            # 0) DÒ THƯ VIỆN CHUNG trước khi quét live (acc khác đã quét sẵn) → remote-buy tại chỗ, KHỎI đi.
            def _verify_submit(items2):
                r = find_slot_for_quest(quest_text, items2)
                return r["slot"] if r.get("ok") else -1
            _cslot = self._cache_buy_loop(lambda cat: (_find(cat) or [None])[0],
                                          _verify_submit, label=f"'{req['phrase']}'")
            if isinstance(_cslot, int) and _cslot >= 0:
                self.target_givebox_slot = _cslot
                self._chat(f"✅ Mua '{req['phrase']}' từ THƯ VIỆN (ô {_cslot}). Đi nộp Dã Tẩu.")
                self._goto_state(BotState.REWARD); return
            # THƯ VIỆN KHÔNG CÓ → mặc định HỦY 100 TẤM ĐỒ CHÍ; không đủ tấm → PENDING (KHÔNG rảo quét live nữa).
            self._cancel_dochi_or_pending(f"'{req['phrase']}'")
            return
            # ===== (dưới đây là code rảo-quét cũ — ĐÃ VÔ HIỆU bởi return ở trên, giữ lại tham khảo) =====
            # QUÉT QUA TỪNG THÀNH (Biện Kinh → Tương Dương) — ngang find_equip: thành này hết thì SANG THÀNH KẾ.
            catalog = {}; cands = []
            for _cn, _mid, _ctr in self.STALL_CITIES:
                if self._stopping() or self._quest_changed_flag:
                    break
                if not self._goto_city_center(_cn, _mid, _ctr):
                    continue   # KHÔNG tới được thành này → bỏ qua, KHÔNG quét/rảo nhầm chỗ
                if self._stopping():
                    self._goto_state(BotState.TRAINING); return
                self._chat(f"🔎 [{_cn}] Quét TƯƠI sạp tìm '{req['phrase']}' >= {min_value} (≤ {self.buy_threshold_van}v)...")
                c0 = scan_stalls(self.game_bot, merge=False)
                merge_catalog(c0)   # bồi đắp thư viện chung cho acc sau
                catalog.update(c0)
                cands = _find(catalog)
                if cands:
                    break
                self._chat(f"[{_cn}] Quanh đây ({len(c0)} sạp): {_report(c0)} → tự rảo quét tiếp…")
                c2, _m, _ = auto_roam_scan(self.game_bot, log=lambda m: self._chat(m),
                                           spec=None, max_price=max_price,
                                           should_stop=_ss, matcher=_mfn, report_fn=_report)
                merge_catalog(c2)   # bồi đắp thư viện chung cho acc sau
                if self._quest_changed_flag:
                    break
                catalog.update(c2)
                cands = _find(catalog)
                if cands:
                    break
                self._chat(f"[{_cn}] chưa thấy '{req['phrase']}' hợp giá → thử thành kế tiếp…")
            if self._quest_changed_flag:
                self._quest_changed_flag = False
                self.current_quest = None
                self._goto_state(BotState.IDLE_PRECHECK); return
            if not cands:
                # PHÂN BIỆT "không có món" vs "CÓ nhưng đắt": dò lại GIÁ KHÔNG GIỚI HẠN → biết là lỗi GIÁ hay scan.
                hi = find_all_in_stalls_by_attr(catalog, attr_key, min_value, id_map, max_price=10**12, min_price=100)
                if hi:
                    # IN CHI TIẾT các món phù hợp nhưng VƯỢT ngưỡng (user: thấy giá để quyết nâng ngưỡng).
                    self._chat(f"💡 CÓ {len(hi)} món '{req['phrase']}' >= {min_value} nhưng GIÁ > ngưỡng "
                               f"{self.buy_threshold_van} vạn — chi tiết (rẻ→đắt):")
                    for _c, _i, _p, _it, _v in hi[:5]:
                        self._chat(f"   • sạp {self._stall_label(_c)} (idx {_i}): '{_v}' — {_p // 10000} vạn")
                    self._start_await_quest_change(
                        f"CÓ '{req['phrase']}' nhưng rẻ nhất {hi[0][2] // 10000} vạn > ngưỡng "
                        f"{self.buy_threshold_van} vạn → NÂNG ngưỡng là tự mua lại (khỏi Resume).")
                    self._pending_buy_van = (hi[0][2] + 9999) // 10000   # nâng ngưỡng ≥ số này → tự mua lại
                else:
                    self._pending_buy_van = 0
                    self._start_await_quest_change(f"Đã rảo quét {len(catalog)} sạp nhưng KHÔNG sạp nào có "
                                                   f"'{req['phrase']}' >= {min_value} (giá ≤ {fmt_money(max_price)}).")
                return
            self._chat(f"Thấy {len(cands)} món '{req['phrase']}' >= {min_value} hợp giá. Thử mua lần lượt...")
            result = {"ok": False}
            _tries = 0
            while cands and _tries < 10 and not self._stopping():
                _tries += 1
                cid, item_index, price, _it, val = cands[0]
                self._chat(f"🛒 Sạp {self._stall_label(cid)} ở {self._town_name()} (idx {item_index})='{val}' "
                           f"giá {fmt_money(price)} → kiểm tiền + mua...")
                if not self._ensure_money(price):   # túi+kho không đủ → _ensure_money tự đỏ tên/PENDING
                    cands.pop(0); continue
                # SAU _ensure_money có thể ĐÃ đi THỦ QUỸ (char ở XA chỗ quét). KHÔNG re-scan/rảo ở chỗ thủ quỹ
                # (xa BK → không thấy sạp cũ = bug "không mua được"). Mua sạp người chơi KHÔNG check khoảng cách
                # (remote OK) → MUA THẲNG cid GỐC remote. Seller đóng thì mua hụt → cands.pop sang món kế.
                if getattr(self, '_just_did_money_trip', False):
                    self._just_did_money_trip = False
                    self._chat(f"   (vừa lấy tiền ở thủ quỹ → mua REMOTE sạp {self._stall_label(cid)}, không re-scan ở xa)…")
                # MUA + bắt op207 (đáng tin) → đọc rương có RETRY (rương trễ sau giao dịch thủ quỹ + flood).
                ok = self._send_buy_capture207(cid, item_index, price)
                if ok is False:
                    self._chat("  ✗ Server TỪ CHỐI (đã bán/đóng) → thử món khác.")
                    cands.pop(0); continue
                def _vf(it):
                    r = find_slot_for_quest(quest_text, it)
                    return r["slot"] if r.get("ok") else -1
                _slot, items2 = self._verify_bought_slot(_vf, ok)
                if isinstance(_slot, int) and _slot >= 0:
                    result = find_slot_for_quest(quest_text, items2)
                    self._chat(f"  ✅ Mua được (vào rương).")
                    self._learn_magic(_it, items2, result["slot"])
                    break
                self._chat(f"  ✗ Mua hụt (chưa thấy trong rương) → thử món khác.")
                cands.pop(0)
            if not result.get("ok"):
                self._start_await_quest_change("Đã thử các món ở sạp nhưng chưa mua được "
                                               "(đã bán/bán bằng nguyên bảo).")
                return
                return

        slot = result["slot"]
        it = result["item"]
        self.target_givebox_slot = slot
        loc = it.get("location")
        loc_txt = {1: "ĐANG MẶC", 2: "trong túi", 3: "trong kho"}.get(loc, f"loc={loc}")
        self._chat(f"✅ Tìm thấy trang bị khớp ở ô {slot} ({loc_txt}, "
                   f"tên={it.get('name','?')}, genre={it.get('genre')}, detail={it.get('detail')}). Đi nộp Dã Tẩu...")
        if loc == 1:
            self._chat("⚠️ Món này ĐANG MẶC — GiveBox thường KHÔNG nhận đồ đang mặc. Có thể phải cởi ra trước.")
        self._goto_state(BotState.REWARD)

    def _handle_execute_submit_points(self):
        # Nộp điểm / Nâng chỉ số — bot CHƯA có packet làm. KHÔNG nav/teleport. Báo 🆘 + đứng (user tự làm).
        self._need_help(f"NV nộp điểm/nâng chỉ số ({self.current_quest.item_name or self.current_quest.clean_text[:40]}) "
                        f"— bot chưa hỗ trợ. Bạn tự làm, hoặc đặt nhóm 'Đồ hiếm / Nâng cấp chỉ số' = Hủy trên UI.")
        self._goto_state(BotState.TRAINING)

    def _handle_execute_deliver(self):
        # Giao thư/đưa đồ — bot CHƯA có packet làm. KHÔNG nav/teleport. Báo 🆘 + đứng.
        self._need_help(f"NV giao thư/đưa đồ ({self.current_quest.item_name or self.current_quest.clean_text[:40]}) "
                        f"— bot chưa hỗ trợ. Bạn tự làm, hoặc đặt loại 'Giao thư' = Hủy trên UI.")
        self._goto_state(BotState.TRAINING)

    def _handle_clear_inventory(self):
        if self._stopping(): return
        self._chat("Hành trang đã đầy, đang đi cất đồ vào rương!")
        logger.info("  -> Chạy tới Quản lý Rương (Stash). Gửi đồ có giá trị.")
        self.navigator.move_to_npc("Tiền Trang Huyện", self.config['preferred_city'])
        if self.game_bot_connected:
            self.game_bot.send_gs('eNpcDialog')
        time.sleep(2)
        if self._stopping(): return

        self._chat("Đang tạt qua Tạp Hóa bán rác...")
        self.navigator.move_to_npc("Tạp hóa", self.config['preferred_city'])
        if self.game_bot_connected:
            self.game_bot.send_gs('eNpcDialog')
        time.sleep(2)
        
        self._chat("Dọn dẹp xong xuôi, chuẩn bị làm việc tiếp!")
        self._goto_state(BotState.IDLE_PRECHECK)

    def _handle_cancel_quest(self):
        mode = "Hủy 100 đồ chí" if self._cancel_do_chi else "Hủy thường"
        self._chat(f"Hủy nhiệm vụ Dã Tẩu bằng packet ({mode})...")
        # Hủy HOÀN TOÀN bằng packet (eNpcSelect index), không tap
        self._datau_cancel(do_chi=self._cancel_do_chi)
        logger.info(f"[CANCEL_QUEST] Đã gửi chuỗi hủy ({mode}). Đứt chuỗi nhiệm vụ.")
        # CHỈ ghi 1 lần/quest (tránh vào CANCEL_QUEST 2 lượt cho cùng NV -> đếm phồng).
        if self.last_quest_number and self.last_quest_number != getattr(self, "_last_cancelled_qno", None):
            self._last_cancelled_qno = self.last_quest_number
            try:
                tracker.record(self.device_id, "quest_cancelled", char=self.player_name,
                               qno=self.last_quest_number, mode=mode)
            except Exception:
                pass
        self._cancel_do_chi = False
        self.current_quest = None
        self._goto_state(BotState.IDLE_PRECHECK)

    def _autoplay_fail_msg(self):
        """Message giải thích VÌ SAO không bật được auto (hiện trên panel). Phân biệt:
        - account có profile nhưng đọc hụt/khác tên (đã fallback dùng profile khác ở _autoplay_guid),
        - account KHÔNG có profile nào (n=0) -> cần tạo 1 profile Auto trong game 1 lần."""
        d = getattr(self.game_bot, '_autoplay_last_diag', None)
        if not d:
            return "⚠️ Chưa bật được auto game (đang dò guid profile). Vẫn theo dõi."
        n = d.get('n', 0)
        if n and d.get('all'):
            names = ", ".join((p.get('name') or '?') for p in d['all'][:5])
            return (f"⚠️ Chưa bật auto: account CÓ {n} profile ({names}) nhưng chưa lấy được guid. Vẫn theo dõi.")
        return ("⚠️ Chưa bật auto: account NÀY KHÔNG có profile Auto nào (cần MỞ bảng AUTO trong game tạo/chọn "
                "1 profile 1 lần — sau đó bot tự dùng). Vẫn theo dõi NV.")

    def _prep_bag_before_turnin(self, target_slot=None):
        """TRƯỚC KHI TRẢ NV: nếu túi GẦN ĐẦY (≥15 ô) -> bán đồ rác + cất kho để chống RƯƠNG ĐẦY khiến
        nộp/nhận thưởng fail. KHÔNG sort/gộp (giữ slot ỔN ĐỊNH = an toàn, theo yêu cầu): bán/cất chỉ để lại
        ô trống, KHÔNG dồn slot -> slot món cần nộp KHÔNG đổi. cleanup_bag_loot + _stash_full_bag đều LOẠI TRỪ
        target_slot (món đang chờ nộp) nên không bao giờ bán/cất nhầm. Túi còn rộng -> bỏ qua (nhanh)."""
        if not self.game_bot_connected:
            return
        occ = self._bag_occupied()
        if occ is None or occ < 15:
            return
        excl = {target_slot} if (target_slot is not None and target_slot >= 0) else set()
        self._chat(f"🧹 Túi gần đầy ({occ} ô) → bán đồ rác + cất kho trước khi trả NV (GIỮ món cần nộp)...")
        try:
            mid = (self.game_bot.rpc.get_player_info() or {}).get('mapId')
        except Exception:
            mid = None
        ctx = self._SELL_SHOP_CTX.get(mid)
        try:
            rep = self.game_bot.cleanup_bag_loot(shop_context=ctx, exclude_slots=excl,
                                                 log=lambda m: logger.info(m))
            self._chat(f"🧹 Đã bán {len(rep.get('sold', []))}, cất kho {len(rep.get('deposited', []))}"
                       + (f", lỗi {len(rep['fail'])}" if rep.get('fail') else "") + ".")
        except Exception as e:
            logger.info(f"[prep_turnin] cleanup lỗi: {e}")
        try:
            self._stash_full_bag(exclude_slots=excl)
        except Exception as e:
            logger.info(f"[prep_turnin] stash lỗi: {e}")
        # CHẨN ĐOÁN (không đoán mò): nếu túi VẪN ≥15 ô sau khi dọn → in 35 món đó GỒM GÌ (genre/gold/khoá +
        # vài tên mẫu) để biết CHÍNH XÁC vì sao bán=0 (gear? consumable? đồ-chí? hoàng kim?). Bán remote từng
        # tốt (06-15 bán 15) → giờ bán 0 = túi không còn gear; cần thấy món thật mới sửa đúng.
        try:
            occ2 = self._bag_occupied()
            if occ2 is not None and occ2 >= 15:
                dump = self.game_bot.dump_bag_items() or {}
                bag2 = [it for it in (dump.get('items') or []) if it.get('location') == 2]
                from collections import Counter
                by_genre = Counter(it.get('genre') for it in bag2)
                ngold = sum(1 for it in bag2 if it.get('isGold'))
                nlock = sum(1 for it in bag2 if it.get('lockstate'))
                ness = sum(1 for it in bag2 if it.get('particular') in self.BAG_KEEP_PARTICULARS)
                samples = []
                for it in bag2[:8]:
                    nm = (it.get('name') or '').strip() or f"g{it.get('genre')}/d{it.get('detail')}/p{it.get('particular')}"
                    samples.append(f"{nm}{'⭐' if it.get('isGold') else ''}{'🔒' if it.get('lockstate') else ''}")
                self._chat(f"🔎 Túi VẪN {occ2} ô sau dọn → genre={dict(by_genre)} | gold={ngold} khoá={nlock} "
                           f"thiết-yếu={ness} | mẫu: {', '.join(samples)}")
        except Exception as e:
            logger.info(f"[prep_turnin] chẩn đoán lỗi: {e}")

    def _handle_reward(self):
        logger.info("[NỘP] Nộp/hoàn thành NV Dã Tẩu bằng packet (GiveBox).")
        logger.info("[REWARD] Hoàn thành NV (packet, không tap).")
        target_slot = getattr(self, 'target_givebox_slot', -1)
        if not self.game_bot_connected:
            self._chat("Chưa kết nối Frida nên không nộp packet được. Đứng chờ.")
            self.npc_interact.dismiss_dialog()
            self._goto_state(BotState.IDLE_PRECHECK)
            return
        if target_slot is None or target_slot < 0:
            self._chat("Lỗi: chưa biết ô túi của vật phẩm cần nộp! Không nộp.")
            self.npc_interact.dismiss_dialog()
            self._datau_dialog_open = False
            self._goto_state(BotState.IDLE_PRECHECK)
            return

        # Chuỗi packet: mở -> advance tới GiveBox -> eGiveBoxSend(slot) -> Confirm -> chờ 245 (xác nhận)
        # (Dọn rương chống-đầy nằm TRONG _datau_complete = điểm nộp chung cho MỌI loại NV, kể cả mua NPC.)
        ok = self._datau_complete(target_slot)
        if ok:
            self._chat("✅ ĐÃ TRẢ NHIỆM VỤ (server xác nhận trả thưởng 245).")
            self._on_quest_completed()
            self._reward_fail = 0
        else:
            self._reward_fail = getattr(self, '_reward_fail', 0) + 1
            self._chat(f"⚠️ CHƯA trả được NV — KHÔNG thấy server xác nhận (245). KHÔNG tính hoàn thành. "
                       f"(itemId nộp={target_slot} có thể sai, hoặc chưa đủ đồ) [lần lỗi {self._reward_fail}]")
            if self._reward_fail >= 2:
                # tránh loop vô hạn: dừng cho người chơi kiểm tra
                self._chat("Trả NV thất bại 2 lần liên tiếp -> tạm dừng Auto để bạn kiểm tra.")
                self.current_quest = None
                self.target_givebox_slot = -1
                self._goto_state(BotState.LOST)
                return
        self.current_quest = None
        self.target_givebox_slot = -1
        self._clear_popups("sau khi trả NV")   # đóng SẠCH GiveBox/hội thoại còn sót trước khi qua NV kế
        self._goto_state(BotState.IDLE_PRECHECK)

    def _push_reward_to_ui(self, qno, opts, idx, chosen, received=None):
        """Đẩy phần thưởng lên UI. CHỈ lưu tracking khi NHẬN THƯỞNG THÀNH CÔNG (idx>=0, tên thật).
        received = chuỗi số/đồ THỰC NHẬN (vd '+1 vạn lượng') để panel hiện cụ thể."""
        self.daily_rewards.append({"qno": qno, "options": list(opts), "chosen_idx": idx,
                                   "chosen": chosen, "received": received})
        success = (idx is not None and idx >= 0 and chosen and not str(chosen).startswith("("))
        if success:
            try:
                tracker.record(self.device_id, "reward", char=self.player_name,
                               qno=qno, options=list(opts), chosen_idx=idx, chosen=chosen,
                               received=received)
                tracker.record(self.device_id, "item_received", char=self.player_name,
                               name=(received or chosen), source="datau_reward", qno=qno)
            except Exception:
                pass
        if hasattr(self, 'ui_update_rewards'):
            try:
                self.ui_update_rewards(list(self.daily_rewards))
            except Exception as e:
                logger.error(f"[REWARD] ui_update_rewards lỗi: {e}")

    def _select_reward(self, prefetched_hex=None):
        """Bắt gói eAwardSelectionAsk (245), chọn phần thưởng theo ưu tiên, gửi eAwardSelectionAnswer (246).
        prefetched_hex: hex gói 245 đã bắt sẵn (từ post-confirm) -> dùng luôn, khỏi chờ lại."""
        from core.equip_matcher import parse_award_ask, pick_reward_index
        qno = self.last_quest_number or (self.daily_done + 1)
        if prefetched_hex:
            pkts = [{"hex": prefetched_hex}]
        else:
            pkts = self.game_bot.wait_for_packet((245, 'eAwardSelectionAsk'), timeout=6.0)
        if not pkts:
            self._chat("⚠️ Không thấy bảng phần thưởng (245) -> server CHƯA nhận đồ/NV. Coi như TRẢ THẤT BẠI.")
            self._push_reward_to_ui(qno, ["(không có bảng chọn thưởng)"], -1, "tự động")
            self.npc_interact.dismiss_dialog()
            return False
        raw_hex = pkts[-1]['hex']
        # Dump gói thật để soi nếu parse sai (giúp test, không bịa).
        try:
            with open(f"data/output/award_ask_dump_{self.device_id.replace(':','_')}.txt", "a") as f:
                f.write(f"qno={qno} | {raw_hex}\n")
        except Exception:
            pass
        info = parse_award_ask(bytes.fromhex(raw_hex)[6:])
        opts = info.get('options') or []
        if not opts:
            # Có gói nhưng tách option lỗi -> hiện prompt thô để còn biết đường sửa.
            prompt = info.get('prompt', '')
            self._chat(f"⚠️ Bảng thưởng không tách được lựa chọn. Prompt: {prompt!r} | hex={raw_hex[:60]}...")
            self._push_reward_to_ui(qno, [prompt or "(rỗng)"], -1, "?")
            self.npc_interact.dismiss_dialog()
            return True   # vẫn bắt được 245 = server ĐÃ nhận NV (chỉ lỗi parse lựa chọn)
        # HỌC danh sách thưởng (để người chơi tự đặt ưu tiên sau) — không đổi logic chọn hiện tại.
        try:
            from core import datau_rewards
            datau_rewards.record_options(opts)
        except Exception:
            pass
        # Ưu tiên theo DANH SÁCH người chơi xếp (drag-drop). Rỗng -> logic mặc định.
        try:
            from core import datau_rewards
            prio = datau_rewards.priority_order()
        except Exception:
            prio = None
        idx = pick_reward_index(opts, priority_names=prio)
        if idx < 0:
            idx = 0  # luôn chọn 1 cái, không để treo
        chosen = opts[idx] if 0 <= idx < len(opts) else "?"
        # Liệt kê thưởng theo kiểu: "Kinh nghiệm - Ngân lượng - Phi tốc hoàn => Tôi chọn xxx".
        self._chat(f"🎁 {' - '.join(opts)} => Tôi chọn {chosen}")
        money_before = self._carried_money()   # đo bạc TRƯỚC để tính ngân lượng nhận (nếu chọn tiền)
        bag_before = self._bag_snapshot()      # chụp rương TRƯỚC để biết món mới nhận
        if hasattr(self.game_bot, 'recv_buffer'):
            self.game_bot.recv_buffer = []     # xoá để bắt đúng gói server trả sau khi chọn thưởng
        if self.game_bot_connected and info.get('id') is not None:
            self.game_bot.send_gs('eAwardSelectionAnswer', id=info['id'], selected=idx)
            logger.info(f"[REWARD] eAwardSelectionAnswer(id={info['id']}, selected={idx})")
        received = self._log_reward_received(chosen, money_before, bag_before)   # tính + in chi tiết NHẬN
        self._push_reward_to_ui(qno, opts, idx, chosen, received=received)        # đẩy panel KÈM số nhận
        self._clear_popups("sau khi nhận thưởng")   # đóng SẠCH bảng thưởng + popup chồng (invoke Close client)
        return True   # bắt được 245 + đã trả lời = trả NV THÀNH CÔNG

    def _bag_snapshot(self):
        """{slot: stack} của rương hiện tại (để diff tìm món/đồ MỚI nhận). {} nếu đọc hụt."""
        try:
            d = self.game_bot.dump_bag_items()
            if d and d.get("ok"):
                return {it.get("slot"): it for it in d.get("items", []) if it.get("slot") is not None}
        except Exception:
            pass
        return {}

    @staticmethod
    def _texts_from_133(body):
        """Tách MỌI chuỗi đọc-được trong gói 133 (eChatMessage) qua protobuf walk (đáng tin hơn decode thô)."""
        out = []
        try:
            from features.bot.shop_parser import _decode_protobuf
            def walk(b, depth=0):
                if depth > 3 or not isinstance(b, (bytes, bytearray)):
                    return
                try:
                    fields = _decode_protobuf(bytes(b))
                except Exception:
                    return
                for v in fields.values():
                    if isinstance(v, (bytes, bytearray)):
                        try:
                            s = v.decode("utf-8")
                            if s and any(c.isalpha() for c in s) and all(ord(c) >= 32 or c in "\n" for c in s):
                                out.append(s.strip())
                        except Exception:
                            walk(v, depth + 1)   # không phải text -> coi như message lồng
                        else:
                            walk(v, depth + 1)
            walk(bytes(body))
        except Exception:
            pass
        return out

    def _log_reward_received(self, chosen, money_before, bag_before=None):
        """In chi tiết phần thưởng đã nhận, ĐA NGUỒN (đáng tin, không bịa):
        - Bạc: chênh lệch GetBagarateMoney trước/sau -> '+X'.
        - Vật phẩm: món MỚI trong rương (diff) -> tên qua item_db.
        - Khác (exp...): decode text gói 133 (eChatMessage) server bắn.
        Dump opcode để soi gói thật khi cần."""
        bag_before = bag_before or {}
        # gom gói server bắn ~2s sau khi trả lời
        seen = []
        t0 = time.time()
        while time.time() - t0 < 2.0:
            for p in (self.game_bot.poll_recv() or []):
                seen.append(p)
            time.sleep(0.1)
        try:
            ops = [p.get('opcode') for p in seen]
            with open(f"data/output/reward_response_dump_{self.device_id.replace(':','_')}.txt", "a", encoding="utf-8") as f:
                f.write(f"--- chon='{chosen}' ops={ops} ---\n")
                for p in seen:
                    if p.get('opcode') in (133, 247, 16, 6, 245, 251):
                        f.write(f"  {p.get('opcode')}: {p.get('hex','')}\n")
        except Exception:
            pass

        found = []
        # 1) Bạc nhận = diff
        if money_before is not None:
            money_after = self._carried_money()
            if money_after is not None and money_after > money_before:
                found.append(f"+{fmt_money(money_after - money_before)}")
        # 2) Vật phẩm MỚI trong rương (diff slot)
        try:
            from core.item_db import get_item_db
            db = get_item_db()
            after = self._bag_snapshot()
            new_slots = set(after) - set(bag_before)
            for s in new_slots:
                it = after[s]
                if it.get("particular") == 2:    # TLH: đếm theo SỐ LƯỢNG bên dưới (stack vào ô cũ cũng tính), bỏ ở đây tránh trùng
                    continue
                nm = ""
                try:
                    nm = db.name_of(it.get("genre"), it.get("detail"), it.get("particular"), it.get("level")) or ""
                except Exception:
                    pass
                qty = it.get("stack") or 1
                # Có tên -> ghi tên; KHÔNG tên (đồ tiêu hao như Quế Hoa Tửu, item_db thiếu) -> vẫn ghi
                # 'vật phẩm mới' để KHÔNG sót (text gói 247 'Nhận được X' nếu có sẽ bổ sung tên).
                label = nm if nm else "vật phẩm mới"
                found.append(label + (f" x{qty}" if qty and qty > 1 else ""))
            # THIẾT LA HÁN (particular 2) — diff theo TỔNG STACK: đếm ĐỦ mọi lần nhận kể cả stack vào ô CŨ
            # (new-slots bỏ sót → trước đây đếm thiếu 15/30). Đếm tại lúc NHẬN nên KHÔNG phụ thuộc giao thủ quỹ.
            try:
                _tb = sum((x.get("stack") or 1) for x in bag_before.values() if x.get("particular") == 2)
                _ta = sum((x.get("stack") or 1) for x in after.values() if x.get("particular") == 2)
                if _ta - _tb > 0:
                    found.append(f"Thiết La Hán x{_ta - _tb}")
            except Exception:
                pass
        except Exception:
            pass
        # 3) Text thông báo trong gói 247 (eAttention2Player — thông báo RIÊNG cho mình, vd exp) + 133.
        #    Ưu tiên 247 (đúng thưởng); 133 hay là rao vặt shop thế giới nên chỉ lấy khi có từ khoá thưởng.
        for p in seen:
            op = p.get('opcode')
            if op not in (247, 133):
                continue
            try:
                body = bytes.fromhex(p.get('hex', ''))[6:]
            except Exception:
                continue
            import re as _re
            for s in self._texts_from_133(body):
                s = _re.sub(r"</?color[^>]*>", "", s).strip()   # BỎ tag màu game <color=#..>..</color>
                s = _re.sub(r"\s+", " ", s)
                if not s:
                    continue
                sl = s.lower()
                if op == 247 and any(c.isalpha() for c in s) and len(s) >= 3:
                    found.append(s)   # 247 = thông báo riêng -> nhận hết (thường là 'nhận X kinh nghiệm')
                elif any(k in sl for k in ("kinh nghiệm", "kinh nghi", "nhận được", "tiềm năng", "danh vọng")):
                    found.append(s)

        # khử trùng lặp, in, TRẢ chuỗi chi tiết để panel Phần thưởng dùng
        uniq = []
        for x in found:
            if x and x not in uniq:
                uniq.append(x)
        if uniq:
            detail = " | ".join(uniq)
            self._chat("   🎁 Nhận: " + detail)
            return detail
        self._chat(f"   (đã nhận '{chosen}'; chưa đọc được chi tiết — xem data/output/reward_response_dump.txt)")
        return None

    def _update_quest_stats(self, quest):
        """Cập nhật mốc + còn lại từ nội dung NV vừa đọc, rồi đẩy lên UI."""
        if quest:
            if getattr(quest, 'quest_number', 0):
                self.last_quest_number = quest.quest_number
            if getattr(quest, 'remaining', 0):
                self.last_remaining = quest.remaining
                # ĐỈNH remaining hôm nay = cap (gói đầu ngày M lớn nhất) -> UI suy cap = max+1, KHÔNG dùng qno.
                self.max_remaining_today = max(getattr(self, 'max_remaining_today', 0) or 0, quest.remaining)
        self._push_quest_stats()

    def _on_quest_completed(self):
        """Gọi sau khi 1 NV hoàn thành: tăng đếm + giảm 'còn lại' + đẩy UI."""
        self._clear_help()   # làm được NV -> bỏ báo đỏ
        self.daily_done += 1
        if self.last_remaining > 0:
            self.last_remaining -= 1
        try:
            tracker.record(self.device_id, "quest_completed", char=self.player_name,
                           qno=self.last_quest_number, remaining=self.last_remaining)
        except Exception:
            pass
        self._push_quest_stats()

    def _push_quest_stats(self):
        """Đẩy 4 chỉ số NV ngày lên UI (nếu UI có đăng ký callback)."""
        total_est = self.daily_done + self.last_remaining  # ước tính tổng NV ngày
        if hasattr(self, 'ui_update_quest_stats'):
            try:
                self.ui_update_quest_stats(self.last_quest_number, total_est, self.daily_done, self.last_remaining)
            except Exception:
                pass

    def _handle_error(self):
        logger.error("State Machine đã dừng hoàn toàn.")
        self.is_running = False

    def _handle_lost(self):
        # CHỈ báo 1 lần rồi đứng im (không spam mỗi tick). Bật lại Auto / đổi thành để thoát LOST.
        if not getattr(self, '_lost_logged', False):
            logger.error("Nhân vật bị lạc / không tìm thấy Dã Tẩu ở đây.")
            self._need_help("Không gọi được Dã Tẩu (lạc map / kết nối treo). Đưa nhân vật về THÀNH rồi bật lại Auto.")
            self._lost_logged = True
        self.is_running = False
        time.sleep(1.0)   # đứng im, đỡ ngốn CPU

    @property
    def game_bot_connected(self):
        return self.game_bot.running

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S")
    adb = ADBHelper()
    sm = DaTauStateMachine(adb)
    sm.start()
