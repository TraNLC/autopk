import json
import os

# Build Item DB once
_ITEM_DB = None
def get_item_db():
    global _ITEM_DB
    if _ITEM_DB is not None:
        return _ITEM_DB
    _ITEM_DB = {}
    item_files = [
        ("data/output/json/item_meleeweapon.json", "Vũ khí cận chiến"),
        ("data/output/json/item_armor.json", "Giáp"),
        ("data/output/json/item_helm.json", "Mũ"),
        ("data/output/json/item_boot.json", "Giày"),
        ("data/output/json/item_belt.json", "Thắt lưng"),
        ("data/output/json/item_cuff.json", "Vòng tay"),
        ("data/output/json/item_horse.json", "Ngựa"),
        ("data/output/json/item_amulet.json", "Bùa"),
    ]
    for fpath, _ in item_files:
        if os.path.exists(fpath):
            try:
                with open(fpath, 'r', encoding='utf-8') as f:
                    items = json.load(f)
                for item in items:
                    name = item.get('\ufeff0', item.get('0', ''))
                    g = item.get('1', 0)
                    d = item.get('2', 0)
                    p = item.get('3', 0)
                    if name:
                        _ITEM_DB[(g, d, p)] = name
            except Exception as e:
                print(f"Error loading {fpath}: {e}")
    return _ITEM_DB

def _decode_varint(data, pos):
    val = 0
    shift = 0
    while pos < len(data):
        b = data[pos]
        pos += 1
        val |= (b & 0x7f) << shift
        if not (b & 0x80):
            break
        shift += 7
    return val, pos

def _decode_protobuf(data):
    result = {}
    pos = 0
    while pos < len(data):
        if pos >= len(data): break
        tag, pos = _decode_varint(data, pos)
        field_num = tag >> 3
        wire_type = tag & 0x07
        if wire_type == 0:
            val, pos = _decode_varint(data, pos)
            result[field_num] = val
        elif wire_type == 1:
            result[field_num] = data[pos:pos+8]
            pos += 8
        elif wire_type == 2:
            length, pos = _decode_varint(data, pos)
            val = data[pos:pos+length]
            result[field_num] = val
            pos += length
        elif wire_type == 5:
            result[field_num] = data[pos:pos+4]
            pos += 4
        else:
            break
    return result

def _decode_shopitem(data):
    fields = _decode_protobuf(data)
    return {
        'cost': fields.get(1, 0),
        'genre': fields.get(6, 0),
        'detail': fields.get(7, 0),
        'particular': fields.get(8, 0),
        'model': fields.get(9, 0),   # số model (1-based) -> phân biệt món cùng (g,d,p)
    }

def parse_shop_indices(hex_str):
    """Trả (shopkey, [itemindex...]) từ gói shop 119/120/212 — CHỈ lấy itemindex RAW, KHÔNG tra tên.
    Dùng lấy MÓN CUỐI = max(itemindex) cho NV Dã Tẩu mua-NPC (món quest server tiêm vào cuối, tên
    có thể lạ/không có trong item_db nên update_shop_dict_from_hex hay BỎ -> mất món cuối). None nếu fail."""
    try:
        body_bytes = bytes.fromhex(hex_str)
        if len(body_bytes) >= 6:
            op = int.from_bytes(body_bytes[4:6], "little")
            if op in (119, 120, 212):
                body_bytes = body_bytes[6:]
        top = _decode_protobuf(body_bytes)
        shopdata_bytes = top.get(2) if isinstance(top.get(2), bytes) else top.get(1, b'')
        if not isinstance(shopdata_bytes, bytes):
            return None
        sub = _decode_protobuf(shopdata_bytes)
        shopkey = sub.get(1, b'')
        if isinstance(shopkey, bytes):
            shopkey = shopkey.decode('utf-8', errors='replace')
        idxs = []
        raw = shopdata_bytes
        pos = 0
        while pos < len(raw):
            tag, pos = _decode_varint(raw, pos)
            fnum = tag >> 3
            wtype = tag & 0x07
            if wtype == 2:
                length, pos = _decode_varint(raw, pos)
                vb = raw[pos:pos+length]
                pos += length
                if fnum in (3, 4):
                    ef = _decode_protobuf(vb)
                    ii = ef.get(1, -1)
                    if isinstance(ii, int) and ii >= 0:
                        idxs.append(ii)
            elif wtype == 0:
                _, pos = _decode_varint(raw, pos)
            elif wtype == 1:
                pos += 8
            elif wtype == 5:
                pos += 4
            else:
                break
        if not idxs:
            return None
        return shopkey, sorted(set(idxs))
    except Exception:
        return None


def update_shop_dict_from_hex(hex_str):
    try:
        body_bytes = bytes.fromhex(hex_str)
        # Gói recv GỒM header 6 byte [len4 LE][opcode2 LE] -> BỎ trước khi decode protobuf.
        if len(body_bytes) >= 6:
            op = int.from_bytes(body_bytes[4:6], "little")
            if op in (119, 120, 212):
                body_bytes = body_bytes[6:]
        top = _decode_protobuf(body_bytes)
        # Cấu trúc thật: top.field2 = shopdata { f1=shopkey, f2=tên, f4=items[] } (KHÔNG phải f1/f3).
        shopdata_bytes = top.get(2) if isinstance(top.get(2), bytes) else top.get(1, b'')
        if not isinstance(shopdata_bytes, bytes):
            print(f"[SHOP PARSER] BỎ: không tìm shopdata (top keys={list(top.keys())})"); return False

        shopdata_fields = _decode_protobuf(shopdata_bytes)
        shopkey = shopdata_fields.get(1, b'')
        if isinstance(shopkey, bytes):
            shopkey = shopkey.decode('utf-8', errors='replace')
        if not shopkey:
            print(f"[SHOP PARSER] BỎ: không đọc được shopkey (sub keys={list(shopdata_fields.keys())})"); return False

        # Items = repeated field 4 (mỗi entry {f1=itemindex, f2=itemdata}). _decode_protobuf chỉ giữ
        # giá trị CUỐI cho field lặp -> phải WALK tay để lấy HẾT field4.
        items = {}
        raw = shopdata_bytes
        pos = 0
        while pos < len(raw):
            tag, pos = _decode_varint(raw, pos)
            fnum = tag >> 3
            wtype = tag & 0x07
            if wtype == 2:
                length, pos = _decode_varint(raw, pos)
                val_bytes = raw[pos:pos+length]
                pos += length
                if fnum in (3, 4):   # 4 = item entry (mới); 3 = MapEntry (cũ) -> giữ tương thích
                    entry_fields = _decode_protobuf(val_bytes)
                    item_index = entry_fields.get(1, -1)
                    item_bytes = entry_fields.get(2, b'')
                    if isinstance(item_bytes, bytes) and isinstance(item_index, int) and item_index >= 0:
                        items[item_index] = _decode_shopitem(item_bytes)
            elif wtype == 0: _, pos = _decode_varint(raw, pos)
            elif wtype == 1: pos += 8
            elif wtype == 5: pos += 4
            else: break
            
        if not items:
            print(f"[SHOP PARSER] BỎ: shopkey={shopkey} nhưng tách 0 item (cấu trúc tab này khác?)"); return False

        item_db = get_item_db()      # dict (g,d,p)->name (fallback)
        try:
            from core.item_db import get_item_db as _core_get_db
            cdb = _core_get_db()     # ItemDB có name_by_model (phân biệt theo model field9)
        except Exception:
            cdb = None
        item_name_map = {}
        unknown = []
        for idx, item in items.items():
            g = item['genre']; d = item['detail']; p = item['particular']; mdl = item.get('model', 0)
            # ƯU TIÊN tra theo MODEL (field9) -> phân biệt món cùng (g,d,p) (vd Mãng Bì vs Thiên Tàm Yêu Đái).
            name = ((cdb.name_by_model(g, d, p, mdl) if cdb else None) or item_db.get((g, d, p), ""))
            if name:
                # GIỮ idx NHỎ NHẤT (lần đầu) — shop hay có món thứ 28 lặp lại idx khác làm sai map.
                item_name_map.setdefault(name.lower(), idx)
            else:
                unknown.append((idx, g, d, p, mdl))
        if not item_name_map:
            print(f"[SHOP PARSER] BỎ: shopkey={shopkey} có {len(items)} item nhưng KHÔNG tra được tên "
                  f"(g,d,p) trong item_db. Mẫu: {unknown[:6]}"); return False
        if unknown:
            print(f"[SHOP PARSER] {shopkey}: {len(unknown)} item không tra được tên (g,d,p): {unknown[:6]}")
        
        # Load and update shop_dict.json
        dict_path = "features/bot/shop_dict.json"
        shop_dict = {}
        if os.path.exists(dict_path):
            try:
                with open(dict_path, "r", encoding="utf-8") as f:
                    shop_dict = json.load(f)
            except: pass
            
        shop_dict[shopkey] = item_name_map
        with open(dict_path, "w", encoding="utf-8") as f:
            json.dump(shop_dict, f, ensure_ascii=False, indent=4)
            
        print(f"[SHOP PARSER] Đã cập nhật shop_dict.json cho {shopkey} với {len(item_name_map)} items!")
        return shopkey   # trả shopkey để caller học context mở shop
    except Exception as e:
        print(f"[SHOP PARSER] Lỗi parse shop data: {e}")
        return None
