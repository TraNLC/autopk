"""
game_bot.py 鈥?VLTK1 Bot Controller
Connect Frida to game, inject hooks, call RPC to control character.

Usage:
    python bot/game_bot.py        (interactive shell)
    python bot/test_bot.py        (test run)
"""
import sys
import time
import struct
import subprocess
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent / 'proto'))
from vltk1_protocol import encode_message_fields, GS_OPCODES_REV, MESSAGES

import frida
import logging

logger = logging.getLogger('game_bot')

import platform
import os
from core.adb_path import resolve_adb
PACKAGE     = 'vn.perfingame.jx1mobile'
ADB         = resolve_adb()   # tự dò đa nền tảng (Windows MEmu / macOS MuMu)
DEVICE_ID   = '127.0.0.1:5555'
# DUMP GÓI DEBUG (packet_dump.txt / all_packets_dump.log / shop_data_dump.hex): TẮT mặc định cho production.
# 10 cửa sổ chạy lâu -> các file này phình hàng trăm MB + TRỘN gói mọi device (không có device prefix) ->
# vô dụng để debug + đầy đĩa. Bật lại bằng biến môi trường GST_DEBUG_DUMP=1 khi cần soi gói.
DEBUG_DUMP  = (os.environ.get('GST_DEBUG_DUMP', '') == '1')
# SỰ THẬT autoplay (chốt 2026-06-15, đừng flip-flop nữa):
#  - Gói 140 (eApplyAutoplayProfile) CHỈ set profile, KHÔNG tự START cày. Phải BẤM nút Auto (EnableAutoplay).
#  - EnableAutoplay qua Il2Cpp.gc.choose = STOP-THE-WORLD -> CRASH (acc Láo Là Bem). ĐÃ đổi sang
#    Resources.FindObjectsOfTypeAll -> KHÔNG crash. (đừng quay lại gc.choose trong vòng lặp.)
#  - ⚠️ NÚT Auto cày bằng profile MẶC ĐỊNH. Acc mới default RỖNG -> bấm nút = client gửi 140 RỖNG = WIPE.
#    => start_autoplay PHẢI SetDefaultProfile(guid) TRƯỚC khi bấm nút (xem start_autoplay). [[profile-wipe-rootcause]]
IL2CPP_AUTOPLAY = (os.environ.get('GST_IL2CPP_AUTOPLAY', '') == '1')
SCRIPT_PATH = Path(__file__).parent / 'frida_bot.js'


class VLTK1Bot:
    """VLTK1 Game Bot 鈥?Frida socket injection."""

    def __init__(self, device_id=DEVICE_ID):
        self.device_id = device_id
        self.session  = None
        self.script   = None
        self.rpc      = None
        self.game_fd  = -1
        self.running  = False
        self.connect_diag = ""   # lý do attach Frida lần gần nhất (đẩy lên UI để chẩn đoán "không bắt được nhân vật")
        self._recv_handlers = {}
        # Node Dã Tẩu HỌC ĐƯỢC từ lần người chơi KÍCH TAY vào NPC (bắt gói eNpcDialogue gửi đi).
        self.last_npc_dialogue_id = None
        self.last_npc_dialogue_t = 0.0
        self._bot_talk_ids = {}   # npcId -> ts: node CHÍNH BOT vừa talk_npc (để phân biệt với kích tay thật)
        self.last_shop_buy = None   # {shopkey,itemindex,ts} mua TAY gần nhất (học idx vũ khí có hệ)
        self.last_autoplay = None   # {startAuto,profile,ts} bấm AUTO tay gần nhất (học guid profile cày)
        # Gói eStringData "2|x|y|.." gần nhất (context mở shop NPC) — để học/replay mở shop từ xa.
        self.last_string_cmd = ""
        self.last_string_cmd_t = 0.0

    def is_connected(self):
        # KHÔNG chỉ check session != None: sau game crash/đóng, Frida 'detached' set _detached=True nhưng
        # self.session VẪN ≠ None (object cũ còn đó) → trả True STALE → tick top poll_recv() throw mỗi tick →
        # spin "Lỗi tick" vô tận, luồng không thoát. PHẢI loại _detached.
        return self.session is not None and not getattr(self, '_detached', False)

    # ==================== CONNECTION ====================

    def connect(self, fast: bool = False) -> bool:
        """Attach Frida to the game process.
        fast=True (dùng khi RE-ATTACH lúc đổi account / relaunch): BỎ QUA vòng dò fd ~12.5s — lúc đang ở màn
        LOGIN game CHƯA có gói server nào để dò (pickBestFd phí 7.5s + diag 3s vô ích), fd sẽ được wait_in_world
        dò lại (redetect_fd_by_traffic) NGAY khi vào thế giới + poll_recv tự hồi. -> tiết kiệm ~10s mỗi lần login."""
        print('[*] Connecting...' + (' (fast re-attach)' if fast else ''))

        # Auto-start frida-server on device. In TUNG BUOC + XAC MINH dang chay -> chan doan "cam ket noi".
        try:
            from core.paths import BASE as _BASE
            # TỰ DÒ ABI Android của giả lập -> chọn ĐÚNG frida-server (Mac/MuMu=arm64, PC/MEmu thường x86_64).
            # KHÔNG hardcode bản ARM. Repo có sẵn frida-server-x86_64.bin / frida-server-arm64.bin.
            _abi = ''
            try:
                _abi = subprocess.check_output(f'{ADB} -s {self.device_id} shell getprop ro.product.cpu.abi',
                                               shell=True, timeout=8, stderr=subprocess.DEVNULL).decode().strip().lower()
            except Exception:
                _abi = ''
            _cands = []
            if 'x86_64' in _abi or 'x86-64' in _abi:
                _cands = ['frida-server-x86_64.bin']
            elif 'arm64' in _abi or 'aarch64' in _abi:
                _cands = ['frida-server-arm64.bin']
            elif 'x86' in _abi:
                _cands = ['frida-server-x86.bin', 'frida-server-x86_64.bin']   # x86 không có -> thử x86_64
            elif _abi:
                _cands = ['frida-server-arm64.bin']
            _cands.append('frida-server')   # fallback file trần (có thể sai ABI nếu copy từ máy khác)
            _fs = next((os.path.join(_BASE, c) for c in _cands if os.path.exists(os.path.join(_BASE, c))), None)
            if not _fs:
                _fs = os.path.join(_BASE, "frida-server")
                _fs = _fs if os.path.exists(_fs) else "frida-server"
            print(f'[*] ABI giả lập={_abi or "?"} -> dùng {os.path.basename(_fs)}')
            # BỎ QUA push/adb-root NẾU frida-server ĐÃ CHẠY (bật 10 cửa sổ: mỗi device push 110MB + adb root
            # -> adb root restart adbd -> mọi device offline thoáng qua -> attach flaky hàng loạt). Chỉ làm khi cần.
            already = ''
            try:
                already = subprocess.check_output(
                    f'{ADB} -s {self.device_id} shell "pidof frida-server"',
                    shell=True, timeout=6, stderr=subprocess.DEVNULL).decode().strip()
            except Exception:
                already = ''
            if already:
                print(f'[*] frida-server đã chạy (pid {already}) -> bỏ qua push/adb-root (đỡ restart adbd khi 10 cửa sổ).')
                fs_pid = already
            else:
                # adb root: MEmu BAT Root mode thi lenh nay cho phep adb chay as root (vo hai neu khong ho tro).
                print('[*] adb root...')
                subprocess.run(f'{ADB} -s {self.device_id} root', shell=True, timeout=12, capture_output=True)
                # adb root co the restart adbd -> device offline thoang qua. Cho ket noi lai.
                subprocess.run(f'{ADB} -s {self.device_id} wait-for-device', shell=True, timeout=15, capture_output=True)
                print('[*] Push frida-server (~110MB, doi vai giay)...')
                r = subprocess.run(
                    f'{ADB} -s {self.device_id} push "{_fs}" /data/local/tmp/frida-server',
                    shell=True, timeout=60, capture_output=True
                )
                if r.returncode != 0:
                    print(f'[-] Push loi: {r.stderr.decode(errors="ignore")[:200]}')
                # Tat ban cu + cap quyen
                subprocess.run(
                    f'{ADB} -s {self.device_id} shell "pkill frida-server 2>/dev/null; chmod 755 /data/local/tmp/frida-server"',
                    shell=True, timeout=10, capture_output=True
                )
                # Start NEN bang Popen (KHONG cho) -> tranh subprocess timeout giet luon daemon.
                print('[*] Start frida-server...')
                subprocess.Popen(
                    f'{ADB} -s {self.device_id} shell "/data/local/tmp/frida-server -D"',
                    shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                )
                # XAC MINH frida-server thuc su chay (pidof) — thu toi 5 lan.
                fs_pid = ''
                for _ in range(5):
                    time.sleep(1)
                    try:
                        fs_pid = subprocess.check_output(
                            f'{ADB} -s {self.device_id} shell "pidof frida-server"',
                            shell=True, timeout=5, stderr=subprocess.DEVNULL
                        ).decode().strip()
                    except Exception:
                        fs_pid = ''
                    if fs_pid:
                        break
                if fs_pid:
                    print(f'[+] frida-server dang chay (pid {fs_pid}).')
                else:
                    print('[-] frida-server KHONG chay duoc -> MEmu chua bat Root mode?')
                    self.connect_diag = ("frida-server KHÔNG chạy được trên MEmu — gần như chắc chắn do MEmu "
                                         "CHƯA bật Root mode (Cài đặt → Root → BẬT) rồi khởi động lại MEmu.")
        except Exception as e:
            print(f'[-] Failed to auto-start frida-server: {e}')
            self.connect_diag = f"Lỗi khởi động frida-server: {e}"

        # Find device
        device = None
        for d in frida.enumerate_devices():
            if self.device_id in d.id:
                device = d
                break
        if not device:
            print(f'[-] Device not found: {self.device_id}')
            self.connect_diag = (f"Frida KHÔNG thấy thiết bị {self.device_id}. "
                                 "MEmu phải BẬT Root mode (Cài đặt → Root → ON) rồi khởi động lại.")
            return False
        print(f'[+] Device: {device.name} ({device.id})')

        # Find PID via ADB (more reliable on emulator than frida enumerate)
        try:
            out = subprocess.check_output(
                f'{ADB} -s {self.device_id} shell "pidof {PACKAGE}"',
                shell=True, timeout=5
            ).decode().strip()
            if not out:
                print(f'[-] Game not running. Start {PACKAGE} first.')
                self.connect_diag = "Game CHƯA chạy trên giả lập. Mở game + vào nhân vật rồi bật Auto lại."
                return False
            pid = int(out.split()[0])
            print(f'[+] PID: {pid}')
        except Exception as e:
            print(f'[-] Could not get PID: {e}')
            self.connect_diag = f"Không lấy được PID game (adb lỗi?): {e}"
            return False

        # Attach
        try:
            self.session = device.attach(pid)
            self._detached = False   # RESET cờ rớt (lần attach mới) -> is_connected() trả True lại sau reconnect.
        except Exception as e:
            print(f'[-] Attach failed: {e}')
            self.connect_diag = (f"Attach Frida THẤT BẠI: {e}. Thường do frida-server KHÔNG chạy "
                                 "(MEmu chưa BẬT Root mode) hoặc SAI kiến trúc (sửa ABI x86_64↔x86 trong installer).")
            return False

        # Load script. Prepend frida-il2cpp-bridge (định nghĩa globalThis.Il2Cpp) nếu có,
        # để đọc field/thuộc tính THEO TÊN, hết lệ thuộc offset 32/64-bit.
        js = SCRIPT_PATH.read_text(encoding='utf-8')
        bridge_path = Path(__file__).parent.parent.parent / 'vendor' / 'il2cpp-bridge.js'
        if bridge_path.exists():
            js = bridge_path.read_text(encoding='utf-8') + "\n;\n" + js
        self.script = self.session.create_script(js)
        self.script.on('message', self._on_message)
        # ĐÓNG CỬA SỔ GAME = process chết -> Frida 'detached'. Đánh dấu để luồng bot NÀY tự dừng gọn (RPC đang
        # chờ được giải phóng, khỏi treo/spin lỗi). CHỈ ảnh hưởng bot này — KHÔNG đụng device khác.
        try:
            self.session.on('detached', self._on_detached)
        except Exception:
            pass
        self.script.load()
        self.rpc = self.script.exports_sync
        print('[+] Script loaded.')

        # FAST re-attach (relaunch/đổi account): chỉ cần script tiêm xong ở màn login. Bỏ qua dò fd + diag
        # (game chưa vào thế giới -> dò vô ích). wait_in_world sẽ redetect fd ngay khi in_world; poll_recv tự hồi.
        if fast:
            time.sleep(1)
            self.running = True
            self.connect_diag = "Re-attach nhanh (sẽ dò fd khi vào thế giới)."
            return True

        # Give hooks time to settle, then detect game fd
        time.sleep(2)
        status = self.rpc.ping()
        self.game_fd = status.get('gameFd', -1)

        # DÒ fd theo BẰNG CHỨNG opcode game (tin cậy NHẤT + bền RE-ATTACH/đổi account): fd nào nhận nhiều gói
        # opcode game hợp lệ nhất = fd game. KHÔNG phụ thuộc hook connect() (re-attach vào game đã nối-sẵn thì
        # connect() KHÔNG bắn) cũng không phụ thuộc /proc (MuMu tunnel localhost -> /proc dò sai -> "đứng" khi
        # tắt/bật Auto). Chờ vài giây cho heartbeat game tới rồi pickBestFd.
        best_fd = -1
        for _ in range(5):                      # tối đa ~7.5s chờ gói game
            time.sleep(1.5)
            try:
                bf = self.rpc.pick_best_fd()
                if bf and bf.get('ok') and bf.get('n', 0) >= 2:
                    best_fd = bf['fd']; break
            except Exception:
                pass
        if best_fd > 0:
            self.set_game_fd(best_fd); self.game_fd = best_fd
            print(f'[+] Game fd (bằng chứng opcode): {best_fd}')
        elif self.game_fd >= 0:
            print(f'[+] Game fd (connect-hook): {self.game_fd}')
        else:
            fd = self._auto_detect_fd()         # fallback cuối: /proc
            if fd > 0:
                print(f'[*] Auto-detect fd (/proc fallback): {fd}'); self.set_game_fd(fd); self.game_fd = fd
            else:
                print('[!] Game fd not detected. Play the game to trigger connection.')

        # CHẨN ĐOÁN recv: chờ 3s rồi xem game có nhận gói nào không (mọi fd) -> tách "kết nối chết"
        # vs "hook sót fd". Quan trọng khi Dã Tẩu câm.
        try:
            time.sleep(3)
            st = self.rpc.ping()
            fds = st.get('fdsSeen', {})
            print(f"[CHẨN ĐOÁN recv] recvAny={st.get('recvAny')} recvTotal={st.get('recvTotal')} "
                  f"gameFd={st.get('gameFd')} fdsSeen={fds} lastOps={st.get('lastOps')}")
            if not st.get('recvAny'):
                print("[CHẨN ĐOÁN] => Game KHÔNG nhận gói nào (kết nối server có thể chết / chưa vào thế giới).")
                self.connect_diag = ("Attach Frida OK nhưng game KHÔNG nhận gói nào — chưa vào thế giới? "
                                     "Vào hẳn nhân vật trong game rồi thử lại.")
            elif not st.get('recvTotal'):
                print(f"[CHẨN ĐOÁN] => Có nhận gói nhưng SAI gameFd. fd thực có data: {list(fds.keys())}")
                self.connect_diag = f"Attach OK, có gói nhưng dò sai gameFd (tự dò lại khi chạy). fd có data: {list(fds.keys())}"
            else:
                self.connect_diag = f"Kết nối OK (gameFd={st.get('gameFd')})."
        except Exception as e:
            print(f"[CHẨN ĐOÁN] lỗi: {e}")

        self.running = True
        return True

    def _auto_detect_fd(self) -> int:
        """Detect game server socket fd via /proc/net/tcp."""
        try:
            pid_out = subprocess.check_output(
                f'{ADB} -s {self.device_id} shell "pidof {PACKAGE}"',
                shell=True, timeout=5
            ).decode().strip()
            pid = int(pid_out.split()[0])

            tcp = subprocess.check_output(
                f'{ADB} -s {self.device_id} shell "cat /proc/{pid}/net/tcp"',
                shell=True, timeout=5
            ).decode()

            # BASELINE (đã chạy được): kết nối ESTABLISHED có remote port > 1000 (bỏ adb/frida).
            # (KHÔNG lọc localhost — MuMu tunnel game qua localhost proxy nên fd game CÓ THỂ là localhost.)
            inodes = {}
            for line in tcp.split('\n')[1:]:
                parts = line.split()
                if len(parts) >= 10 and parts[3] == '01':  # ESTABLISHED
                    inodes[parts[9]] = parts[2]  # inode -> remote hex

            fds = subprocess.check_output(
                f'{ADB} -s {self.device_id} shell "ls -l /proc/{pid}/fd"',
                shell=True, timeout=5
            ).decode()

            for line in fds.split('\n'):
                if 'socket:[' not in line:
                    continue
                inode = line.split('socket:[')[1].split(']')[0]
                if inode not in inodes:
                    continue
                port = int(inodes[inode].split(':')[1], 16)
                if port > 1000 and port not in (5555, 5037, 27042):
                    parts = line.split()
                    for j, p in enumerate(parts):
                        if p == '->' and j > 0:
                            return int(parts[j - 1])
        except Exception as e:
            print(f'[!] Auto-detect fd failed: {e}')
        return -1

    def redetect_fd(self) -> bool:
        """Dò lại game fd (sau khi đổi map/thành, game thường mở socket MỚI -> fd đổi -> bot đọc nhầm
        fd cũ -> câm). Trả True nếu đổi sang fd mới."""
        try:
            fd = self._auto_detect_fd()
            if fd and fd > 0 and fd != self.game_fd:
                print(f'[+] RE-DETECT game fd: {self.game_fd} -> {fd} (đổi map?)')
                self.set_game_fd(fd)
                return True
        except Exception as e:
            print(f'[!] redetect_fd lỗi: {e}')
        return False

    def redetect_fd_by_traffic(self) -> bool:
        """Chọn fd game theo BẰNG CHỨNG runtime (fd nhận nhiều opcode game hợp lệ nhất).
        Bền với ĐỔI TÀI KHOẢN / đổi map (game mở socket mới) — không đoán theo /proc.
        Trả True nếu đổi sang fd mới."""
        try:
            res = self.rpc.pick_best_fd()
        except Exception as e:
            print(f'[!] pick_best_fd lỗi: {e}')
            return False
        if res and res.get('ok') and res.get('fd', -1) > 0:
            fd = int(res['fd'])
            if fd != self.game_fd:
                print(f'[+] FD theo traffic: {self.game_fd} -> {fd} '
                      f'(opcode game={res.get("n")}, bộ đếm={res.get("gameOps")})')
                self.set_game_fd(fd)
                return True
        else:
            print(f'[i] pick_best_fd chưa thấy fd game (gameOps={res.get("gameOps") if res else "?"}) '
                  f'-> có thể data đang mã hoá / chưa có gói game nào parse được.')
        return False

    def set_game_fd(self, fd: int):
        """Set the game socket fd."""
        self.rpc.set_game_fd(fd)
        self.game_fd = fd
        print(f'[+] Game fd set to {fd}')

    def _on_detached(self, reason=None, *args):
        """Frida session detach (process game ĐÓNG/CHẾT). Đánh dấu RIÊNG bot này dừng — KHÔNG ném lỗi ra ngoài,
        KHÔNG đụng device khác (mỗi bot 1 session). Luồng bot sẽ thấy running=False/RPC lỗi → dừng gọn."""
        try:
            self.running = False
            self._detached = True
            logger.info(f"[frida] session detached (reason={reason}) — game đã đóng/chết, dừng bot này.")
        except Exception:
            pass

    def _on_message(self, message, data):
        """Handle messages from Frida script."""
        if message['type'] != 'send':
            if message['type'] == 'error':
                logger.error(f"[FRIDA ERROR] {message.get('description', message)}")
            return
        
        p = message['payload']
        t = p.get('type', '')

        if t == 'ready':
            hooks = p.get('hooks', {})
            ok = sum(1 for v in hooks.values() if v)
            logger.info(f'[+] Socket hooks: {ok}/{len(hooks)}')

        elif t == 'il2cpp_ready':
            lib = p.get('lib')
            if lib:
                print(f'[+] Il2cpp hooks: {lib} @ {p.get("base")}')
            else:
                print(f'[!] Il2cpp: {p.get("msg", "not found")}')

        elif t == 'il2cpp_event':
            print(f'[IL2CPP] {p.get("event")} {p}')

        elif t == 'il2cpp_send':
            print(f'[IL2CPP SEND] id={p.get("id")} name={p.get("name")}')

        elif t == 'game_fd':
            self.game_fd = p.get('fd', self.game_fd)
            if p.get('auto'):
                print(f'[+] Game fd AUTO-KHÓA = {self.game_fd} (opcode {p.get("opcode")})')
            else:
                print(f'[+] Game server: {p.get("ip","?")}:{p.get("port","?")} fd={self.game_fd}')

        elif t == 'recv':
            name = p.get('name', '')
            if name in self._recv_handlers:
                self._recv_handlers[name](p)

        elif t == 'send':
            print(f'[RAW SEND] fd={p.get("fd")} size={p.get("size")} | {p.get("hex")}')
        elif t == 'send_out':
            # BUFFER gói gửi đi (để probe đọc qua poll_sent) — bật/tắt bằng self.capture_sent (mặc định off
            # để khỏi tốn RAM lúc cày). Probe set bot.capture_sent=True trước khi quan sát.
            if getattr(self, 'capture_sent', False):
                if not hasattr(self, 'sent_buffer'):
                    self.sent_buffer = []
                self.sent_buffer.append({'opcode': p.get('opcode'), 'name': p.get('name'),
                                         'size': p.get('size'), 'hex': p.get('hex')})
                if len(self.sent_buffer) > 3000:
                    self.sent_buffer = self.sent_buffer[-3000:]
            # 🔴 BẮT WIPE: op140 (eApplyAutoplayProfile) GỬI ĐI với profile RỖNG = gói XOÁ profile. LOG cảnh báo
            # (vào shared log) DÙ nguồn là send_gs bot HAY client tự gửi (bấm nút Auto khi chưa chọn profile).
            # → lần mất-profile sau soi log thấy NGAY thời điểm + xác nhận đúng vector.
            if p.get('opcode') == 140:
                try:
                    body = bytes.fromhex(p.get('hex', ''))[6:]
                    has_profile = False
                    o = 0
                    while o < len(body):
                        tag = body[o]; o += 1; f, w = tag >> 3, tag & 7
                        if w == 0:
                            while o < len(body) and body[o] & 0x80: o += 1
                            o += 1
                        elif w == 2:
                            ln = body[o]; o += 1
                            if f == 2 and ln > 0: has_profile = True
                            o += ln
                        else:
                            break
                    if not has_profile:
                        logger.warning(f"[WIPE-DETECT] GỬI op140 eApplyAutoplayProfile PROFILE RỖNG (hex={p.get('hex')}) "
                                       f"= GÓI XOÁ PROFILE! Nguồn: bot send_gs HOẶC client (bấm nút Auto chưa có profile).")
                        try:
                            if getattr(self, 'ui_log', None):
                                self.ui_log("🔴 PHÁT HIỆN gói XOÁ PROFILE (op140 rỗng) vừa gửi đi — báo dev soi log.")
                        except Exception:
                            pass
                except Exception:
                    pass
            # KHÔNG print mỗi gói: lúc autoplay cày (8000+ gói skill/eStringData) -> flood stdout/ui_run.log +
            # tốn CPU vô ích. Chỉ print/ghi khi DEBUG_DUMP. (Học node op33 bên dưới vẫn chạy bình thường.)
            if DEBUG_DUMP:
                msg = f'[OUT -> Server] fd={p.get("fd")} Opcode: {p.get("opcode")} ({p.get("name")}) | Hex: {p.get("hex")}'
                print(msg)
                with open(f"packet_dump_{self.device_id.replace(':','_')}.txt", "a") as f:
                    f.write(msg + "\n")
            # HỌC node Dã Tẩu khi người chơi KÍCH TAY: eNpcDialogue(33) -> field1 string = npcId.
            if p.get('opcode') == 33:
                try:
                    body = bytes.fromhex(p.get('hex', ''))[6:]
                    if body and body[0] == 0x0a:
                        ln = body[1]
                        nid = body[2:2 + ln].decode('utf-8', 'ignore')
                        # CHỈ học khi là KÍCH TAY THẬT: bỏ qua nếu node này do CHÍNH BOT vừa talk_npc (≤2s)
                        # — nếu không bot tự ghi đè last_npc_dialogue_id bằng node config, đè cú nhấn tay thật.
                        bot_t = self._bot_talk_ids.get(nid, 0)
                        if nid and (time.time() - bot_t) > 2.0:
                            self.last_npc_dialogue_id = nid
                            self.last_npc_dialogue_t = time.time()
                            print(f'[+] Bắt eNpcDialogue KÍCH TAY THẬT -> npcId={nid} (học node Dã Tẩu)')
                except Exception:
                    pass
            # HỌC item shop khi người chơi MUA TAY: eShopBuyItem(148) -> shopkey + itemindex.
            # Dùng cho vũ khí có 'hệ X' (hệ KHÔNG nằm trong data shop nên bot không tự suy được idx).
            if p.get('opcode') == 148:
                try:
                    from features.bot.shop_parser import _decode_protobuf
                    fb = _decode_protobuf(bytes.fromhex(p.get('hex', ''))[6:])
                    sk = fb.get(1)
                    if isinstance(sk, (bytes, bytearray)):
                        sk = sk.decode('utf-8', 'ignore')
                    bidx = fb.get(2)
                    if sk and isinstance(bidx, int):
                        self.last_shop_buy = {'shopkey': sk, 'itemindex': bidx, 'ts': time.time()}
                        print(f'[+] Bắt mua tay eShopBuyItem -> {sk} idx {bidx} (học idx vũ khí/hệ)')
                except Exception:
                    pass
            # HỌC profile autoplay khi người chơi BẤM NÚT AUTO trong game: eApplyAutoplayProfile(140)
            # -> {startAuto bool (field1), profile guid (field2)}. Bot dùng để BẬT/TẮT auto game cho NV đánh quái/đồ chí.
            if p.get('opcode') == 140:
                try:
                    from features.bot.shop_parser import _decode_protobuf
                    fb = _decode_protobuf(bytes.fromhex(p.get('hex', ''))[6:])
                    start = bool(fb.get(1))
                    prof = fb.get(2)
                    if isinstance(prof, (bytes, bytearray)):
                        prof = prof.decode('utf-8', 'ignore')
                    self.last_autoplay = {'startAuto': start, 'profile': prof or '', 'ts': time.time()}
                    print(f'[+] Bắt eApplyAutoplayProfile -> startAuto={start} profile={prof!r} (học guid profile cày)')
                    # LƯU guid ra file để sống qua restart + test replay (Frida attach 1 lần).
                    try:
                        import json, os as _os
                        from core.paths import BASE as _B
                        _d = _os.path.join(_B, 'data', 'output')
                        _os.makedirs(_d, exist_ok=True)
                        # PER-DEVICE: mỗi nhân vật 1 file profile (không ghi đè guid của device khác).
                        _fn = f"autoplay_profile_{self.device_id.replace(':','_')}.json"
                        with open(_os.path.join(_d, _fn), 'w', encoding='utf-8') as _f:
                            json.dump(self.last_autoplay, _f, ensure_ascii=False)
                    except Exception:
                        pass
                except Exception as e:
                    print(f'[-] Parse eApplyAutoplayProfile lỗi: {e}')
            # HỌC context mở shop: eStringData(9) dạng "2|x|y|..." = click/tương tác NPC trước eOpenShop.
            if p.get('opcode') == 9:
                try:
                    s = bytes.fromhex(p.get('hex', ''))[6:].decode('utf-8', 'ignore')
                    if s.startswith('2|') and s.count('|') >= 2:
                        self.last_string_cmd = s
                        self.last_string_cmd_t = time.time()
                except Exception:
                    pass

        elif t == 'shop_data':
            # Dump to file for debugging/scanning
            hex_data = p.get('hex', '')
            # LƯU hex gói shop MỚI NHẤT để buy đọc MÓN CUỐI tươi (max itemindex raw, khỏi qua file/tên).
            self.last_shop_hex = hex_data
            self.last_shop_hex_t = time.time()
            # LƯU HEX/DÒNG (debug — chỉ khi DEBUG_DUMP; parse shop dùng hex_data in-memory bên dưới, KHÔNG đọc file).
            if DEBUG_DUMP:
                with open(f"shop_data_dump_{self.device_id.replace(':','_')}.hex", "a", encoding="utf-8") as f:
                    f.write(hex_data + "\n")
            
            # Auto parse and update shop_dict.json
            try:
                from features.bot.shop_parser import update_shop_dict_from_hex
                shopkey = update_shop_dict_from_hex(hex_data)
                # HỌC context mở shop từ xa: gắn shopkey vừa mở với gói eStringData "2|x|y|.." gần nhất.
                if isinstance(shopkey, str) and shopkey and \
                   getattr(self, 'last_string_cmd', '') and (time.time() - getattr(self, 'last_string_cmd_t', 0)) < 8:
                    try:
                        from core import npc_shop
                        npc_shop.save_shop_context(shopkey, self.last_string_cmd)
                        print(f'[+] Học context mở shop từ xa: {shopkey} <- "{self.last_string_cmd}"')
                    except Exception:
                        pass
            except Exception as e:
                logger.error(f"Error parsing shop data: {e}")

        elif t == 'error':
            print(f'[-] Script error: {p.get("msg")}')

        elif t == 'dialog_hide':
            if p.get('ok'):
                print(f'[+] Ẩn dialog Dã Tẩu (đã hook): {p.get("hooked")}')
                seen = p.get('seen') or []
                if seen:
                    print(f'[i] Class có "Dialog" ở runtime: {seen}')
            else:
                print(f'[!] Ẩn dialog lỗi: {p.get("err") or p.get("msg")} (cls={p.get("cls")})')

        elif t == 'il2cpp_error':
            print(f'[-] Il2cpp error: {p.get("msg")}')

        elif t == 'info':
            print(f'[i] {p.get("msg")}')

    # ==================== SEND ====================

    def send_raw(self, data: bytes) -> bool:
        hex_data = data.hex()
        # Thử dùng sslSend trước (nếu game dùng SSL)
        try:
            result = self.rpc.ssl_send(hex_data)
            if result.get('ok'):
                return True
        except Exception:
            pass

        # Fallback sang sendRaw (socket thường) — đường này CHẠY ỔN nhiều ngày (server vẫn nhận), KHÔNG log spam.
        result = self.rpc.send_raw(hex_data)
        return result.get('ok', False)

    def send_gs(self, opcode_name: str, **kwargs) -> bool:
        """Build and send a game server packet.

        Packet format (confirmed via disassembly of SendGSMessage):
          [uint32 LE proto_len] [uint16 LE opcode] [proto body]
        """
        oid = GS_OPCODES_REV.get(opcode_name)
        if oid is None:
            print(f'[-] Unknown opcode: {opcode_name}')
            return False

        msg_class = opcode_name[1:] if opcode_name.startswith('e') else opcode_name
        
        # Determine actual class name in MESSAGES dict
        actual_class = msg_class
        if actual_class not in MESSAGES and actual_class + 'Message' in MESSAGES:
            actual_class += 'Message'

        proto = encode_message_fields(actual_class, **kwargs) if (actual_class in MESSAGES and kwargs) else b''

        # Header: uint32 proto_len + uint16 opcode
        packet = struct.pack('<IH', len(proto), oid) + proto
        return self.send_raw(packet)

    # ==================== RECEIVE ====================

    def on_recv(self, opcode_name: str, handler):
        """Register handler for incoming packet type."""
        self._recv_handlers[opcode_name] = handler

    def poll_recv(self):
        """Poll buffered received packets from Frida and store them."""
        pkts = self.rpc.get_recv_packets()
        # MERGE buffer dialog RIÊNG (34/124/126/166/245) — ở thành đông op9 lụt đẩy gói dialog ra khỏi recvBuffer
        # cap 3000 (mất tiến độ NV, "phải focus mới bắt"). dialogBuffer giữ riêng -> luôn lấy được. Dedupe theo hex
        # (gói nào còn sót trong recvBuffer thì khỏi thêm lần 2).
        try:
            dpkts = self.rpc.get_dialog_packets() or []
        except Exception:
            dpkts = []
        if dpkts:
            _have = {p.get('hex') for p in (pkts or [])}
            _extra = [d for d in dpkts if d.get('hex') not in _have]
            if _extra:
                pkts = (list(pkts) if pkts else []) + _extra
        if not hasattr(self, 'recv_buffer'):
            self.recv_buffer = []
        # TỰ HỒI gameFd: connect() chỉ dò fd 1 LẦN. Nếu cửa sổ dò đó trùng lúc game im (vd vừa phù về thành,
        # autoplay tắt) -> recvAny=0 -> gameFd SAI/-1 -> buffer game RỖNG MÃI -> bot MÙ -> ĐỨNG (đúng bug
        # "tắt/bật Auto cũng đứng im"). -> Khi buffer im >10s, gọi pick_best_fd (đếm opcode game trên MỌI fd):
        # traffic vừa quay lại sẽ tự khoá đúng fd. pick_best_fd chỉ đổi khi có bằng chứng -> fd đúng thì no-op.
        now = time.time()
        if pkts:
            self._last_recv_ts = now
        else:
            last = getattr(self, '_last_recv_ts', None)
            if last is None:
                self._last_recv_ts = now
            elif now - last > 10 and now - getattr(self, '_last_fd_reheal', 0) > 10:
                self._last_fd_reheal = now
                try:
                    if self.redetect_fd_by_traffic():
                        self._last_recv_ts = now   # vừa đổi fd -> cho chu kỳ mới
                except Exception:
                    pass
        if pkts:
            if DEBUG_DUMP:   # all_packets_dump.log phình hàng trăm MB khi chạy lâu -> chỉ ghi khi debug, per-device
                with open(f"all_packets_dump_{self.device_id.replace(':','_')}.log", "a") as out:
                    for p in pkts:
                        out.write(f"[{p['opcode']}] {p['name']} - Size: {p['size']}\n")
                        if p['size'] > 100:
                            out.write(f"Hex: {p['hex']}\n")
            self.recv_buffer.extend(pkts)
            # Keep buffer bounded
            if len(self.recv_buffer) > 3000:
                self.recv_buffer = self.recv_buffer[-3000:]
        return pkts

    def clear_buffer(self):
        if hasattr(self, 'recv_buffer'):
            self.recv_buffer.clear()

    def wait_for_packet(self, opcode_name: str, timeout: float = 3.0) -> list:
        """Wait for specific packet(s) by opcode name. Returns list of packet hex payloads.
        Checks the buffer first, then polls."""
        import time
        start_time = time.time()
        found = []
        
        if not hasattr(self, 'recv_buffer'):
            self.recv_buffer = []
            
        while time.time() - start_time < timeout:
            self.poll_recv() # Pull new packets into buffer
            
            # Consume matching packets from buffer
            new_buffer = []
            
            # Normalize to tuple for `in` check
            target_opcodes = opcode_name if isinstance(opcode_name, (list, tuple)) else (opcode_name,)
            
            for p in self.recv_buffer:
                # Khớp theo TÊN (eNpcQuest...) hoặc theo SỐ OPCODE (34/124/126/166...)
                # vì nhiều gói quan trọng chưa được đặt tên (UNK_124, UNK_126).
                if p.get('name') in target_opcodes or p.get('opcode') in target_opcodes:
                    found.append(p)
                else:
                    new_buffer.append(p)
            self.recv_buffer = new_buffer
            
            if found:
                return found
            time.sleep(0.1)
        return found

    # ==================== GAME ACTIONS ====================

    def ping(self):
        return self.send_gs('ePing')

    def chat(self, message: str, channel: int = 1):
        print(f'[>] Chat [{channel}]: {message}')
        return self.send_gs('eChatSend', channel=channel, message=message)

    def _autoplay_guid(self):
        """guid 'Luyện công' RIÊNG của account — TÌM THEO TÊN trong profileMapping (get_named_autoplay_profile,
        tự InitializeForce nạp profile nếu chưa). MỌI account đều có 'Luyện công' -> luôn ra guid RIÊNG đúng của
        account đó, FULLY AUTO — KHÔNG cần tap tay, KHÔNG gc.choose (chỉ InitializeForce data-init, đã test KHÔNG
        crash). Guid khác nhau theo account (đo live: Muội Yêu=78723a28, GSTNhanNhan=1dc8514c). Cache lại; xoay
        account -> _reinit_after_relogin reset để đọc lại guid account mới."""
        # (0) tap tay (hook gói 140 set last_autoplay) -> ưu tiên nếu có
        g = (self.last_autoplay or {}).get('profile', '')
        if g:
            return g.strip('"')
        # (1) đã resolve guid 'Luyện công' của account này -> dùng luôn (không gọi lại il2cpp)
        if getattr(self, '_autoplay_guid_resolved', None):
            return self._autoplay_guid_resolved
        # (2) TÌM 'Luyện công' THEO TÊN — thử tối đa 3 lần (InitializeForce có thể cần 1-2 nhịp để nạp xong)
        if getattr(self, '_autoplay_named_tries', 0) < 3:
            self._autoplay_named_tries = getattr(self, '_autoplay_named_tries', 0) + 1
            try:
                r = self.rpc.get_named_autoplay_profile("Luyện công")
                if r and r.get('ok') and r.get('guid'):
                    gg = (r.get('guid') or '').strip('"')
                    self._autoplay_guid_resolved = gg
                    self.last_autoplay = {'startAuto': True, 'profile': gg, 'ts': time.time()}
                    self._autoplay_last_diag = None
                    print(f"[autoplay] tìm 'Luyện công' theo tên (account này): {gg!r} -> dùng")
                    return gg
                # FALLBACK: account KHÔNG có profile tên 'Luyện công' nhưng CÓ profile khác (tên khác/sai dấu) ->
                # dùng guid profile ĐẦU TIÊN có sẵn. Đủ để bật auto đánh quái (NV đồ-chí/mật-chí) và KHÔNG gửi
                # op140 RỖNG -> KHÔNG wipe. (Trước đây bỏ hẳn -> nhiều acc rotation không bật được auto cả ngày.)
                allp = (r or {}).get('all') or []
                cand = next((p for p in allp if (p.get('guid') or '').strip('"')), None)
                if cand:
                    gg = (cand.get('guid') or '').strip('"')
                    self._autoplay_guid_resolved = gg
                    self.last_autoplay = {'startAuto': True, 'profile': gg, 'ts': time.time()}
                    self._autoplay_last_diag = None
                    print(f"[autoplay] KHÔNG có 'Luyện công' — DÙNG profile có sẵn {cand.get('name')!r} guid={gg!r} "
                          f"(tổng {len(allp)} profile).")
                    return gg
                # KHÔNG có profile nào -> lưu chẩn đoán để UI báo rõ (cần tạo profile trong game 1 lần).
                self._autoplay_last_diag = {'all': allp, 'error': (r.get('error') if r else None),
                                            'n': len(allp)}
                print(f"[autoplay] get_named_autoplay_profile chưa ra (thử {self._autoplay_named_tries}/3): "
                      f"err={(r.get('error') if r else None)} all={allp}")
                # GHI LOG CHẨN ĐOÁN ra file (chỉ ở LẦN THỬ CUỐI để khỏi spam) -> acc mới nào dính lỗi
                # "không có profile" sẽ tự ghi đủ data-layer + UI-layer, đọc log sau khỏi cần canh live.
                if self._autoplay_named_tries >= 3:
                    self._log_autoplay_diag(r)
            except Exception as e:
                self._autoplay_last_diag = {'all': [], 'error': str(e), 'n': 0}
                print(f"[autoplay] get_named_autoplay_profile lỗi: {e}")
                if self._autoplay_named_tries >= 3:
                    self._log_autoplay_diag({'error': str(e), 'exc': True})
        return ''

    def _log_autoplay_diag(self, named_res):
        """Ghi 1 bản chẩn đoán đầy đủ ra data/output/autoplay_profile_diag.log khi KHÔNG đọc được profile.
        Mục đích: acc MỚI nào log vào dính lỗi 'không có profile Auto' sẽ tự lưu lại (data-layer profileMapping
        QUA InitializeForce(false) + UI-layer UnityAutoplay + tên/cid acc) -> đọc log sau là biết nguồn nào có
        profile, khỏi phải tái hiện live. KHÔNG ném lỗi (best-effort)."""
        import json as _json, os as _os, time as _t
        rec = {'ts': _t.strftime('%Y-%m-%d %H:%M:%S'), 'device': self.device_id,
               'data_layer': named_res}
        try:
            pi = self.rpc.get_player_info() or {}
            rec['account'] = {'name': pi.get('name'), 'cid': pi.get('cid'),
                              'mapId': pi.get('mapId'), 'level': pi.get('level')}
        except Exception as e:
            rec['account'] = {'error': str(e)}
        # UI-layer (UnityAutoplay.selectedProfile) — chỉ có khi panel đã mở; so với data-layer để biết lệch ở đâu
        try:
            rec['ui_layer'] = self.rpc.get_autoplay_profile()
        except Exception as e:
            rec['ui_layer'] = {'error': str(e)}
        # GHI vào thư mục SYNC (treasurer_shared/logs) bằng đường dẫn TUYỆT ĐỐI + qua logger -> đọc được TỪ XA
        # (trước ghi 'data/output' relative + print: không sync, không vào log cửa sổ -> mù khi debug LinhDL).
        line = _json.dumps(rec, ensure_ascii=False)
        logger.warning(f"[autoplay-diag] {line}")        # vào log cửa sổ (đã sync qua Syncthing)
        try:
            _root = _os.path.dirname(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
            _dir = _os.path.join(_root, 'data', 'output', 'treasurer_shared', 'logs')
            _os.makedirs(_dir, exist_ok=True)
            with open(_os.path.join(_dir, 'autoplay_profile_diag.log'), 'a', encoding='utf-8') as f:
                f.write(line + '\n')
        except Exception as e:
            logger.warning(f"[autoplay-diag] ghi file lỗi: {e}")

    def start_autoplay(self, profile: str = None, arm: bool = True):
        """BẬT auto game = eApplyAutoplayProfile(140){startAuto=True, profile=GUID THẬT}.
        arm=True: gọi thêm il2cpp EnableAutoplay (gc.choose — STOP-THE-WORLD, ĐƠ GAME) để 'bấm' nút Auto thật;
        CHỈ cần 1 lần lúc bắt đầu. arm=False (giữ auto trong vòng cày): CHỈ gửi gói 140 -> KHÔNG gc.choose,
        KHÔNG đơ game. Gói 140 + GUID đúng đã đủ giữ cày."""
        profile = (profile or '').strip('"') or self._autoplay_guid()
        if not profile:
            # TUYỆT ĐỐI KHÔNG gửi gói 140 với profile RỖNG: server coi 'apply profile=empty' = XOÁ chuỗi auto
            # của nhân vật (đã gây mất profile hàng loạt sau re-exec/đổi acc khi guid đọc hụt). Bỏ qua + báo.
            print('[!] start_autoplay: KHÔNG có guid profile → BỎ QUA (KHÔNG gửi 140 rỗng để tránh XOÁ profile '
                  'in-game). Mở bảng AUTO + chọn 1 profile trong game để bot đọc được guid.')
            try:
                if getattr(self, 'ui_log', None):
                    self.ui_log("⚠️ Không đọc được guid profile auto → KHÔNG bật auto (tránh xoá profile). "
                                "Mở bảng AUTO chọn 1 profile trong game.")
            except Exception:
                pass
            return False
        self.send_gs('eApplyAutoplayProfile', startAuto=True, profile=profile)
        if not arm:
            return True            # arm=False (keep-alive mỗi 20s trong vòng cày): chỉ gói 140, KHÔNG bấm nút
        # CHỐNG WIPE (khôi phục flow chạy ngon trước đây): nút Auto (EnableAutoplay) cày bằng profile MẶC ĐỊNH,
        # KHÔNG dùng guid gửi qua gói 140. Acc MỚI default RỖNG -> bấm nút = client gửi eApplyAutoplayProfile
        # RỖNG = XOÁ profile (đây là lý do gần đây cứ acc mới là mất profile). => SET DEFAULT = guid hợp lệ
        # TRƯỚC khi bấm nút thì nút bấm gửi profile ĐÚNG -> auto start + KHÔNG wipe.
        try:
            rsd = self.rpc.set_default_autoplay_profile(profile)
            print(f'[autoplay] SetDefaultProfile({profile}) -> {rsd}')
        except Exception as e:
            print(f'[!] set_default_autoplay_profile lỗi: {e}')
        # arm=True (ĐẦU mỗi vòng cày): BẤM nút Auto = EnableAutoplay -> game thật sự START cày. Đã đổi sang
        # FindObjectsOfTypeAll -> KHÔNG gc.choose, KHÔNG đơ/crash. (gói 140 một mình KHÔNG start được.)
        try:
            r = self.rpc.enable_autoplay(True)
            print(f'[>] start_autoplay(arm) enable_autoplay(True) -> {r}')
        except Exception as e:
            print(f'[!] enable_autoplay lỗi: {e}')
        return True

    def stop_autoplay(self, profile: str = None):
        """TẮT auto game. 2 cơ chế (KHÔNG bao giờ gửi profile RỖNG = tránh wipe):
        (1) BẤM NÚT Auto OFF qua il2cpp ButtonAutoplay.EnableAutoplay(false) — FindObjectsOfTypeAll, KHÔNG
            gc.choose → AN TOÀN, KHÔNG cần guid, KHÔNG wipe. Đây là cách dừng CHÍNH (auto-AI thôi điều khiển char,
            không còn đè walk_to khi đi tới điểm quét).
        (2) NẾU có guid: gửi thêm gói 140 startAuto=False để đồng bộ server. Không có guid → bỏ qua gói (đừng gửi rỗng)."""
        profile = (profile or '').strip('"') or (self.last_autoplay or {}).get('profile', '') or self._autoplay_guid()
        print('[>] stop_autoplay()')
        if not profile:
            # ⚠️ KHÔNG có guid profile = account CHƯA có/đã mất profile autoplay. TUYỆT ĐỐI KHÔNG đụng autoplay:
            #    không bấm nút (EnableAutoplay có thể khiến CLIENT tự gửi eApplyAutoplayProfile profile RỖNG = WIPE),
            #    không gửi gói. Không có profile thì autoplay cũng không chạy → khỏi cần tắt.
            print('[!] stop_autoplay: KHÔNG có guid → SKIP hoàn toàn (tránh wipe profile).')
            return False
        # CÓ guid hợp lệ → tắt an toàn: bấm nút Auto OFF + gửi gói startAuto=False với GUID THẬT (không rỗng).
        try:
            self.rpc.enable_autoplay(False)
        except Exception as e:
            print(f'[!] stop_autoplay enable_autoplay(False) lỗi: {e}')
        return self.send_gs('eApplyAutoplayProfile', startAuto=False, profile=profile)

    # Chữ ký THP (Thần Hành Phù) — nhận diện theo loại, KHÔNG theo ô (ô đổi). particular=10 duy nhất.
    THP_SIG = {'genre': 6, 'detail': 1, 'particular': 10, 'series': 0}

    def find_thp_slot(self):
        """Tìm ô (slot) THP trong túi theo chữ ký THP_SIG. None nếu không có THP."""
        try:
            res = self.rpc.dump_bag_items()
        except Exception as e:
            print(f'[find_thp] dump_bag_items lỗi: {e}'); return None
        if not res or not res.get('ok'):
            print(f'[find_thp] dump fail: {res}'); return None
        for it in res.get('items', []):
            if all(it.get(k) == v for k, v in self.THP_SIG.items()):
                return it.get('slot')
        return None

    def thp_select(self, seq):
        """Dùng THP (ô động theo chữ ký) rồi gửi CHUỖI eNpcSelect để chọn điểm đến.
        seq = list selectIndex; phần tử None = eNpcSelect() rỗng (nút xác nhận/advance).
        Trả False nếu hết THP. Chuỗi bắt từ thao tác tay."""
        slot = self.find_thp_slot()
        if slot is None:
            print('[thp] KHÔNG thấy THP trong túi (hết Thần Hành Phù?).')
            return False
        print(f'[thp] dùng THP ô {slot}, chuỗi chọn = {seq}')
        self.use_item(slot)                 # ePlayerUserItem(itemindex=slot)
        time.sleep(1.2)                     # chờ menu điểm đến mở
        for idx in seq:
            if idx is None:
                self.send_gs('eNpcSelect')
            else:
                self.send_gs('eNpcSelect', selectIndex=idx)
            time.sleep(0.8)
        return True

    def thp_to_datau(self):
        """THP -> 'Nv Dã Tẩu' (tới động làm NV): use THP + eNpcSelect(5)."""
        return self.thp_select([5])

    def thp_to_tuong_duong(self):
        """THP -> 'Tương Dương trung tâm' (về thành nộp NV): use THP + eNpcSelect(1)+(4)+rỗng."""
        return self.thp_select([1, 4, None])

    # ==================== XA PHU (di chuyển thay Thần Hành Phù) ====================
    XAPHU_ROUTES_PATH = "data/output/xaphu_routes.json"

    # Chuẩn hoá VỊ TRÍ DẤU kiểu cũ↔mới (oà/òa, khoả/khỏa, thuỷ/thủy...) -> 1 dạng, để khớp route Xa Phu.
    _TONE_FIX = {
        'oà': 'òa', 'oá': 'óa', 'oả': 'ỏa', 'oã': 'õa', 'oạ': 'ọa',
        'oè': 'òe', 'oé': 'óe', 'oẻ': 'ỏe', 'oẽ': 'õe', 'oẹ': 'ọe',
        'uỳ': 'ùy', 'uý': 'úy', 'uỷ': 'ủy', 'uỹ': 'ũy', 'uỵ': 'ụy',
    }

    @staticmethod
    def _norm_map(s):
        """Chuẩn hoá tên map để khớp: lowercase, bỏ '[N]' cuối, bỏ chữ 'động', chuẩn dấu oa/oe/uy, gộp space."""
        import re
        s = (s or "").lower().strip()
        s = re.sub(r'\s*\[\d+\]\s*$', '', s)
        s = s.replace('động', '')               # bỏ chữ 'động'
        for a, b in VLTK1Bot._TONE_FIX.items():  # 'khoả'->'khỏa', 'hoà'->'hòa'... (cũ->mới, áp cả 2 phía nên khớp)
            s = s.replace(a, b)
        s = re.sub(r'\s+', ' ', s).strip()
        return s

    def _load_xaphu_routes(self):
        import json
        try:
            return json.load(open(self.XAPHU_ROUTES_PATH, encoding="utf-8"))
        except Exception:
            return {}

    @staticmethod
    def parse_npc_menu(hex_str):
        """Parse gói menu NPC (op34) -> list chuỗi lựa chọn THEO THỨ TỰ (đã bỏ byte-length protobuf).
        Mỗi option là 1 field wire-type-2 (string). opts[0] thường là câu hỏi; sau đó là các điểm đến."""
        out = []
        try:
            b = bytes.fromhex(hex_str)[6:]
            i, n = 0, len(b)
            while i < n:
                tag = b[i]; i += 1
                wt = tag & 7
                if wt == 2:                       # length-delimited (string)
                    length = 0; shift = 0
                    while i < n:
                        c = b[i]; i += 1
                        length |= (c & 0x7f) << shift
                        if not (c & 0x80):
                            break
                        shift += 7
                    val = b[i:i + length]; i += length
                    try:
                        s = val.decode('utf-8')
                        if s and sum(ch.isprintable() for ch in s) >= len(s) * 0.6:
                            out.append(s.strip())
                    except Exception:
                        pass
                elif wt == 0:                     # varint -> skip
                    while i < n and (b[i] & 0x80):
                        i += 1
                    i += 1
                elif wt == 5:
                    i += 4
                elif wt == 1:
                    i += 8
                else:
                    break
        except Exception:
            pass
        return out

    # Top-menu Xa Phu (cat): 1=Thành Thị 2=Thôn Trấn 3..11=LC10..90 12=Tẩy Tủy đảo 13=Đêm Huy Hoàng
    XAPHU_TIERS = {1: 'Thành Thị', 2: 'Thôn Trấn', 3: 'LC10', 4: 'LC20', 5: 'LC30', 6: 'LC40',
                   7: 'LC50', 8: 'LC60', 9: 'LC70', 10: 'LC80', 11: 'LC90', 12: 'Tẩy Tủy đảo', 13: 'Đêm Huy Hoàng'}

    def xaphu_scan_routes(self, town_npc=None, cats=None, save=True, wait=3.0):
        """QUÉT menu Xa Phu (mở NPC -> chọn từng nhóm cat -> parse danh sách điểm đến theo TÊN) -> tự bổ sung
        xaphu_routes.json {norm_name: {name, seq:[cat,idx], tier}}. Khắc phục triệt để 'thiếu route' (Mật Đạo
        Nha Môn, Tương Dương, Đêm Huy Hoàng...). Trả dict đã quét. talk_npc remote OK (server không check k/c)."""
        import json, re
        try:
            mid = (self.rpc.get_player_info() or {}).get('mapId')
        except Exception:
            mid = None
        if town_npc is None:
            town_npc, _ = self._xaphu_npc_for_map(mid)
        BACK = ('quay lại', 'quay về', 'trở lại', 'trở về', 'thoát')

        def _drain_menu(secs):
            """Poll op34 trong `secs`s, trả list option DÀI NHẤT thấy được."""
            best = []
            t0 = time.time()
            while time.time() - t0 < secs:
                for p in (self.poll_recv() or []):
                    if p.get('opcode') == 34:
                        cand = self.parse_npc_menu(p.get('hex', ''))
                        if len(cand) > len(best):
                            best = cand
                time.sleep(0.15)
            return best

        def _is_top_menu(opts):
            head = ' '.join(opts[:5]).lower()
            return ('luyện công' in head) or ('thôn trấn' in head)

        found = {}
        for cat in (cats or range(1, 14)):
            opts = []
            for attempt in range(3):
                try:
                    self.clear_buffer(); self.talk_npc(town_npc)
                    _drain_menu(2.0)                       # đợi TOP menu mở
                    self.clear_buffer(); self.send_gs('eNpcSelect', selectIndex=cat)
                    cand = _drain_menu(wait)               # danh sách điểm đến của nhóm
                    if len(cand) > 1 and not _is_top_menu(cand):
                        opts = cand; break                 # đúng list điểm đến
                    time.sleep(0.5)
                except Exception as e:
                    print(f'[xaphu-scan] cat {cat} thử {attempt} lỗi: {e}')
            if len(opts) < 2:
                print(f'[xaphu-scan] cat {cat} ({self.XAPHU_TIERS.get(cat)}): KHÔNG đọc được list')
                continue
            # opts[0] = câu hỏi; điểm đến = các option sau, dừng khi gặp nút 'Quay lại'
            dest = []
            for s in opts[1:]:
                if any(bk in s.lower() for bk in BACK):
                    break
                dest.append(s)
            for idx, name in enumerate(dest):
                clean = re.sub(r'\s*\[\d+\]\s*$', '', name).strip()   # bỏ đuôi cost ' [100]'
                if clean:
                    found[self._norm_map(clean)] = {'name': clean, 'seq': [cat, idx],
                                                    'tier': self.XAPHU_TIERS.get(cat, str(cat))}
            print(f'[xaphu-scan] cat {cat} ({self.XAPHU_TIERS.get(cat)}): {len(dest)} điểm đến')
            time.sleep(0.3)
        if save and found:
            cfg = self._load_xaphu_routes() or {}
            cfg.setdefault('routes', {})
            cfg['routes'].update(found)        # GHI ĐÈ/bổ sung theo tên thật từ menu (chuẩn nhất)
            try:
                json.dump(cfg, open(self.XAPHU_ROUTES_PATH, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
                print(f'[xaphu-scan] đã lưu {len(found)} route vào {self.XAPHU_ROUTES_PATH}')
            except Exception as e:
                print(f'[xaphu-scan] lưu lỗi: {e}')
        return found

    def xaphu_route_for(self, target_map):
        """Tra (cat, idx) cho tên map đích. Khớp chuẩn-hoá; trả (cat,idx,route_name) hoặc None."""
        cfg = self._load_xaphu_routes()
        routes = cfg.get("routes", {})
        tgt = self._norm_map(target_map)
        if not tgt:
            return None
        # 0) ALIAS: tên NV ≠ tên trong menu Xa Phu (vd 'Mật Đạo Nha Môn' = 'Mật Đạo Tương Dương' vào từ Nha Môn
        #    thành Tương Dương). Map alias -> tên menu thật rồi tra như thường.
        ali = (cfg.get("aliases") or {}).get(tgt)
        if ali:
            tgt = self._norm_map(ali)
        # 1) KHỚP CHÍNH XÁC trước (tránh 'sa mạc 1' dính 'sa mạc 11').
        for key, r in routes.items():
            if self._norm_map(r.get("name", key)) == tgt:
                seq = r.get("seq") or []
                if len(seq) == 2:
                    return (seq[0], seq[1], r.get("name"))
        # 2) Substring có ranh giới (tgt là cụm con đầy đủ của route hoặc ngược lại, kèm space/biên).
        for key, r in routes.items():
            rn = self._norm_map(r.get("name", key))
            if rn and ((tgt + ' ') in (rn + ' ') and tgt.split()[0] == rn.split()[0]):
                seq = r.get("seq") or []
                if len(seq) == 2:
                    return (seq[0], seq[1], r.get("name"))
        # 3) TOKEN-SUBSET: tên NV có thể thừa chữ (vd 'Trường Bạch SƠN Bắc' vs route 'Trường Bạch Bắc').
        #    Khớp route mà MỌI token của route đều có trong target; chọn route khớp NHIỀU token nhất (cụ thể nhất).
        tgt_tokens = set(tgt.split())
        best = None; best_n = 0
        for key, r in routes.items():
            rtoks = [t for t in self._norm_map(r.get("name", key)).split() if t]
            if rtoks and all(t in tgt_tokens for t in rtoks) and len(rtoks) > best_n:
                seq = r.get("seq") or []
                if len(seq) == 2:
                    best = (seq[0], seq[1], r.get("name")); best_n = len(rtoks)
        return best

    XAPHU_TOWN_NPC_PATH = "data/output/xaphu_town_npc.json"

    def _xaphu_npc_for_map(self, mid):
        """Xa Phu npcId CỦA THÀNH đang đứng (Xa Phu KHÔNG remote xuyên thành — verified 2026-06-09:
        BK=1386, TĐ... khác; menu/route seq DÙNG CHUNG, chỉ npcId khác). Đọc xaphu_town_npc.json[mapId].
        Fallback: node vừa HỌC khi click tay (≤180s) -> 1222 (Tương Dương)."""
        import json
        try:
            cfg = json.load(open(self.XAPHU_TOWN_NPC_PATH, encoding="utf-8"))
            v = cfg.get(str(mid))
            if v:
                return str(v), True
        except Exception:
            pass
        # ĐANG Ở ĐỘNG (mid không phải thành) → tra Xa Phu npc của THÀNH cùng VÙNG (remote same-region gọi được
        # từ động). map→thành suy từ datau-node đã học. → Xa Phu chạy NGAY từ động, khỏi recall về thành.
        try:
            from core import map_region as _MR
            rnpc = _MR.npc_for_map(mid, "xaphu")
            if rnpc:
                return str(rnpc), True
        except Exception:
            pass
        # chưa có trong config: thử node Xa Phu vừa click tay (nếu user vừa học), else mặc định Tương Dương
        try:
            nid = getattr(self, 'last_npc_dialogue_id', None)
            nt = getattr(self, 'last_npc_dialogue_t', 0)
            if nid and (time.time() - nt) <= 180:
                return str(nid), False
        except Exception:
            pass
        return "1222", False

    # 7 Xa Phu npc THÀNH đã biết (PT/TĐ/DC/BK/TĐ.../ĐạiLý/LâmAn) — dùng để DÒ same-region từ động.
    _XAPHU_NPC_CANDIDATES = ["879", "1222", "1312", "1386", "1058", "4159", "3363"]

    def _all_known_xaphu_npcs(self):
        """Mọi Xa Phu npc đã biết = 7 thành mặc định ∪ giá trị trong xaphu_town_npc.json (học thêm)."""
        import json
        cands = list(self._XAPHU_NPC_CANDIDATES)
        try:
            cfg = json.load(open(self.XAPHU_TOWN_NPC_PATH, encoding="utf-8"))
            for k, v in cfg.items():
                if k.startswith("_"):          # bỏ "_note" (meta) — KHÔNG phải npcId
                    continue
                if str(v).isdigit() and str(v) not in cands:   # chỉ lấy npcId là SỐ
                    cands.append(str(v))
        except Exception:
            pass
        return cands

    def _probe_working_xaphu_npc(self, mid=None, timeout=1.3):
        """DÒ npc Xa Phu nào MỞ được menu từ vị trí hiện tại (remote same-region: chỉ npc CÙNG VÙNG trả
        lời, vùng khác server bỏ qua → timeout). Trả npcId mở được, hoặc None. Cache theo mid (in-memory)."""
        if not hasattr(self, '_xaphu_probe_cache'):
            self._xaphu_probe_cache = {}
        if mid is not None and str(mid) in self._xaphu_probe_cache:
            return self._xaphu_probe_cache[str(mid)]
        MENU_OPS = (34, 124, 166, 167)
        found = None
        for npc in self._all_known_xaphu_npcs():
            try:
                self.recv_buffer = []
            except Exception:
                pass
            self.talk_npc(npc)
            if self.wait_for_packet(MENU_OPS, timeout=timeout):
                found = npc
                print(f'[xaphu] 🔎 dò ra npc Xa Phu {npc} MỞ menu từ map {mid} (same-region).')
                break
        if found and mid is not None:
            self._xaphu_probe_cache[str(mid)] = found
        return found

    def xaphu_travel(self, target_map, town_npc=None, wait=3.5, attempts=3):
        """Đi tới map NV bằng XA PHU (thay THP, KHÔNG tốn item).
        talk_npc(town_npc) -> eNpcSelect(cat) -> eNpcSelect(idx). Trả True nếu mapId ĐỔI sau khi đi.

        XA PHU KHÔNG REMOTE XUYÊN THÀNH (verified): npcId KHÁC theo thành (BK=1386, TĐ=1222...), nhưng
        menu/route seq DÙNG CHUNG. town_npc=None -> tự tra npcId của THÀNH ĐANG ĐỨNG (xaphu_town_npc.json).

        RETRY cả chuỗi + timeout rộng (3.5s): dưới tải nhiều cửa sổ menu hay về SAU timeout (flaky) y hệt
        node Dã Tẩu → thử lại trước khi báo fail."""
        route = self.xaphu_route_for(target_map)
        if not route:
            # THIẾU route -> QUÉT menu Xa Phu tự bổ sung (fix B) rồi thử lại. Khắc phục triệt để 'đi không tới'
            # (Mật Đạo Nha Môn, Tương Dương, Đêm Huy Hoàng...) mà KHÔNG cần bảng tĩnh đầy đủ.
            print(f'[xaphu] chưa có route "{target_map}" -> quét menu Xa Phu bổ sung...')
            try:
                self.xaphu_scan_routes(town_npc=town_npc)
            except Exception as e:
                print(f'[xaphu] quét lỗi: {e}')
            route = self.xaphu_route_for(target_map)
        if not route:
            print(f'[xaphu] KHÔNG tìm thấy "{target_map}" trong menu Xa Phu (kể cả sau khi quét).')
            return False
        cat, idx, rname = route
        try:
            mid_before = (self.rpc.get_player_info() or {}).get('mapId')
        except Exception:
            mid_before = None
        if town_npc is None:
            town_npc, known = self._xaphu_npc_for_map(mid_before)
            if not known:
                # CHƯA chắc npc (vd động vùng ngoài bảng 7 thành: Ba Lăng / Long Môn / Nha Môn / Lâm An sót)
                # → DÒ 7 npc xem cái nào mở menu = đúng vùng, region-agnostic, tự lành ca ghi nhầm node.
                probed = self._probe_working_xaphu_npc(mid=mid_before)
                if probed:
                    town_npc, known = probed, True
                else:
                    print(f'[xaphu] ⚠️ CHƯA biết Xa Phu npcId của map={mid_before} (dò 7 npc đều không mở) '
                          f'-> dùng {town_npc} (vùng lạ — học id Xa Phu vùng này, vd Ba Lăng).')
        print(f'[xaphu] "{target_map}" -> {rname} seq=[{cat},{idx}] (npc {town_npc} @ map {mid_before}); map trước={mid_before}')
        logger.info(f"[xaphu] đi '{target_map}' → route '{rname}' seq=[{cat},{idx}] (npc {town_npc}), map trước={mid_before}")
        MENU_OPS = (34, 124, 166, 167)
        for att in range(attempts):
            self.talk_npc(town_npc)
            r1 = self.wait_for_packet(MENU_OPS, timeout=wait)
            if not r1:
                print(f'[xaphu] lần {att+1}/{attempts}: menu Xa Phu CHƯA phản hồi (flaky/tải?) — thử lại.')
                time.sleep(0.5)
                continue
            # menu đã mở -> chọn nhóm (cat) rồi điểm đến (idx)
            self.send_gs('eNpcSelect', selectIndex=cat)
            self.wait_for_packet(MENU_OPS, timeout=wait)
            self.send_gs('eNpcSelect', selectIndex=idx)
            time.sleep(2.5)
            try:
                mid_after = (self.rpc.get_player_info() or {}).get('mapId')
            except Exception:
                mid_after = None
            if mid_after is not None and mid_after != mid_before:
                print(f'[xaphu] map sau={mid_after} -> ĐÃ DI CHUYỂN (lần {att+1}).')
                logger.info(f"[xaphu] '{target_map}' seq=[{cat},{idx}] → map SAU={mid_after} (di chuyển OK).")
                return True
            print(f'[xaphu] lần {att+1}/{attempts}: menu mở nhưng map sau={mid_after} chưa đổi — thử lại.')
            time.sleep(0.5)
        # Hết attempts với npc hiện tại → có thể npc SAI VÙNG (menu không mở suốt). DÒ npc đúng vùng rồi
        # thử 1 lần nữa (chỉ khi chưa dò) — tự lành ca _xaphu_npc_for_map đoán nhầm.
        if not getattr(self, '_xaphu_probe_cache', {}).get(str(mid_before)):
            probed = self._probe_working_xaphu_npc(mid=mid_before)
            if probed and probed != town_npc:
                print(f'[xaphu] thử lại với npc dò được {probed} (thay {town_npc}).')
                self.talk_npc(probed)
                if self.wait_for_packet(MENU_OPS, timeout=wait):
                    self.send_gs('eNpcSelect', selectIndex=cat)
                    self.wait_for_packet(MENU_OPS, timeout=wait)
                    self.send_gs('eNpcSelect', selectIndex=idx)
                    time.sleep(2.5)
                    try:
                        mid_after = (self.rpc.get_player_info() or {}).get('mapId')
                    except Exception:
                        mid_after = None
                    if mid_after is not None and mid_after != mid_before:
                        print(f'[xaphu] map sau={mid_after} -> ĐÃ DI CHUYỂN (npc dò {probed}).')
                        return True
        print(f'[xaphu] {attempts} lần đều KHÔNG đổi map (ĐÃ loại flaky + đã dò npc vùng). Nghi: vùng lạ chưa '
              f'có Xa Phu npc (vd Ba Lăng) HOẶC route/npc thành này khác → cần học per-thành.')
        return False

    def _invalidate_player_main(self):
        """Xoá cache instance PlayerMain (gọi NGAY SAU khi ĐỔI MAP/teleport) → walk_to lần sau lấy instance
        HIỆN TẠI (qua static PlayerMain.instance), tránh invoke GotoFindingPath vào object cũ = không di chuyển."""
        try:
            self.rpc.invalidate_player_main()
        except Exception:
            pass

    def xaphu_to_city_by_name(self, city, wait=3.5, attempts=3):
        """ĐI THÀNH↔THÀNH bằng Xa Phu — chọn theo TÊN trong submenu 'Thành Thị' (ĐỌC LIVE), KHÔNG dùng index
        cứng. LÝ DO: submenu Thành Thị LOẠI thành đang đứng → index điểm đến DỊCH theo thành nguồn (vd từ Biện
        Kinh, eNpcSelect(4)=Dương Châu chứ không phải Tương Dương). Phải dò index theo tên mỗi lần.
        Mapping: eNpcSelect(N) ↔ option parse-index (N+1) (option [0]=câu hỏi không chọn được)."""
        import re
        self.last_xaphu_no_money = False   # cờ: lần Xa Phu này thất bại do THIẾU TIỀN (chọn đúng nhưng map ko đổi)
        target = self._norm_map(city)
        if not target:
            return False
        try:
            mid_before = (self.rpc.get_player_info() or {}).get('mapId')
        except Exception:
            mid_before = None
        npc, _ = self._xaphu_npc_for_map(mid_before)

        def _drain(secs):
            best = []
            t0 = time.time()
            while time.time() - t0 < secs:
                for p in (self.poll_recv() or []):
                    if p.get('opcode') == 34:
                        c = self.parse_npc_menu(p.get('hex', ''))
                        if len(c) > len(best):
                            best = c
                time.sleep(0.15)
            return best

        KNOWN = {self._norm_map(c) for c in self._XAPHU_FIELD_CITY_IDX}     # 7 thành đã biết (verify submenu)
        attempts = max(attempts, 4)
        sel = None; matched = None; cost = None   # init Ở NGOÀI vòng: nếu mọi attempt fail trước khi match thành
                                                  # (menu chưa sẵn/không thấy thành), 'if cost' cuối hàm KHÔNG crash.
        for att in range(attempts):
            self.clear_buffer(); self.poll_recv()                           # flush gói residual (tránh menu cũ)
            self.talk_npc(npc)
            top = _drain(max(2.0, wait))
            # VERIFY mở đúng TOP menu (có 'Thành Thị') — tránh chọn nhầm trên menu cũ/residual khi nhảy liên tiếp.
            if not top:
                probed = self._probe_working_xaphu_npc(mid=mid_before)
                if probed and probed != npc:
                    npc = probed
                time.sleep(0.5); continue
            if not any('thành thị' in o.lower() for o in top):
                # menu KHÔNG phải top (dialog residual) → đóng rồi thử lại.
                try: self.send_gs('eNpcSelect')
                except Exception: pass
                time.sleep(0.6); continue
            self.clear_buffer(); self.send_gs('eNpcSelect', selectIndex=1)   # 1 = 'Thành Thị' (mở list thành)
            opts = _drain(wait)
            # VERIFY đây LÀ list thành (có ≥1 thành đã biết) — nếu không, menu chưa sẵn → thử lại (không chọn mù).
            if not any(self._norm_map(re.sub(r'\s*\[\d+\]\s*$', '', o).strip()) in KNOWN for o in opts):
                print(f'[xaphu-city] submenu chưa phải list thành (opts={opts[:4]}…) — thử lại.')
                time.sleep(0.6); continue
            sel = None; matched = None; cost = None
            for pi, name in enumerate(opts):
                clean = re.sub(r'\s*\[\d+\]\s*$', '', name).strip()          # bỏ đuôi cost ' [300]'
                if self._norm_map(clean) == target:
                    mcost = re.search(r'\[(\d+)\]', name)
                    cost = int(mcost.group(1)) if mcost else None
                    sel = pi - 1; matched = clean; break                     # eNpcSelect = parse-index - 1
            if sel is None or sel < 0:
                print(f'[xaphu-city] KHÔNG thấy "{city}" trong submenu Thành Thị (opts={opts}) — thử lại.')
                time.sleep(0.5); continue
            print(f'[xaphu-city] "{city}" = option[{sel+1}] "{matched}" → eNpcSelect({sel}) (map trước={mid_before}).')
            logger.info(f"[xaphu-city] đi '{city}' → option '{matched}' eNpcSelect({sel}) (đọc-live), map trước={mid_before}")
            self.send_gs('eNpcSelect', selectIndex=sel); time.sleep(2.5)
            try:
                mid_after = (self.rpc.get_player_info() or {}).get('mapId')
            except Exception:
                mid_after = None
            if mid_after is not None and mid_after != mid_before:
                print(f'[xaphu-city] "{city}" OK: map {mid_before} -> {mid_after} (lần {att+1}).')
                logger.info(f"[xaphu-city] '{city}' → map SAU={mid_after} (di chuyển OK).")
                self._invalidate_player_main()   # đổi map → instance cũ stale → ép re-resolve cho walk_to sau
                return True
            print(f'[xaphu-city] lần {att+1}: map chưa đổi (={mid_after}) — thử lại.')
            time.sleep(0.5)
        # Chọn đúng option mà map KHÔNG đổi sau nhiều lần → gần như chắc THIẾU TIỀN Xa Phu (phí {cost}/lần).
        if cost:
            logger.info(f"[xaphu-city] '{city}' chọn ĐÚNG (eNpcSelect {sel}) nhưng KHÔNG dịch chuyển sau {attempts} lần "
                        f"→ NGHI THIẾU TIỀN Xa Phu (phí {cost} lượng).")
            self.last_xaphu_no_money = True    # broke: chọn đúng option nhưng map ko đổi = hết tiền Xa Phu
        return False

    # Thứ tự THÀNH trong menu Xa Phu FIELD (dest-index, 0-based sau câu hỏi) — verify live 2026-06-13 từ động.
    _XAPHU_FIELD_CITY_IDX = {"Phượng Tường": 0, "Thành Đô": 1, "Đại Lý": 2, "Biện Kinh": 3,
                             "Tương Dương": 4, "Dương Châu": 5, "Lâm An": 6}

    def xaphu_recall_to_city(self, city="Biện Kinh", wait=3.0, attempts=3):
        """VỀ THÀNH TỪ ĐỘNG bằng Xa Phu (menu FIELD — KHÁC Xa Phu thành↔thành). Verify live 2026-06-13:
        từ động, talk_npc(Xa Phu vùng) -> eNpcSelect(0) ra THẲNG list 7 thành -> eNpcSelect(dest-index thành).
        (Route thành [1,3] SAI ở động: eNpcSelect(1) ra submenu lồng 'Khu vực Thành Thị'.) Trả True nếu mapId đổi."""
        cfg = self._load_xaphu_routes() or {}
        idx = (cfg.get("cities_field_idx") or {}).get(city)
        if idx is None:
            idx = self._XAPHU_FIELD_CITY_IDX.get(city)
        if idx is None:
            print(f'[xaphu-recall] không biết dest-index của thành "{city}".')
            return False
        try:
            mid_before = (self.rpc.get_player_info() or {}).get('mapId')
        except Exception:
            mid_before = None
        npc, _ = self._xaphu_npc_for_map(mid_before)
        MENU_OPS = (34, 124, 166, 167)
        for att in range(attempts):
            self.clear_buffer()
            self.talk_npc(npc)
            if not self.wait_for_packet(MENU_OPS, timeout=wait):
                probed = self._probe_working_xaphu_npc(mid=mid_before)
                if probed and probed != npc:
                    npc = probed
                    self.clear_buffer(); self.talk_npc(npc); self.wait_for_packet(MENU_OPS, timeout=wait)
                else:
                    time.sleep(0.5); continue
            self.send_gs('eNpcSelect', selectIndex=0)        # 0 = ra list 7 thành (menu field)
            self.wait_for_packet(MENU_OPS, timeout=wait)
            self.send_gs('eNpcSelect', selectIndex=int(idx)) # dest-index của thành
            time.sleep(2.5)
            try:
                mid_after = (self.rpc.get_player_info() or {}).get('mapId')
            except Exception:
                mid_after = None
            if mid_after is not None and mid_after != mid_before:
                print(f'[xaphu-recall] "{city}" (idx {idx}) OK: map {mid_before} -> {mid_after} (lần {att+1}).')
                return True
            print(f'[xaphu-recall] lần {att+1}/{attempts}: map chưa đổi (={mid_after}) — thử lại.')
            time.sleep(0.5)
        return False

    # ==================== THỔ ĐỊA PHÙ (bay về thành, thay THP về) ====================
    TDP_CFG_PATH = "data/output/tdp_buy_config.json"

    def buy_tdp(self, qty=None):
        """Mua Thổ Địa Phù từ Tạp Hóa (config tdp_buy_config.json) -> vào TÚI để recall.
        Mua remote theo shopkey (ở THÀNH, không phải khu chiến đấu). Trả số lượng đang có trong túi sau mua."""
        import json
        try:
            cfg = json.load(open(self.TDP_CFG_PATH, encoding="utf-8"))
        except Exception:
            print('[tdp] CHƯA có config mua TDP (tdp_buy_config.json).')
            return 0
        shopkey = cfg.get("shopkey"); idx = cfg.get("itemindex")
        n = int(qty if qty is not None else cfg.get("qty", 4))
        if not shopkey or idx is None:
            return 0
        have = self.count_tdp_in_bag()
        if have >= n:
            print(f'[tdp] đã có {have} TDP trong túi (>= {n}), khỏi mua.')
            return have
        need = n - have
        try:
            mid = (self.rpc.get_player_info() or {}).get('mapId')
        except Exception:
            mid = None
        print(f'[tdp] mua {need} TDP ({shopkey} idx {idx}); map hiện tại={mid}; có {have} sẵn.')
        # PHẢI MỞ SHOP TRƯỚC: list item (vd idx 1 = TDP) chỉ tồn tại trong PHIÊN shop server đã mở; mua
        # khi shop CHƯA mở -> server BỎ QUA (đã thấy: buy không có gói item trả về). Mở qua context đã học
        # (open_shop_remote: eStringData toạ độ + eOpenShop). KHÔNG phải 'đúng thành' — chỉ là LẬP PHIÊN shop.
        import binascii
        try:
            from core import npc_shop
            ctx = npc_shop.load_shop_context(shopkey)
            if ctx:
                self.open_shop_remote(ctx)
            else:
                self.open_shop_read()
            time.sleep(1.0)
        except Exception as e:
            print(f'[tdp] mở shop lỗi: {e}')
        def _bag_slots():
            try:
                d = self.dump_bag_items()
                return [it for it in (d.get('items', []) if d and d.get('ok') else []) if it.get('location') == 2]
            except Exception:
                return []
        nbag0 = len(_bag_slots())
        for attempt in range(3):
            cur = self.count_tdp_in_bag()
            if cur >= n:
                break
            want = n - cur
            if hasattr(self, 'recv_buffer'):
                self.recv_buffer = []
            try:
                pkt = self._build_shop_buy_packet(shopkey, int(idx), want)   # 1 gói, qty=want (mua LÔ)
                print(f'[tdp] mua LÔ qty={want} (lần {attempt+1}): {binascii.hexlify(pkt).decode()}')
                self.send_raw(pkt)
            except Exception as e:
                print(f'[tdp] mua lỗi: {e}'); break
            time.sleep(1.8)
            # bắt phản hồi server (16=thêm item / 133/247 báo) -> biết server NHẬN hay BỎ QUA
            resp = []
            t0 = time.time()
            while time.time() - t0 < 1.0:
                for p in (self.poll_recv() or []):
                    op = p.get('opcode')
                    if op in (16, 247, 149, 6): resp.append(op)
                time.sleep(0.1)
            print(f'[tdp]   lần {attempt+1} resp(16/247/...): {resp}')
        after = self.count_tdp_in_bag()
        nbag = len(_bag_slots())
        print(f'[tdp] sau mua: {after} TDP (trước {have}) | túi {nbag} món (trước {nbag0}) — nghi ĐẦY nếu ~24+.')
        return after

    @staticmethod
    def _decode_text_packet(hx):
        """Rút text UTF-8 đọc được từ hex gói (để soi thông báo lỗi mua: 'túi đầy' / 'thiếu bạc'...)."""
        try:
            b = bytes.fromhex(hx)
            out = []
            cur = bytearray()
            for ch in b:
                if 32 <= ch < 127 or ch >= 0xC0 or (0x80 <= ch < 0xC0 and cur):
                    cur.append(ch)
                else:
                    if len(cur) >= 3:
                        try: out.append(cur.decode('utf-8', 'ignore'))
                        except Exception: pass
                    cur = bytearray()
            if len(cur) >= 3:
                try: out.append(cur.decode('utf-8', 'ignore'))
                except Exception: pass
            return ' | '.join(s for s in out if s.strip())[:100]
        except Exception:
            return ''

    def _tdp_particular(self):
        import json
        try:
            return int(json.load(open(self.TDP_CFG_PATH, encoding="utf-8")).get("particular", 9))
        except Exception:
            return 9

    def count_tdp_in_bag(self):
        """Đếm TDP trong TÚI (location==2). TDP particular = file id (mặc định 9)."""
        p = self._tdp_particular()
        try:
            d = self.dump_bag_items()
            if d and d.get("ok"):
                return sum((it.get("stack", 1) or 1) for it in d.get("items", [])
                           if it.get("genre") == 6 and it.get("detail") == 1
                           and it.get("particular") == p and it.get("location") == 2)
        except Exception:
            pass
        return 0

    def find_tdp_slot(self):
        """Trả slot TDP trong TÚI (location==2) để use_item, hoặc None."""
        p = self._tdp_particular()
        try:
            d = self.dump_bag_items()
            for it in (d.get("items", []) if d and d.get("ok") else []):
                if (it.get("genre") == 6 and it.get("detail") == 1 and it.get("particular") == p
                        and it.get("location") == 2 and isinstance(it.get("slot"), int)):
                    return it.get("slot")
        except Exception:
            pass
        return None

    def tho_dia_phu_recall(self):
        """Dùng Thổ Địa Phù (trong TÚI) bay về thành. Trả True nếu mapId ĐỔI (đã về)."""
        slot = self.find_tdp_slot()
        if slot is None:
            print('[tdp] KHÔNG có TDP trong túi (cần mua ở Tạp Hóa trước).')
            return False
        try:
            mid0 = (self.rpc.get_player_info() or {}).get('mapId')
        except Exception:
            mid0 = None
        print(f'[tdp] dùng TDP ô {slot} (map trước={mid0})...')
        self.use_item(slot)
        # Recall có animation/loading -> map đổi CHẬM. Poll tới ~14s (đừng check 1 lần 4s rồi báo fail oan).
        mid1 = mid0
        t0 = time.time()
        while time.time() - t0 < 14:
            time.sleep(2.0)
            try:
                mid1 = (self.rpc.get_player_info() or {}).get('mapId')
            except Exception:
                mid1 = None
            if mid1 is not None and mid1 != mid0:
                break
        ok = (mid1 is not None and mid1 != mid0)
        print(f'[tdp] map sau={mid1} -> {"ĐÃ VỀ THÀNH" if ok else "KHÔNG đổi (động chặn TDP? hết hiệu lực?)"}')
        return ok

    def trainoff_check(self, autoplay_is_open: bool = True):
        """HỎI server: có được treo offline (train off) tại chỗ này không? (opcode 136)
        Server đáp eTrainoffCheckResponse(137) {description, enterAllowed, enterLabel, autoplayAllowed}."""
        print(f'[>] trainoff_check(autoplayIsOpen={autoplay_is_open})')
        return self.send_gs('eTrainoffCheckRequet', autoplayIsOpen=autoplay_is_open)

    def trainoff_start(self, profile: str = None):
        """BẮT ĐẦU treo offline với profile (opcode 138). CẨN THẬN: có thể chuyển nhân vật sang chế độ treo.
        ⚠️ GUARD WIPE: KHÔNG gửi eTrainoffStart với autoplayProfile RỖNG — đây là vector WIPE profile y như
        eApplyAutoplayProfile rỗng (account mới/chưa có profile chạy flow luyện công → trainoff_start('') → server
        ghi profile rỗng = mất profile). Không có guid hợp lệ → SKIP (trainoff không có profile cũng vô nghĩa)."""
        profile = (profile or '').strip('"') or (self.last_autoplay or {}).get('profile', '') or self._autoplay_guid()
        if not profile:
            print('[!] trainoff_start: KHÔNG có guid profile → SKIP (tránh WIPE profile bằng autoplayProfile rỗng).')
            return False
        print(f'[>] trainoff_start(profile={profile!r})')
        return self.send_gs('eTrainoffStart', autoplayProfile=profile)

    def move_to(self, x: int, y: int):
        """Di chuyển đến tọa độ 5 số (world coords).
        
        Dùng eGotoPosition (opcode 248) với fields mapx, mapy.
        Lưu ý: x, y là tọa độ WORLD (5 số), không phải game (3 số).
        Để di chuyển bằng tọa độ 3 số, dùng move_to_game().
        """
        print(f'[>] Move to world ({x}, {y})')
        return self.send_gs('eGotoPosition', mapx=x, mapy=y)

    # ==================== PLAYER TRADE (giao dịch người chơi, opcode 150-165) ====================
    # Flow: invite(150){cid} -> [server gửi 151 tới đối phương] -> accept(152){cid} -> start(153 cả 2 bên)
    #       -> add item(154){itemid} / cash(160){cash} -> lock(164 cả 2) -> confirm(165 cả 2) -> server swap.
    #       cancel=163 (trả đồ về). ⚠️ Trade CÓ check khoảng cách -> 2 nhân vật phải đứng CẠNH nhau (khu thành).
    def trade_invite(self, cid):
        """Gửi lời mời giao dịch tới player `cid` (eTradeInviteToGsv 150)."""
        return self.send_gs('eTradeInviteToGsv', cid=str(cid))

    def trade_accept(self, cid):
        """Chấp nhận lời mời giao dịch từ `cid` (eTradeInviteAccept 152)."""
        return self.send_gs('eTradeInviteAccept', cid=str(cid))

    def trade_add_item(self, itemid):
        """Thêm 1 item (theo field `identify` từ dump_bag_items) vào ô trade (eTradeProcessSendItemToGsv 154)."""
        return self.send_gs('eTradeProcessSendItemToGsv', itemid=int(itemid))

    def trade_remove_item(self, itemid):
        """Rút 1 item khỏi ô trade (eTradeProcessSendItemToRemove 155)."""
        return self.send_gs('eTradeProcessSendItemToRemove', itemid=int(itemid))

    def trade_add_cash(self, cash):
        """Thêm tiền (bạc) vào ô trade (eTradeProcessSendCashToGsv 160). cash = lượng (1 vạn = 10000)."""
        return self.send_gs('eTradeProcessSendCashToGsv', cash=int(cash))

    def trade_lock(self):
        """Khoá ô trade — sẵn sàng (eTradeFinishLock 164, body rỗng)."""
        return self.send_gs('eTradeFinishLock')

    def trade_confirm(self):
        """Xác nhận hoàn tất (eTradeFinishConfirm 165, body rỗng) -> khi CẢ 2 confirm, server swap đồ/tiền."""
        return self.send_gs('eTradeFinishConfirm')

    def trade_cancel(self):
        """Huỷ giao dịch (eTradeFinishCancel 163, body rỗng) -> trả đồ về cả 2 bên (an toàn khi lỗi)."""
        return self.send_gs('eTradeFinishCancel')

    @staticmethod
    def parse_trade_cid(hex_str):
        """Lấy field-1 string (cid) từ body gói 151/153. Body=[u32 len][u16 op][protobuf]; field1: tag 0x0a,len,bytes."""
        return VLTK1Bot.parse_trade_invite(hex_str).get('cid', '')

    @staticmethod
    def parse_trade_invite(hex_str):
        """Parse gói 151 eTradeInviteToCli / 153 eTradeStart -> {cid(f1), name(f2)} để biết AI mời + TÊN họ.
        protobuf: field1 string tag 0x0a, field2 string tag 0x12 (mỗi cái: tag, len-byte, bytes)."""
        out = {'cid': '', 'name': ''}
        try:
            b = bytes.fromhex(hex_str)[6:]   # bỏ 6 byte header
            i = 0
            while i + 1 < len(b):
                tag = b[i]; ln = b[i + 1]
                val = b[i + 2:i + 2 + ln]
                if tag == 0x0a:
                    out['cid'] = val.decode('utf-8', 'ignore')
                elif tag == 0x12:
                    out['name'] = val.decode('utf-8', 'ignore')
                    break   # đủ cid+name
                i += 2 + ln
        except Exception:
            pass
        return out

    def open_shop_read(self, wait: float = 2.5):
        """Gửi eOpenShop (opcode 51, body RỖNG) -> server đẩy shop_data (119/120) -> frida tự
        parse vào features/bot/shop_dict.json. Mở shop của NPC ĐANG tương tác/gần.
        Chờ `wait`s cho parse xong. Không trả gì (đọc shop_dict.json sau khi gọi)."""
        try:
            self.send_raw(struct.pack('<IH', 0, 51))   # len=0, opcode=51, không field
        except Exception as e:
            logger.error(f"[open_shop_read] gửi eOpenShop lỗi: {e}")
            return
        time.sleep(wait)

    def open_shop_remote(self, context_str: str, wait: float = 2.5):
        """Mở shop NPC TỪ XA: gửi eStringData("2|x|y|..") = tương tác NPC tại toạ độ đã học,
        rồi eOpenShop. Server đẩy shop_data -> frida parse vào shop_dict.json. Cần nhân vật
        CÙNG MAP với NPC (toạ độ theo map)."""
        if not context_str:
            return self.open_shop_read(wait)
        try:
            body = context_str.encode('utf-8')
            self.send_raw(struct.pack('<IH', len(body), 9) + body)   # eStringData: set context NPC
            time.sleep(0.4)
            self.send_raw(struct.pack('<IH', 0, 51))                 # eOpenShop
        except Exception as e:
            logger.error(f"[open_shop_remote] lỗi: {e}")
            return
        time.sleep(wait)

    def move_to_game(self, game_x: int, game_y: int):
        """Di chuyển đến tọa độ 3 số (game/minimap coords).
        
        Tự động quy đổi sang world coords (5 số) rồi gửi.
        """
        from core.position import game_to_world_center
        wx, wy = game_to_world_center(game_x, game_y)
        print(f'[>] Move to game ({game_x}, {game_y}) [world: {wx}, {wy}]')
        return self.send_gs('eGotoPosition', mapx=wx, mapy=wy)

    def goto_path_native(self, x: int, y: int):
        print(f'[>] Native GotoFindingPath to ({x}, {y})')
        result = self.rpc.gotopath(x, y)
        print(f'    {result}')
        return result.get('ok', False)

    def walk_to_world(self, world_x: int, world_y: int, approach: int = 90):
        """ĐI BỘ tới toạ độ WORLD (5 số) — invoke PlayerMain.GotoFindingPath TRÊN MAIN THREAD (hook Update).
        ⚠️ VERIFY LIVE 2026-06-10 (bắt từ AUTO game): GotoFindingPath nhận **WORLD coords (5 số)**, approach3d≈90,
        NULL callback VẪN đi (đã thấy minimap 221,198->214,190). get_player_info mapX/mapY ĐÃ là WORLD -> truyền
        thẳng. (Trước đây tưởng nhầm là GAME 3 số -> truyền game = góc gốc bản đồ -> đứng im suốt.)
        GotoFindingPath đi 1 đoạn rồi có thể dừng -> RE-ISSUE cùng đích mỗi ~2s tới khi sát (KHÔNG phải bug stutter
        vì đích world đúng). Trả True nếu lệnh nhận."""
        try:
            r = self.rpc.goto_hooked(int(world_x), int(world_y), int(approach))
            return bool(r and r.get('ok'))
        except Exception as e:
            print(f'[walk_to_world] {e}'); return False

    def walk_to(self, game_x: int, game_y: int, approach: int = 90):
        """ĐI BỘ tới toạ độ GAME/minimap (3 số) — quy về WORLD (*256) rồi walk_to_world.
        VD minimap hiện (213,186) -> walk_to(213,186) -> world (54528,47616)."""
        return self.walk_to_world(int(game_x) * 256, int(game_y) * 256, approach)

    def sort_bag_items(self, wait: float = 0.7) -> int:
        """XẾP CHỒNG/GỘP đồ túi (invoke PlayerSelfBagarate.SortItems trên main thread) — tiết kiệm ô.
        Trả số instance đã sort (0 = bảng túi chưa mở -> không sort được). AN TOÀN (không mất đồ)."""
        try:
            r = self.rpc.sort_bag_items()
        except Exception as e:
            print(f'[sort_bag] {e}'); return 0
        if not (r and r.get('ok')):
            return 0
        time.sleep(wait)
        return int(r.get('found', 0) or 0)

    def close_datau_popups(self, wait: float = 0.7) -> dict:
        """ĐÓNG SẠCH mọi popup Dã Tẩu client (NpcDialogInfiPc/NpcDialogPc/AwardSelection/StandardConfirmPc/
        MessageBox) bằng cách invoke .Close() của CHÍNH CLIENT trên MAIN THREAD (không tap ESC, không chồng).
        Trả {class: số popup đã đóng}. Gọi SAU khi đã gửi gói accept/answer (server đã xử lý xong)."""
        try:
            r = self.rpc.close_datau_popups()
        except Exception as e:
            print(f'[close_popups] {e}'); return {}
        if not (r and r.get('ok')):
            return {}
        time.sleep(wait)   # chờ hook PlayerMain.Update bắn (1 frame trên main thread)
        try:
            res = self.rpc.close_popup_result() or {}
            return (res.get('res') or {}).get('closed', {}) or {}
        except Exception:
            return {}

    def set_riding(self, ride: bool):
        """Mount/dismount horse. Confirmed working via disassembly."""
        print(f'[>] set_riding({ride})')
        # Direct packet build (proven working in test_riding.py)
        proto = b'\x08\x01' if ride else b''
        packet = struct.pack('<IH', len(proto), 58) + proto
        return self.send_raw(packet)

    def adb_tap(self, x: int, y: int):
        """M么 ph峄弉g thao t谩c ch岷 m脿n h矛nh qua ADB"""
        try:
            import subprocess
            adb_cmd = [ADB, '-s', self.device_id, 'shell', 'input', 'tap', str(x), str(y)]
            subprocess.run(adb_cmd, check=True)
            print(f'[+] ADB Tap at ({x}, {y})')
            return True
        except Exception as e:
            print(f'[-] ADB Tap Error: {e}')
            return False

    NPC_MAP_COORDS = {
        "Phượng Tường": {
            "Da Tau": (51836, 49441),  # game coords (map_id=1)
        },
        "Thành Đô": {
            "Da Tau": (100922, 81048),  # game coords (map_id=11)
        },
        "Map_20": {
            "Da Tau": (113218, 99704),  # game coords (map_id=20)
        },
        "Biện Kinh": {
            "Da Tau": (55537, 49611),  # game coords (map_id=37)
        },
        "Ba Lăng Huyện": {
            "Da Tau": (52033, 50761),  # game coords (map_id=53)
        },
        "Dương Châu": {
            "Da Tau": (55812, 47465),  # game coords (map_id=80)
        },
        "Vĩnh Lạc trấn": {
            "Da Tau": (52690, 51080),  # game coords (map_id=99)
        },
        "Chu Tiên trấn": {
            "Da Tau": (51709, 51190),  # game coords (map_id=100)
        },
        "Map_101": {
            "Da Tau": (53697, 50303),  # game coords (map_id=101)
        },
        "Long Môn trấn": {
            "Da Tau": (62705, 72005),  # game coords (map_id=121)
        },
        "Thạch Cổ trấn": {
            "Da Tau": (52580, 51769),  # game coords (map_id=153)
        },
        "Đại Lý phủ": {
            "Da Tau": (52832, 51609),  # game coords (map_id=162)
        },
        "Long Tuyền thôn": {
            "Da Tau": (51464, 51204),  # game coords (map_id=174)
        },
        "Lâm An": {
            "Da Tau": (50006, 47670),  # game coords (map_id=176)
        },
    }

    def go_to_npc_via_map(self, map_name: str, npc_name: str):
        """Navigate to an NPC based on predefined coordinates via GotoFindingPath"""
        coords = self.NPC_MAP_COORDS.get(map_name, {}).get(npc_name)
        if not coords:
            print(f"[-] Không tìm thấy tọa độ {npc_name} tại {map_name} trong NPC_MAP_COORDS!")
            return False
            
        tar_x, tar_y = coords
        print(f"[+] Tìm thấy {npc_name} tại {map_name}: ({tar_x}, {tar_y})")
        return self.goto_path_native(tar_x, tar_y)


    def tap_joystick(self, cur_x: int, cur_y: int, tar_x: int, tar_y: int):
        """T铆nh to谩n h瓢峄沶g 膽i v脿 Click m岷穞 膽岷 (Tap and Hold) 膽峄?nh芒n v岷璽 di chuy峄僴 1 b瓢峄沜"""
        import math
        import subprocess
        # Quy 膽峄昳 vector l瓢峄沬 ra vector m脿n h矛nh (G贸c nh矛n Isometric)
        dx_grid = tar_x - cur_x
        dy_grid = tar_y - cur_y
        
        # VLTK1 Isometric:
        screen_dx = dx_grid - dy_grid
        screen_dy = dx_grid + dy_grid
        
        # Chu岷﹏ h贸a vector
        length = math.sqrt(screen_dx**2 + screen_dy**2)
        if length == 0: return False
        
        # Click m岷穞 膽岷 c谩ch nh芒n v岷璽 (480, 270) m峄檛 kho岷g 80 pixel 膽峄?tr谩nh UI (Chatbox, Skill)
        # Click mặt đất cách nhân vật (480, 270) một khoảng 80 pixel để tránh UI (Chatbox, Skill)
        click_x = 480 + int((screen_dx / length) * 80)
        click_y = 270 + int((screen_dy / length) * 80)
        
        print(f"[Walk] Hướng tới ({tar_x}, {tar_y}) -> Click mặt đất ({click_x}, {click_y})")
        try:
            # Dùng swipe tại chỗ 150ms để mô phỏng ngón tay chạm thật (tránh game coi là auto-click rác)
            adb_cmd = [ADB, '-s', self.device_id, 'shell', 'input', 'swipe', 
                       str(click_x), str(click_y), str(click_x), str(click_y), '150']
            subprocess.run(adb_cmd, check=True)
            return True
        except Exception as e:
            print(f'[-] ADB Tap Ground Error: {e}')
            return False

    def goto_npc(self, npc_name: str):
        print(f'[>] goto_npc: {npc_name}')
        return self.send_gs('eGotoNpc', npcName=[npc_name], data=0)

    def talk_npc(self, npc_id: str):
        """Gửi packet tương tác NPC"""
        print(f'[>] talk_npc: {npc_id}')
        # Đánh dấu CHÍNH BOT vừa gửi node này -> hook send_out KHÔNG tính là 'kích tay' (tránh bot tự dạy
        # nhầm chính nó + ghi đè cú nhấn tay thật của người chơi). Lưu theo npcId + thời điểm.
        self._bot_talk_ids[str(npc_id)] = time.time()
        return self.send_gs('eNpcDialogue', npcId=npc_id)

    # ==================== ACCOUNT ROTATION (login/logout qua method il2cpp) ====================
    def get_login_state(self) -> str:
        """'in_world' | 'at_login' | 'unknown'."""
        try:
            r = self.rpc.get_login_state()
            return r.get('state', 'unknown') if r else 'unknown'
        except Exception:
            return 'unknown'

    def logout(self) -> bool:
        try:
            r = self.rpc.logout_account()
        except Exception as e:
            print(f'[logout] {e}'); return False
        if not (r and r.get('ok')):
            print(f'[logout] fail: {r.get("error") if r else "no res"}')
        return bool(r and r.get('ok'))

    def relaunch_game(self) -> bool:
        """LOGOUT CHẮC CHẮN: force-stop + relaunch game (về màn login) rồi RE-ATTACH Frida.
        (il2cpp logout in-world không khả thi: NetCoreManager.Disconnect tự reconnect account cũ;
        UIManager.BackToLogin không lấy được instance.) Trả True nếu re-attach + thấy màn login."""
        import subprocess
        from core.adb_helper import ADB_PATH, PACKAGE
        dev = self.device_id
        try:
            subprocess.run(f'{ADB_PATH} -s {dev} shell am force-stop {PACKAGE}',
                           shell=True, timeout=20, capture_output=True)
            time.sleep(2)
            subprocess.run(f'{ADB_PATH} -s {dev} shell monkey -p {PACKAGE} '
                           f'-c android.intent.category.LAUNCHER 1',
                           shell=True, timeout=20, capture_output=True)
        except Exception as e:
            print(f'[relaunch] adb lỗi: {e}'); return False
        time.sleep(3)   # game KHÔNG có splash: ~3s là tới màn login. Chưa kịp -> vòng retry dưới tự bắt lại.
        for _ in range(10):
            try:
                if self.connect(fast=True):   # re-attach NHANH (bỏ dò fd ~12.5s — fd dò lại khi vào thế giới)
                    return True
            except Exception as e:
                print(f'[relaunch] connect: {e}')
            time.sleep(2)   # chưa attach được (game chưa sẵn) -> thử lại nhanh
        return False

    def is_game_running(self) -> bool:
        """Game có đang chạy trên device không (pidof PACKAGE). KHÔNG cần Frida."""
        import subprocess
        from core.adb_helper import ADB_PATH, PACKAGE
        try:
            out = subprocess.check_output(f'{ADB_PATH} -s {self.device_id} shell "pidof {PACKAGE}"',
                                          shell=True, timeout=8, stderr=subprocess.DEVNULL).decode().strip()
            return bool(out)
        except Exception:
            return False

    def launch_game(self) -> bool:
        """MỞ game (monkey LAUNCHER) — KHÔNG force-stop (chỉ dùng khi game chưa chạy). Trả True nếu gửi lệnh OK."""
        import subprocess
        from core.adb_helper import ADB_PATH, PACKAGE
        try:
            subprocess.run(f'{ADB_PATH} -s {self.device_id} shell monkey -p {PACKAGE} '
                           f'-c android.intent.category.LAUNCHER 1',
                           shell=True, timeout=20, capture_output=True)
            return True
        except Exception as e:
            print(f'[launch_game] {e}'); return False

    def login(self, acc: str, password: str) -> bool:
        try:
            r = self.rpc.login_account(acc, password)
        except Exception as e:
            print(f'[login] {e}'); self.last_login_result = {'ok': False, 'error': str(e)}; return False
        self.last_login_result = r or {'ok': False, 'error': 'no res'}   # LƯU để báo LÝ DO khi fail (no popup / không ở màn login)
        if not (r and r.get('ok')):
            print(f'[login] fail: {r.get("error") if r else "no res"}')
        return bool(r and r.get('ok'))

    def login_screen_message(self) -> str:
        """Text đang hiện trên màn LOGIN (popup từ chối của server…). '' nếu không đọc được. Để báo LÝ DO login fail."""
        try:
            r = self.rpc.login_screen_message() or {}
            txts = [t for t in (r.get('texts') or []) if t]
            return " | ".join(dict.fromkeys(txts))[:300]   # gộp, bỏ trùng
        except Exception:
            return ""

    def enter_world(self) -> bool:
        try:
            r = self.rpc.enter_world(); return bool(r and r.get('ok'))
        except Exception:
            return False

    def at_create_screen(self) -> bool:
        """True nếu ĐANG ở màn TẠO NHÂN VẬT (createNameInputTmp != null)."""
        try:
            r = self.rpc.create_char_probe()
            return bool(r and r.get('ok') and not r.get('inputNull'))
        except Exception:
            return False

    def create_character(self, name: str) -> bool:
        """TẠO nhân vật bằng INVOKE (set tên + UIManager.CreateCharacter()). Game tự mã hoá data đúng session.
        'breakpoint triggered' = artifact bridge SAU khi method chạy -> setOk=true coi như đã gửi tạo."""
        try:
            r = self.rpc.create_char_invoke(name)
        except Exception as e:
            print(f'[create] {e}'); return False
        ok = bool(r and r.get('setOk'))
        print(f'[create] invoke name={name!r} -> {r}')
        return ok

    BACH_CAU_HOAN_PARTICULARS = (91, 92)   # 91=tiểu(+24h trainoff), 92=đại(+30 ngày)

    def equip_bag_gear(self) -> int:
        """TRANG BỊ đồ trong túi: use_item trên item KHÔNG phải tiêu hao (genre != 6) -> mặc vũ khí/giáp.
        Char mới lvl1 có vũ khí starter (cây chuỳ) trong túi nhưng CHƯA mặc -> auto không đánh được. Trả số đã mặc."""
        n = 0
        try:
            for attempt in range(3):   # RETRY: char mới spawn -> equip lần đầu hay chưa ăn; lặp tới khi hết đồ ở túi
                r = self.dump_bag_items() or {}
                items = r.get('items') if isinstance(r, dict) else r
                todo = [it for it in (items or [])
                        if it.get('genre') != 6 and it.get('location') == 2]   # CÒN trong túi (chưa mặc)
                if not todo:
                    break   # tất cả trang bị đã ở location != 2 (đã mặc)
                for it in todo:
                    idx = it.get('index') or it.get('slot')
                    # EQUIP = eAutoEquip{itemId, isEquip} (verify live: double-tap vũ khí -> op24{itemId,1}).
                    self.send_gs('eAutoEquip', itemId=int(idx), isEquip=True)
                    n += 1; time.sleep(0.5)
                time.sleep(1.2)   # chờ server áp + dump lại kiểm
        except Exception as e:
            print(f'[equip] {e}')
        return n

    def use_items_by_particular(self, particulars, max_each=1) -> list:
        """Dùng item trong túi theo PARTICULAR (file id). particulars = set/list id (vd {3}=Tiên Thảo Lộ).
        Dùng tối đa max_each cái mỗi loại. Trả list particular đã dùng. (genre6 detail1 location2.)"""
        used = []
        try:
            r = self.dump_bag_items() or {}
            items = r.get('items') if isinstance(r, dict) else r
            want = set(int(p) for p in particulars)
            cnt = {}
            for it in (items or []):
                p = it.get('particular')
                if (it.get('genre') == 6 and it.get('detail') == 1 and p in want
                        and it.get('location') == 2 and cnt.get(p, 0) < max_each):
                    idx = it.get('index') or it.get('slot')
                    self.use_item(int(idx))
                    used.append(p); cnt[p] = cnt.get(p, 0) + 1
                    time.sleep(0.4)
        except Exception as e:
            print(f'[use_items] {e}')
        return used

    def use_bach_cau_hoan(self) -> bool:
        """Dùng Bạch Câu Hoàn trong túi (genre6 detail1 particular∈{91,92}) để nạp giờ Trainoff. Trả True nếu đã dùng."""
        try:
            r = self.dump_bag_items() or {}
            items = r.get('items') if isinstance(r, dict) else r
            for it in (items or []):
                if (it.get('genre') == 6 and it.get('detail') == 1
                        and it.get('particular') in self.BACH_CAU_HOAN_PARTICULARS
                        and it.get('location') == 2):
                    idx = it.get('index') or it.get('slot')
                    print(f"[bachcauhoan] dùng particular={it.get('particular')} index={idx}")
                    self.use_item(int(idx))
                    return True
        except Exception as e:
            print(f'[bachcauhoan] {e}')
        return False

    def wait_in_world(self, timeout: float = 75.0) -> bool:
        """Poll tới khi 'in_world'. Account mới = socket fd MỚI -> re-detect fd (không thì Dã Tẩu câm).
        User xác nhận auto-enter; nếu kẹt 'at_login' >15s thì thử enter_world() 1 lần (fallback)."""
        t0 = time.time(); tried_srv = False; tried_enter = False
        while time.time() - t0 < timeout:
            st = self.get_login_state()
            if st == 'in_world':
                try:
                    self.redetect_fd_by_traffic()
                    self.rpc.reset_fd_evidence()
                except Exception:
                    pass
                # CHỐNG WIPE LÚC LOGIN: set ngay default profile = guid "Luyện công" của acc này. Nếu KHÔNG set,
                # client tự bật lại auto khi vào thế giới sẽ dùng default RỖNG -> gửi op140 rỗng = XOÁ profile
                # (vector wipe "vừa log vào là mất"). Set sớm ở đây để client auto-resume dùng default HỢP LỆ.
                try:
                    g = self._autoplay_guid()
                    if g:
                        self.rpc.set_default_autoplay_profile(g)
                        print(f'[autoplay] (login) SetDefaultProfile({g}) — chống wipe lúc vào thế giới.')
                except Exception as e:
                    print(f'[autoplay] (login) set default lỗi: {e}')
                return True
            # Chưa vào world sau ~8s -> nudge chọn server lần trước (game tự nhớ); ~15s -> thử enter_world.
            if not tried_srv and (time.time() - t0) > 8:
                try: self.rpc.select_last_server()
                except Exception: pass
                tried_srv = True
            if st == 'at_login' and not tried_enter and (time.time() - t0) > 15:
                self.enter_world(); tried_enter = True
            time.sleep(2.0)
        return False

    def get_bag_slots(self):
        """Get occupied bag slots from memory using Frida RPC."""
        try:
            return self.rpc.get_bag_slots()
        except Exception as e:
            logger.error(f"[VLTK1Bot] get_bag_slots error: {e}")
            return None

    def dump_bag_items(self):
        """Đọc toàn bộ item trong PlayerMain.items kèm thuộc tính (qua frida-il2cpp-bridge)."""
        try:
            return self.rpc.dump_bag_items()
        except Exception as e:
            logger.error(f"[VLTK1Bot] dump_bag_items error: {e}")
            return None

    def cleanup_bag_loot(self, dry_run=False, shop_context=None, log=None, exclude_slots=None):
        """TẠI THÀNH (khu phi-chiến): DUY TRÌ trong KHO đúng 1 món/mỗi thuộc tính Dã Tẩu (xem-trả) — xem
        equip_matcher.DA_TAU_ATTR_KEYS. Mỗi đồ nhặt genre0 trong TÚI: nếu có thuộc tính NV CHƯA có trong kho →
        CẤT KHO (loc 3, làm đồ tham chiếu); nếu thuộc tính đã đủ trong kho (TRÙNG) hoặc KHÔNG có thuộc tính NV →
        BÁN. KHÔNG đụng gen6 (thuốc/Dã Tẩu lệnh/TĐP...). Verify từng món (re-dump). dry_run=True: chỉ phân loại.
        Cần ĐANG Ở THÀNH (shop+kho mới dùng). Trả {sold,deposited,fail,shop,covered}.
        exclude_slots: tập slot KHÔNG được đụng (vd món đang chờ nộp Dã Tẩu) — bán/cất sẽ bỏ qua."""
        from core import equip_matcher as _EM
        _log = log if callable(log) else (lambda m: None)
        exclude_slots = set(exclude_slots or ())
        rep = {'sold': [], 'deposited': [], 'fail': [], 'shop': False, 'covered': []}
        # 1) THUỘC TÍNH ĐÃ CÓ TRONG KHO (loc 3) — không cất trùng nữa.
        dump0 = self.dump_bag_items() or {}
        covered = set()
        for it in (dump0.get('items') or []):
            if it.get('genre') == 0 and it.get('location') == 3:
                covered |= _EM.matched_attr_keys(it)
        _log(f"[loot] thuộc tính NV đã có trong kho: {sorted(covered) or '(chưa có)'}")
        # BẢO VỆ HOÀNG KIM (tái bật 2026-06-19 — isGold giờ TIN CẬY: check NỘI DUNG goldequip, verified real-gold
        # misz=6/magic≠0 vs đồ thường misz=0). FAIL-SAFE chống tái phát sự cố bán-0: HOÀNG KIM chỉ là genre 0;
        # nếu món genre≠0 (thuốc/tiêu hao) bị flag isGold = isGold CHẮC CHẮN hỏng (đúng bug cũ 28/28 cả g6) →
        # BỎ bảo vệ pass này (bán như thường), KHÔNG để kẹt auto.
        gold_broken = any(it.get('isGold') and it.get('genre') != 0 for it in (dump0.get('items') or []))
        gold_protect = not gold_broken
        if gold_broken:
            _log("[loot] ⚠️ isGold HỎNG (có món genre≠0 bị flag gold) → BỎ bảo vệ hoàng kim pass này (bán thường, tránh kẹt auto).")
        # 2) MỞ shop để eShopSellItem có hiệu lực (ở động/không mở shop → bán fail).
        if not dry_run:
            try:
                if shop_context:
                    self.open_shop_remote(shop_context, wait=2.5)
                else:
                    self.open_shop_read(wait=2.0)
            except Exception as e:
                _log(f"[loot] mở shop lỗi: {e}")
            rep['shop'] = any(p.get('opcode') in (119, 120) for p in (self.poll_recv() or []))
            if not rep['shop']:
                _log("[loot] ⚠️ shop CHƯA mở (119/120) — bán có thể fail; cất kho vẫn chạy.")
        # 3) duyệt genre0 trong TÚI (loc 2): cung cấp thuộc tính MỚI → cất; trùng/không-có → bán.
        processed = set()
        for _ in range(80):
            dump = self.dump_bag_items() or {}
            # Bán gear genre0; BỎ QUA hoàng kim (gold_protect) — trừ khi fail-safe phát hiện isGold hỏng.
            items = [it for it in (dump.get('items') or [])
                     if it.get('genre') == 0 and it.get('location') == 2
                     and not (gold_protect and it.get('isGold'))      # hoàng kim -> không bán (khi tín hiệu tin cậy)
                     and isinstance(it.get('slot'), int) and it.get('slot') not in processed
                     and it.get('slot') not in exclude_slots]
            if not items:
                break
            it = items[0]
            slot = it.get('slot')
            item_keys = _EM.matched_attr_keys(it)
            new_keys = item_keys - covered
            keep = bool(new_keys)                 # có thuộc tính NV CHƯA có trong kho → giữ làm tham chiếu
            processed.add(slot)
            if dry_run:
                if keep:
                    covered |= new_keys
                    rep['deposited'].append(slot)
                    _log(f"[loot] slot {slot} → CẤT KHO (thuộc tính mới: {sorted(new_keys)})")
                else:
                    rep['sold'].append(slot)
                    _log(f"[loot] slot {slot} → BÁN (thuộc tính: {sorted(item_keys) or 'không'}; đã đủ trong kho)")
                continue
            if keep:
                self.send_gs('eItemLocationRequest', itemIndex=slot, itemLocation=3)   # → KHO
            else:
                self.send_gs('eShopSellItem', itemid=slot)                              # BÁN
            time.sleep(0.7)
            after = self.dump_bag_items() or {}
            still = any(x.get('slot') == slot and x.get('location') == 2 for x in (after.get('items') or []))
            if still:
                rep['fail'].append(slot)
                _log(f"[loot] slot {slot}: {'cất' if keep else 'bán'} CHƯA ăn (còn loc2).")
            else:
                if keep:
                    covered |= new_keys
                    rep['deposited'].append(slot)
                else:
                    rep['sold'].append(slot)
        rep['covered'] = sorted(covered)
        _log(f"[loot] xong: bán {len(rep['sold'])}, cất kho {len(rep['deposited'])}, fail {len(rep['fail'])}; "
             f"kho phủ {len(covered)} thuộc tính NV.")
        return rep

    def talk_npc_by_name(self, npc_name: str):
        """Interact with NPC directly using game backend functions"""
        print(f'[>] talk_npc_by_name: {npc_name}')
        try:
            res = self.rpc.talk_to_npc_by_name(npc_name)
            if res and res.get('ok'):
                npc_id = res.get('npcId')
                print(f"[+] Successfully found {npc_name} (ID: {npc_id}). Sending packet...")
                return self.talk_npc(str(npc_id))
            else:
                print(f"[-] Failed to trigger dialog: {res.get('error')}")
                return False
        except Exception as e:
            print(f"[-] Frida RPC Exception in talk_npc_by_name: {e}")
            import traceback
            traceback.print_exc()
            return False

    # ==================== LỄ QUAN: remote nhận buff Tân Thủ ====================
    LEQUAN_PATH = "data/output/lequan_town_npc.json"

    def _all_lequan_npcs(self):
        """npcId Lễ Quan 7 thành (đọc lequan_town_npc.json; fallback hằng số). Dùng để DÒ Lễ Quan cùng vùng."""
        import json
        fallback = ["673", "999", "1727", "1375", "1243", "4095", "3445"]
        try:
            cfg = json.load(open(self.LEQUAN_PATH, encoding="utf-8"))
            ids = [str(v.get("npcId")) for k, v in cfg.items()
                   if not k.startswith("_") and isinstance(v, dict) and v.get("npcId")]
            return ids or fallback
        except Exception:
            return fallback

    def receive_tan_thu_buff(self):
        """Remote nhận buff 'Hồi phục Tân Thủ': DÒ Lễ Quan cùng vùng (talk_npc tới từng npc, npc nào mở menu =
        đúng vùng) -> eNpcSelect(0) (lặp để qua bước xác nhận; đã thấy server gửi chuỗi eNpcSelect(0) rỗng).
        KHÔNG di chuyển nhân vật. Trả 'ok' / 'no_lequan' / 'err'.
        ⚠️ Chuỗi confirm = best-effort (eNpcSelect 0) — cần verify với char <79 thật."""
        MENU_OPS = (34, 124)
        try:
            lequan = None
            for npc in self._all_lequan_npcs():
                try:
                    self.recv_buffer = []
                except Exception:
                    pass
                self.talk_npc(npc)
                if self.wait_for_packet(MENU_OPS, timeout=1.3):
                    lequan = npc
                    break
            if not lequan:
                return 'no_lequan'
            # 'Hồi phục Tân Thủ' = index 0 (user xác nhận), chọn = nhận luôn (KHÔNG bước confirm).
            # XÁC NHẬN buff THẬT: khi cấp buff server gửi op48 ePlayerTalk (thông báo). Xoá buffer -> select ->
            # soi op48 ~1.5s. CÓ op48 -> 'ok' (nhận thật); KHÔNG -> 'unconfirmed' (Lễ Quan sai/đông/cooldown ->
            # KHÔNG báo "đã nhận" dối). Trước đây trả 'ok' mù -> log dương-tính-giả (user phát hiện 2026-06-16).
            try:
                self.recv_buffer = []
            except Exception:
                pass
            # XẢ buffer op48 RIÊNG (JS siphon op48 vào get_op48, KHÔNG vào recv_buffer → poll_recv KHÔNG BAO GIỜ
            # thấy op48 → trước đây LUÔN 'unconfirmed' dù buff đã nhận, user: "buff được mà toàn báo fail").
            try:
                self.rpc.get_op48()
            except Exception:
                pass
            for _ in range(3):
                self.send_gs('eNpcSelect', selectIndex=0)
                self.wait_for_packet(MENU_OPS, timeout=0.8)
            got48 = False
            t0 = time.time()
            while time.time() - t0 < 2.5:
                try:
                    if (self.rpc.get_op48() or {}).get('items'):   # ĐỌC ĐÚNG buffer op48 → bắt được xác nhận buff
                        got48 = True
                except Exception:
                    pass
                # phòng hờ op48 cũng lọt recv_buffer ở 1 số build:
                try:
                    if not got48 and any(p.get('opcode') == 48 for p in (self.poll_recv() or [])):
                        got48 = True
                except Exception:
                    pass
                if got48:
                    break
                time.sleep(0.15)
            print(f'[buff] remote Lễ Quan {lequan} + select 0 -> {"CÓ op48 (nhận thật)" if got48 else "KHÔNG op48 (chưa xác nhận)"}.')
            return 'ok' if got48 else 'unconfirmed'
        except Exception as e:
            print(f'[buff] lỗi nhận buff: {e}')
            return 'err'

    def select_option(self, index: int):
        return self.send_gs('eNpcSelect', selectIndex=index)

    def use_skill_npc(self, skill_id: int, nid: str):
        return self.send_gs('eDoSkillTargetNpc', skillid=skill_id, nid=nid)

    def use_skill_pos(self, skill_id: int, x: int, y: int):
        return self.send_gs('eDoSkillTargetPosition', skillid=skill_id, positionX=x, positionY=y)

    def pickup(self, object_id: str):
        return self.send_gs('eObjectPickup', objectId=object_id)

    def do_skill(self, skill_id: int):
        """TỰ ĐÁNH = invoke PlayerMain.DoSkill(id) TRÊN MAIN THREAD (client tự cast: dựng state niệm/hướng/target
        rồi mới gửi op239 → server TÍNH DAME). KHÁC replay op239 thô (không dame với skill đánh-xa/caster vì thiếu
        state). DoSkill tự nhắm con gần (như bấm nút skill). Gọi LẶP ~nhịp niệm. Verify live 2026-06-16: DoSkill(362)
        → quái 99→34. [[boss-detection]]"""
        try:
            return self.rpc.do_skill_hooked(int(skill_id))
        except Exception as e:
            return {'ok': False, 'error': str(e)}

    def accept_party(self, team_id: int):
        """Chấp nhận lời mời vào tổ đội (ePartySelfAccept op92){teamId}. teamId lấy từ gói mời op79 ePartyInvite
        (party.teamId). Trong party: ai nhặt đồ-chí mình CŨNG được tính → cày chung = nhân tiến độ."""
        return self.send_gs('ePartySelfAccept', teamId=int(team_id))

    def use_item(self, item_index: int):
        return self.send_gs('ePlayerUserItem', itemindex=item_index)

    def use_thp_balanghuyen(self):
        """Send exact eContextDesSelect packet to teleport to Ba Lang Huyen via THP"""
        print("[>] use_thp_balanghuyen")
        # eContextDesSelect (167 = 0xa7) with option 0x0802
        return self.send_raw(bytes.fromhex("02000000a7000802"))

    def _build_shop_buy_packet(self, shopkey: str, itemindex: int, quantity: int = 1):
        """Dựng bytes gói eShopBuyItem(148): [len][148] + 0x0A len shopkey + 0x10 idx(varint) + 0x18 qty(varint)."""
        import struct
        payload = bytearray()
        sk = shopkey.encode('utf-8')
        payload.append(0x0A); payload.append(len(sk)); payload.extend(sk)
        for tag, val in ((0x10, itemindex), (0x18, quantity)):
            payload.append(tag)
            v = val
            while True:
                b = v & 0x7F; v >>= 7
                payload.append(b | 0x80 if v else b)
                if not v:
                    break
        return struct.pack('<IH', len(payload), 148) + payload

    def buy_item_remote(self, shopkey: str, itemindex: int, quantity: int = 1):
        """Mua đồ từ xa (Distance Hack) bằng cách gửi thẳng Opcode 148"""
        return self.send_raw(self._build_shop_buy_packet(shopkey, itemindex, quantity))

    CREATECHAR_TEMPLATE_PATH = "data/output/createchar_template.json"

    @staticmethod
    def _pb_varint(v):
        out = bytearray()
        while True:
            b = v & 0x7F; v >>= 7
            out.append(b | 0x80 if v else b)
            if not v:
                return bytes(out)

    def create_character_raw(self, name: str, data: str = None):
        """TẠO nhân vật bằng REPLAY op5 UnityCreateCharacterRequest {field1 data(tạo hình base64-string),
        field3 name}. factionId/sex = 0 (vắng = nằm trong data). data=None -> đọc createchar_template.json.
        ⚠️ data là blob có phần đổi mỗi request (xem op3) -> server CÓ THỂ từ chối replay; PHẢI test op6.
        Trả dict op6 {isOk,message} (hoặc None nếu không nhận phản hồi)."""
        import json, struct
        if data is None:
            try:
                data = json.load(open(self.CREATECHAR_TEMPLATE_PATH, encoding="utf-8")).get("data")
            except Exception:
                data = None
        if not data:
            print("[create] THIẾU data template (createchar_template.json) — bắt op5 trước."); return None
        db = data.encode("utf-8"); nb = name.encode("utf-8")
        body = b'\x0a' + self._pb_varint(len(db)) + db + b'\x1a' + self._pb_varint(len(nb)) + nb
        pkt = struct.pack('<IH', len(body), 5) + body
        try:
            self.recv_buffer = []
        except Exception:
            pass
        print(f"[create] gửi op5 tạo char name={name!r} (data {len(db)}B)")
        self.send_raw(pkt)
        r = self.wait_for_packet((6, 'UnityCreateCharacterResponse'), timeout=6.0)
        if r:
            try:
                from features.bot.shop_parser import _decode_protobuf
                fb = _decode_protobuf(bytes.fromhex(r.get('hex', ''))[6:])
                msg = fb.get(2)
                if isinstance(msg, (bytes, bytearray)): msg = msg.decode('utf-8', 'ignore')
                ok = bool(fb.get(1))
                print(f"[create] op6 phản hồi: isOk={ok} message={msg!r}")
                return {'isOk': ok, 'message': msg}
            except Exception as e:
                print(f"[create] op6 raw nhưng parse lỗi: {e} hex={r.get('hex')}")
                return {'raw': r.get('hex')}
        print("[create] KHÔNG nhận op6 (server im hoặc gửi op khác).")
        return None

    # ==================== BOT UTILS ====================

    def auto_keepalive(self, interval=30):
        """Background ping thread."""
        def _loop():
            while self.running:
                try:
                    self.ping()
                except Exception as e:
                    # Game CHẾT / Frida detach ("script has been destroyed") -> dừng keepalive GỌN,
                    # KHÔNG văng traceback ra log (trước đây luồng chết bẩn, nhìn như "bot crash" trong khi
                    # thực ra GAME tự crash). Đánh dấu mất kết nối để state machine biết (bootstrap sẽ thử lại).
                    print(f'[keepalive] mất kết nối game ({str(e)[:50]}) → dừng ping.')
                    try:
                        self.game_bot_connected = False
                    except Exception:
                        pass
                    return
                time.sleep(interval)
        t = threading.Thread(target=_loop, daemon=True)
        t.start()
        print(f'[+] Keepalive started (every {interval}s)')

    def close(self):
        self.running = False
        if self.script:
            try: self.script.unload()
            except: pass
        if self.session:
            try: self.session.detach()
            except: pass
        print('[*] Disconnected')


# ==================== INTERACTIVE CLI ====================

def main():
    print('=' * 50)
    print('  VLTK1 Bot Controller')
    print(f'  Package: {PACKAGE}')
    print('=' * 50)

    bot = VLTK1Bot()
    if not bot.connect():
        return

    bot.auto_keepalive()

    print('\n[*] Bot ready. Use bot.xxx() commands.')
    print('    bot.chat("msg")           - send chat')
    print('    bot.move_to(wx, wy)       - move (world coords 5 số)')
    print('    bot.move_to_game(gx, gy)  - move (game coords 3 số)')
    print('    bot.set_riding(True)      - mount horse')
    print('    bot.goto_npc("name")      - go to NPC')
    print('    bot.poll_recv()           - read packets')
    print('    bot.close()               - disconnect\n')

    import code
    code.interact(banner='', local={'bot': bot, 'VLTK1Bot': VLTK1Bot})
    bot.close()


if __name__ == '__main__':
    main()

