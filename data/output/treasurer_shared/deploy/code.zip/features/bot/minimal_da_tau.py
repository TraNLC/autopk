import time
import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))

from core.adb_helper import ADBHelper
from features.bot.game_bot import VLTK1Bot
from core.navigator import Navigator
from core.map_manager import MapManager

class MinimalDaTauBot:
    def __init__(self, ui_callback=None):
        self.ui_callback = ui_callback or print
        self.is_running = False
        self.adb = ADBHelper()
        self.map_mgr = MapManager()
        self.game_bot = VLTK1Bot()
        self.nav = Navigator(self.adb)
        self.nav.game_bot = self.game_bot
        self.step = 0
        
    def start(self):
        self.is_running = True
        self.log("Đang khởi tạo kết nối game...")
        
        # Connect Frida
        self.game_bot.connect()
        time.sleep(2)
        
        self.log("Kết nối thành công. Sẵn sàng chạy.")
        self.step = 1

    def stop(self):
        self.is_running = False

    def log(self, msg):
        self.ui_callback(msg)
        
    def run_step(self):
        if not self.is_running:
            return
            
        if self.step == 1:
            self.log("Đang chạy đến Dã Tẩu (203, 198)...")
            # Giảm thời gian delay, dùng bot.goto_path_native tự động chờ
            ok = self.nav.move_to(203, 198, wait_seconds=8)
            if ok:
                self.log("Đã tới nơi. Chuẩn bị đối thoại.")
                self.step = 2
            else:
                self.log("Không thể đến vị trí. Vui lòng kiểm tra lại xem nhân vật có kẹt không.")
                self.stop()
                
        elif self.step == 2:
            self.log("Đang tìm và click vào Dã Tẩu...")
            
            # Đóng bất kỳ hộp thoại nào đang mở (VD: Long Ngũ) bằng cách bấm ra chỗ trống và ESC
            self.adb.tap(800, 200)
            time.sleep(0.5)
            self.adb.keyevent(4) # BACK
            time.sleep(0.5)
            # adb_helper.py tự động scale từ base 960x540.
            # Ở độ phân giải 960x540:
            # - Tâm (nhân vật) là (480, 270)
            # - Hitbox chuẩn xác của Dã Tẩu nằm ở (460, 200)
            tap_points = [
                (460, 200) # Chuẩn xác 100%
            ]
            
            success = False
            for tx, ty in tap_points:
                self.log(f"Thử click Dã Tẩu tại ({tx}, {ty})...")
                self.adb.tap(tx, ty)
                time.sleep(1.0)
                
                # Bắt packet (đôi khi là eNpcDialogue hoặc eNpcQuest)
                start_wait = time.time()
                while time.time() - start_wait < 3.0: # Tăng thời gian chờ lên 3 giây để tránh bị thoát sớm
                    pkts = self.game_bot.rpc.get_recv_packets()
                    for pkt in pkts:
                        if pkt['opcode'] in [33, 34, 35]: # eNpcDialogue or eNpcQuest
                            self.log(f"Đã bắt được giao tiếp với Dã Tẩu! (opcode {pkt['opcode']})")
                            quest_data = [pkt]
                            success = True
                            break
                    if success: break
                    time.sleep(0.1)
                
                if success:
                    break
                else:
                    self.log("Trượt. Đóng UI nhầm (nếu có)...")
                    # Nếu lỡ mở trúng NPC khác (như Long Ngũ) hoặc Rương, đóng lại
                    self.adb.tap(800, 200) # Click đất trống để đóng
                    time.sleep(0.2)
                    self.adb.keyevent(4)   # Phím Back
                    time.sleep(0.5)
            
            if not success:
                self.log("Đã thử click các tọa độ nhưng không tìm thấy Dã Tẩu!")
                self.stop()
                return
                
            pkts = quest_data
            
            if pkts:
                from core.quest import parse_opcode34
                quest_data = parse_opcode34(pkts[-1])
                
                if quest_data:
                    self.log(f"Đã nhận diện nhiệm vụ: {quest_data.get('quest_type', 'unknown')}")
                    # In chi tiết nhiệm vụ ra log
                    self.log(f"Chi tiết: {quest_data}")
                    self.step = 3
                else:
                    self.log("Không thể parse nội dung nhiệm vụ.")
                    self.stop()
                    return
            
            # Gửi chat báo cáo lên kênh Lân Cận
            self.log("Đang báo cáo lên kênh Chat game...")
            
            if quest_data and 'clean_text' in quest_data:
                quest_str = quest_data['clean_text'][:50] + "..."
            elif quest_data and 'quest_type' in quest_data:
                quest_str = f"Nhiệm vụ: {quest_data['quest_type']}"
            else:
                quest_str = str(quest_data)[:50]
                
            chat_msg = f"Đã nhận nhiệm vụ Dã Tẩu: {quest_str}"
            # Gửi qua GameBot
            try:
                self.game_bot.send_chat(1, chat_msg)
            except Exception as e:
                self.log(f"Lỗi gửi chat: {e}")
                
            self.log("Hoàn thành báo cáo. Sẽ tự động tắt Bot.")
            self.stop()
