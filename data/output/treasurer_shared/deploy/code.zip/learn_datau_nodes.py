# -*- coding: utf-8 -*-
"""learn_datau_nodes.py — Đi Xa Phu tới các ĐỘNG + open_datau để TỰ HỌC node Dã Tẩu (lưu datau_nodes.json).

RESUMABLE: open_datau tự lưu map→node; chạy lại sẽ BỎ QUA map đã học. Dừng giữa chừng vô hại.
Cơ chế đi: nếu Xa Phu(dest) từ vị trí hiện tại KHÔNG đổi map (vì đang trong động, Xa Phu NPC ở thành) →
RECALL về thành (TDP) rồi Xa Phu lại. Đếm số TDP dùng.

  venv/bin/python learn_datau_nodes.py [--limit N] [--device 127.0.0.1:26624] [--tiers LC30,LC40]
"""
import sys, time, json
sys.path.insert(0, ".")
from core.adb_helper import ADBHelper
from features.bot.da_tau_state_machine import DaTauStateMachine

DEV = "127.0.0.1:26624"
LIMIT = None
TIERS = None   # None = mọi tier động; hoặc lọc vd ["LC30","LC40"]
a = sys.argv
if "--device" in a: DEV = a[a.index("--device")+1]
if "--limit" in a: LIMIT = int(a[a.index("--limit")+1])
if "--tiers" in a: TIERS = set(a[a.index("--tiers")+1].split(","))

# LOG REALTIME SẠCH ra file cố định để xem bằng: tail -f data/output/learn_datau_live.log
# (chỉ tee print CỦA SCRIPT NÀY; log frida/[xaphu] ở module khác không lọt vào → file gọn).
import builtins as _bi
_LIVE = open("data/output/learn_datau_live.log", "w", encoding="utf-8")
_orig_print = _bi.print
def print(*args, **kw):
    _orig_print(*args, **kw)
    try:
        _LIVE.write(" ".join(str(x) for x in args) + "\n"); _LIVE.flush()
    except Exception:
        pass

SKIP_TIERS = {"Thành Thị", "Tẩy Tủy đảo", "Đêm Huy Hoàng", "Thôn Trấn"}
SKIP_NAMES = {"Đi đảo tẩy tủy", "Đi miễn phí", "Kết thúc đối thoại"}

routes = json.load(open("data/output/xaphu_routes.json", encoding="utf-8"))["routes"]
dests = {}   # name -> route_key (dedup theo name)
for key, info in routes.items():
    nm, tier = info.get("name"), info.get("tier")
    if not nm or tier in SKIP_TIERS or nm in SKIP_NAMES:
        continue
    if TIERS and tier not in TIERS:
        continue
    dests.setdefault(nm, key)
names = list(dests.items())
if LIMIT:
    names = names[:LIMIT]
print(f"[*] {len(names)} động/khu để học (device {DEV})", flush=True)

sm = DaTauStateMachine(ADBHelper(device_id=DEV))
if not sm.game_bot.connect():
    print("connect fail"); sys.exit()

def cur_map():
    try: return (sm.game_bot.rpc.get_player_info() or {}).get("mapId")
    except Exception: return None

# Xa Phu npc THEO THÀNH (mapId->npc). Remote same-region: từ động vùng X, npc thành vùng X MỞ MENU được.
TOWN_XAPHU = ["879", "1222", "1312", "1386", "1058", "4159", "3363"]
MENU = {34, 124, 166, 167}

def menu_opens(npc, timeout=1.3):
    sm.game_bot.recv_buffer = []; sm.game_bot.poll_recv(); sm.game_bot.recv_buffer = []
    sm.game_bot.talk_npc(str(npc))
    t0 = time.time()
    while time.time() - t0 < timeout:
        for p in (sm.game_bot.poll_recv() or []):
            if p.get("opcode") in MENU:
                return True
        time.sleep(0.1)
    return False

# TỪ ĐỘNG, Xa Phu CHỈ về THÀNH ("Khu vực Thành Thị"); KHÔNG đi động khác. Nên chain: động→THÀNH→động kế.
TOWN_MAPIDS = {1, 11, 162, 37, 78, 80, 176, 53, 20, 121, 174, 101, 99, 100, 153}
NODE_TOWN = {"588": "Phượng Tường", "1049": "Thành Đô", "1723": "Biện Kinh", "1425": "Tương Dương",
             "1192": "Dương Châu", "4099": "Đại Lý", "3447": "Lâm An"}

_npc_cache = [None]
def working_xaphu_npc():
    if _npc_cache[0] and menu_opens(_npc_cache[0]):
        return _npc_cache[0]
    for npc in TOWN_XAPHU:
        if menu_opens(npc):
            _npc_cache[0] = npc
            return npc
    return None

def ensure_in_town():
    """Trong động → Xa Phu VỀ THÀNH (free). Từ động menu CHỈ có ['Khu vực Thành Thị'(0), 'Kết thúc'(1)] → nav
    eNpcSelect(0) [Thành Thị] → eNpcSelect(0) [thành đầu] (VERIFY 2026-06-12: map4→map1). Trả True nếu ở thành."""
    if cur_map() in TOWN_MAPIDS:
        return True
    for _ in range(2):
        npc = working_xaphu_npc()       # dò npc Xa Phu mở menu (cùng vùng)
        if not npc:
            return False
        sm.game_bot.send_gs('eNpcSelect', selectIndex=0)   # Khu vực Thành Thị
        time.sleep(0.8)
        sm.game_bot.send_gs('eNpcSelect', selectIndex=0)   # thành đầu danh sách
        time.sleep(1.8)
        if cur_map() in TOWN_MAPIDS:
            return True
    return cur_map() in TOWN_MAPIDS

# CACHE tên-động → mapId (resumable): bỏ qua động ĐÃ HỌC (đỡ travel lại).
CACHE_PATH = "data/output/learned_dungeons.json"
try:
    name2map = json.load(open(CACHE_PATH, encoding="utf-8"))
except Exception:
    name2map = {}

def save_cache():
    try:
        json.dump(name2map, open(CACHE_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    except Exception:
        pass

done = 0; skipped = 0
for i, (nm, key) in enumerate(names, 1):
    try:
        # SKIP nếu đã học trước: tên trong cache + map đó có node thật trong datau_nodes.json → KHỎI travel.
        cm = name2map.get(nm)
        if cm is not None and sm._load_datau_nodes().get(str(cm)):
            skipped += 1
            print(f"   ⏭️ [{i}/{len(names)}] '{nm}' (map {cm}) — ĐÃ HỌC trước → bỏ qua (không travel).", flush=True)
            continue
        if not ensure_in_town():
            print(f"  [{i}/{len(names)}] {nm}: KHÔNG về được thành (dò npc fail) → bỏ qua.", flush=True)
            continue
        print(f"🚶 [{i}/{len(names)}] Đang tới ĐỘNG: {nm} …", flush=True)
        # ĐANG Ở THÀNH → Xa Phu tới động (menu thành có đủ route động). npc auto theo thành đang đứng.
        sm.game_bot.xaphu_travel(key, wait=2.0, attempts=2)
        time.sleep(1.0)
        m1 = cur_map()
        if m1 in TOWN_MAPIDS:
            print(f"   ⚠️ [{i}/{len(names)}] {nm}: VẪN Ở THÀNH (map {m1}) — không vào được động (level chưa đủ? route fail) → bỏ qua.", flush=True)
            continue
        already = str(m1) in sm._load_datau_nodes()
        sm.open_datau()                # tự lưu map->node
        node = sm.datau_npc_id
        town = NODE_TOWN.get(str(node), "?")
        done += 1
        if m1 and node:                      # CHỈ cache khi học được node thật (để lần sau skip đúng)
            name2map[nm] = m1; save_cache()
        if node:
            print(f"   ✅ [{i}/{len(names)}] ĐỘNG '{nm}' (map {m1}) — {'đã có sẵn' if already else 'ĐÃ HỌC'} node Dã Tẩu {node} (thành {town}).", flush=True)
        else:
            print(f"   ❓ [{i}/{len(names)}] ĐỘNG '{nm}' (map {m1}) — KHÔNG ra Dã Tẩu (vùng chưa có node thành) → cần bổ sung.", flush=True)
    except Exception as e:
        print(f"   ❌ [{i}/{len(names)}] {nm}: LỖI {e}", flush=True)
    time.sleep(0.1)

print(f"\n=== XONG: học {done} động, bỏ qua {skipped} (đã học trước), KHÔNG tốn TDP. "
      f"datau_nodes.json có {len(sm._load_datau_nodes())} map. ===", flush=True)
