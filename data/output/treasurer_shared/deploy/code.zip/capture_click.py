"""
capture_click.py — BẮT gói game GỬI ĐI khi bạn CLICK "1" (ô nhiệm vụ trên tracker).
Mục đích: tìm CHÍNH XÁC opcode + payload của "click 1" để bot replicate (eQuestClick đoán SAI).

DÙNG:
  1. TẮT Auto cửa sổ sẽ test (Frida attach 1 lần/PID). Nên dùng cửa sổ đang có NV đồ-chí.
  2. venv/bin/python capture_click.py 127.0.0.1:26784
  3. Chờ "ĐANG BẮT — hãy CLICK vào ô NV (1)". Rồi tự tay CLICK ô NV trên tracker 1-2 lần.
  4. Copy các dòng [SEND] in ra gửi lại.
"""
import sys, time
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot


def main():
    dev = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1:26784"
    print(f"[*] Attach {dev}…", flush=True)
    bot = VLTK1Bot(device_id=dev)
    if not bot.connect():
        print("[-] Attach FAIL (cửa sổ còn bật Auto? game chưa vào?).", flush=True)
        return
    for _ in range(6):
        try: bot.poll_recv()
        except Exception: pass
        time.sleep(0.3)
    try: bot.redetect_fd_by_traffic()
    except Exception: pass
    # XẢ gói gửi cũ
    try: bot.rpc.get_send_packets()
    except Exception: pass
    print("=" * 50, flush=True)
    print("👉 ĐANG BẮT (60s) — hãy CLICK vào ô NV (1) trên tracker 1-2 lần…", flush=True)
    print("=" * 50, flush=True)
    t0 = time.time()
    seen = 0
    while time.time() - t0 < 60:
        try:
            pkts = bot.rpc.get_send_packets() or []
        except Exception:
            pkts = []
        for p in pkts:
            op = p.get("opcode"); nm = p.get("name") or "?"; hx = p.get("hex") or ""
            print(f"[SEND] op={op} name={nm} hex={hx}", flush=True)
            seen += 1
        time.sleep(0.4)
    print(f"[*] Xong. Bắt được {seen} gói gửi. (Nếu 0 → chưa click hoặc fd sai.)", flush=True)
    try: bot.close()
    except Exception: pass


if __name__ == "__main__":
    main()
