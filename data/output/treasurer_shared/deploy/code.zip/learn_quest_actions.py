"""
learn_quest_actions.py — Sniff gói LỆNH các nút Dã Tẩu để bot tự gửi (khỏi mở dialog).

Cách dùng: TẮT UI trước. Chạy tool -> mở 1 NPC Dã Tẩu -> bấm LẦN LƯỢT từng nút
(Nhận/Biết rồi, Đã hoàn thành, Ta muốn hủy, Hủy 100 tấm đồ chí). Tool bắt MỌI gói GỬI ĐI
liên quan (lọc nhiễu di chuyển/ping), in opcode + nodeId/index + hex để map nút -> gói.

    venv/bin/python -u learn_quest_actions.py [giây]   # mặc định 180s

Sau khi biết nút nào ra gói nào, lưu vào data/output/quest_action_packets.json:
    {"accept": {...}, "complete": {...}, "cancel": {...}, "cancel_do_chi": {...}}
"""
import sys, time, json, os, subprocess, platform
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot
from core.adb_helper import ADB_PATH
try:
    from proto.vltk1_protocol import GS_OPCODES
except Exception:
    GS_OPCODES = {}

PKG = "vn.perfingame.jx1mobile"
FEED_PATH = "data/output/quest_action_feed.txt"
RAW_PATH = "data/output/quest_action_packets_raw.jsonl"

# Bỏ qua các gói GỬI ĐI tần suất cao / không liên quan nút NV
NOISE = {20, 69, 70, 16, 18, 88, 117, 168}
# Gói đáng chú ý (đánh dấu ⭐) — hội thoại/quest/givebox/context
INTEREST = {33, 34, 35, 122, 123, 124, 125, 126, 127, 128, 129, 130,
            141, 142, 144, 166, 167, 245, 246, 94, 95}


def _feed(line):
    print(line, flush=True)
    try:
        with open(FEED_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def detect():
    if platform.system() == "Darwin":
        for p in [26624, 26656, 26688, 16384, 22471, 5555]:
            subprocess.run(f"{ADB_PATH} connect 127.0.0.1:{p}", shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3)
    for l in subprocess.check_output(f"{ADB_PATH} devices", shell=True).decode().split("\n")[1:]:
        if "device" in l and "offline" not in l:
            d = l.split("\t")[0]
            if not d.startswith("emulator-"):
                try:
                    if subprocess.check_output(f"{ADB_PATH} -s {d} shell pidof {PKG}", shell=True,
                                               stderr=subprocess.DEVNULL).decode().strip():
                        return d
                except Exception:
                    pass
    return None


def _decode_first(body):
    """Giải mã sơ field đầu: string (nodeId) hoặc varint (index) để dễ đọc."""
    if not body:
        return ""
    try:
        tag = body[0]; fnum = tag >> 3; wt = tag & 7
        if wt == 2 and len(body) >= 2:           # length-delimited (string)
            ln = body[1]; s = body[2:2+ln]
            try:
                return f"f{fnum}=str({s.decode('utf-8')!r})"
            except Exception:
                return f"f{fnum}=bytes({s.hex()})"
        if wt == 0:                               # varint
            val = 0; shift = 0; pos = 1
            while pos < len(body):
                b = body[pos]; pos += 1
                val |= (b & 0x7f) << shift
                if not (b & 0x80):
                    break
                shift += 7
            return f"f{fnum}=int({val})"
    except Exception:
        pass
    return ""


def main():
    secs = int(sys.argv[1]) if len(sys.argv) > 1 else 180
    dev = detect()
    if not dev:
        print("[-] no device"); return
    b = VLTK1Bot(device_id=dev)
    if not b.connect():
        print("[-] connect fail"); return
    time.sleep(1)

    try:
        os.makedirs("data/output", exist_ok=True)
        open(FEED_PATH, "w", encoding="utf-8").close()
    except Exception:
        pass

    def on_msg(message, data):
        if message.get("type") != "send":
            return
        p = message.get("payload", {})
        if not isinstance(p, dict) or p.get("type") != "send_out":   # CHỈ gói GỬI ĐI (client->server)
            return
        op = p.get("opcode")
        if op is None or op in NOISE:
            return
        try:
            hx = p.get("hex", "")
            body = bytes.fromhex(hx)[6:] if len(hx) >= 12 else b""
            name = GS_OPCODES.get(op, f"op{op}")
            star = "⭐" if op in INTEREST else "  "
            dec = _decode_first(body)
            _feed(f"{star} [{time.strftime('%H:%M:%S')}] GỬI {name}({op}) {dec} | hex={hx}")
            try:
                with open(RAW_PATH, "a", encoding="utf-8") as f:
                    f.write(json.dumps({"ts": time.strftime('%H:%M:%S'), "opcode": op,
                                        "name": name, "decoded": dec, "hex": hx},
                                       ensure_ascii=False) + "\n")
            except Exception:
                pass
        except Exception as e:
            _feed(f"   parse err: {e}")

    b.script.on("message", on_msg)
    _feed(f"🟢 SNIFF NÚT NV {secs}s — mở Dã Tẩu, bấm LẦN LƯỢT từng nút "
          f"(Nhận → Hoàn thành → Hủy → Hủy 100 đồ chí). ⭐ = gói liên quan.")
    t0 = time.time()
    while time.time() - t0 < secs:
        time.sleep(0.3)
    _feed("🏁 HẾT GIỜ sniff nút NV.")
    b.close()


if __name__ == "__main__":
    main()
