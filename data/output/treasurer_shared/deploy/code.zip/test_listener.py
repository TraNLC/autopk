import sys, time
sys.path.insert(0,'.')
from core.adb_helper import ADB_PATH
from core.device_discovery import discover_devices
from features.bot.game_bot import VLTK1Bot
from core.stall_shopper import scan_stalls
def vn(n):
    v=n//10000; l=n%10000
    return ((f"{v} vạn" if v else "") + (f" {l} lượng" if l else "")).strip() or "0"
dev=discover_devices(ADB_PATH,package="vn.perfingame.jx1mobile")[0]
bot=VLTK1Bot(device_id=dev); bot.connect(); time.sleep(2)
p=bot.rpc.get_player_info() or {}
print(f"char={p.get('name')} map={p.get('mapId')}")
cat=scan_stalls(bot, merge=False)
print(f"tổng {len(cat)} sạp. MÓN ĐẦU mỗi sạp:")
for cid,its in (cat or {}).items():
    if its:
        it=its[0]
        print(f"  cid={cid} | {len(its)} món | món đầu: {vn(it.get('price',0))} ({it.get('price')}) g{it.get('genre')}d{it.get('detail')}p{it.get('particular')}lv{it.get('level')}")
