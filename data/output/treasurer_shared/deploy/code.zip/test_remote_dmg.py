# -*- coding: utf-8 -*-
"""test_remote_dmg.py — TEST bắn gói gây damage TỪ XA lên quái.

Pha 1 (capture): bạn ĐÁNH 1 con quái bằng tay ~15s -> script bắt gói GỬI (op40 eCastSkill / op239
eDoSkillTargetNpc / op240) + giải mã skillId + targetId. -> biết skill thật client dùng.
Pha 2 (replay): script tự bắn eDoSkillTargetNpc(skillId, <id quái khác>) nhiều lần + đọc hp% con đó
TRƯỚC/SAU -> nếu tụt máu = remote damage CÓ tác dụng (server không check khoảng cách).

Dùng: (TẮT UI) venv/bin/python -u test_remote_dmg.py [device]
"""
import sys, time
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

DEV = next((a for a in sys.argv[1:]), "127.0.0.1:26624")


def varints(body):
    """Giải mã protobuf đơn giản -> {field_no: value} (varint) + {field_no: bytes} (len-delim)."""
    out = {}
    i = 0
    while i < len(body):
        tag = body[i]; i += 1
        fno = tag >> 3; wt = tag & 7
        if wt == 0:
            v = 0; sh = 0
            while i < len(body):
                b = body[i]; i += 1
                v |= (b & 0x7F) << sh; sh += 7
                if not b & 0x80: break
            out[fno] = v
        elif wt == 2:
            ln = body[i]; i += 1
            out[fno] = body[i:i+ln]; i += ln
        else:
            break
    return out


def mobs(bot):
    try:
        r = bot.rpc.get_near_npcs_detail() or {}
    except Exception:
        return []
    return [n for n in (r.get("npcs") or []) if (n.get("hpMax", 0) or 0) > 0]


def hp_of(bot, mid):
    for n in mobs(bot):
        if str(n.get("id")) == str(mid):
            return n.get("hp")
    return None


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect():
        print("connect FAIL (UI còn attach?)"); return
    bot.capture_sent = True
    for _ in range(8):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.4)
    bot.redetect_fd_by_traffic()
    p = bot.rpc.ping()
    print(f"gameFd={p.get('gameFd')} recvAny={p.get('recvAny')}")
    if not p.get("recvAny"):
        print("recvAny=0 — chưa vào thế giới."); return

    print("\nQuái quanh bạn:")
    for n in mobs(bot)[:12]:
        print(f"  id={n.get('id')} name={n.get('name')!r} hp%={n.get('hp')} type={n.get('npcType')}")

    bot.sent_buffer = []
    print("\n==> PHA 1: ĐÁNH 1 con quái bằng tay NGAY (bắt 15s để học skillId)...\n")
    t0 = time.time(); casts = []
    while time.time() - t0 < 15:
        try: bot.poll_recv()
        except: pass
        for pp in list(getattr(bot, "sent_buffer", [])):
            op = pp.get("opcode")
            if op in (40, 239, 240):
                hx = pp.get("hex") or ""
                try:
                    body = bytes.fromhex(hx)[6:]
                    casts.append((op, varints(body), hx))
                except Exception:
                    pass
        bot.sent_buffer = []
        time.sleep(0.1)

    if not casts:
        print("KHÔNG bắt được gói đánh (op40/239/240). Bạn đã đánh quái chưa? Thử lại."); return
    print(f"Bắt được {len(casts)} gói đánh. Mẫu:")
    skillid = None; tgt = None
    for op, d, hx in casts[:6]:
        print(f"  op{op} fields={ {k:(v if isinstance(v,int) else v.hex()) for k,v in d.items()} }")
    # op239 eDoSkillTargetNpc: f1=skillid, f2=nid(string). op40 eCastSkill: f7=skillId, f4=targetId.
    for op, d, hx in casts:
        if op == 239 and 1 in d:
            skillid = d[1]; tgt = d.get(2); break
        if op == 40 and 7 in d:
            skillid = d[7]; tgt = d.get(4); break
    if skillid is None:
        print("Chưa rút được skillId tự động — xem fields ở trên, báo tôi."); return
    tgt_s = tgt.decode('utf-8','replace') if isinstance(tgt, (bytes, bytearray)) else tgt
    print(f"\n>>> HỌC ĐƯỢC: skillId={skillid}, target lúc đánh tay={tgt_s!r}")

    # PHA 2: chọn 1 con quái (ưu tiên KHÁC con vừa đánh) làm bia, bắn remote.
    cand = [n for n in mobs(bot) if str(n.get("id")) != str(tgt_s)]
    if not cand:
        cand = mobs(bot)
    if not cand:
        print("Hết quái quanh để test bia."); return
    bia = cand[0]; bid = bia.get("id")
    hp0 = bia.get("hp")
    print(f"\n==> PHA 2: bia = id={bid} name={bia.get('name')!r} hp%={hp0}. "
          f"Bắn eDoSkillTargetNpc(skill={skillid}) x8...\n")
    for k in range(8):
        bot.send_gs('eDoSkillTargetNpc', skillid=int(skillid), nid=str(bid))
        time.sleep(0.6)
        hp = hp_of(bot, bid)
        print(f"  lần {k+1}: hp% con bia = {hp}")
        if hp is None:
            print("  (con bia biến mất khỏi list — có thể đã chết/ra tầm)"); break
    hp1 = hp_of(bot, bid)
    print(f"\n=== KẾT QUẢ: hp% bia {hp0} -> {hp1} ===")
    if hp1 is not None and hp0 is not None and hp1 < hp0:
        print("✅ CÓ MẤT MÁU -> remote damage (eDoSkillTargetNpc) CÓ tác dụng từ xa!")
    elif hp1 is None:
        print("⚠️ Bia biến mất — có thể chết (mất máu mạnh) hoặc ra tầm. Chạy lại nhắm con khác để chắc.")
    else:
        print("❌ KHÔNG mất máu -> server CÓ check khoảng cách / cần điều kiện khác (đứng gần).")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[*] Dừng.")
