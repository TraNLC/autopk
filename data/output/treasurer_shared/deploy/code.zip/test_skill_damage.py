# -*- coding: utf-8 -*-
"""test_skill_damage.py — TEST 1 PHÁT, CHỨNG MINH DAME của skill replay (tự học skillId).

Ý tưởng: bạn đánh 1 con quái BẰNG TAY ~12s -> script HỌC skillId + nhớ luôn nid con bạn vừa đánh
(chắc chắn TRONG TẦM). Sau đó script gửi LẠI đúng gói cast (eDoSkillTargetNpc) vào CHÍNH con đó 1 phát,
đọc HP% mọi con quanh TRƯỚC/SAU -> nếu con mục tiêu tụt máu = replay GÂY DAME khi trong tầm (kết luận chắc).

Vì game TÁCH fd recv/send -> để BẮT được cú cast tay (gói OUT op239/240) phải ép gameFd = SEND fd
(mặc định 120). Gửi packet (pha 2) cũng đi qua gameFd nên dùng chung fd này.

Dùng: (TẮT UI cửa sổ acc đó)  venv/bin/python -u test_skill_damage.py [device] [sendfd] [skillId]
  vd:  venv/bin/python -u test_skill_damage.py 127.0.0.1:26624
       venv/bin/python -u test_skill_damage.py 127.0.0.1:26624 120 375   (bỏ pha học, dùng skill 375)
"""
import sys, time
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

_a = sys.argv[1:]
DEV = next((x for x in _a if (":" in x or x.startswith("emulator"))), "127.0.0.1:26624")
_nums = [int(x) for x in _a if x.isdigit()]
FORCE_FD = next((n for n in _nums if n <= 200), None)       # fd nhỏ = ÉP fd (chỉ khi redetect sai); mặc định KHÔNG ép
SKILL = next((n for n in _nums if n > 200), None)           # số lớn = skillId truyền tay (bỏ pha học)
LEARN_SECS = 18


def varints(body):
    """Giải mọi field protobuf top-level -> {fieldno: int(varint) | bytes(len-delim)}."""
    out = {}; i = 0
    while i < len(body):
        tag = body[i]; i += 1; fno = tag >> 3; wt = tag & 7
        if wt == 0:
            v = 0; sh = 0
            while i < len(body):
                b = body[i]; i += 1; v |= (b & 0x7F) << sh; sh += 7
                if not b & 0x80: break
            out[fno] = v
        elif wt == 2:
            ln = body[i]; i += 1; out[fno] = body[i:i+ln]; i += ln
        else:
            break
    return out


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect():
        print("connect FAIL (UI bot còn attach? tắt đi rồi chạy lại)"); return
    bot.capture_sent = True
    for _ in range(6):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.3)
    # TCP: recv & send DÙNG CHUNG fd -> khóa fd GAME THẬT bằng redetect (theo opcode game) thì bắt được
    # cả gói RA (op239). KHÔNG ép fd cứng (số fd đổi mỗi lần launch). Chỉ ép nếu user truyền tay FORCE_FD.
    if FORCE_FD is not None:
        try: bot.set_game_fd(FORCE_FD); print(f"[ép fd] gameFd={FORCE_FD}")
        except Exception as e: print(f"set_game_fd lỗi: {e}")
    else:
        try:
            bot.redetect_fd_by_traffic()
        except Exception as e:
            print(f"redetect lỗi: {e}")
    try:
        p = bot.rpc.ping(); print(f"gameFd(khóa)={p.get('gameFd')} recvAny={p.get('recvAny')}")
    except Exception as e:
        print(f"ping lỗi: {e}")
    # BẬT bắt gói GỬI trên MỌI fd (việc detect gameFd không ổn định: lúc fd 5 bắt được op239, lúc fd
    # chính là 94/98). Bật all-fd -> chắc chắn bắt được cú cast tay dù nó đi fd nào.
    try:
        rc = bot.rpc.set_capture_all_sends(True); print(f"captureAllSends: {rc}")
    except Exception as e:
        print(f"set_capture_all_sends lỗi (JS chưa có RPC? chạy bản frida_bot.js mới): {e}")

    def mobs():
        try:
            r = bot.rpc.get_near_npcs_detail() or {}
        except Exception:
            return []
        return [n for n in (r.get("npcs") or []) if (n.get("hpMax", 0) or 0) > 0]

    def snap():
        return {str(n.get("id")): {"name": n.get("name") or "?", "hp": n.get("hp")} for n in mobs()}

    skill = SKILL
    target = None
    # ---------- PHA 1: HỌC skillId + nid mục tiêu ----------
    if skill is None:
        print(f"\n==> PHA 1 (≤{LEARN_SECS}s): ĐÁNH con quái BẰNG TAY — DỪNG NGAY khi bắt được cú cast đầu (để con đó còn SỐNG + trong tầm).\n")
        bot.sent_buffer = []
        t0 = time.time()
        seen_ops = {}                                    # {opcode: số lần} mọi gói RA — chẩn đoán nếu không thấy skill
        seen_samples = {}                                # {opcode: (hex, decoded)} 1 mẫu/op để soi field
        while time.time() - t0 < LEARN_SECS and skill is None:
            try: bot.poll_recv()
            except: pass
            for pp in list(getattr(bot, "sent_buffer", [])):
                op = pp.get("opcode")
                seen_ops[op] = seen_ops.get(op, 0) + 1
                try: d = varints(bytes.fromhex(pp.get("hex", ""))[6:])
                except Exception: d = {}
                if op not in seen_samples:
                    seen_samples[op] = (pp.get("hex", "")[:80], {k: (v if isinstance(v, int) else bytes(v).hex()) for k, v in d.items()})
                if op not in (40, 239, 240):
                    continue
                if op == 239 and 1 in d:                 # ưu tiên op239: có skillId f1 + target f2
                    skill = d[1]
                    if isinstance(d.get(2), (bytes, bytearray)):
                        try: target = bytes(d[2]).decode("utf-8", "ignore")
                        except Exception: target = None
                    break
                if op == 240 and 1 in d and skill is None: skill = d[1]
                if op == 40 and 7 in d and skill is None: skill = d[7]
            bot.sent_buffer = []
            time.sleep(0.05)
        if skill is None:
            print("❌ Chưa học được skillId (không thấy op239/240/40). MỌI opcode gửi ra trong cửa sổ:")
            if not seen_ops:
                print("   (KHÔNG bắt được gói RA nào → bạn chưa đánh đúng lúc, HOẶC fd sai. Chạy lại + đánh liên tục.)")
            for op in sorted(seen_ops):
                hx, dec = seen_samples.get(op, ("", {}))
                print(f"   op{op} ×{seen_ops[op]}  fields={dec}  hex={hx}")
            print("→ Tìm op có field giống skillId+target rồi báo tôi (hoặc truyền tay skillId ở cuối lệnh).")
            return
        print(f">>> HỌC NHANH: skillId={skill}" + (f", target nid={target} (con bạn vừa đánh)" if target else " (không có target nid → cast diện)"))

    # ---------- PHA 2: CAST NGAY vào con vừa đánh (còn sống + trong tầm) — chùm 3 phát, đo HP% trước/sau ----------
    before = snap()
    if not before:
        print("❌ Không đọc được con quái nào quanh nhân vật (ra bãi quái + đứng cạnh quái rồi chạy lại)."); return
    # GIỮ target từ pha học (con bạn vừa đánh = chắc chắn trong tầm). Chỉ fallback khi KHÔNG có target.
    if not target:
        alive = sorted(before.items(), key=lambda kv: (kv[1]["hp"] if kv[1]["hp"] is not None else 100))
        target = alive[0][0]
        print(f"(không có target từ pha học → chọn con HP% thấp nhất: {before[target]['name']} id={target})")
    elif target not in before:
        print(f"⚠️ target {target} (con bạn vừa đánh) đã KHÔNG còn trong danh sách (chết/ra tầm) — vẫn cast thử vào nó.")
    tname = before.get(target, {}).get("name", "?")
    print(f"\n==> PHA 2: CAST 3 PHÁT skill {skill} vào '{tname}' (id={target}). Liếc thanh MANA xem có tụt.\n")
    print(f"   [BASELINE] {len(before)} con quanh:")
    for mid, info in before.items():
        mark = "  <== MỤC TIÊU" if mid == target else ""
        print(f"     id={mid:<8} hp%={info['hp']}  {info['name']}{mark}")

    for _i in range(3):                                  # chùm 3 phát ~0.6s (đúng nhịp niệm của auto), tránh 1 phát lỡ
        bot.send_gs('eDoSkillTargetNpc', skillid=int(skill), nid=str(target))
        t1 = time.time()
        while time.time() - t1 < 0.6:
            try: bot.poll_recv()
            except: pass
            time.sleep(0.05)
    print(f"   >>> đã gửi 3× eDoSkillTargetNpc(skillid={skill}, nid={target}). Đọc lại HP%...")
    after = snap()

    print(f"\n=== KẾT QUẢ (HP% trước → sau) ===")
    any_drop = False
    for mid, info in before.items():
        hb = info["hp"]; ha = after.get(mid, {}).get("hp")
        gone = mid not in after
        drop = (hb is not None and ha is not None and ha < hb)
        if drop or (gone and mid == target): any_drop = True
        mark = " <== MỤC TIÊU" if mid == target else ""
        tail = "  💥 TỤT MÁU" if drop else ("  ☠️ biến mất (chết?)" if gone else "")
        print(f"   id={mid:<8} {hb} → {('—(mất)' if gone else ha)}  {info['name']}{mark}{tail}")
    tb = before.get(target, {}).get("hp"); ta = after.get(target, {}).get("hp")
    print("\n----- KẾT LUẬN -----")
    if target not in after:
        print(f"☠️ Mục tiêu biến mất sau chùm cast → nhiều khả năng CHẾT = replay GÂY DAME (skill {skill} dùng được).")
    elif tb is not None and ta is not None and ta < tb:
        print(f"✅ Mục tiêu {tb}%→{ta}% = replay skill {skill} GÂY DAME khi TRONG TẦM. 'Vừa đi vừa đánh' KHẢ THI.")
    elif any_drop:
        print(f"✅ Có con tụt máu (dù mục tiêu không đổi) → skill {skill} có tác dụng diện rộng/đổi mục tiêu.")
    else:
        print(f"❌ Không con nào tụt máu sau 3 phát. Nếu thanh MANA CÓ tụt → skill fire nhưng KHÔNG dame "
              f"(cần state cast/lock client). Nếu mana KHÔNG tụt → gói bị server bỏ (sai fd/skillId/tầm).")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[*] Dừng.")
