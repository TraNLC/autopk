# -*- coding: utf-8 -*-
"""test_f20_debug.py — AUDIT F20: dò backdoor DEBUG còn bật server-side.

Test 2 thứ:
  A) op37 `eNpcDebug{uuid,mapX,mapY,direction,name}` — opcode tên DEBUG đi client->server. Nếu server XỬ LÝ
     (spawn NPC/object, trả gói tham chiếu tên/uuid mình gửi) trên acc THƯỜNG = BACKDOOR -> báo dev tắt.
  B) Lệnh `biln.*` qua chat (memory: là lệnh CLIENT-side, KỲ VỌNG server KHÔNG phản hồi). Quan sát để chắc
     server không có nhánh xử lệnh dev qua chat.

Tiêu chí: gửi xong, BẮT recv vài giây. Có gói server tham chiếu marker mình gửi / opcode lạ phát sinh = server
CÓ xử = đáng ngờ. Im hoàn toàn = nhiều khả năng an toàn (server bỏ qua).

CÁCH DÙNG (acc TEST):
  1. TẮT UI Auto.
  2. venv/bin/python test_f20_debug.py
  3. Copy toàn bộ output gửi lại.
"""
import sys
import time
import subprocess
import platform

sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot
from core.adb_helper import ADB_PATH

PACKAGE = "vn.perfingame.jx1mobile"
MARKER = "ZZAUDIT37"   # tên đặc biệt để grep trong gói server trả
NOISE = {7, 8, 9, 16, 17, 18, 19, 20, 23, 63, 66}


def detect_device():
    if platform.system() == "Darwin":
        for p in [26624, 26656, 26688, 16384, 22471, 5555]:
            subprocess.run(f"{ADB_PATH} connect 127.0.0.1:{p}", shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3)
    try:
        out = subprocess.check_output(f"{ADB_PATH} devices", shell=True).decode().strip().split("\n")
    except Exception as e:
        print(f"[-] adb devices lỗi: {e}")
        return None
    for line in out[1:]:
        if "device" in line and "offline" not in line:
            dev = line.split("\t")[0]
            if dev.startswith("emulator-"):
                continue
            try:
                pid = subprocess.check_output(f"{ADB_PATH} -s {dev} shell pidof {PACKAGE}",
                                              shell=True, stderr=subprocess.DEVNULL).decode().strip()
                if pid:
                    return dev
            except Exception:
                pass
    return None


def capture(bot, seconds):
    """Bắt recv trong `seconds`, trả list packet (đã trừ buffer)."""
    got = []
    bot.recv_buffer = []
    t0 = time.time()
    while time.time() - t0 < seconds:
        try:
            bot.poll_recv()
        except Exception:
            pass
        if getattr(bot, "recv_buffer", None):
            got.extend(bot.recv_buffer)
            bot.recv_buffer = []
        time.sleep(0.15)
    return got


def report(label, pkts):
    notable = [p for p in pkts if p.get("opcode") not in NOISE]
    marker_hits = [p for p in pkts if MARKER.encode().hex() in (p.get("hex", "") or "").lower()
                   or "5a5a4155444954" in (p.get("hex", "") or "").lower()]  # 'ZZAUDIT' hex
    print(f"\n--- {label} ---")
    print(f"  tổng gói nhận: {len(pkts)} | đáng chú ý (bỏ noise): {len(notable)}")
    for p in notable[:25]:
        print(f"    ← op{p.get('opcode')} ({p.get('name')})  {(p.get('hex') or '')[:70]}")
    if marker_hits:
        print(f"  ⚠️ CÓ {len(marker_hits)} gói server CHỨA marker '{MARKER}' -> SERVER ĐÃ XỬ LÝ gói debug! (backdoor)")
    else:
        print(f"  (không thấy gói nào chứa marker '{MARKER}')")


def main():
    dev = detect_device()
    if not dev:
        print("[-] Không thấy giả lập đang chạy game.")
        return
    print(f"[*] Device: {dev}")
    bot = VLTK1Bot(device_id=dev)
    if not bot.connect():
        print("[-] connect() FAIL.")
        return
    try:
        info = bot.get_player_info() or {}
        print(f"[*] recvAny={bot.rpc.ping().get('recvAny')} | mapId={info.get('mapId')}")
    except Exception:
        info = {}

    # ===== TEST A: eNpcDebug(37) =====
    print("\n" + "=" * 56)
    print("TEST A — op37 eNpcDebug (opcode DEBUG). Gửi 1 gói + bắt 6s.")
    print("=" * 56)
    capture(bot, 0.5)   # xả
    ok = bot.send_gs("eNpcDebug", uuid="audit-probe", mapX=1000, mapY=1000, direction=0, name=MARKER)
    print(f"[*] đã gửi eNpcDebug (name='{MARKER}'), send_gs={ok}")
    pkts = capture(bot, 6)
    report("Phản hồi sau eNpcDebug", pkts)
    print("  [i] Nếu trong game XUẤT HIỆN NPC/object tên ZZAUDIT37 -> backdoor spawn. Nhìn màn hình giúp.")

    # ===== TEST B: lệnh biln.* qua chat =====
    print("\n" + "=" * 56)
    print("TEST B — lệnh biln.* qua chat (kỳ vọng CLIENT-side, server KHÔNG xử).")
    print("=" * 56)
    cmds = [
        "biln.emulate.run",
        "biln.map.findingpath.debug",
        "biln.export.minimap.image",
        "@itemall", "//give", ".gm", "#spawn",   # vài mẫu GM-pattern phổ biến để dò (không rõ cú pháp thật)
    ]
    for c in cmds:
        capture(bot, 0.3)
        bot.chat(c, channel=1)
        pk = capture(bot, 2.5)
        nt = [p for p in pk if p.get("opcode") not in NOISE]
        chat_back = [p for p in pk if p.get("opcode") == 133]
        print(f"  gửi {c!r:36} -> nhận {len(pk)} gói, đáng chú ý {len(nt)}, chat-trả {len(chat_back)}")
        for p in nt[:4]:
            print(f"       ← op{p.get('opcode')} ({p.get('name')}) {(p.get('hex') or '')[:50]}")

    print("\n[KẾT LUẬN] Gửi tôi toàn bộ output. Đánh giá: A có gói tham chiếu marker / spawn = BACKDOOR (nặng);"
          " B có chat-trả/đồ/đổi state = server xử lệnh dev. Im hết = F20 an toàn trên acc thường.")


if __name__ == "__main__":
    main()
