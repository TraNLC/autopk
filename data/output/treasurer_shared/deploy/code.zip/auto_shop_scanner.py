#!/usr/bin/env python3
"""
Auto Shop Scanner - Tự động quét tất cả cửa hàng Thợ Rèn và xây dựng từ điển
Cách hoạt động:
  1. Gửi lệnh eGotoNpc đến từng Thợ Rèn (theo shopkey pattern)
  2. Bắt response eShopTypeOne chứa danh sách vật phẩm
  3. Decode từng ShopItem (genre, detail, particular) -> tên vật phẩm
  4. Lưu vào shop_dict.json
"""

import time
import json
import struct
import sys

sys.path.insert(0, '.')
from features.bot.game_bot import VLTK1Bot
from proto.vltk1_protocol import encode_message_fields, decode_message_fields, MS_OPCODES

# ==================== CẤU HÌNH ====================

DEVICE_ID = "127.0.0.1:26624"

# Danh sách tất cả shopkey cần quét (pattern: tên_npc.thành)
# Format dựa trên shopkey tho.ren.thanh.thi.1 đã xác nhận
SHOP_KEYS_TO_SCAN = [
    # Thợ Rèn - Các Thành Thị
    "tho.ren.thanh.thi.1",
    "tho.ren.thanh.thi.2",
    "tho.ren.thanh.thi.3",
    # Long Tuyền Thôn  
    "tho.ren.long.tuyen.thon.1",
    "tho.ren.long.tuyen.thon",
    # Ba Lăng Huyện
    "tho.ren.ba.lang.huyen.1",
    "tho.ren.ba.lang.huyen",
    # Phượng Tường
    "tho.ren.phuong.tuong.1",
    "tho.ren.phuong.tuong",
    # Tương Dương
    "tho.ren.tuong.duong.1",
    "tho.ren.tuong.duong",
    # Trường Thành
    "tho.ren.truong.thanh.1",
    "tho.ren.truong.thanh",
    # Lạc Dương
    "tho.ren.lac.duong.1",
    "tho.ren.lac.duong",
    # Tạp Hóa - Thành Thị
    "tap.hoa.thanh.thi.1",
    "tap.hoa.thanh.thi.2",
    # Tạp Hóa - các thôn
    "tap.hoa.long.tuyen.thon.1",
    "tap.hoa.long.tuyen.thon",
    "tap.hoa.ba.lang.huyen.1",
    "tap.hoa.ba.lang.huyen",
    "tap.hoa.phuong.tuong.1",
    "tap.hoa.phuong.tuong",
    # Dược Điếm
    "hieu.thuoc.thanh.thi",
    "hieu.thuoc.long.tuyen.thon",
    "hieu.thuoc.ba.lang.huyen",
    "hieu.thuoc.phuong.tuong",
]

# ==================== LOAD ITEM DATABASE ====================

def build_item_db():
    """Xây dựng bảng tra cứu (genre, detail, particular) -> tên vật phẩm"""
    db = {}
    item_files = [
        ("data/output/json/item_meleeweapon.json", "Vũ khí cận chiến"),
        ("data/output/json/item_armor.json", "Giáp"),
        ("data/output/json/item_helm.json", "Mũ"),
        ("data/output/json/item_boot.json", "Giày"),
        ("data/output/json/item_belt.json", "Thắt lưng"),
        ("data/output/json/item_cuff.json", "Vòng tay"),
        ("data/output/json/item_horse.json", "Ngựa"),
        ("data/output/json/item_amulet.json", "Bùa"),
    ]
    
    for fpath, category in item_files:
        try:
            with open(fpath, 'r', encoding='utf-8') as f:
                items = json.load(f)
            for item in items:
                name = item.get('\ufeff0', item.get('0', ''))
                g = item.get('1', 0)
                d = item.get('2', 0)
                p = item.get('3', 0)
                if name:
                    db[(g, d, p)] = name
        except FileNotFoundError:
            pass
    return db

# ==================== PROTOBUF DECODER ====================

def decode_varint(data, pos):
    val = 0
    shift = 0
    while pos < len(data):
        b = data[pos]; pos += 1
        val |= (b & 0x7f) << shift
        if not (b & 0x80):
            break
        shift += 7
    return val, pos

def decode_protobuf(data):
    """Decode protobuf bytes -> dict {field_num: value}"""
    result = {}
    pos = 0
    while pos < len(data):
        if pos >= len(data):
            break
        tag, pos = decode_varint(data, pos)
        field_num = tag >> 3
        wire_type = tag & 0x07
        
        if wire_type == 0:  # varint
            val, pos = decode_varint(data, pos)
            result[field_num] = val
        elif wire_type == 1:  # 64-bit
            result[field_num] = data[pos:pos+8]
            pos += 8
        elif wire_type == 2:  # length-delimited
            length, pos = decode_varint(data, pos)
            val = data[pos:pos+length]
            result[field_num] = val
            pos += length
        elif wire_type == 5:  # 32-bit
            result[field_num] = data[pos:pos+4]
            pos += 4
        else:
            break
    return result

def decode_shopitem(data):
    """Decode ShopItem protobuf: cost, lockstate, genre, detail, particular..."""
    fields = decode_protobuf(data)
    return {
        'cost': fields.get(1, 0),
        'lockstate': fields.get(2, 0),
        'genre': fields.get(6, 0),
        'detail': fields.get(7, 0),
        'particular': fields.get(8, 0),
        'level': fields.get(9, 0),
        'series': fields.get(10, 0),
    }

def decode_shoptypeone(body_bytes):
    """Decode eShopTypeOne body -> {shopkey, shopname, items: [{itemindex, name, cost}]}"""
    # ShopTypeOne: field 1 = ShopData (nested message)
    fields = decode_protobuf(body_bytes)
    
    shopdata_bytes = fields.get(1, b'')
    if isinstance(shopdata_bytes, bytes):
        shopdata_fields = decode_protobuf(shopdata_bytes)
    else:
        return None
    
    shopkey = shopdata_fields.get(1, b'')
    if isinstance(shopkey, bytes):
        shopkey = shopkey.decode('utf-8', errors='replace')
    
    shopname = shopdata_fields.get(2, b'')
    if isinstance(shopname, bytes):
        shopname = shopname.decode('utf-8', errors='replace')
    
    # Items: MapField<int, ShopItem> = field 3 of ShopData in proto, but actually
    # items come as separate repeated fields in MapEntry format
    items = {}
    # Map entries: field 3 = repeated MapEntry (key=int, value=ShopItem)
    raw = shopdata_bytes
    pos = 0
    while pos < len(raw):
        try:
            tag, pos = decode_varint(raw, pos)
            field_num = tag >> 3
            wire_type = tag & 0x07
            
            if wire_type == 2:
                length, pos = decode_varint(raw, pos)
                val_bytes = raw[pos:pos+length]
                pos += length
                
                if field_num == 3:  # Items MapEntry
                    # MapEntry: field 1 = key (int), field 2 = value (ShopItem)
                    entry_fields = decode_protobuf(val_bytes)
                    item_index = entry_fields.get(1, -1)
                    item_bytes = entry_fields.get(2, b'')
                    if isinstance(item_bytes, bytes) and item_index >= 0:
                        item_info = decode_shopitem(item_bytes)
                        item_info['itemindex'] = item_index
                        items[item_index] = item_info
            elif wire_type == 0:
                _, pos = decode_varint(raw, pos)
            elif wire_type == 1:
                pos += 8
            elif wire_type == 5:
                pos += 4
            else:
                break
        except:
            break
    
    return {'shopkey': shopkey, 'shopname': shopname, 'items': items}

# ==================== MAIN SCANNER ====================

def scan_shop_by_key(bot, shopkey, timeout=3.0):
    """Gửi lệnh mở shop bằng shopkey và chờ response"""
    # Dùng eGotoNpc với tên NPC tương ứng
    npc_name = shopkey_to_npc_name(shopkey)
    
    print(f"  Trying: {npc_name} (shopkey={shopkey})")
    
    # Clear buffer trước
    bot.clear_buffer()
    
    # Gửi lệnh eGotoNpc 
    bot.send_gs('eGotoNpc', name=npc_name)
    time.sleep(0.5)
    
    # Gửi eNpcDialogue để mở shop (không cần NPC ID vì Server biết)
    # Gửi eOpenShop trực tiếp với shopkey
    payload = encode_message_fields('ShopBuyItem', shopkey=shopkey, itemindex=0, quantity=0)
    # Actually - gửi eNpcSelect để mở giao diện shop
    
    # Chờ nhận eShopTypeOne
    pkts = bot.wait_for_packet(('eShopTypeOne', 'eShopTypeTwo'), timeout=timeout)
    return pkts

def shopkey_to_npc_name(shopkey):
    """Map shopkey về tên NPC tương ứng"""
    if shopkey.startswith('tho.ren'):
        return 'Thợ Rèn'
    elif shopkey.startswith('tap.hoa'):
        return 'Tạp Hóa'
    elif shopkey.startswith('hieu.thuoc'):
        return 'Hiệu Thuốc'
    return 'NPC'

def probe_shopkey(bot, shopkey):
    """
    Cách thông minh hơn: gửi eShopBuyItem với itemindex=0 để probe shopkey có tồn tại không.
    Nếu Server trả về lỗi thay vì eShopTypeOne -> shopkey không tồn tại.
    Nếu trả về eShopTypeOne -> lấy dữ liệu luôn!
    """
    bot.clear_buffer()
    
    # Gửi lệnh mở shop (eOpenShop opcode 51)
    try:
        bot.send_gs('eOpenShop', shopkey=shopkey)
    except:
        # eOpenShop mungkin không có trong protocol, dùng eNpcDialogue
        pass
    
    pkts = bot.wait_for_packet(('eShopTypeOne', 'eShopTypeTwo', 'eShopTypeThree'), timeout=2.0)
    return pkts

def main():
    print("=" * 60)
    print("AUTO SHOP SCANNER - Quét tất cả cửa hàng và xây dựng từ điển")
    print("=" * 60)
    
    # Load item DB  
    print("\n[1/3] Đang load Item Database từ JSON files...")
    item_db = build_item_db()
    print(f"  Loaded {len(item_db)} items from game data files")
    
    # Kết nối Bot
    print("\n[2/3] Đang kết nối Frida Bot...")
    bot = VLTK1Bot(device_id=DEVICE_ID)
    if not bot.connect():
        print("FAILED: Không kết nối được Frida!")
        return
    print("  Connected!")
    
    # Quét từng shopkey
    print(f"\n[3/3] Đang quét {len(SHOP_KEYS_TO_SCAN)} shop keys...")
    
    shop_dict = {}
    try:
        with open("features/bot/shop_dict.json", "r", encoding="utf-8") as f:
            shop_dict = json.load(f)
        print(f"  Loaded {len(shop_dict)} existing entries from shop_dict.json")
    except:
        pass
    
    results = {}
    
    for shopkey in SHOP_KEYS_TO_SCAN:
        print(f"\n--- Scanning: {shopkey} ---")
        
        # Gửi lệnh GotoNpc
        npc_name = shopkey_to_npc_name(shopkey)
        bot.clear_buffer()
        
        try:
            bot.send_gs('eGotoNpc', name=npc_name)
        except Exception as e:
            print(f"  Error sending eGotoNpc: {e}")
        
        time.sleep(0.5)
        
        # Chờ response
        pkts = bot.wait_for_packet(('eShopTypeOne', 'eShopTypeTwo'), timeout=3.0)
        
        if pkts:
            print(f"  ✅ Nhận được {len(pkts)} gói tin shop!")
            for pkt in pkts:
                pkt_body = bytes.fromhex(pkt['hex'])[6:]
                shop_info = decode_shoptypeone(pkt_body)
                if shop_info:
                    real_shopkey = shop_info['shopkey']
                    print(f"  ShopKey thực: {real_shopkey}")
                    print(f"  ShopName: {shop_info['shopname']}")
                    print(f"  Items ({len(shop_info['items'])}):")
                    
                    item_name_map = {}
                    for idx, item in shop_info['items'].items():
                        g = item['genre']
                        d = item['detail']
                        p = item['particular']
                        name = item_db.get((g, d, p), f"Unknown(g={g},d={d},p={p})")
                        cost = item['cost']
                        print(f"    [{idx}] {name} | cost={cost} | g={g},d={d},p={p}")
                        item_name_map[name.lower()] = idx
                    
                    if real_shopkey and item_name_map:
                        results[real_shopkey] = item_name_map
                        shop_dict[real_shopkey] = item_name_map
        else:
            print(f"  ❌ Không tìm thấy shop với key này")
        
        time.sleep(0.3)
    
    # Lưu kết quả
    print("\n" + "=" * 60)
    print(f"Đã quét xong! Tìm thấy {len(results)} shop mới.")
    
    with open("features/bot/shop_dict.json", "w", encoding="utf-8") as f:
        json.dump(shop_dict, f, ensure_ascii=False, indent=2)
    
    print(f"Đã lưu vào features/bot/shop_dict.json!")
    print("\nTổng kết:")
    for key, items in shop_dict.items():
        print(f"  {key}: {len(items)} vật phẩm")

if __name__ == '__main__':
    main()
