import sys, time
sys.path.insert(0,'.')
from core.adb_helper import ADB_PATH
from core.device_discovery import discover_devices
from features.bot.game_bot import VLTK1Bot
from core.stall_shopper import scan_stalls
def name_of(bot, cid):
    try:
        if hasattr(bot,'recv_buffer'): bot.recv_buffer=[]
        bot.poll_recv()
        bot.send_gs('eOpenPlayerInfoRequest', targetCid=str(cid))
        pkts=bot.wait_for_packet((170,), timeout=2.5)
        for p in (pkts or []):
            if p.get('opcode')==170:
                b=bytes.fromhex(p.get('hex',''))[6:]
                if b and b[0]==0x0a:
                    f1=b[2:2+b[1]]; q=0
                    while q<len(f1):
                        tag=f1[q]; q+=1
                        if tag==0x12:
                            ln=f1[q]; q+=1; return f1[q:q+ln].decode('utf-8','ignore')
                        elif (tag&7)==2: ln=f1[q]; q+=1+ln
                        elif (tag&7)==0:
                            while q<len(f1) and f1[q]&0x80: q+=1
                            q+=1
                        else: break
    except Exception as e: print("  name lỗi",e)
    return None
dev=discover_devices(ADB_PATH,package="vn.perfingame.jx1mobile")[0]
bot=VLTK1Bot(device_id=dev); bot.connect(); time.sleep(2)
cat=scan_stalls(bot, merge=False)
cands=[(cid,its) for cid,its in (cat or {}).items() if its and its[0].get('price')==30000]
print(f"sạp món-đầu = 3 vạn (30000): {len(cands)} sạp → resolve tên:")
for cid,its in cands:
    nm=name_of(bot, cid)
    print(f"  cid={cid} | tên={nm!r} | món đầu g{its[0].get('genre')}d{its[0].get('detail')}p{its[0].get('particular')}lv{its[0].get('level')}")
    if nm and 'Cái Thế Ma Tôn' in nm:
        print(f"  ⬅⬅ TÌM THẤY 'Cái Thế Ma Tôn' = cid {cid}")
