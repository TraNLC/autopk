# -*- coding: utf-8 -*-
"""auto_huyhoang.py — TỰ HÁI Quả Huy Hoàng, KHOÁ 1 QUẢ TRONG TẦM (mỗi lượt chỉ hái được 1 quả).

Sự thật cơ chế (user chốt 2026-06-17):
  - TẤT CẢ quả trong bãi chín CÙNG LÚC (sóng ~5 phút), chỉ chín vài giây.
  - MỖI LƯỢT CHỈ HÁI ĐƯỢC 1 QUẢ -> KHÔNG cần bắn nhiều quả, chỉ KHOÁ ĐÚNG 1 QUẢ.
  - Click quả chín 1 lần -> mở kênh ~10s -> quả TỰ biến mất = nhặt xong (click lại = RESET kênh).

CHIẾN THUẬT: khoá 1 quả ĐANG TRONG TẦM (quả trả lời op48; quả ngoài tầm bỏ — lỗi hôm qua là khoá nhầm quả
  ngoài tầm rồi bấm 72 lần vô ích, phí cả lượt). Dò chín bằng click-thử DÀY (chưa chín = vô hại). Cú click ra
  "giây" = cú mở kênh -> DỪNG, chờ ~11s không đụng. Quả biến mất = nhặt xong -> chọn quả khác.

Click = eNpcDialogue(op33, npcId). Quả = NPC id CAO (>=10000).

Dùng: (TẮT UI cửa sổ đó)  venv/bin/python -u auto_huyhoang.py [secs] [device]
"""
import sys, time, os
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

_a = sys.argv[1:]
SECS = next((int(x) for x in _a if x.isdigit() and int(x) > 60), 1800)
DEV = next((x for x in _a if (":" in x or x.startswith("emulator"))), "127.0.0.1:26624")
QUA_MIN_ID = 10000            # quả = khối NPC id CAO (bắt live: 12xxx); NPC thật quanh đó <3000.
RIPE_HEX = "6769c3a279"       # "giây" trong "N giây sau nhặt được" = quả CHÍN (op48). Chưa chín -> không có.
WAIT_SECS = 11.0             # chờ sau khi NHẤN 1 LẦN lúc chín (kênh ~10s + biên). KHÔNG nhấn trong lúc chờ.
PROBE_GAP = 0.8              # GIÃN giữa 2 cú click-thử trên CÙNG 1 quả (KHÔNG spray) — "click 1 lần rồi chờ".
NORESP_SWITCH = 3            # quả click ngần này lần KHÔNG phản hồi op48 = NGOÀI TẦM -> đổi quả khác.
NOISE = {7, 8, 9, 16, 17, 18, 19, 20, 23, 40, 54, 63, 66, 69, 70, 251}
_tag = ("".join(c for c in DEV if c.isdigit())[-5:]) or "dev"
LOG = f"data/output/auto_huyhoang_{_tag}.log"
os.makedirs("data/output", exist_ok=True)
_lf = open(LOG, "w", encoding="utf-8")


def emit(s):
    print(s, flush=True); _lf.write(s + "\n"); _lf.flush()


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect():
        emit("connect FAIL (UI bot còn attach? tắt rồi chạy lại)"); return
    bot.capture_sent = True
    for _ in range(6):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.3)
    try: bot.redetect_fd_by_traffic()
    except Exception as e: emit(f"redetect: {e}")
    try:
        p = bot.rpc.ping(); emit(f"gameFd={p.get('gameFd')} recvAny={p.get('recvAny')}")
    except Exception as e:
        emit(f"ping: {e}")

    _last_raw = [[]]
    def qua_ids():
        try:
            r = bot.rpc.get_near_npcs_safe() or {}
            allids = []
            for n in (r.get("npcs") or []):
                try: allids.append(int(n.get("id")))
                except: pass
            _last_raw[0] = sorted(allids)
            return sorted(i for i in allids if i >= QUA_MIN_ID)
        except Exception:
            return []

    def drain():
        try: bot.poll_recv()
        except: pass
        return list(getattr(bot, "recv_buffer", []) or [])

    seen = [len(drain())]
    def classify_after_click():
        """Click xong settle 0.13s -> đọc op48 MỚI: 'ripe'(có 'giây') | 'unripe' | None(không phản hồi)."""
        time.sleep(0.13)
        buf = drain(); res = None
        for pk in buf[seen[0]:]:
            if pk.get("opcode") == 48:
                if RIPE_HEX in (pk.get("hex") or "").lower():
                    res = 'ripe'; break
                if res is None:
                    res = 'unripe'
        seen[0] = len(buf)
        return res

    def dump_reward(label):
        emit(f"       {label} — gói IN (tìm thưởng):")
        buf = drain()
        for pk in buf[max(0, seen[0] - 14):]:
            op = pk.get("opcode")
            if op not in NOISE:
                emit(f"         ←IN op{op} ({pk.get('name')}) {(pk.get('hex') or '')[:140]}")
        seen[0] = len(buf)

    emit(f"[*] HÁI khoá-1-quả-trong-tầm {SECS}s | {DEV}. log={LOG}\n")
    t0 = time.time()
    target = None; ripe_at = 0.0; clicks = 0; noresp = 0; harvested = 0
    tried = set()           # quả đã thử lượt này mà ngoài tầm -> không chọn lại tới khi đổi danh sách
    last_beat = 0.0

    while time.time() - t0 < SECS:
        now = time.time()
        ids = qua_ids()

        if not ids:
            if target is not None and ripe_at and (now - ripe_at) >= 9:   # đang chờ mà bãi sạch = nhặt xong
                harvested += 1; emit(f"  t+{int(now-t0)}s ✅ nhặt xong (bãi sạch). Tổng hái={harvested}")
            target = None; ripe_at = 0.0; tried.clear()
            if now - last_beat > 12:
                last_beat = now
                emit(f"  --- t+{int(now-t0)}s: 0 quả (id>={QUA_MIN_ID}) | hái {harvested} | NPC thô={_last_raw[0]} ---")
            time.sleep(0.5); continue

        # ---- CHỌN 1 QUẢ TRONG TẦM (bỏ quả đã xác định ngoài tầm) ----
        if target is None or target not in ids:
            if target is not None and ripe_at:            # quả đang chờ vừa biến mất = nhặt xong
                harvested += 1
                dump_reward(f"  t+{int(now-t0)}s ✅ quả {target} nhặt xong (chờ {now-ripe_at:.0f}s). Tổng hái={harvested}")
            cand = [i for i in ids if i not in tried] or ids   # hết quả chưa thử -> thử lại từ đầu
            target = cand[0]; ripe_at = 0.0; clicks = 0; noresp = 0
            emit(f"  t+{int(now-t0)}s 🎯 KHOÁ quả {target} (trong {len(ids)} quả): dò chín → chín nhấn 1 lần → chờ {WAIT_SECS:.0f}s.")

        # ---- ĐÃ CHÍN & ĐÃ NHẤN: chờ, TUYỆT ĐỐI không đụng (đụng = reset 10s) ----
        if ripe_at:
            waited = now - ripe_at
            if target not in ids:                          # đã xử ở nhánh chọn quả; phòng hờ
                harvested += 1; target = None; ripe_at = 0.0; continue
            if waited >= WAIT_SECS:                         # hết chờ quả còn -> hụt/bị reset -> nhấn lại 1 lần
                bot.talk_npc(str(target)); clicks += 1; ripe_at = now
                emit(f"  t+{int(now-t0)}s 🔁 chờ đủ mà quả {target} còn → nhấn lại 1 lần, chờ tiếp.")
            time.sleep(0.4); continue

        # ---- DÒ CHÍN: click-thử (chưa chín = vô hại) ----
        bot.talk_npc(str(target)); clicks += 1
        r = classify_after_click()
        if r == 'ripe':
            ripe_at = now; noresp = 0
            emit(f"  t+{int(now-t0)}s 🍎🔥 quả {target} CHÍN! nhấn 1 lần → CHỜ {WAIT_SECS:.0f}s, KHÔNG nhấn nữa.")
        elif r is None:
            noresp += 1
            if noresp >= NORESP_SWITCH:                    # ngoài tầm -> bỏ, đổi quả khác TRONG TẦM
                tried.add(target)
                emit(f"  t+{int(now-t0)}s ↪️ quả {target} ngoài tầm ({noresp} lần im) → đổi quả khác.")
                target = None
        else:
            noresp = 0
        if now - last_beat > 8:
            last_beat = now
            emit(f"  --- t+{int(now-t0)}s: {len(ids)} quả | khoá {target} | {clicks} cú click-thử (giãn {PROBE_GAP}s) | hái {harvested} ---")
        time.sleep(PROBE_GAP)        # GIÃN: click 1 lần rồi CHỜ, KHÔNG spray (tránh click đè lúc vừa chín = reset)

    emit(f"\n[xong] {SECS}s | đã hái ~{harvested} quả. Log: {LOG}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        emit("\n[*] Dừng.")
    finally:
        _lf.close()
