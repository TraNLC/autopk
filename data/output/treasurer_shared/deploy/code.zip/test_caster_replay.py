# -*- coding: utf-8 -*-
"""test_caster_replay.py — CHỨNG MINH replay op239 caster GÂY DAME (KHÔNG cần gói khoá-target).

Bắt live 2026-06-16: đánh chiêu tay caster (skill 362) = CHỈ op239(skillid,nid) và con CHẾT. Test này
replay op239 N lần (mặc định 30, ~nhịp niệm tay) lên 1 con TRONG TẦM, KHÔNG đụng tay → đo HP% trước/sau.
Con tụt máu/chết = replay caster auto được. (Lần trước "0 dame" do chỉ 3 phát + HP đọc %/100 thô.)

⚠️ TRONG LÚC TEST: ĐỨNG YÊN, KHÔNG đánh tay con nào (để kết quả KHÔNG nhiễm bởi đòn tay).

Dùng: TẮT UI cửa sổ đó → venv/bin/python -u test_caster_replay.py [device] [skillId] [nid] [n]
  vd:  venv/bin/python -u test_caster_replay.py 127.0.0.1:26624 362        (tự chọn con gần nhất còn sống)
       venv/bin/python -u test_caster_replay.py 127.0.0.1:26624 362 1359 30
"""
import sys, time
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

_a = sys.argv[1:]
DEV = next((x for x in _a if (":" in x or x.startswith("emulator"))), "127.0.0.1:26624")
_nums = [x for x in _a if x.isdigit()]
SKILL = int(_nums[0]) if len(_nums) >= 1 else 362
NID = _nums[1] if len(_nums) >= 2 else None        # nid con mục tiêu (chuỗi). None = tự chọn con còn sống đầu.
N = int(_nums[2]) if len(_nums) >= 3 else 30        # số phát replay


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect():
        print("connect FAIL (UI bot còn attach? tắt rồi chạy lại)"); return
    bot.capture_sent = True
    for _ in range(6):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.3)
    try: bot.redetect_fd_by_traffic()
    except Exception as e: print(f"redetect: {e}")
    try:
        p = bot.rpc.ping(); print(f"gameFd={p.get('gameFd')} recvAny={p.get('recvAny')}")
        pi = bot.rpc.get_player_info() or {}; print(f"CHAR = {pi.get('name')!r}")
    except Exception as e: print(f"ping/char: {e}")

    def snap():
        try: r = bot.rpc.get_near_npcs_detail() or {}
        except Exception: return {}
        return {str(n.get("id")): {"name": n.get("name") or "?", "hp": n.get("hp")}
                for n in (r.get("npcs") or []) if (n.get("hpMax", 0) or 0) > 0}

    target = NID
    # ---- PHA HỌC: nếu KHÔNG truyền nid → HỌC con bạn vừa đánh tay (CHẮC CHẮN TRONG TẦM) ----
    if target is None:
        print("\n==> PHA HỌC (≤15s): ĐÁNH CHIÊU TAY 1 con quái sát bạn vài lần → học nid (con đó chắc chắn TRONG TẦM).")
        print("    (học xong tôi báo → bạn DỪNG tay, để replay chạy sạch.)\n")
        bot.sent_buffer = []; t0 = time.time()
        while time.time() - t0 < 25 and target is None:
            try: bot.poll_recv()
            except: pass
            for pp in list(getattr(bot, "sent_buffer", [])):
                if pp.get("opcode") == 239:
                    try:
                        b = bytes.fromhex(pp.get("hex", ""))[6:]; i = 0; d = {}
                        while i < len(b):
                            tag = b[i]; i += 1; f = tag >> 3; w = tag & 7
                            if w == 0:
                                v = 0; s = 0
                                while i < len(b):
                                    c = b[i]; i += 1; v |= (c & 0x7F) << s; s += 7
                                    if not c & 0x80: break
                                d[f] = v
                            elif w == 2:
                                ln = b[i]; i += 1; d[f] = b[i:i+ln]; i += ln
                            else: break
                        if isinstance(d.get(2), (bytes, bytearray)):
                            target = bytes(d[2]).decode("utf-8", "ignore")
                    except Exception: pass
                    if target: break
            bot.sent_buffer = []; time.sleep(0.05)
        if target is None:
            print("❌ Không học được nid (chưa đánh tay đúng lúc / fd sai). Chạy lại + đánh chiêu tay liên tục."); return
        print(f">>> HỌC ĐƯỢC nid={target}. 🛑 DỪNG ĐÁNH TAY + TẮT AUTOPLAY NGAY — hands off hoàn toàn!")
        time.sleep(2.0)
    tname = (snap().get(target, {}) or {}).get("name", "?")
    # ---- KIỂM CHỨNG CHỐNG NHIỄM: theo dõi 5s KHÔNG cast. HP target tự tụt = autoplay/đòn khác đang đánh → test HỎNG ----
    print(f"\n==> KIỂM CHỨNG 5s (KHÔNG gửi gói gì) — HP {tname}#{target} phải ĐỨNG YÊN nếu không có gì khác đánh:")
    h0 = (snap().get(target, {}) or {}).get("hp")
    for s in range(5):
        t1 = time.time()
        while time.time() - t1 < 1.0:
            try: bot.poll_recv()
            except: pass
            time.sleep(0.05)
        hc = (snap().get(target, {}) or {}).get("hp")
        print(f"   +{s+1}s: HP% {target} = {('mất' if target not in snap() else hc)}")
    h_stable = (snap().get(target, {}) or {}).get("hp")
    if target not in snap():
        print("⚠️⚠️ Target CHẾT khi tôi CHƯA gửi gói nào → AUTOPLAY/đòn khác đang đánh → test HỎNG. Tắt autoplay + hands off, chạy lại."); return
    if h0 is not None and h_stable is not None and h_stable < h0:
        print(f"⚠️⚠️ HP TỰ TỤT ({h0}→{h_stable}) khi tôi CHƯA gửi gói → có thứ KHÁC đang đánh (autoplay?) → KẾT QUẢ SẼ NHIỄM. Tắt hẳn rồi chạy lại."); return
    print(f"   ✓ HP đứng yên ở {h_stable}% suốt 5s = SẠCH (không gì khác đánh). Giờ mới replay.")
    before = snap()
    if target not in before:
        print(f"⚠️ con {target} mất — dừng."); return
    print(f"\n==> REPLAY {N}× op239(skill={SKILL}, nid={target} '{tname}'). (baseline replay = {h_stable}%)\n")

    for i in range(N):
        bot.send_gs('eDoSkillTargetNpc', skillid=int(SKILL), nid=str(target))
        t1 = time.time()
        while time.time() - t1 < 0.8:        # ~nhịp niệm tay; poll để giữ recv tươi
            try: bot.poll_recv()
            except: pass
            time.sleep(0.05)
        if (i + 1) % 5 == 0:
            cur = snap().get(target, {}).get("hp")
            print(f"   ...{i+1}/{N} phát | HP% {tname}#{target} = {('mất' if target not in snap() else cur)}")

    after = snap()
    print("\n=== KẾT QUẢ (HP% trước → sau) ===")
    for mid, info in before.items():
        ha = after.get(mid, {}).get("hp")
        gone = mid not in after
        drop = (info["hp"] is not None and ha is not None and ha < info["hp"])
        mark = " <== MỤC TIÊU" if mid == target else ""
        tail = "  💥 TỤT" if drop else ("  ☠️ MẤT" if gone else "")
        print(f"   {info['name']}#{mid}: {info['hp']} → {('mất' if gone else ha)}{mark}{tail}")
    tb = before.get(target, {}).get("hp"); ta = after.get(target, {}).get("hp")
    print("\n----- KẾT LUẬN -----")
    if target not in after:
        print(f"☠️✅ Mục tiêu CHẾT sau {N} phát replay (bạn KHÔNG đánh tay) = caster op239 GÂY DAME → auto được.")
    elif tb is not None and ta is not None and ta < tb:
        print(f"✅ Mục tiêu {tb}%→{ta}% = replay caster CÓ dame. Auto 'vừa đi vừa đánh' khả thi (cần ở trong tầm).")
    else:
        print(f"❌ Mục tiêu KHÔNG đổi HP. Nếu mana CÓ tụt → nghi NGOÀI TẦM (đứng sát hơn) hoặc nid sai. "
              f"Nếu mana KHÔNG tụt → gói bị bỏ (sai fd/skill).")


if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: print("\n[*] Dừng.")
