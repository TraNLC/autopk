# -*- coding: utf-8 -*-
"""scan_huyhoang.py — QUÉT LIÊN TỤC object quanh nhân vật để TÌM "Quả Huy Hoàng".

Quét 3 nguồn mỗi vòng (~1.5s), in object MỚI / BIẾN MẤT + 1 mục lọc riêng cho QUẢ:
  - NPC gần      : getNearNpcsSafe   -> [{id, name}]
  - OBJECT gần   : getNearObjects    -> [{id, name, cls}]   (node hái / vật phẩm scene THƯỜNG ở đây)
  - PLAYER gần   : getNearPlayers    -> [{id}]
Lọc QUẢ = name/cls chứa 'qua'/'quả'/'huy hoang'/'huy hoàng'/'fruit'/'gather'/'harvest'.

CÁCH DÙNG:
  1. TẮT hẳn UI Auto (Frida attach 1 lần).
  2. Đứng ở bãi quả.
  3. Chạy:  venv/bin/python scan_huyhoang.py
     (nhiều cửa sổ -> chỉ định đúng device:  venv/bin/python scan_huyhoang.py 127.0.0.1:26656)
  4. Ctrl+C để dừng. Gửi tôi output (nhất là dòng [QUẢ?] + diag.fields nếu có).
"""
import sys
import time
import subprocess
import platform
import unicodedata

sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot
from core.adb_helper import ADB_PATH

PACKAGE = "vn.perfingame.jx1mobile"
# từ khoá nhận diện quả huy hoàng (so khớp sau khi bỏ dấu + lower)
QUA_KW = ("qua", "huy hoang", "fruit", "gather", "harvest", "thu hoach", "hai")


def _norm(s):
    s = unicodedata.normalize("NFD", str(s or ""))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.lower()


def is_qua(name, cls=""):
    blob = _norm(name) + " " + _norm(cls)
    return any(k in blob for k in QUA_KW)


def detect_device():
    if platform.system() == "Darwin":
        for p in [26624, 26656, 26688, 26720, 26880, 16384, 22471, 5555]:
            subprocess.run(f"{ADB_PATH} connect 127.0.0.1:{p}", shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3)
    try:
        out = subprocess.check_output(f"{ADB_PATH} devices", shell=True).decode().strip().split("\n")
    except Exception as e:
        print(f"[-] adb devices lỗi: {e}")
        return None
    for line in out[1:]:
        if "device" in line and "offline" not in line:
            dev = line.split("\t")[0]
            if dev.startswith("emulator-"):
                continue
            try:
                pid = subprocess.check_output(f"{ADB_PATH} -s {dev} shell pidof {PACKAGE}",
                                              shell=True, stderr=subprocess.DEVNULL).decode().strip()
                if pid:
                    return dev
            except Exception:
                pass
    return None


def scan(bot):
    """Trả dict {key: (kind, id, name, cls)} — key='kind:id' để theo dõi xuất hiện/biến mất."""
    out = {}
    diag_fields = None
    # NPC
    try:
        r = bot.rpc.get_near_npcs_safe() or {}
        for n in (r.get("npcs") or []):
            out[f"NPC:{n.get('id')}"] = ("NPC", str(n.get("id")), (n.get("name") or "").strip(), "")
    except Exception as e:
        out["_err_npc"] = ("ERR", "", f"npc:{e}", "")
    # OBJECT (node hái / vật phẩm scene)
    try:
        r = bot.rpc.get_near_objects() or {}
        diag_fields = (r.get("diag") or {}).get("fields")
        for n in (r.get("objs") or []):
            out[f"OBJ:{n.get('id')}"] = ("OBJ", str(n.get("id")), (n.get("name") or "").strip(),
                                         (n.get("cls") or "").strip())
    except Exception as e:
        out["_err_obj"] = ("ERR", "", f"obj:{e}", "")
    # PLAYER
    try:
        r = bot.rpc.get_near_players() or {}
        for n in (r.get("players") or []):
            out[f"PLR:{n.get('id')}"] = ("PLR", str(n.get("id")), "", "")
    except Exception:
        pass
    return out, diag_fields


def main():
    dev = detect_device()
    if not dev:
        print("[-] Không thấy giả lập đang chạy game. Mở game trước.")
        return
    print(f"[*] Device: {dev}")
    bot = VLTK1Bot(device_id=dev)
    if not bot.connect():
        print("[-] connect() FAIL — UI Auto còn attach Frida? Tắt UI rồi chạy lại.")
        return
    try:
        print(f"[*] recvAny={bot.rpc.ping().get('recvAny')}")
    except Exception:
        pass
    print("[*] QUÉT LIÊN TỤC (Ctrl+C để dừng)... đứng ở bãi quả.\n")

    prev = {}
    diag_printed = False
    rnd = 0
    while True:
        rnd += 1
        cur, diag_fields = scan(bot)
        if diag_fields and not diag_printed:
            print(f"[diag] getNearObjects value fields = {diag_fields}\n")
            diag_printed = True
        # thay đổi so với vòng trước
        new = [v for k, v in cur.items() if k not in prev and not k.startswith("_")]
        gone = [v for k, v in prev.items() if k not in cur and not k.startswith("_")]
        for kind, oid, nm, cls in new:
            tag = "  ✨MỚI " if not is_qua(nm, cls) else "  ✨🍎QUẢ?"
            print(f"{tag} [{kind}] id={oid} name={nm!r}" + (f" cls={cls!r}" if cls else ""))
        for kind, oid, nm, cls in gone:
            tag = "  ❌MẤT " if not is_qua(nm, cls) else "  ❌🍎QUẢ "
            print(f"{tag} [{kind}] id={oid} name={nm!r}" + (f" cls={cls!r}" if cls else ""))
        # mục lọc QUẢ hiện có (mỗi 5 vòng in tổng quan để dễ nhìn)
        quas = [(kind, oid, nm, cls) for k, (kind, oid, nm, cls) in cur.items()
                if not k.startswith("_") and is_qua(nm, cls)]
        if rnd % 5 == 1:
            n_npc = sum(1 for k in cur if k.startswith("NPC:"))
            n_obj = sum(1 for k in cur if k.startswith("OBJ:"))
            n_plr = sum(1 for k in cur if k.startswith("PLR:"))
            errs = [v[2] for k, v in cur.items() if k.startswith("_err")]
            print(f"[vòng {rnd}] NPC={n_npc} OBJ={n_obj} PLR={n_plr} | QUẢ khớp={len(quas)}"
                  + (f" | LỖI: {errs}" if errs else ""))
            for kind, oid, nm, cls in quas:
                print(f"        🍎 [{kind}] id={oid} name={nm!r}" + (f" cls={cls!r}" if cls else ""))
        prev = cur
        time.sleep(1.5)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[*] Dừng quét.")
