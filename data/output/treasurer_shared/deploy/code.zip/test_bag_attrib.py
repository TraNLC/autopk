"""
test_bag_attrib.py — Probe đọc thuộc tính trang bị trong hành trang.

Mục đích: in ra từng ô bag (slot, genre/detail, isEquip) kèm danh sách thuộc tính
(Attrib.type + value[]) để xác định CHUỖI type thật của "kháng băng", "tăng kháng"...
trước khi viết bộ so khớp nhiệm vụ Dã Tẩu.

CÁCH DÙNG:
  1. TẮT hẳn cửa sổ UI Auto (vì Frida chỉ attach được 1 lần).
  2. Mở game, để trang bị nhiệm vụ (vd món có 'tăng kháng băng') nằm trong rương.
  3. Chạy:  venv/bin/python test_bag_attrib.py
  4. Copy toàn bộ output gửi lại.
"""
import sys
import json
import time
import subprocess
import platform

sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot
from core.adb_helper import ADB_PATH

PACKAGE = "vn.perfingame.jx1mobile"


def detect_device():
    """Dò device giả lập đang chạy game (giống ui_bot_app._refresh_devices)."""
    if platform.system() == "Darwin":
        for p in [26624, 26656, 26688, 16384, 22471, 5555]:
            subprocess.run(f"{ADB_PATH} connect 127.0.0.1:{p}", shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3)
    try:
        out = subprocess.check_output(f"{ADB_PATH} devices", shell=True).decode().strip().split("\n")
    except Exception as e:
        print(f"[-] adb devices lỗi: {e}")
        return None
    for line in out[1:]:
        if "device" in line and "offline" not in line:
            dev = line.split("\t")[0]
            if dev.startswith("emulator-"):
                continue
            try:
                pid = subprocess.check_output(
                    f"{ADB_PATH} -s {dev} shell pidof {PACKAGE}", shell=True,
                    stderr=subprocess.DEVNULL).decode().strip()
                if pid:
                    return dev
            except Exception:
                pass
    return None


def main():
    dev = sys.argv[1] if len(sys.argv) > 1 else detect_device()
    if not dev:
        print("[-] Không tìm thấy giả lập nào đang chạy game. Hãy mở game trước.")
        return
    print(f"[*] Dùng device: {dev}")
    bot = VLTK1Bot(device_id=dev)
    if not bot.connect():
        print("[-] Không kết nối được Frida vào game. Đảm bảo game đang chạy và đã TẮT UI Auto.")
        return

    time.sleep(1.0)
    try:
        res = bot.rpc.dump_bag_items()
    except Exception as e:
        print(f"[-] Lỗi gọi dump_bag_items: {e}")
        bot.close()
        return

    if not res or not res.get("ok"):
        print(f"[-] dump_bag_items thất bại: {res}")
        bot.close()
        return

    print(f"\n===== DIAG: {res.get('diag')} =====")
    items = res.get("items", [])
    items.sort(key=lambda x: (x.get("slot") if isinstance(x.get("slot"), int) else 9999))
    print(f"===== SỐ ITEM TRONG TÚI: {len(items)} =====\n")
    for it in items:
        head = (f"[slot {it.get('slot')}] genre={it.get('genre')} detail={it.get('detail')} "
                f"particular={it.get('particular')} lv={it.get('level')}")
        print(head)
        attribs = it.get("attribs", [])
        for a in attribs:
            print(f"    - type={a.get('type')!r}  value={a.get('value')}")
        if not attribs:
            print("    (không có thuộc tính)")
        print()

    # In raw JSON cuối để chắc chắn không mất dữ liệu
    print("===== RAW JSON =====")
    print(json.dumps(res, ensure_ascii=False))
    bot.close()


if __name__ == "__main__":
    main()
