"""
learn_turnin.py — Sniff TOÀN BỘ chuỗi NỘP nhiệm vụ Dã Tẩu (cả gửi + nhận) để chốt:
  - mở GiveBox bằng gì (eNpcSelect rỗng hay phải tap?) -> có thấy recv 126 eGiveBoxOpen không
  - eGiveBoxSend gửi itemId gì
  - tín hiệu HOÀN THÀNH là gói nào (245 eAwardSelectionAsk / 125 eQuestComplete / 124 update / 16)
+ dump rương quanh lúc nộp để đối chiếu itemId <-> _key/tên.

    venv/bin/python -u learn_turnin.py [giây]   # mặc định 240s
TẮT UI trước. Mở Dã Tẩu -> Đã hoàn thành nv -> bỏ đồ -> Giao nộp -> nhận thưởng.
"""
import sys, time, json, os, subprocess, platform
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot
from core.adb_helper import ADB_PATH
try:
    from proto.vltk1_protocol import GS_OPCODES
except Exception:
    GS_OPCODES = {}

PKG = "vn.perfingame.jx1mobile"
FEED_PATH = "data/output/turnin_feed.txt"

# Gói LIÊN QUAN nộp NV (cả 2 chiều). Lọc nhiễu di chuyển/ping.
OUT_INTEREST = {33, 35, 127, 128, 129, 130, 246}            # gửi đi
IN_INTEREST = {34, 124, 125, 126, 166, 245, 16, 6, 27}      # nhận về
NOISE = {20, 69, 70, 88, 117, 168, 9, 54}


def _feed(line):
    print(line, flush=True)
    try:
        with open(FEED_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def detect():
    if platform.system() == "Darwin":
        for p in [26624, 26656, 26688, 16384, 22471, 5555]:
            subprocess.run(f"{ADB_PATH} connect 127.0.0.1:{p}", shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3)
    for l in subprocess.check_output(f"{ADB_PATH} devices", shell=True).decode().split("\n")[1:]:
        if "device" in l and "offline" not in l:
            d = l.split("\t")[0]
            if not d.startswith("emulator-"):
                try:
                    if subprocess.check_output(f"{ADB_PATH} -s {d} shell pidof {PKG}", shell=True,
                                               stderr=subprocess.DEVNULL).decode().strip():
                        return d
                except Exception:
                    pass
    return None


def _first_field(body):
    if not body:
        return ""
    try:
        tag = body[0]; fnum = tag >> 3; wt = tag & 7
        if wt == 2 and len(body) >= 2:
            ln = body[1]; s = body[2:2+ln]
            try:
                return f"f{fnum}=str({s.decode('utf-8')!r})"
            except Exception:
                return f"f{fnum}=bytes({s.hex()})"
        if wt == 0:
            val = 0; sh = 0; pos = 1
            while pos < len(body):
                b = body[pos]; pos += 1
                val |= (b & 0x7f) << sh
                if not (b & 0x80):
                    break
                sh += 7
            return f"f{fnum}=int({val})"
    except Exception:
        pass
    return ""


def main():
    secs = int(sys.argv[1]) if len(sys.argv) > 1 else 240
    dev = detect()
    if not dev:
        print("[-] no device"); return
    b = VLTK1Bot(device_id=dev)
    if not b.connect():
        print("[-] connect fail"); return
    time.sleep(1)
    try:
        os.makedirs("data/output", exist_ok=True)
        open(FEED_PATH, "w", encoding="utf-8").close()
    except Exception:
        pass

    def on_msg(message, data):
        if message.get("type") != "send":
            return
        p = message.get("payload", {})
        if not isinstance(p, dict):
            return
        d = p.get("type"); op = p.get("opcode")
        if op is None or op in NOISE:
            return
        if d == "send_out":
            if op not in OUT_INTEREST:
                return
            arrow = "→GỬI"
        elif d == "recv":
            if op not in IN_INTEREST:
                return
            arrow = "←NHẬN"
        else:
            return
        try:
            hx = p.get("hex", "")
            body = bytes.fromhex(hx)[6:] if len(hx) >= 12 else b""
            name = GS_OPCODES.get(op, f"op{op}")
            _feed(f"{arrow} [{time.strftime('%H:%M:%S')}] {name}({op}) {_first_field(body)} | hex={hx[:80]}")
            # KHÔNG gọi RPC (dump_bag) trong handler -> gây deadlock Frida.
        except Exception as e:
            _feed(f"   err: {e}")

    b.script.on("message", on_msg)
    _feed(f"🟢 SNIFF NỘP NV {secs}s — mở Dã Tẩu, NỘP TAY 1 nhiệm vụ (hoàn thành→giao nộp→nhận thưởng). "
          f"→GỬI = client gửi, ←NHẬN = server trả.")
    t0 = time.time()
    while time.time() - t0 < secs:
        time.sleep(0.3)
    _feed("🏁 HẾT GIỜ sniff nộp NV.")
    b.close()


if __name__ == "__main__":
    main()
