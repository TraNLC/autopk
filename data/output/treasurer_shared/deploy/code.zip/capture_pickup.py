# -*- coding: utf-8 -*-
"""capture_pickup.py — bắt op54 (eAddMapObject, IN) + op56 (eObjectPickup, OUT) + op48 (IN, đếm đồ-chí)
để ghép objectId op54 ↔ op56 (xác nhận nguồn id cho auto-nhặt) + thấy lúc nhặt 1 tấm đồ-chí.
Dùng: (char đang CÀY + autoplay ON)  venv/bin/python -u capture_pickup.py [secs] [device]
"""
import sys, time, os
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

_a = sys.argv[1:]
SECS = next((int(x) for x in _a if x.isdigit() and int(x) > 30), 900)
DEV = next((x for x in _a if (":" in x or x.startswith("emulator"))), "127.0.0.1:26624")
LOG = "data/output/capture_pickup.log"
os.makedirs("data/output", exist_ok=True)
_lf = open(LOG, "w", encoding="utf-8")


def emit(s):
    print(s, flush=True); _lf.write(s + "\n"); _lf.flush()


def f1_string(hx):
    """field1 (tag 0x0a) string của 1 frame -> objectId/cid."""
    try:
        b = bytes.fromhex(hx)[6:]
        if len(b) >= 2 and b[0] == 0x0a:
            ln = b[1]; return b[2:2+ln].decode("utf-8", "ignore")
    except Exception:
        pass
    return ""


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect():
        emit("connect FAIL (UI Auto giữ Frida? tắt Auto cửa sổ đó)"); return
    bot.capture_sent = True
    for _ in range(5):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.3)
    try: bot.redetect_fd_by_traffic()
    except Exception: pass
    try:
        pi = bot.rpc.get_player_info() or {}
        emit(f"[*] CAPTURE pickup {SECS}s | {DEV} char={pi.get('name')!r}. Để char CÀY+autoplay nhặt. log={LOG}\n")
    except Exception:
        emit(f"[*] CAPTURE pickup {SECS}s | {DEV}")
    t0 = time.time(); seen_out = 0
    n54 = n56 = n48 = 0
    while time.time() - t0 < SECS:
        try: pk = bot.poll_recv() or []
        except Exception: pk = []
        for p in pk:
            op = p.get("opcode"); hx = p.get("hex", "")
            if op == 54:
                n54 += 1; emit(f"  t+{round(time.time()-t0,1):>6}s ←op54 IN  objectId={f1_string(hx)}  {hx[:120]}")
            elif op == 48:
                n48 += 1; emit(f"  t+{round(time.time()-t0,1):>6}s ←op48 IN  (đồ-chí/talk)  {hx[:120]}")
        sb = list(getattr(bot, "sent_buffer", []))
        for p in sb[seen_out:]:
            if p.get("opcode") == 56:
                n56 += 1; emit(f"  t+{round(time.time()-t0,1):>6}s →op56 OUT objectId={f1_string(p.get('hex',''))}  {p.get('hex','')[:120]}")
        seen_out = len(sb)
        time.sleep(0.05)
    emit(f"\n[xong] {SECS}s | op54={n54} op56={n56} op48={n48}. Log: {LOG}")


if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: emit("\n[*] Dừng.")
    finally: _lf.close()
