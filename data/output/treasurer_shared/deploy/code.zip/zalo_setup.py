# -*- coding: utf-8 -*-
"""Trợ lý cài thông báo Zalo — chạy 1 lệnh để KIỂM TRA đăng nhập + TỰ ĐIỀN thread_id + GỬI TIN TEST.

    venv/bin/python zalo_setup.py

Yêu cầu trước khi chạy: đã điền `imei` + đặt file cookies (data/output/zalo_cookies.json) trong
data/output/notify_config.json. Xem HUONG_DAN_ZALO.md để lấy cookies/imei.

Script sẽ:
  1. Đọc config + cookies, thử đăng nhập Zalo.
  2. Đăng nhập OK → in UID của bạn; nếu thread_id còn trống → TỰ điền = UID (gửi cho chính mình) + lưu lại.
  3. Gửi 1 tin test tới thread_id.
KHÔNG đụng gì tới bot — chỉ dựng/kiểm tra cấu hình.
"""
import os
import sys
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from core import notifier as N


def main():
    cfg_path = N.CONFIG_PATH
    if not os.path.exists(cfg_path):
        print(f"❌ Chưa có {cfg_path}. Xem HUONG_DAN_ZALO.md.")
        return
    with open(cfg_path, encoding="utf-8") as f:
        cfg = json.load(f)
    z = cfg.get("zalo") or {}

    # Kiểm tra đầu vào
    cookies = N._resolve_cookies(z)
    if not cookies:
        print("❌ Cookies KHÔNG đọc được / sai định dạng.")
        print(f"   - Kiểm tra đường dẫn: {z.get('cookies')!r}")
        print("   - File phải là JSON: dict {tên:giá_trị} HOẶC list [{name,value}] (Cookie-Editor).")
        return
    print(f"✅ Đọc được {len(cookies)} cookie.")
    if not z.get("imei"):
        print("❌ Thiếu 'imei' trong config (lấy từ Network request zalo.me, tham số imei=). Xem HUONG_DAN_ZALO.md.")
        return

    # Thử đăng nhập
    try:
        from zlapi import ZaloAPI
        from zlapi.models import Message, ThreadType
    except Exception as e:
        print(f"❌ zlapi chưa cài: {e}\n   chạy: venv/bin/pip install zlapi")
        return
    try:
        client = ZaloAPI(phone=z.get("phone") or None, password=z.get("password") or None,
                         imei=z.get("imei"), cookies=cookies, user_agent=z.get("user_agent") or None)
    except Exception as e:
        print(f"❌ Đăng nhập Zalo FAIL: {e}")
        print("   → Cookies/imei có thể sai hoặc hết hạn. Đăng nhập lại chat.zalo.me và export cookies mới.")
        return

    uid = getattr(client, "user_id", None)
    print(f"✅ ĐĂNG NHẬP OK. UID của bạn: {uid}")

    # Tự điền thread_id nếu trống (gửi cho chính mình)
    if not z.get("thread_id") and uid:
        z["thread_id"] = str(uid)
        cfg["zalo"] = z
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        print(f"✅ Đã TỰ điền thread_id = {uid} (gửi cho chính bạn) + lưu config.")

    thread_id = z.get("thread_id")
    if not thread_id:
        print("⚠️ Chưa có thread_id và không lấy được UID — điền tay thread_id (uid bạn hoặc id group).")
        return

    # Gửi tin test
    try:
        tt = ThreadType.GROUP if str(z.get("thread_type", "USER")).upper() == "GROUP" else ThreadType.USER
        client.send(Message(text="✅ Bot Dã Tẩu: kết nối Zalo thành công! (tin test)"),
                    thread_id=str(thread_id), thread_type=tt)
        print(f"✅ ĐÃ GỬI TIN TEST tới {thread_id}. Kiểm tra Zalo của bạn.")
        print("→ Nếu nhận được: bật 'enabled': true trong config là xong.")
    except Exception as e:
        print(f"❌ Gửi tin test FAIL: {e}")
        print("   → Kiểm tra thread_id (đúng uid/group?) và thread_type (USER/GROUP).")


if __name__ == "__main__":
    main()
