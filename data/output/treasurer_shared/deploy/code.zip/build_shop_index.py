"""
build_shop_index.py — Gom hàng NPC shop (tạp hóa/thợ rèn...) -> shop_index.json để remote-mua theo index.
Listener đọc-only: bạn MỞ shop trong game, tool bắt gói eShopTypeOne(119)/Two(120)/Three(212),
parse shopkey + danh sách item (itemindex + genre/detail/particular + tên + giá) + map hiện tại, lưu dồn.
TẮT UI trước. Đi từng thành/trấn, mở tạp hóa+thợ rèn để gom đủ.

DÙNG:
    venv/bin/python -u build_shop_index.py [giây]    # mặc định nghe 120s
"""
import sys, time, json, os, subprocess, platform
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot
from core.adb_helper import ADB_PATH
from features.bot.shop_parser import _decode_protobuf, _decode_varint, get_item_db
PKG = "vn.perfingame.jx1mobile"
INDEX_PATH = "data/output/shop_index.json"
FEED_PATH = "data/output/shop_capture_feed.txt"   # mỗi capture 1 dòng -> Monitor tail -f để báo realtime

try:
    from database.db_manager import db
    def _map_name(mid):
        try:
            n = db.get_map_name(mid)
            return n if n and not str(n).startswith("Map_") else f"map {mid}"
        except Exception:
            return f"map {mid}"
except Exception:
    def _map_name(mid):
        return f"map {mid}"


def _feed(line):
    """Ghi 1 dòng vào feed (Monitor tail -f) + stdout."""
    print(line, flush=True)
    try:
        with open(FEED_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def detect():
    if platform.system() == "Darwin":
        for p in list(range(26624, 26641)) + [16384, 16400, 22471, 5555, 7555, 21503]:
            subprocess.run(f"{ADB_PATH} connect 127.0.0.1:{p}", shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3)
    for l in subprocess.check_output(f"{ADB_PATH} devices", shell=True).decode().split("\n")[1:]:
        if "device" in l and "offline" not in l:
            d = l.split("\t")[0]
            if not d.startswith("emulator-"):
                try:
                    if subprocess.check_output(f"{ADB_PATH} -s {d} shell pidof {PKG}", shell=True,
                                               stderr=subprocess.DEVNULL).decode().strip():
                        return d
                except Exception:
                    pass
    return None


def parse_shop(body, mapid, full_hex=""):
    """Cấu trúc THẬT (decode từ gói 119): ShopData ở FIELD 2; item ở FIELD 4 (repeated entry).
    Entry: f1=itemindex, f2=Item. Item: f1=GIÁ, f7/f8/f9=định danh (cần map tên sau).
    Trả {shopkey,name,costtype,map,items:[{itemindex,cost,f7,f8,f9,name}], hex}."""
    top = _decode_protobuf(body)
    shopdata = top.get(2) or top.get(1)          # ShopData thường ở field 2
    if not isinstance(shopdata, bytes) or not shopdata:
        return None
    sd = _decode_protobuf(shopdata)
    shopkey = sd.get(1, b""); shopkey = shopkey.decode("utf-8", "replace") if isinstance(shopkey, bytes) else ""
    name = sd.get(2, b""); name = name.decode("utf-8", "replace") if isinstance(name, bytes) else ""
    costtype = sd.get(3, 0)
    if not shopkey:
        return None
    items = []
    raw = shopdata; pos = 0
    db = get_item_db()
    while pos < len(raw):
        tag, pos = _decode_varint(raw, pos)
        fnum = tag >> 3; wt = tag & 7
        if wt == 2:
            ln, pos = _decode_varint(raw, pos); vb = raw[pos:pos+ln]; pos += ln
            if fnum == 4:                         # item entry (repeated)
                ef = _decode_protobuf(vb)
                idx = ef.get(1, -1); ib = ef.get(2, b"")
                if isinstance(ib, bytes) and idx >= 0:
                    it = _decode_protobuf(ib)
                    f7, f8, f9 = it.get(7, 0), it.get(8, 0), it.get(9, 0)
                    # thử vài cách map (g,d,p) để lấy tên — chốt sau khi có data trang bị
                    nm = (db.get((0, f7, f8)) or db.get((0, f7, f9)) or db.get((f7, f8, f9)) or "")
                    items.append({"itemindex": idx, "cost": it.get(1, 0),
                                  "f7": f7, "f8": f8, "f9": f9, "name": nm,
                                  "item_hex": ib.hex()})
        elif wt == 0: _, pos = _decode_varint(raw, pos)
        elif wt == 1: pos += 8
        elif wt == 5: pos += 4
        else: break
    if not items:
        return None
    return {"shopkey": shopkey, "name": name, "costtype": costtype, "map": mapid,
            "items": items, "hex": full_hex}


def main():
    secs = int(sys.argv[1]) if len(sys.argv) > 1 else 120
    dev = detect()
    if not dev:
        print("[-] no device"); return
    b = VLTK1Bot(device_id=dev)
    if not b.connect():
        print("[-] connect fail"); return
    time.sleep(1)
    try:
        mapid = (b.rpc.get_player_info() or {}).get("mapId")
    except Exception:
        mapid = None

    index = {}
    if os.path.exists(INDEX_PATH):
        try: index = json.load(open(INDEX_PATH, encoding="utf-8"))
        except Exception: index = {}
    state = {"map": mapid}   # mapId HIỆN TẠI, cập nhật mỗi vòng để gắn ĐÚNG thành cho từng shop

    # Reset feed cho phiên này + báo những shop ĐÃ CÓ (để khỏi quét lại, đỡ tốn time)
    try:
        os.makedirs("data/output", exist_ok=True)
        open(FEED_PATH, "w", encoding="utf-8").close()
    except Exception:
        pass
    if index:
        _feed(f"📂 ĐÃ CÓ {len(index)} shop (khỏi quét lại):")
        for k, v in index.items():
            _feed(f"    • {k} | {_map_name(v.get('map'))} (map {v.get('map')}) | {len(v.get('items', []))} món")
    else:
        _feed("📂 Chưa có shop nào, quét từ đầu.")

    def on_msg(message, data):
        if message.get("type") != "send":
            return
        p = message.get("payload", {})
        if not isinstance(p, dict) or p.get("type") != "recv":
            return
        if p.get("opcode") not in (119, 120, 212):
            return
        try:
            body = bytes.fromhex(p["hex"])[6:]
            shop = parse_shop(body, state["map"], full_hex=p["hex"])
            if not shop:
                return
            key = shop["shopkey"]
            is_new = key not in index
            # GHI ĐÈ luôn (kể cả đã có) -> capture lại sẽ sửa được map tag sai / cập nhật món mới
            index[key] = shop
            try:
                os.makedirs("data/output", exist_ok=True)
                json.dump(index, open(INDEX_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
            except Exception:
                pass
            named = [it["name"] for it in shop["items"] if it["name"]]
            mname = _map_name(shop["map"])
            tag = "MỚI" if is_new else "cập nhật"
            sample = ", ".join(named[:5]) if named else "(chưa map được tên)"
            _feed(f"✅ [{time.strftime('%H:%M:%S')}] {tag}: {key} | {mname} (map {shop['map']}) "
                  f"| {len(shop['items'])} món | vd: {sample}")
        except Exception as e:
            _feed(f"⚠️ parse err: {e}")

    b.script.on("message", on_msg)
    _feed(f"🟢 LISTENER BẬT {secs}s (đang ở {_map_name(mapid)}/map {mapid}) — đi từng thành/thôn MỞ tạp hóa + thợ rèn...")
    t0 = time.time(); last = 0
    while time.time() - t0 < secs:
        time.sleep(0.3)
        if time.time() - last > 2:   # cập nhật mapId hiện tại để gắn đúng thành
            last = time.time()
            try:
                m = (b.rpc.get_player_info() or {}).get("mapId")
                if m: state["map"] = m
            except Exception:
                pass
    os.makedirs("data/output", exist_ok=True)
    json.dump(index, open(INDEX_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    _feed(f"🏁 HẾT GIỜ. Tổng {len(index)} shop trong shop_index.json:")
    for k, v in index.items():
        _feed(f"    • {k} | {_map_name(v.get('map'))} (map {v.get('map')}) | {len(v.get('items', []))} món")
    b.close()


if __name__ == "__main__":
    main()
