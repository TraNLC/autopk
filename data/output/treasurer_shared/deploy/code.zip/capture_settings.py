# -*- coding: utf-8 -*-
"""capture_settings.py — BẮT gói khi user tích 'nhặt đồ' + 'tổ đội' trong bảng cấu hình Auto.
Log MỌI gói OUT (mọi fd, captureAllSends) trừ noise → để dò packet/opcode lưu cài đặt auto-nhặt + auto-party.
Dùng: (TẮT Auto cửa sổ đó)  venv/bin/python -u capture_settings.py [secs] [device]
"""
import sys, time, os
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

_a = sys.argv[1:]
SECS = next((int(x) for x in _a if x.isdigit() and int(x) > 30), 180)
DEV = next((x for x in _a if (":" in x or x.startswith("emulator"))), "127.0.0.1:26624")
NOISE = {7, 8, 9, 16, 17, 18, 19, 20, 23, 40, 54, 63, 66, 69, 70, 251, 9}
LOG = "data/output/capture_settings.log"
os.makedirs("data/output", exist_ok=True)
_lf = open(LOG, "w", encoding="utf-8")


def emit(s):
    print(s, flush=True); _lf.write(s + "\n"); _lf.flush()


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect():
        emit("connect FAIL (UI Auto còn giữ Frida? tắt Auto cửa sổ đó rồi chạy lại)"); return
    bot.capture_sent = True
    for _ in range(5):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.3)
    try: bot.redetect_fd_by_traffic()
    except Exception: pass
    try: bot.rpc.set_capture_all_sends(True)
    except Exception as e: emit(f"set_capture_all_sends lỗi: {e}")
    try:
        pi = bot.rpc.get_player_info() or {}
        emit(f"[*] CAPTURE {SECS}s | {DEV} | char={pi.get('name')!r}. BÂY GIỜ mở bảng AUTO + tích 'nhặt đồ' rồi 'tổ đội'. log={LOG}\n")
    except Exception:
        emit(f"[*] CAPTURE {SECS}s | {DEV}. Mở bảng AUTO + tích cài đặt.\n")
    t0 = time.time(); seen = 0
    while time.time() - t0 < SECS:
        try: bot.poll_recv()
        except: pass
        sb = list(getattr(bot, "sent_buffer", []))
        for p in sb[seen:]:
            op = p.get("opcode")
            if op in NOISE:
                continue
            emit(f"  t+{round(time.time()-t0,1):>6}s →OUT op{op} ({p.get('name')}) {(p.get('hex') or '')[:160]}")
        seen = len(sb)
        time.sleep(0.05)
    emit(f"\n[xong] {SECS}s. Log: {LOG}")


if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: emit("\n[*] Dừng.")
    finally: _lf.close()
