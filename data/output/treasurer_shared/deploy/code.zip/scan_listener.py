"""
scan_listener.py — LISTENER quét sạp THEO DI CHUYỂN. Attach 1 lần, theo dõi toạ độ nhân vật:
mỗi khi bạn DI CHUYỂN sang chỗ mới rồi ĐỨNG LẠI → tự quét (nhiều lượt) + gộp thư viện + publish 2 máy.
Bạn chỉ việc lái radar đi khắp nơi đông sạp — không cần báo "quét".

DÙNG:  venv/bin/python scan_listener.py 127.0.0.1:26784
DỪNG:  Ctrl-C (hoặc kill tiến trình).
ĐIỀU KIỆN: cửa sổ đó TẮT Auto (Frida attach 1 lần/PID). Đã lọc KNB (money_type!=0) tại gốc scan_stalls.
"""
import sys, time, signal
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot
from core.stall_shopper import (
    scan_stalls, load_catalog, save_catalog, publish_catalog, catalog_counts,
)

MAX_STALLS = 400
MIN_NEW = 3            # cần ≥ ngần này sạp MỚI (chưa quét) quanh chỗ đứng mới kích quét
CHURN_TOL = 3         # danh sách sạp đổi ≤ ngần này giữa 2 nhịp = coi như "đứng yên" (chịu nhiễu load)
STILL_SECS = 3.0      # danh sách sạp ổn định ngần này (giây) mới quét (đã dừng + load xong)
PASSES = 5            # số lượt quét mỗi lần dừng (đồ về lai rai → nhiều lượt vét gần hết)
POLL = 1.0            # nhịp đọc danh sách sạp gần
_RUN = True


def _pos(bot):
    """Vị trí ỔN ĐỊNH: x,y đọc THẲNG memory nhân vật mình (read_position_from_memory) — KHÔNG dùng mapX/mapY của
    get_player_info vì cái đó lấy từ _lastPosition (op9), ở THÀNH ĐÔNG bị op9 người khác ghi đè → nhảy loạn ~1000
    dù đứng yên. mapId vẫn lấy get_player_info (không nhiễu, chỉ đổi khi sang map). Trả (mapId, x, y, src)."""
    mid = None
    try:
        mid = (bot.rpc.get_player_info() or {}).get("mapId")
    except Exception:
        pass
    try:
        r = bot.rpc.read_position_from_memory() or {}
        if r.get("ok") and int(r.get("x") or 0) > 0:
            return mid, int(r["x"]), int(r["y"]), "mem"
    except Exception:
        pass
    # fallback (memory đọc hụt): get_player_info — kém ổn định ở thành đông, chỉ để không chết hẳn.
    try:
        i = bot.rpc.get_player_info() or {}
        return mid, int(i.get("mapX") or 0), int(i.get("mapY") or 0), "op9"
    except Exception:
        return mid, 0, 0, "none"


def _near_cids(bot):
    """Tập CID sạp client đang load quanh mình (KHÔNG gửi packet, chỉ đọc dict salesmans) — dùng làm tín hiệu
    'đang ở đâu' thay cho toạ độ (toạ độ op9 nhiễu ở thành đông; memory 64-bit đọc hụt)."""
    try:
        r = bot.rpc.get_near_salesmans() or {}
        if r.get("ok"):
            return set(str(p.get("id")) for p in (r.get("players") or []) if isinstance(p, dict) and p.get("id"))
    except Exception:
        pass
    return set()


def _map_id(bot):
    try:
        return (bot.rpc.get_player_info() or {}).get("mapId")
    except Exception:
        return None


def _scan_session(bot):
    """Quét PASSES lượt tại chỗ, gom catalog phiên → merge lib + publish. Trả (sạp_phiên, món_phiên, +sạp, +món)."""
    b_items, b_stalls = catalog_counts(load_catalog())
    session = {}
    dry = 0
    # in DIAG mỗi lượt (sạp-gần vs trả-lời) để biết PT/TD ít sạp là do: (a) salesmans load chưa đủ, hay (b) sạp ko trả lời.
    def _diag(msg):
        if "[CHẨN ĐOÁN QUÉT]" in str(msg):
            print("   " + str(msg).replace("[CHẨN ĐOÁN QUÉT] ", ""), flush=True)
    for _p in range(PASSES):
        scanned = scan_stalls(bot, max_players=MAX_STALLS, merge=False, log=_diag) or {}
        new = sum(1 for c in scanned if c not in session)
        session.update(scanned)
        if new == 0:
            dry += 1
            if dry >= 2:
                break
        else:
            dry = 0
        time.sleep(0.6)
    lib = load_catalog(); lib.update(session); save_catalog(lib); publish_catalog()
    a_items, a_stalls = catalog_counts(lib)
    si, ss = catalog_counts(session)
    return ss, si, a_stalls - b_stalls, a_items - b_items, a_stalls, a_items


def main():
    global _RUN
    dev = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1:26784"
    print(f"[*] Listener attach {dev}…", flush=True)
    bot = VLTK1Bot(device_id=dev)
    if not bot.connect():
        print("[-] Attach FAIL (cửa sổ đó còn bật Auto? game chưa vào?).", flush=True)
        return
    for _ in range(6):
        try: bot.poll_recv()
        except Exception: pass
        time.sleep(0.3)
    try: bot.redetect_fd_by_traffic()
    except Exception: pass

    def _stop(*_):
        global _RUN
        _RUN = False
    signal.signal(signal.SIGINT, _stop)
    signal.signal(signal.SIGTERM, _stop)

    print(f"[*] BẮT ĐẦU NGHE (theo DANH SÁCH SẠP, không theo toạ độ). Tới chỗ có ≥{MIN_NEW} sạp mới, "
          f"đứng yên ~{STILL_SECS:.0f}s là tự quét.", flush=True)
    scanned_cids = set()      # MỌI cid đã quét (để biết 'sạp mới chưa quét')
    prev = set()              # cid lần poll trước (đo 'danh sách ổn định')
    stable_since = time.time()
    last_hb = 0.0
    while _RUN:
        cur = _near_cids(bot)
        churn = len(cur ^ prev)                 # số cid khác giữa 2 nhịp → đang di chuyển/đang load thì cao
        if churn > CHURN_TOL:
            stable_since = time.time()          # danh sách còn đổi nhiều → chưa "đứng yên"
        stable_for = time.time() - stable_since
        unscanned = cur - scanned_cids
        prev = cur
        if time.time() - last_hb > 2.0:
            last_hb = time.time()
            mid = _map_id(bot)
            print(f"   [hb] map {mid} | {len(cur)} sạp gần, {len(unscanned)} CHƯA quét | ổn định {stable_for:.0f}/{STILL_SECS:.0f}s",
                  flush=True)
        # CÓ ĐỦ SẠP MỚI quanh đây + danh sách đã ỔN ĐỊNH (ngừng di chuyển/đã load xong) → quét.
        if len(unscanned) >= MIN_NEW and stable_for >= STILL_SECS:
            mid = _map_id(bot)
            print(f"[QUÉT] map {mid} | {len(cur)} sạp gần ({len(unscanned)} mới), bắt đầu quét…", flush=True)
            try:
                ss, si, ds, di, tot_s, tot_i = _scan_session(bot)
                print(f"   ✅ {ss} sạp/{si} món | +{ds} sạp mới/+{di} món mới → THƯ VIỆN {tot_s} sạp/{tot_i} món.",
                      flush=True)
            except Exception as e:
                print(f"   ⚠️ quét lỗi: {e}", flush=True)
            scanned_cids |= cur                 # đánh dấu đã quét cụm này → khỏi quét lại tại chỗ
            stable_since = time.time()
        time.sleep(POLL)
    try: bot.close()
    except Exception: pass
    print("[*] Listener dừng.", flush=True)


if __name__ == "__main__":
    main()
