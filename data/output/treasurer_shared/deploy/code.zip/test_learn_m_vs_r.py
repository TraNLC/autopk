# -*- coding: utf-8 -*-
"""Học nid con đánh tay (chắc chắn trong tầm) → replay skill 1 (melee) rồi 362 (ranged) lên ĐÚNG con đó.
So: melee replay có tụt máu không vs ranged. Chỉ tính HP GIẢM. Pre-check chống nhiễm autoplay.
⚠️ TẮT autoplay. Dùng: venv/bin/python -u test_learn_m_vs_r.py [device]
"""
import sys, time
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot
DEV = next((x for x in sys.argv[1:] if (":" in x or x.startswith("emulator"))), "127.0.0.1:26624")

def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect(): print("connect FAIL"); return
    bot.capture_sent = True
    for _ in range(6):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.3)
    try: bot.redetect_fd_by_traffic()
    except Exception as e: print("redetect:", e)
    def snap():
        try: r = bot.rpc.get_near_npcs_detail() or {}
        except Exception: return {}
        return {str(n.get("id")): (n.get("hp")) for n in (r.get("npcs") or []) if (n.get("hpMax",0) or 0)>0}
    # HỌC nid + skillId từ cú đánh tay đầu
    print("\n>>> ĐÁNH TAY (đánh thường HOẶC chiêu) vào 1 con SÁT BÊN vài phát để học nid+skill. (≤25s)")
    target=None; learned_skill=None; bot.sent_buffer=[]; t0=time.time()
    while time.time()-t0<25 and target is None:
        try: bot.poll_recv()
        except: pass
        for pp in list(getattr(bot,"sent_buffer",[])):
            if pp.get("opcode")==239:
                try:
                    b=bytes.fromhex(pp.get("hex",""))[6:]; i=0; d={}
                    while i<len(b):
                        tag=b[i]; i+=1; f=tag>>3; w=tag&7
                        if w==0:
                            v=0; s=0
                            while i<len(b):
                                c=b[i]; i+=1; v|=(c&0x7f)<<s; s+=7
                                if not c&0x80: break
                            d[f]=v
                        elif w==2:
                            ln=b[i]; i+=1; d[f]=b[i:i+ln]; i+=ln
                        else: break
                    learned_skill=d.get(1)
                    if isinstance(d.get(2),(bytes,bytearray)): target=bytes(d[2]).decode("utf-8","ignore")
                except Exception: pass
                if target: break
        bot.sent_buffer=[]; time.sleep(0.05)
    if not target: print("❌ không học được nid (đánh tay liên tục hơn)."); return
    print(f">>> HỌC: nid={target}, skill tay={learned_skill}. 🛑 DỪNG TAY + TẮT AUTOPLAY. (chờ 2s)")
    time.sleep(2)
    def hp(): return snap().get(target)
    # pre-check 5s
    ha=hp(); time.sleep(5); hb=hp()
    if target not in snap() or (ha is not None and hb is not None and hb<ha):
        print(f"⚠️ HP tự đổi {ha}->{hb}/mất khi 0 gói → AUTOPLAY còn bật → BỎ. Tắt hẳn rồi chạy lại."); return
    print(f"   ✓ sạch, HP {hb}%.")
    def test(skill,label):
        if target not in snap(): print(f"[{label}] target mất, bỏ."); return
        before=hp()
        for _ in range(15):
            bot.send_gs('eDoSkillTargetNpc', skillid=skill, nid=target)
            t1=time.time()
            while time.time()-t1<0.4:
                try: bot.poll_recv()
                except: pass
                time.sleep(0.04)
        after=hp(); gone=target not in snap()
        print(f"[{label}] replay skill {skill} -> HP {before}->{('mất' if gone else after)}  " +
              ("💥 TỤT = TRÚNG" if (before is not None and after is not None and after<before) else "KHÔNG đổi=trượt" if not gone else "(mất-chưa chắc)"))
    print("\n--- replay MELEE skill 1 lên con đã học ---"); test(1,"MELEE")
    print("--- replay RANGED skill 362 lên con đã học ---"); test(362,"RANGED")

if __name__=="__main__":
    try: main()
    except KeyboardInterrupt: print("\n[*] Dừng.")
