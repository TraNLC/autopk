import os, sys
# ĐÓNG GÓI (.exe): chuyển về thư mục chứa exe để mọi đường dẫn tương đối (data/, features/...) đúng.
try:
    from core.paths import BASE
    os.chdir(BASE)
except Exception:
    pass
import tkinter as tk
from tkinter import ttk, scrolledtext
import threading
import time
import logging
from features.bot.da_tau_state_machine import DaTauStateMachine
from core.adb_helper import ADBHelper
from core import tracker
from core import quest_actions
from core import datau_rewards
from core import treasurer as _treasurer
from core import luyencong as _luyencong
from core import buff_config as _buff_config
from core import recall_config as _recall_config
from core import loot_config as _loot_config
from core import luyencong_accounts as _lc_accounts

# SỐ NV Dã Tẩu tối đa/ngày — THEO SERVER (sv này = 20, sv trước = 30). Đọc data/output/daily_cap.txt nếu có.
DAILY_CAP = 20   # CỐ ĐỊNH 20 NV/ngày (server này — user xác nhận). KHÔNG lấy động nữa.

# Ghi log INFO (routing READ_QUEST/EVALUATE...) ra file để debug ngoài UI
try:
    os.makedirs("data/output", exist_ok=True)
    _fh = logging.FileHandler("data/output/auto_flow.log", encoding="utf-8")
    _fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%H:%M:%S"))
    _root = logging.getLogger()
    _root.setLevel(logging.INFO)
    if not any(getattr(h, "baseFilename", "").endswith("auto_flow.log") for h in _root.handlers):
        _root.addHandler(_fh)
except Exception:
    pass

# LOG RIÊNG TỪNG CỬA SỔ (Syncthing): mỗi bot ghi vào treasurer_shared/logs/<máy>_<cổng>.log RIÊNG → KHÔNG
# TRỘN 4 cửa sổ (trước gộp 1 file, không tách được window nào làm gì → chẩn đoán mò). Thread-local gắn device
# cho mỗi luồng bot (_run_bot_thread set); handler route record theo đó. Luồng UI (không device) → <máy>_UI.log.
import socket as _socket, threading as _threading
LOG_DEVICE = _threading.local()
_MID = "".join(c if (c.isalnum() or c in "-_") else "_" for c in (_socket.gethostname() or "may"))[:32] or "may"
_SHARED_LOG_DIR = "data/output/treasurer_shared/logs"


class _PerDeviceLogHandler(logging.Handler):
    """Ghi mỗi record vào file theo DEVICE của luồng hiện tại (thread-local). Cache file handle; cắt khi >2MB."""
    def __init__(self):
        super().__init__()
        self._files = {}

    def _path(self, dev):
        tag = ("".join(c if (c.isalnum() or c in "-_") else "_" for c in str(dev))[:24]) if dev else "UI"
        return os.path.join(_SHARED_LOG_DIR, f"{_MID}_{tag}.log")

    def emit(self, record):
        try:
            dev = getattr(LOG_DEVICE, "dev", None)
            p = self._path(dev)
            f = self._files.get(p)
            if f is not None and f.tell() > 2_000_000:    # cap ~2MB cho file sync nhỏ
                try: f.close()
                except Exception: pass
                open(p, "w").close(); f = None
            if f is None:
                f = open(p, "a", encoding="utf-8"); self._files[p] = f
            f.write(self.format(record) + "\n"); f.flush()
        except Exception:
            pass


try:
    os.makedirs(_SHARED_LOG_DIR, exist_ok=True)
    _root = logging.getLogger()
    if not any(isinstance(h, _PerDeviceLogHandler) for h in _root.handlers):
        _pdh = _PerDeviceLogHandler()
        _pdh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%Y-%m-%d %H:%M:%S"))
        _root.addHandler(_pdh)
except Exception:
    pass

class BotUIApp:
    def __init__(self, root):
        self.root = root
        # Phiên bản build (đọc BUILD_VERSION.txt) — hiện trên TITLE để biết đang chạy bản nào.
        try:
            with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "BUILD_VERSION.txt"), encoding="utf-8") as _bf:
                _ver = _bf.read().strip()
        except Exception:
            _ver = "?"
        self.root.title(f"Auto Dã Tẩu - Ver {_ver}")
        # Cửa sổ HẸP (user yêu cầu) nhưng RESPONSIVE: cao theo màn hình thực (máy LinhDL màn nhỏ → KHÔNG bị
        # che/cụt nội dung), cho resize + minsize để layout luôn đủ. Tránh hard-code 900 gây tràn trên màn thấp.
        try:
            _sh = self.root.winfo_screenheight()
        except Exception:
            _sh = 900
        # GỌN cho 1080p (LinhDL): trước để tới 900 → quá to/cụt. Cao tối đa 720, chừa ~150px taskbar.
        _w, _h = 380, max(540, min(720, _sh - 150))
        self.root.geometry(f"{_w}x{_h}")
        self.root.minsize(360, 540)
        self.root.resizable(True, True)
        # ĐỒNG BỘ FONT toàn UI: 1 base font cho mọi widget tk (cái nào KHÔNG khai báo font riêng sẽ ăn cái này).
        self.FONT = ("Helvetica", 10); self.FONT_B = ("Helvetica", 10, "bold")
        try:
            self.root.option_add("*Font", self.FONT)
        except Exception:
            pass
        
        # self.bots maps device_id -> {'bot': DaTauStateMachine, 'thread': threading.Thread, 'is_running': bool}
        self.bots = {}
        self.paused_devices = set()   # device_id đang PENDING (chờ Resume)
        # Dữ liệu tracking (NV/thưởng/vật phẩm/log) ĐỌC TỪ FILE LOG NGÀY qua core.tracker,
        # không giữ state trong RAM nữa -> tắt app không mất, xem lại được theo ngày.
        self.current_log_device = None
        self.char_log_buf = {}        # {tên nhân vật: [dòng log]} — log thực thi RIÊNG theo nhân vật
        self._log_view_char = None    # nhân vật đang hiển thị ở panel log
        self.device_labels = self._load_device_labels()   # {device_id: tên cửa sổ user đặt} (vd 'Dã Tẩu 1')

        self._create_widgets()
        self._reset_adb_server()   # reset adb mỗi lần app KHỞI ĐỘNG (kể cả re-exec auto-deploy) → tránh "không thấy cửa sổ"
        self._refresh_devices()
        self._load_view(rebuild_log=True)
        # DỌN thư viện sạp: bỏ đồ KNB cũ tích trước khi có filter -> chỉ còn đồ bán bằng VẠN/LƯỢNG.
        try:
            from core.stall_shopper import sanitize_catalog
            _rm, _left = sanitize_catalog()
            if _rm:
                self.log(f"🧹 Dọn thư viện sạp: bỏ {_rm} món KNB (chỉ giữ đồ bán bằng vạn) → còn {_left} món.")
        except Exception as e:
            logging.getLogger().info(f"[sanitize_catalog] {e}")
        self._poll_tracking()   # đọc lại file log định kỳ (UI lấy dữ liệu từ log, không bắt trực tiếp game)
        self.root.after(self.WATCHDOG_POLL_MS, self._watchdog_tick)   # watchdog: tự cứu cửa sổ treo
        self._auto_resume_after_deploy()                              # vừa cập nhật code? -> tự bật lại Auto
        self.root.after(8000, self._deploy_watch_tick)                # canh code mới qua Syncthing -> tự deploy
        self.root.after(2500, self._start_zalo_listener)              # nghe lệnh Zalo (resume cửa sổ từ xa)
        self.root.after(3000, self._web_tick)                         # WEB AGENT: publish status + nhận lệnh web

    def _create_widgets(self):
        # --- Style chung cho bảng (đẹp/chuyên nghiệp): dòng cao, header đậm, màu chọn accent ---
        _style = ttk.Style()
        try:
            _style.configure("Treeview", rowheight=24, font=("Helvetica", 10), borderwidth=0)
            _style.configure("Treeview.Heading", font=("Helvetica", 10, "bold"), padding=3)
            _style.map("Treeview", background=[("selected", "#1f8b5f")], foreground=[("selected", "white")])
            # Tab: font 10 ĐỒNG BỘ với content (trước để 9 -> lệch). padding gọn.
            _style.configure("TNotebook.Tab", padding=(8, 4), font=("Helvetica", 10))
        except Exception:
            pass

        # --- Top Half: danh sách cửa sổ (banner + toolbar + bảng có scrollbar) ---
        top_frame = tk.Frame(self.root, bg="#eceff1")
        top_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=False, padx=8, pady=(8, 4))

        _bar = tk.Frame(top_frame, bg="#2c3e50"); _bar.pack(fill=tk.X)
        # WATCHDOG (tự cứu cửa sổ treo): LUÔN BẬT mặc định — bỏ checkbox khỏi UI theo yêu cầu, vẫn chạy ngầm.
        self.var_watchdog = tk.BooleanVar(value=True)
        self.lbl_dev_count = None   # bỏ nhãn đếm cửa sổ khỏi UI (gọn)
        # Nút phẳng MÀU (macOS bỏ qua bg của tk.Button → Label-as-button). Width hẹp → pad nhỏ + label gọn, KHÔNG vỡ.
        # 3 nút TRẢI ĐỀU full chiều ngang header (expand+fill) — header trống nhiều nên cover hết cho đẹp.
        self._flatbtn(_bar, "🔄 Làm mới", self._refresh_devices, "#3b5168", "#4a637e", pad=6, fsize=10).pack(side=tk.LEFT, expand=True, fill=tk.X, padx=(8, 3), pady=6)
        self._flatbtn(_bar, "📊 Thống kê", self._show_treasurer_stats, "#1a7f37", "#22a046", pad=6, fsize=10).pack(side=tk.LEFT, expand=True, fill=tk.X, padx=3, pady=6)
        self._flatbtn(_bar, "♻️ Khởi động lại", self._restart_app, "#b9770e", "#d4890f", pad=6, fsize=10).pack(side=tk.LEFT, expand=True, fill=tk.X, padx=(3, 8), pady=6)

        _tw = tk.Frame(top_frame, bg="white"); _tw.pack(fill=tk.BOTH, expand=True)
        columns = ("auto", "name", "money", "today")
        self.tree = ttk.Treeview(_tw, columns=columns, show="headings", height=8)
        self.tree.heading("auto", text="Auto")
        self.tree.heading("name", text="Tên nhân vật")
        self.tree.heading("money", text="Ngân lượng")
        self.tree.heading("today", text="NV")
        self.tree.column("auto", width=40, anchor=tk.CENTER, stretch=False)
        self.tree.column("name", width=150, anchor=tk.W)
        self.tree.column("money", width=120, anchor=tk.E, stretch=False)
        self.tree.column("today", width=48, anchor=tk.CENTER, stretch=False)
        _vsb = ttk.Scrollbar(_tw, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=_vsb.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        _vsb.pack(side=tk.RIGHT, fill=tk.Y)
        # Tag tô ĐỎ tên nhân vật khi bot CẦN TRỢ GIÚP (không tự làm được NV)
        self.tree.tag_configure("need_help", foreground="#d33")
        self.tree.bind('<Button-1>', self._on_tree_click)
        self.tree.bind('<Button-2>', self._on_tree_right_click)
        self.tree.bind('<Button-3>', self._on_tree_right_click)
        self.tree.bind('<<TreeviewSelect>>', self._on_tree_select)

        # --- Bottom Half: Notebook (Tabs) + LOG CHUNG ---
        bottom_frame = tk.Frame(self.root)
        bottom_frame.pack(side=tk.BOTTOM, fill=tk.BOTH, expand=True, padx=5, pady=5)

        # LOG THỰC THI CHUNG: log của MỌI chế độ (Dã Tẩu / luyện công / buff / thủ quỹ) — luôn hiển thị,
        # KHÔNG nằm trong tab (để cửa sổ luyện công bị ẩn tab Dã Tẩu vẫn xem được log).
        # Log CHUNG nở to (expand) lấp phần dưới; notebook ở trên CHỈ vừa nội dung (không expand) -> hết khoảng trống.
        # VulanPro-style: MỌI thứ nằm trong tab, notebook lấp cả nửa dưới. LOG là 1 TAB riêng (tạo CUỐI,
        # sau các tab khác) → bỏ vùng log đáy = hết bug log-co-ngắn + khoảng trống thừa.
        self.notebook = ttk.Notebook(bottom_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        self.notebook.bind("<<NotebookTabChanged>>", self._on_tab_changed)

        # ===== Tab ĐẦU TIÊN: "Hỗ trợ luyện công" =====
        # Cửa sổ Luyện Công (đặt qua CHUỘT PHẢI tên cửa sổ → "Luyện Công"): chỉ tab này bật, các tab Dã Tẩu ẩn.
        # Mặc định cửa sổ là Dã Tẩu → tab này bị disable.
        # BooleanVar DÙNG CHUNG cho checkbox "nhận buff" ở cả 2 tab (Dã tẩu + Luyện công) -> đồng bộ.
        self.var_buff = tk.BooleanVar(value=_buff_config.is_enabled())

        self.tab_luyencong = tk.Frame(self.notebook)
        # TẠM BỎ tab Luyện công khỏi UI (chưa cần) — KHÔNG add vào notebook. Frame vẫn tạo để giữ tham chiếu
        # (var_buff/txt_lc_accounts) cho code cũ; chỉ là không hiển thị tab.
        # self.notebook.add(self.tab_luyencong, text="🏋️ Luyện công")
        tk.Label(self.tab_luyencong, font=("Helvetica", 10, "bold"), fg="#1a7f37",
                 text="🏋️ Cửa sổ HỖ TRỢ LUYỆN CÔNG").pack(anchor="w", padx=10, pady=(10, 2))
        tk.Checkbutton(self.tab_luyencong, variable=self.var_buff, command=self._on_buff_toggle,
                       text="🔆 Nhận buff Tân Thủ", wraplength=360, justify=tk.LEFT
                       ).pack(anchor="w", padx=10, pady=4)

        # Danh sách account luyện công (acc:pass:tên) — mỗi cửa sổ 1 danh sách (giống tab Tài khoản).
        lc_top = tk.Frame(self.tab_luyencong); lc_top.pack(fill=tk.X, padx=10, pady=(6, 2))
        self.lbl_lc_device = tk.Label(lc_top, text="Cửa sổ: (chọn cửa sổ ở bảng trên)", font=("Helvetica", 10, "bold"))
        self.lbl_lc_device.pack(side=tk.LEFT)
        tk.Label(self.tab_luyencong, text="Danh sách (mỗi dòng: taikhoan:matkhau:tennhanvat):",
                 font=("Helvetica", 10)).pack(anchor="w", padx=10)
        self.txt_lc_accounts = scrolledtext.ScrolledText(self.tab_luyencong, wrap=tk.WORD, height=8)
        self.txt_lc_accounts.pack(fill=tk.BOTH, expand=True, padx=10, pady=4)
        tk.Button(self.tab_luyencong, text="💾 Lưu danh sách cho cửa sổ này",
                  command=self._save_luyencong_queue).pack(anchor="w", padx=10, pady=(0, 6))

        # Tab "Dã tẩu"
        self.tab_datau = tk.Frame(self.notebook)
        self.notebook.add(self.tab_datau, text="📜 Dã tẩu")

        # NÚT "Để tôi làm NV này": PAUSE toàn bộ auto để user tự làm 1 NV tay → bấm lại ("Tôi đã xong") =
        # resume tất cả (đọc lại NV Dã Tẩu LIVE + chạy tiếp flow cũ).
        self._manual_paused = False
        _mf = tk.Frame(self.tab_datau); _mf.pack(anchor="w", padx=5, pady=(6, 0))
        # Label-as-button (tk.Button trên macOS bỏ qua bg → nút trắng/chữ trắng vô hình). bg hiện đúng trên Label.
        self.btn_manual = tk.Label(_mf, text="🙋 Để tôi làm NV này", bg="#3b5168", fg="white",
                                   font=("Helvetica", 10, "bold"), cursor="hand2", padx=10, pady=4)
        self.btn_manual.pack(side=tk.LEFT)
        self.btn_manual.bind("<Button-1>", lambda e: self._toggle_manual_quest())

        # --- Khối CẤU HÌNH MUA (giá max + thuốc cày) trong tab Dã tẩu ---
        cfg_frame = tk.LabelFrame(self.tab_datau, text="Cấu hình mua", font=("Helvetica", 10, "bold"))
        cfg_frame.pack(fill=tk.X, padx=5, pady=(6, 2))
        row1 = tk.Frame(cfg_frame); row1.pack(fill=tk.X, padx=4, pady=2)
        tk.Label(row1, text="Mua giá ≤ (vạn):").pack(side=tk.LEFT)
        self.var_threshold = tk.StringVar(value="5")
        tk.Entry(row1, textvariable=self.var_threshold, width=8).pack(side=tk.LEFT, padx=4)
        self.var_threshold.trace_add("write", lambda *a: self._apply_threshold())

        row2 = tk.Frame(cfg_frame); row2.pack(fill=tk.X, padx=4, pady=2)
        tk.Label(row2, text="💊 Thuốc cày:").pack(side=tk.LEFT)
        self._potion_catalog = self._load_potion_catalog()
        names = [f"{it['idx']:>2} · {it['name']}" for it in self._potion_catalog]
        self.var_potion = tk.StringVar()
        self.cmb_potion = ttk.Combobox(row2, textvariable=self.var_potion,
                                       values=names, width=15, state="readonly")
        self.cmb_potion.pack(side=tk.LEFT, padx=3)
        tk.Label(row2, text="SL:").pack(side=tk.LEFT)
        self.var_potion_qty = tk.StringVar(value="0")
        tk.Spinbox(row2, from_=0, to=999, increment=10, width=5,
                   textvariable=self.var_potion_qty).pack(side=tk.LEFT, padx=2)
        tk.Button(row2, text="Lưu", command=self._apply_potion).pack(side=tk.LEFT, padx=3)
        self.lbl_potion = tk.Label(row2, text="", fg="gray")   # bỏ note "(0=không mua)" cho gọn
        self.lbl_potion.pack(side=tk.LEFT, padx=4)
        self._load_potion_selection()

        tk.Checkbutton(self.tab_datau, variable=self.var_buff, command=self._on_buff_toggle,
                       text="🔆 Nhận buff Tân Thủ", wraplength=360, justify=tk.LEFT
                       ).pack(anchor="w", padx=5, pady=(4, 2))

        # VỀ THÀNH (Xa Phu→Biện Kinh) + DỌN TÚI (bán đồ nhặt dư, cất 1 món/thuộc-tính vào kho) = MẶC ĐỊNH LUÔN,
        # không tạo UI (recall_config mặc định 'xaphu', loot_config mặc định bật).

        # ===== PHÂN LOẠI NHIỆM VỤ (gộp vào tab Dã tẩu): mỗi LOẠI nhiệm vụ → 1 hành động =====
        class_frame = tk.LabelFrame(self.tab_datau, text="Phân loại nhiệm vụ", font=("Helvetica", 10, "bold"))
        class_frame.pack(fill=tk.X, padx=5, pady=(6, 2))
        self._action_labels = [lbl for _, lbl in quest_actions.ACTIONS]
        self._act_key_by_label = {lbl: k for k, lbl in quest_actions.ACTIONS}
        self._act_label_by_key = {k: lbl for k, lbl in quest_actions.ACTIONS}
        self.action_vars = {}
        self.lbl_type_count = {}   # {group_key: Label} — số lần GẶP loại NV này HÔM NAY (theo nhân vật đang xem)
        cfg0 = quest_actions.load_config()
        for tkey, tlabel in quest_actions.QUEST_TYPES:
            row = tk.Frame(class_frame)
            row.pack(fill=tk.X, padx=10, pady=2)
            tk.Label(row, text=tlabel, width=14, anchor=tk.W).pack(side=tk.LEFT)
            var = tk.StringVar(value=self._act_label_by_key.get(cfg0.get(tkey, "auto"), "Auto làm"))
            ttk.Combobox(row, textvariable=var, values=self._action_labels,
                         state="readonly", width=12).pack(side=tk.LEFT, padx=3)
            cl = tk.Label(row, text="·", width=6, anchor=tk.E, fg="#1a7f37", font=("Helvetica", 10, "bold"))
            cl.pack(side=tk.RIGHT)
            self.lbl_type_count[tkey] = cl
            self.action_vars[tkey] = var
            var.trace_add("write", lambda *a: self._save_quest_actions())
        tk.Label(class_frame, text="(số bên phải = số lần gặp loại NV đó hôm nay)",
                 fg="#888").pack(anchor=tk.W, padx=10, pady=(0, 3))

        # (Log thực thi đã chuyển ra vùng CHUNG dưới notebook — xem mọi chế độ.)

        # --- Widget ẩn: giữ object để code update live (poll tracking) KHÔNG vỡ, nhưng KHÔNG hiển thị ---
        self.var_day = tk.StringVar(value=tracker.today())
        self.cmb_day = None
        _hidden = tk.Frame(self.tab_datau)   # KHÔNG pack() -> ẩn hoàn toàn
        self.lbl_quest = tk.Label(_hidden, text="")
        self.lbl_view_dev = tk.Label(_hidden, text="")
        self.lbl_stat_milestone = tk.Label(_hidden, text="")
        self.lbl_stat_total = tk.Label(_hidden, text="")
        self.lbl_stat_done = tk.Label(_hidden, text="")
        self.lbl_stat_cancelled = tk.Label(_hidden, text="")
        self.lbl_stat_remain = tk.Label(_hidden, text="")

        # (Tab "Phân loại NV" đã GỘP vào tab Dã tẩu ở trên — không còn tab riêng.)
        self.tab_class = None

        # ===== Tab "Phần thưởng DT" — danh sách thưởng bot HỌC được (để sau đặt ưu tiên) =====
        self.tab_rewards = tk.Frame(self.notebook)
        self.notebook.add(self.tab_rewards, text="🎁 Phần thưởng")
        # 1 PANEL DUY NHẤT "phần thưởng nhận hôm nay" (đã merge 'nhận hôm nay' + 'vật phẩm' vì trùng nhau),
        # THEO NHÂN VẬT. Có label ĐẾM TỔNG theo loại.
        rw_frame = tk.LabelFrame(self.tab_rewards, text="Phần thưởng nhận hôm nay (theo nhân vật)", font=("Helvetica", 10, "bold"))
        rw_frame.pack(fill=tk.X, padx=8, pady=(8, 3))
        self.lbl_cnt_summary = tk.Label(rw_frame, anchor=tk.W, justify=tk.LEFT, font=("Helvetica", 10, "bold"), fg="#1a7f37",
                                        text="💰 Ngân lượng: 0\n⚔️ Kinh nghiệm: 0\n🟢 Thiết La Hán: 0")
        self.lbl_cnt_summary.pack(anchor=tk.W, padx=4, pady=(2, 0))
        self.txt_rewards = scrolledtext.ScrolledText(rw_frame, wrap=tk.WORD, height=7, state='disabled')
        self.txt_rewards.pack(fill=tk.BOTH, expand=True, padx=4, pady=3)
        self.txt_items = None   # đã merge vào txt_rewards

        rcols = ("name", "count", "rank")
        self.rewards_tree = ttk.Treeview(self.tab_rewards, columns=rcols, show="headings", height=7)
        self.rewards_tree.heading("name", text="Phần thưởng (kéo xếp)")
        self.rewards_tree.heading("count", text="Lần")
        self.rewards_tree.heading("rank", text="Hạng")
        self.rewards_tree.column("name", width=210, anchor=tk.W)
        self.rewards_tree.column("count", width=55, anchor=tk.CENTER, stretch=False)
        self.rewards_tree.column("rank", width=60, anchor=tk.CENTER, stretch=False)
        self.rewards_tree.pack(fill=tk.BOTH, expand=True, padx=8, pady=4)
        self.rewards_tree.bind("<ButtonPress-1>", self._rw_drag_start)
        self.rewards_tree.bind("<B1-Motion>", self._rw_drag_motion)
        self.rewards_tree.bind("<ButtonRelease-1>", self._rw_drag_drop)
        rbtn = tk.Frame(self.tab_rewards)
        rbtn.pack(fill=tk.X, padx=8, pady=4)
        tk.Button(rbtn, text="🔄 Tải lại", command=self._refresh_rewards).pack(side=tk.LEFT)
        self._refresh_rewards()

        # ===== TAB TÀI KHOẢN (account rotation): mỗi cửa sổ ôm 1 danh sách account =====
        self.tab_accounts = tk.Frame(self.notebook)
        self.notebook.add(self.tab_accounts, text="👤 Tài khoản")
        tk.Label(self.tab_accounts, font=("Helvetica", 10, "bold"),
                 text="Danh sách tài khoản (taikhoan:matkhau, mỗi dòng 1 acc):"
                 ).pack(anchor=tk.W, padx=8, pady=(8, 2))
        acc_top = tk.Frame(self.tab_accounts); acc_top.pack(fill=tk.X, padx=8, pady=2)
        self.lbl_acc_device = tk.Label(acc_top, text="Cửa sổ: (chọn cửa sổ ở bảng trên)", font=("Helvetica", 10, "bold"))
        self.lbl_acc_device.pack(side=tk.LEFT)
        self.lbl_acc_progress = tk.Label(acc_top, text="", fg="#1a7f37"); self.lbl_acc_progress.pack(side=tk.LEFT, padx=8)
        self.txt_accounts = scrolledtext.ScrolledText(self.tab_accounts, wrap=tk.WORD, height=5)
        self.txt_accounts.pack(fill=tk.BOTH, expand=True, padx=8, pady=4)
        tk.Button(self.tab_accounts, text="💾 Lưu danh sách cho cửa sổ này",
                  command=self._save_account_queue).pack(anchor=tk.W, padx=8, pady=(0, 4))
        # Bảng TRẠNG THÁI từng account: đã hoàn thành bao nhiêu/30 Dã Tẩu hôm nay.
        tk.Label(self.tab_accounts, text="Trạng thái Dã Tẩu từng tài khoản (hôm nay):",
                 font=("Helvetica", 10, "bold")).pack(anchor=tk.W, padx=8, pady=(4, 0))
        self.acct_status_tree = ttk.Treeview(self.tab_accounts, columns=("acc", "char", "st", "dep"), show="headings", height=6)
        self.acct_status_tree.heading("acc", text="TK")
        self.acct_status_tree.heading("char", text="Tên NV")
        self.acct_status_tree.heading("st", text="DT")
        self.acct_status_tree.heading("dep", text="Nộp")
        # Rút header + thu cột cho VỪA bề ngang ~380px (trước tổng 550px → cột 'Nộp' bị khuất).
        self.acct_status_tree.column("acc", width=95, anchor=tk.W, stretch=False)
        self.acct_status_tree.column("char", width=120, anchor=tk.W)
        self.acct_status_tree.column("st", width=55, anchor=tk.CENTER, stretch=False)
        self.acct_status_tree.column("dep", width=55, anchor=tk.CENTER, stretch=False)
        self.acct_status_tree.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))
        self._refresh_acct_devices()

        # ===== Tab "Thủ quỹ" — layout phẳng đơn giản (như trước) =====
        self.tab_treasurer = tk.Frame(self.notebook)
        self.notebook.add(self.tab_treasurer, text="💰 Thủ quỹ")
        # (Đã bỏ note 'Cửa sổ thủ quỹ' theo yêu cầu.)
        # Label tổng Thiết La Hán nhận hôm nay — ĐẾM TỪ LOG MỌI nhân vật (item_received 'Thiết La Hán'),
        # cập nhật định kỳ trong _poll_tracking → bền qua restart, không phụ thuộc trade event của riêng thủ quỹ.
        self.lbl_tlh_total = tk.Label(self.tab_treasurer, fg="white", bg="#1a7f37", font=("Helvetica", 10, "bold"),
                                      text="🟢 Thiết La Hán nhận hôm nay: 0 cái")
        self.lbl_tlh_total.pack(anchor=tk.W, padx=8, pady=(8, 4))
        # Vị trí thủ quỹ: chỉ NÚT GHIM (đọc vị trí hiện tại) + LABEL kết quả — không nhập tay.
        posf = tk.LabelFrame(self.tab_treasurer, text=" Vị trí thủ quỹ (worker sẽ đi tới đây) ")
        posf.pack(fill=tk.X, padx=8, pady=4)
        tk.Button(posf, text="📌 Ghim vị trí hiện tại của thủ quỹ", command=self._pin_treasurer_pos
                  ).pack(anchor=tk.W, padx=8, pady=6)
        self.lbl_treasurer_pos = tk.Label(posf, text="Vị trí: (chưa ghim)", fg="#1a7f37", justify=tk.LEFT)
        self.lbl_treasurer_pos.pack(anchor=tk.W, padx=8, pady=(0, 6))
        # Ngân lượng cấp cho worker mỗi lần xin tiền — nhập theo VẠN (mặc định 2 vạn).
        tr_money = tk.Frame(self.tab_treasurer); tr_money.pack(fill=tk.X, padx=8, pady=2)
        tk.Label(tr_money, text="Ngân lượng cấp mỗi lần worker xin tiền (VẠN):").pack(side=tk.LEFT)
        self.ent_tr_money = tk.Entry(tr_money, width=8); self.ent_tr_money.pack(side=tk.LEFT, padx=4)
        tk.Label(self.tab_treasurer, text="Vật phẩm GIAO cho thủ quỹ (tick = giao; bỏ tick = giữ lại):",
                 font=("Helvetica", 10, "bold")).pack(anchor=tk.W, padx=8, pady=(6, 0))
        gi_frame = tk.Frame(self.tab_treasurer); gi_frame.pack(fill=tk.X, padx=8, pady=4)
        gi_frame.columnconfigure(0, weight=1, uniform="gi")
        gi_frame.columnconfigure(1, weight=1, uniform="gi")
        # give_vars[label] = (BooleanVar, [member_names]) — 'Lắc Tống Kim' gom hết item (Tống Kim).
        self.give_vars = {}
        for i, (label, members) in enumerate(_treasurer.candidate_give_groups()):
            v = tk.BooleanVar(value=False)
            self.give_vars[label] = (v, members)
            tk.Checkbutton(gi_frame, anchor=tk.W, variable=v, text=label).grid(
                row=i // 2, column=i % 2, sticky=tk.W, padx=4, pady=1)
        tk.Button(self.tab_treasurer, text="💾 Lưu cấu hình thủ quỹ",
                  command=self._save_treasurer_config).pack(anchor=tk.W, padx=8, pady=(2, 4))
        # Panel LOG giao dịch của thủ quỹ.
        tk.Label(self.tab_treasurer, text="Nhật ký giao dịch thủ quỹ:",
                 font=("Helvetica", 10, "bold")).pack(anchor=tk.W, padx=8, pady=(2, 0))
        self.txt_treasurer_log = scrolledtext.ScrolledText(self.tab_treasurer, wrap=tk.WORD, height=5, state='disabled')
        self.txt_treasurer_log.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))
        self._refresh_treasurer_ui()

        # ===== Tab "Log" (chung mọi chế độ) — tách riêng theo yêu cầu (VulanPro-style gọn) =====
        self.tab_log = tk.Frame(self.notebook)
        self.notebook.add(self.tab_log, text="📋 Log")
        log_header = tk.Frame(self.tab_log); log_header.pack(fill=tk.X, padx=2, pady=(4, 0))
        tk.Label(log_header, text="Log thực thi (chung):", font=("Helvetica", 10, "bold")).pack(side=tk.LEFT)
        tk.Button(log_header, text="Xoá", command=self._clear_log).pack(side=tk.RIGHT)
        tk.Button(log_header, text="📋 Copy", command=self._copy_log).pack(side=tk.RIGHT, padx=4)
        self.log_area = scrolledtext.ScrolledText(self.tab_log, wrap=tk.WORD, height=16, state='disabled')
        self.log_area.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)

        self.log("Phần mềm sẵn sàng. Quét thiết bị và click [Auto] để bật.")
        self._apply_tab_access()   # khởi đầu: ẩn tab Thủ quỹ (chỉ hiện khi chọn cửa sổ đã đặt là thủ quỹ)

    ACCOUNT_QUEUE_PATH = "data/output/account_queue.json"
    ACCOUNT_PROGRESS_PATH = "data/output/account_progress.json"

    def _refresh_acct_devices(self):
        """(giữ tên cho tương thích) Nạp danh sách account của cửa sổ ĐANG CHỌN ở bảng trên."""
        self._load_account_queue_to_ui()

    def _treasurer_pos_text(self, cfg=None):
        cfg = cfg or _treasurer.load_config()
        pos = cfg.get("pos") or {}
        if pos.get("gx") is not None and pos.get("gy") is not None:
            town = _treasurer.town_for_map(pos.get("map_id"))
            return (f"📌 Đã ghim Thủ Quỹ tại {town or ('mapId ' + str(pos.get('map_id')))}, "
                    f"toạ độ ({pos.get('gx')},{pos.get('gy')})")
        return "Vị trí: (chưa ghim)"

    def _refresh_treasurer_ui(self):
        """Cập nhật nhãn cửa sổ thủ quỹ + nhãn vị trí + tick item + ngân lượng theo config."""
        cfg = _treasurer.load_config()
        if hasattr(self, 'lbl_treasurer_dev'):
            d = cfg.get("device")
            self.lbl_treasurer_dev.config(
                text=f"Cửa sổ thủ quỹ: {d}" if d else "Cửa sổ thủ quỹ: (chưa đặt — chuột phải tên cửa sổ → Đây là Thủ Quỹ)")
        if hasattr(self, 'lbl_treasurer_pos'):
            self.lbl_treasurer_pos.config(text=self._treasurer_pos_text(cfg))
        give = set(cfg.get("give_names") or [])
        for label, (v, members) in self.give_vars.items():
            if give:
                v.set(bool(members) and all(m in give for m in members))
            else:
                low = label.lower()
                v.set(("tống kim" in low) or ("la hán" in low))
        self.ent_tr_money.delete(0, tk.END)
        self.ent_tr_money.insert(0, str(int(cfg.get("give_money") or 20000) // 10000))   # VẠN (mặc định 2)

    def _pin_treasurer_pos(self):
        """GHIM vị trí hiện tại thủ quỹ -> LƯU THẲNG vào config + cập nhật nhãn (không cần nhập tay/bấm Lưu)."""
        dev = _treasurer.treasurer_device()
        if not dev:
            self.log("⚠️ Chưa đặt cửa sổ thủ quỹ (chuột phải tên cửa sổ → Đây là Thủ Quỹ) trước khi ghim."); return
        info = self.bots.get(dev)
        sm = info.get('bot') if info else None
        if not sm or not getattr(sm, 'game_bot_connected', False):
            self.log(f"⚠️ Cửa sổ {dev} chưa chạy/chưa kết nối Frida — bật Auto cửa sổ đó rồi ghim."); return
        try:
            pi = sm.game_bot.rpc.get_player_info() or {}
        except Exception as e:
            self.log(f"⚠️ Đọc vị trí lỗi: {e}", dev); return
        mx, my, mid = pi.get('mapX'), pi.get('mapY'), pi.get('mapId')
        # op9 (_lastPosition) CHỈ có khi nhân vật DI CHUYỂN → thủ quỹ đứng yên thường = 0/stale.
        # FALLBACK: đọc thẳng Character trong memory (không phụ thuộc di chuyển).
        if not (mx and my):
            try:
                r = sm.game_bot.rpc.read_position_from_memory() or {}
                if r.get('ok') and r.get('x') and r.get('y'):
                    mx, my = r.get('x'), r.get('y')
                    self.log(f"📌 (đọc vị trí từ memory: {mx},{my})", dev)
            except Exception as e:
                self.log(f"(đọc memory vị trí lỗi: {e})", dev)
        self.log(f"📌 Vị trí đọc được: mapX={mx} mapY={my} mapId={mid}", dev)
        if not (mx and my):
            self.log("⚠️ Toạ độ vẫn = 0 (thủ quỹ đứng yên, op9 chưa bắn + memory cũng 0). "
                     "Cho thủ quỹ ĐI 1 BƯỚC (di chuyển 1 ô) rồi bấm Ghim lại NGAY.", dev); return
        gx, gy = int(mx) // 256, int(my) // 256
        cfg = _treasurer.load_config()
        _treasurer.save_config(cfg.get("device"), cfg.get("give_names"),
                               pos={"map_id": mid, "gx": gx, "gy": gy}, give_money=cfg.get("give_money"))
        if hasattr(self, 'lbl_treasurer_pos'):
            self.lbl_treasurer_pos.config(text=self._treasurer_pos_text())
        town = _treasurer.town_for_map(mid)
        self.log(f"📌 Đã ghim Thủ Quỹ tại {town or ('mapId ' + str(mid))}, toạ độ ({gx},{gy}).", dev)

    def _save_treasurer_config(self):
        """Lưu danh sách item giao + ngân lượng. Vị trí đặt qua nút Ghim, cửa sổ qua chuột phải (giữ nguyên)."""
        cfg = _treasurer.load_config()
        dev = cfg.get("device")
        names = []
        for label, (v, members) in self.give_vars.items():
            if v.get():
                names.extend(members)          # nhóm 'Lắc Tống Kim' -> bung ra toàn bộ tên item Tống Kim
        try:
            gm = int(self.ent_tr_money.get().strip() or 2) * 10000   # nhập VẠN -> lượng (mặc định 2 vạn)
        except Exception:
            gm = 20000
            self.log("⚠️ Ngân lượng nhập sai → dùng mặc định 2 vạn.")
        _treasurer.save_config(dev, names, pos=cfg.get("pos"), give_money=gm)   # pos giữ nguyên (từ nút Ghim)
        self.log(f"💰 Đã lưu THỦ QUỸ = {dev or '(chưa đặt)'} | giao {len(names)} loại item | cấp {gm//10000} vạn/lần.",
                 dev or None)

    def treasurer_log(self, msg):
        """Ghi 1 dòng text thường vào panel nhật ký thủ quỹ (thread-safe)."""
        def _append():
            try:
                self.txt_treasurer_log.config(state='normal')
                self.txt_treasurer_log.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n", 'dim')
                self.txt_treasurer_log.see(tk.END)
                if int(self.txt_treasurer_log.index('end-1c').split('.')[0]) > 600:
                    self.txt_treasurer_log.delete(1.0, '200.0')
                self.txt_treasurer_log.config(state='disabled')
            except Exception:
                pass
        self.root.after(0, _append)

    TREASURER_STATS_DIR = "data/output/treasurer_stats"

    def _record_treasurer_stat(self, ev):
        """LƯU mỗi giao dịch thủ quỹ vào file theo NGÀY (để Thống kê tổng hợp): 1 dòng JSON
        {ts, who, received:{tên:sl}, money_van}. Toàn bộ cửa sổ ghi chung 1 file/ngày."""
        try:
            import os, json, datetime
            os.makedirs(self.TREASURER_STATS_DIR, exist_ok=True)
            day = datetime.date.today().isoformat()
            rec = {"ts": time.strftime('%H:%M:%S'),
                   "who": ev.get('who') or '?',
                   "received": ev.get('received') or {},
                   "money_van": int(ev.get('money_van') or 0)}
            with open(os.path.join(self.TREASURER_STATS_DIR, f"{day}.jsonl"), "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        except Exception:
            pass

    def treasurer_tx(self, ev):
        """Ghi 1 GIAO DỊCH có cấu trúc: Nhận (XANH) / Giao (ĐỎ), thẳng hàng + cập nhật tổng Thiết La Hán hôm nay.
        ev = {'who':..., 'received':{tên:sl}, 'money_van':int}."""
        self._record_treasurer_stat(ev)   # lưu để Thống kê theo ngày (mọi cửa sổ ghi chung file/ngày)
        def _append():
            try:
                t = self.txt_treasurer_log
                t.tag_configure('g', foreground='#1a7f37', font=("Menlo", 10))
                t.tag_configure('r', foreground='#c0392b', font=("Menlo", 10))
                t.tag_configure('dim', foreground='#888')
                who = ev.get('who') or '?'; recv = ev.get('received') or {}; mv = ev.get('money_van') or 0
                t.config(state='normal')
                t.insert(tk.END, f"[{time.strftime('%H:%M:%S')}]\n", 'dim')
                if recv:
                    t.insert(tk.END, "Nhận:\n", 'g')
                    for nm, c in recv.items():
                        t.insert(tk.END, f"    {nm}: {c}\n", 'g')
                    t.insert(tk.END, f"    từ {who}\n", 'g')
                if mv:
                    t.insert(tk.END, "Giao:\n", 'r')
                    t.insert(tk.END, f"    {mv}v\n", 'r')
                    t.insert(tk.END, f"    cho {who}\n", 'r')
                t.insert(tk.END, "──────────────\n", 'dim')
                t.see(tk.END)
                if int(t.index('end-1c').split('.')[0]) > 600:
                    t.delete(1.0, '200.0')
                t.config(state='disabled')
                # (Tổng Thiết La Hán hôm nay nay ĐẾM TỪ LOG mọi nhân vật trong _poll_tracking, không cộng dồn ở đây.)
            except Exception:
                pass
        self.root.after(0, _append)

    def _load_account_queue_to_ui(self):
        """Đổ list account của CỬA SỔ ĐANG CHỌN (bảng trên) ra ô text + hiện tiến độ done/N."""
        import json
        dev = self.current_log_device
        if hasattr(self, 'lbl_acc_device'):
            self.lbl_acc_device.config(text=f"Cửa sổ: {dev}" if dev else "Cửa sổ: (chọn cửa sổ ở bảng trên)")
        self.txt_accounts.delete("1.0", tk.END)
        if not dev:
            self.lbl_acc_progress.config(text=""); return
        try:
            data = json.load(open(self.ACCOUNT_QUEUE_PATH, encoding="utf-8"))
        except Exception:
            data = {}
        accts = data.get(dev) or []
        self.txt_accounts.insert("1.0", "\n".join(f"{a.get('acc','')}:{a.get('pass','')}" for a in accts))
        # tiến độ done hôm nay
        try:
            prog = json.load(open(self.ACCOUNT_PROGRESS_PATH, encoding="utf-8")).get(dev) or {}
            import datetime
            done = len(prog.get("done") or []) if prog.get("date") == datetime.date.today().isoformat() else 0
        except Exception:
            done = 0
        self.lbl_acc_progress.config(text=f"Đã xong hôm nay: {done}/{len(accts)}" if accts else "")
        self._refresh_account_status()

    ACC_CHAR_PATH = "data/output/acc_char_map.json"   # map acc(login) -> tên nhân vật (bền qua restart)

    def _load_acc_char(self):
        import json
        try:
            return json.load(open(self.ACC_CHAR_PATH, encoding="utf-8")) or {}
        except Exception:
            return {}

    def _remember_acc_char(self, acc, char):
        """Lưu acc->tên nhân vật khi bot đọc được tên (để bảng hiện tên cho cả account không chạy)."""
        import json, os
        if not acc or not char:
            return
        try:
            m = self._load_acc_char()
            if m.get(acc) == char:
                return
            m[acc] = char
            os.makedirs(os.path.dirname(self.ACC_CHAR_PATH), exist_ok=True)
            json.dump(m, open(self.ACC_CHAR_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _account_status_rows(self, dev):
        """Trạng thái Dã Tẩu từng account của 1 CỬA SỔ (dùng chung cho bảng UI lẫn web).
        Trả list [{acc, char, st, dep}] — KHÔNG kèm mật khẩu. st = '✅/▶️/⏸️/⏳/⚠️ X/N (...)'."""
        import json, datetime
        rows = []
        if not dev:
            return rows
        try:
            accts = json.load(open(self.ACCOUNT_QUEUE_PATH, encoding="utf-8")).get(dev) or []
        except Exception:
            accts = []
        try:
            prog = json.load(open(self.ACCOUNT_PROGRESS_PATH, encoding="utf-8")).get(dev) or {}
            _td = prog.get("date") == datetime.date.today().isoformat()
            done_set = set(prog.get("done") or []) if _td else set()
            err_set = set(prog.get("errored") or []) if _td else set()   # account LỖI login (KHÔNG phải xong)
        except Exception:
            done_set = set(); err_set = set()
        # account ĐANG chạy (acc + tên nhân vật live)
        cur_acc, ch = None, ''
        info = self.bots.get(dev)
        bot = info.get('bot') if info else None
        if bot is not None:
            try:
                q = getattr(bot, 'account_queue', []) or []
                idx = getattr(bot, 'account_index', 0)
                if 0 <= idx < len(q):
                    cur_acc = q[idx].get('acc')
                ch = getattr(bot, 'player_name', '') or ''
            except Exception:
                pass
        # TIẾN ĐỘ đọc từ TRACKER (quest_completed/received theo NHÂN VẬT) — NGUỒN ĐÁNG TIN, BỀN QUA RESTART.
        # ⚠️ Trước đây suy từ session-state bot (daily_done/last_remaining/max_remaining_today) → watchdog restart
        # cửa sổ là reset hết về 0 dù char đã làm nhiều NV → hiển thị SAI/0 ("không phản ánh đúng gì luôn").
        # Tracker: qno = số thứ tự NV (tích luỹ/ngày) → done = qno lớn nhất của quest_completed; remaining ở record
        # cuối → cap = done + remaining (tổng NV/ngày, ĐỘNG). daily_limit → done = cap (xong).
        day_recs = [r for r in self._load_day_cached(tracker.today())
                    if r.get("device") in (dev, "SYSTEM")]

        def _char_prog(cname):
            if not cname:
                return None
            cr = [r for r in day_recs if r.get('char') == cname]
            if not cr:
                return None
            # MAX CỐ ĐỊNH = DAILY_CAP (20) — user CHỐT mỗi nhân vật 20 NV/ngày, KHÔNG suy động (done+remaining)
            # nữa (trước hiện 16/18/19 lung tung do server trả 'còn M nhiệm vụ' lệch). done = HOÀN THÀNH + ĐÃ HUỶ
            # (user: "15 làm + 5 huỷ = 20/20"), đếm theo NGÀY, chặn trần ở 20.
            done = sum(1 for r in cr if r.get('type') in ('quest_completed', 'quest_cancelled'))
            done = min(done, DAILY_CAP)
            return (done, DAILY_CAP)

        # Ghi nhớ tên nhân vật của account ĐANG chạy (acc -> char) để hiện cho cả account không chạy.
        if cur_acc and ch:
            self._remember_acc_char(cur_acc, ch)
        acc_char = self._load_acc_char()
        dep_set = _treasurer.deposited_today(dev)   # account đã nộp thủ quỹ hôm nay
        for a in accts:
            acc = a.get('acc', '')
            # tên NV: ưu tiên tên LIVE của account đang chạy, còn lại tra map đã lưu.
            cname = (ch if (acc and acc == cur_acc and ch) else acc_char.get(acc, "")) or ""
            name = cname or "—"
            p = _char_prog(cname)
            if acc in err_set:
                st = "⚠️ LỖI login (chưa làm được)"   # KHÔNG hiện "xong" cho account lỗi
            elif acc in done_set:
                cap = p[1] if p else DAILY_CAP
                st = f"✅ {cap}/{cap} (xong)"
            elif acc and acc == cur_acc:
                st = f"▶️ {p[0]}/{p[1]} (đang làm)" if p else f"▶️ 0/{DAILY_CAP} (đang làm)"
            elif p and p[0] > 0:
                st = f"⏸️ {p[0]}/{p[1]} (dở dang)"
            else:
                st = f"⏳ 0/{DAILY_CAP} (chưa làm)"
            dep = "✅ đã nộp" if acc in dep_set else "—"
            rows.append({'acc': acc, 'char': name, 'st': st, 'dep': dep})
        return rows

    def _refresh_account_status(self):
        """Bảng trạng thái (UI app): mỗi account đã làm X/N Dã Tẩu hôm nay + đã nộp thủ quỹ chưa."""
        tv = getattr(self, "acct_status_tree", None)
        if tv is None:
            return
        for it in tv.get_children():
            tv.delete(it)
        for r in self._account_status_rows(self.current_log_device):
            tv.insert("", tk.END, values=(r['acc'], r['char'], r['st'], r['dep']))

    def _save_account_queue(self):
        """Parse 'user:pass' mỗi dòng -> ghi account_queue.json[device] -> push live cho bot đang chạy."""
        import json, os
        dev = self.current_log_device
        if not dev:
            self.log("Chưa chọn cửa sổ để lưu danh sách tài khoản."); return
        accts = []
        for line in self.txt_accounts.get("1.0", tk.END).splitlines():
            line = line.strip()
            if not line or ":" not in line:
                continue
            u, p = line.split(":", 1)
            if u.strip():
                accts.append({"acc": u.strip(), "pass": p.strip()})
        try:
            data = json.load(open(self.ACCOUNT_QUEUE_PATH, encoding="utf-8"))
        except Exception:
            data = {}
        data[dev] = accts
        os.makedirs(os.path.dirname(self.ACCOUNT_QUEUE_PATH), exist_ok=True)
        json.dump(data, open(self.ACCOUNT_QUEUE_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        # push live cho bot đang chạy (nạp lại queue ngay)
        info = self.bots.get(dev)
        if info and info.get('bot'):
            try:
                info['bot']._load_account_queue()
            except Exception:
                pass
        self.log(f"Đã lưu {len(accts)} tài khoản cho cửa sổ {dev}.")
        self._load_account_queue_to_ui()

    def _load_luyencong_queue_to_ui(self):
        """Đổ danh sách account luyện công (acc:pass:tên) của cửa sổ ĐANG CHỌN ra ô text."""
        dev = self.current_log_device
        if hasattr(self, 'lbl_lc_device'):
            self.lbl_lc_device.config(text=f"Cửa sổ: {dev}" if dev else "Cửa sổ: (chọn cửa sổ ở bảng trên)")
        if not hasattr(self, 'txt_lc_accounts'):
            return
        self.txt_lc_accounts.delete("1.0", tk.END)
        if dev:
            self.txt_lc_accounts.insert("1.0", _lc_accounts.queue_text(dev))

    def _save_luyencong_queue(self):
        """Parse 'acc:pass:tên' mỗi dòng -> lưu luyencong_queue.json[device] -> push live cho bot."""
        dev = self.current_log_device
        if not dev:
            self.log("Chưa chọn cửa sổ để lưu danh sách luyện công."); return
        accts = _lc_accounts.parse_lines(self.txt_lc_accounts.get("1.0", tk.END))
        _lc_accounts.save_queue(dev, accts)
        info = self.bots.get(dev)
        if info and info.get('bot'):
            try:
                info['bot']._lc_reload_queue()
            except Exception:
                pass
        self.log(f"🏋️ Đã lưu {len(accts)} account luyện công cho cửa sổ {dev}.")

    def _refresh_rewards(self):
        """Đổ lại danh sách phần thưởng đã học từ data/output/datau_rewards.json."""
        try:
            for it in self.rewards_tree.get_children():
                self.rewards_tree.delete(it)
            # SẮP theo ưu tiên người chơi (trên=cao); cột 'Hạng' = số thứ tự (1=cao nhất).
            for i, r in enumerate(datau_rewards.load_ordered(), 1):
                self.rewards_tree.insert("", tk.END, values=(r["name"], r["count"], i))
        except Exception as e:
            logging.error(f"refresh_rewards: {e}")

    # ---- Drag-drop sắp xếp ưu tiên phần thưởng ----
    def _rw_drag_start(self, e):
        self._rw_drag_item = self.rewards_tree.identify_row(e.y)
        self._rw_moved = False

    def _rw_drag_motion(self, e):
        it = getattr(self, "_rw_drag_item", "")
        if not it:
            return
        tgt = self.rewards_tree.identify_row(e.y)
        if tgt and tgt != it:
            self.rewards_tree.move(it, "", self.rewards_tree.index(tgt))
            self._rw_moved = True

    def _rw_drag_drop(self, e):
        if not getattr(self, "_rw_drag_item", "") or not getattr(self, "_rw_moved", False):
            self._rw_drag_item = ""
            return
        self._rw_drag_item = ""
        try:
            names = [self.rewards_tree.item(i, "values")[0] for i in self.rewards_tree.get_children()]
            datau_rewards.save_order(names)               # lưu: trên = ưu tiên cao
            for n, i in zip(self.rewards_tree.get_children(), range(1, len(names) + 1)):
                v = list(self.rewards_tree.item(n, "values")); v[2] = i
                self.rewards_tree.item(n, values=v)       # cập nhật cột Hạng
            self.log("Đã lưu thứ tự ưu tiên phần thưởng (bot sẽ chọn theo thứ tự này).")
        except Exception as ex:
            logging.error(f"rw_drag_drop: {ex}")

    def _flatbtn(self, parent, text, cmd, bg, hover, fg="white", pad=12, fsize=10):
        """Nút PHẲNG có màu (Label-as-button) — đẹp + đồng nhất trên macOS (tk.Button bỏ qua bg). Có hover."""
        b = tk.Label(parent, text=text, bg=bg, fg=fg, font=("Helvetica", fsize, "bold"), cursor="hand2", padx=pad, pady=5)
        b.bind("<Button-1>", lambda e: cmd())
        b.bind("<Enter>", lambda e: b.config(bg=hover))
        b.bind("<Leave>", lambda e: b.config(bg=bg))
        return b

    def _show_treasurer_stats(self):
        """Dashboard THỐNG KÊ theo NGÀY: header + 2 thẻ tổng (ngân lượng/vật phẩm) + bảng vật phẩm.
        Dữ liệu = mọi cửa sổ nộp thủ quỹ (file treasurer_stats/<ngày>.jsonl)."""
        import os, json, glob, datetime
        def _vn(n):   # định dạng số kiểu VN: 12345 -> 12.345
            return f"{int(n):,}".replace(",", ".")
        win = tk.Toplevel(self.root)
        win.title("Thống kê Thủ Quỹ"); win.geometry("470x540"); win.configure(bg="#eef1f4")

        # ── HEADER (dải màu tối + tiêu đề + chọn ngày) ──
        hdr = tk.Frame(win, bg="#1f2d3d"); hdr.pack(fill=tk.X)
        tk.Label(hdr, text="📊  THỐNG KÊ THỦ QUỸ", font=("Helvetica", 10, "bold"),
                 fg="white", bg="#1f2d3d").pack(side=tk.LEFT, padx=16, pady=13)
        days = []
        try:
            for f in sorted(glob.glob(os.path.join(self.TREASURER_STATS_DIR, "*.jsonl")), reverse=True):
                days.append(os.path.basename(f)[:-6])
        except Exception:
            pass
        today = datetime.date.today().isoformat()
        if today not in days:
            days = [today] + days
        var = tk.StringVar(value=days[0] if days else today)
        cmb = ttk.Combobox(hdr, textvariable=var, values=days, width=13, state="readonly")
        cmb.pack(side=tk.RIGHT, padx=(0, 16))
        tk.Label(hdr, text="📅", bg="#1f2d3d", fg="white", font=("Helvetica", 10)).pack(side=tk.RIGHT, padx=(0, 4))

        # ── 2 THẺ TỔNG ──
        cards = tk.Frame(win, bg="#eef1f4"); cards.pack(fill=tk.X, padx=14, pady=(14, 4))
        cards2 = tk.Frame(win, bg="#eef1f4"); cards2.pack(fill=tk.X, padx=14, pady=(0, 10))
        def _card(title, color, parent=None):
            c = tk.Frame(parent or cards, bg="white", highlightbackground="#d8dee5", highlightthickness=1)
            c.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=6)
            tk.Label(c, text=title, font=("Helvetica", 10, "bold"), fg="#7a8794", bg="white").pack(anchor="w", padx=14, pady=(11, 0))
            v = tk.Label(c, text="—", font=("Helvetica", 10, "bold"), fg=color, bg="white")
            v.pack(anchor="w", padx=14, pady=(0, 12))
            return v
        lbl_money = _card("💰 NGÂN LƯỢNG ĐÃ CẤP", "#b9770e")
        lbl_total = _card("📦 TỔNG VẬT PHẨM", "#1a7f37")
        lbl_accts = _card("👥 ACC LÀM NV HÔM NAY", "#1f6feb", parent=cards2)
        lbl_quests = _card("✅ TỔNG NV HOÀN THÀNH", "#8250df", parent=cards2)
        lbl_tlh = tk.Label(win, text="—", font=("Helvetica", 10, "bold"), fg="#8a6d3b", bg="#eef1f4")
        lbl_tlh.pack(anchor="w", padx=20, pady=(0, 2))

        # ── BẢNG ĐỐI SOÁT: NHẬN vs GIAO theo NHÂN VẬT (xem account nào giao thừa/thiếu) ──
        tk.Label(win, text="Đối soát vật phẩm giao-được theo nhân vật:  NHẬN (reward) vs ĐÃ GIAO thủ quỹ",
                 font=("Helvetica", 10, "bold"), fg="#34495e", bg="#eef1f4").pack(anchor="w", padx=20, pady=(2, 4))
        tframe = tk.Frame(win, bg="white", highlightbackground="#d8dee5", highlightthickness=1)
        tframe.pack(fill=tk.BOTH, expand=True, padx=16, pady=(0, 8))
        st = ttk.Style()
        st.configure("Stat.Treeview", rowheight=30, font=("Helvetica", 10),
                     background="white", fieldbackground="white", borderwidth=0)
        st.configure("Stat.Treeview.Heading", font=("Helvetica", 10, "bold"))
        tree = ttk.Treeview(tframe, columns=("char", "recv", "given", "diff"), show="headings", style="Stat.Treeview", height=8)
        tree.heading("char", text="NHÂN VẬT"); tree.heading("recv", text="NHẬN"); tree.heading("given", text="ĐÃ GIAO"); tree.heading("diff", text="CHÊNH")
        tree.column("char", width=200, anchor="w"); tree.column("recv", width=80, anchor="e")
        tree.column("given", width=80, anchor="e"); tree.column("diff", width=90, anchor="e")
        tree.tag_configure("odd", background="#f4f7fa")
        tree.tag_configure("short", foreground="#c0392b")   # chênh != 0 (nhận nhưng chưa giao đủ) = ĐỎ
        tree.tag_configure("ok", foreground="#1a7f37")
        tree.pack(fill=tk.BOTH, expand=True)

        foot = tk.Frame(win, bg="#eef1f4"); foot.pack(fill=tk.X, padx=20, pady=(0, 10))
        lbl_foot = tk.Label(foot, text="", font=("Helvetica", 10), fg="#7a8794", bg="#eef1f4")
        lbl_foot.pack(side=tk.LEFT)
        def _send_zalo():
            from core import notifier as _N
            if not _N.is_enabled():
                lbl_foot.config(text="⚠️ Chưa bật/cấu hình Zalo (data/output/notify_config.json)")
                return
            ok = _N.send_stats(var.get() or today)
            lbl_foot.config(text=("📤 Đã gửi thống kê qua Zalo." if ok else "⚠️ Ngày này chưa có dữ liệu để gửi."))
        self._flatbtn(foot, "📤 Gửi Zalo", _send_zalo, "#0068ff", "#3385ff").pack(side=tk.RIGHT)

        def _load():
            day = var.get() or today
            # ĐỒ ĐÃ GIAO THỦ QUỸ theo NHÂN VẬT (treasurer_stats: who + received) — để đối soát với NHẬN.
            given = {}; money = 0; ntx = 0
            given_by_char = {}
            try:
                for l in open(os.path.join(self.TREASURER_STATS_DIR, f"{day}.jsonl"), encoding="utf-8"):
                    if not l.strip():
                        continue
                    r = json.loads(l); ntx += 1
                    money += int(r.get("money_van", 0) or 0)
                    who_g = (r.get("who") or "").strip()
                    n_g = sum(int(c or 0) for c in (r.get("received") or {}).values())
                    if who_g:
                        given_by_char[who_g] = given_by_char.get(who_g, 0) + n_g
                    for nm, c in (r.get("received") or {}).items():
                        given[nm] = given.get(nm, 0) + int(c or 0)
            except Exception:
                pass
            # VẬT PHẨM = ĐẾM TỪ REWARD LOG MỌI NHÂN VẬT (tracker item_received) — mọi cửa sổ, mọi char trong NGÀY.
            # (User chốt 2026-06-16: thống kê phải lấy từ log thưởng của TẤT CẢ char, KHÔNG phải chỉ đồ đã giao
            # thủ quỹ — trước đây bảng này chỉ cộng treasurer_stats nên thiếu đồ char tự nhận mà chưa giao.)
            import re as _re
            def _parse_reward(raw):
                """Chuỗi thưởng thô -> (kind, key, amount). kind: 'item'|'money'|'exp'.
                Tách tên VẬT PHẨM thật khỏi exp/lượng để gom nhóm sạch (vd 'Nhận được Chiến cổ (Tống Kim) từ
                Dã Tẩu' -> item 'Chiến cổ (Tống Kim)')."""
                s = (raw or "").strip()
                m = _re.search(r'nhận được\s+(.+?)(?:\s+từ dã tẩu)?$', s, _re.I)
                content = (m.group(1).strip() if m else s)
                cl = content.lower()
                dnum = _re.search(r'([\d.]+)', content)
                amt = int(dnum.group(1).replace('.', '')) if dnum else 0
                if 'kinh nghiệm' in cl:
                    return ('exp', 'Kinh nghiệm', amt)
                if 'lượng' in cl:
                    return ('money', 'Ngân lượng', amt)
                name = _re.sub(r'^\+?\d[\d.]*\s*', '', content)            # bỏ tiền tố '+123 '
                name = name.replace('vật phẩm mới', '').strip(' |').strip()
                return ('item', name or '(không rõ)', 1)

            # NHẬN vật phẩm GIAO-ĐƯỢC theo NHÂN VẬT (reward log: char + item_received). Giao-được = Thiết La Hán
            # + đồ Tống Kim (đúng bộ giao thủ quỹ). exp/lượng KHÔNG tính (không giao). items{}=tổng theo loại (thẻ).
            items = {}; chars_done = set(); n_quests = 0; chars_daily = set(); tlh_recv = 0
            recv_by_char = {}
            def _giveable(nm):
                low = (nm or "").lower()
                return ("thiết la hán" in low) or ("tống kim" in low)
            try:
                for r in (tracker.load_day(day) or []):
                    t = r.get("type")
                    who = (r.get("char") or r.get("device_id") or "").strip()
                    if t == "quest_completed":
                        n_quests += 1
                        if who: chars_done.add(who)
                    elif t == "daily_limit":
                        if who: chars_daily.add(who)
                    elif t == "item_received":
                        kind, key, amt = _parse_reward(r.get("name"))
                        if kind == 'item':
                            items[key] = items.get(key, 0) + 1
                            if _giveable(key):
                                if who: recv_by_char[who] = recv_by_char.get(who, 0) + 1
                                if "thiết la hán" in key.lower(): tlh_recv += 1
            except Exception:
                pass
            total_giveable_recv = sum(recv_by_char.values())
            lbl_money.config(text=f"{_vn(money)} vạn")
            lbl_total.config(text=f"{_vn(total_giveable_recv)} nhận · {_vn(sum(given_by_char.values()))} giao")
            lbl_accts.config(text=f"{_vn(len(chars_done))} acc"
                             + (f"  (xong daily: {_vn(len(chars_daily))})" if chars_daily else ""))
            lbl_quests.config(text=f"{_vn(n_quests)} nhiệm vụ")
            tlh_given = sum(c for nm, c in given.items() if "thiết la hán" in (nm or "").lower())
            lbl_tlh.config(text=f"🤝 Thiết La Hán: nhận {_vn(tlh_recv)} · giao thủ quỹ {_vn(tlh_given)}")
            for i in tree.get_children():
                tree.delete(i)
            chars = sorted(set(recv_by_char) | set(given_by_char),
                           key=lambda c: -(recv_by_char.get(c, 0) - given_by_char.get(c, 0)))
            for n, c in enumerate(chars):
                rv = recv_by_char.get(c, 0); gv = given_by_char.get(c, 0); diff = rv - gv
                tag = "short" if diff != 0 else "ok"
                dtxt = (f"+{diff}" if diff > 0 else str(diff))   # +N = nhận nhiều hơn giao (giữ lại/CHƯA giao đủ)
                tree.insert("", tk.END, values=(f"  {c}", f"{_vn(rv)} ", f"{_vn(gv)} ", f"{dtxt} "),
                            tags=(tag, "odd") if n % 2 else (tag,))
            if not chars:
                tree.insert("", tk.END, values=("  (chưa có dữ liệu nhận/giao trong ngày)", "", "", ""))
            lbl_foot.config(text=f"Nhận {_vn(total_giveable_recv)} vs Giao {_vn(sum(given_by_char.values()))} (giao-được) · "
                                 f"CHÊNH>0 = nhận nhưng chưa giao đủ · ngày {day}")

        cmb.bind("<<ComboboxSelected>>", lambda e: _load())
        _load()

    def _reset_adb_server(self):
        """Reset adb-server lúc app khởi động — GIỐNG run_mac.command (pkill adb + start-server). QUAN TRỌNG khi
        app tự re-exec (auto-deploy) vì re-exec KHÔNG chạy lại run_mac.command → adb có thể kẹt (version conflict /
        socket cũ) → discover_devices rỗng → 'không tìm thấy cửa sổ'. CHẠY ĐỒNG BỘ (xong trước khi dò thiết bị
        để khỏi đua adb với _refresh_devices) — ~1-2s, chỉ 1 lần lúc mở app."""
        import subprocess
        try:
            from core.adb_helper import ADB_PATH
        except Exception:
            ADB_PATH = "adb"
        try:
            subprocess.run("pkill -9 adb", shell=True, timeout=5,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
        time.sleep(1)
        try:
            subprocess.run(f'"{ADB_PATH}" start-server', shell=True, timeout=10,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
        try:
            self.log("🔌 Đã reset adb-server (tránh lỗi không thấy cửa sổ sau khi khởi động lại).")
        except Exception:
            pass

    DEPLOY_POLL_MS = 30 * 1000   # canh code mới (Syncthing) mỗi 30s

    def _deploy_watch_tick(self):
        """Canh gói code MỚI từ máy nguồn (qua Syncthing treasurer_shared/deploy). Thấy bản mới -> áp code đè +
        ghi cờ resume (cửa sổ đang chạy) -> re-exec app. Sau re-exec _auto_resume_after_deploy tự bật Auto lại.
        (User chọn: re-exec NGAY khi có code mới, kể cả đang giữa NV.)"""
        try:
            from core import deploy_sync as _D
            nd = _D.has_new_deploy()
            if nd:
                ver, pub = nd
                self.log(f"📦 Có bản code MỚI (build {ver}) từ máy {pub} → áp + khởi động lại app…")
                if _D.apply_code_zip():
                    _D.mark_applied(ver)
                    running = [d for d, info in self.bots.items()
                               if isinstance(info, dict) and info.get('is_running')]
                    _D.save_resume(running)
                    self.log(f"📦 Đã áp code {ver}. Khởi động lại app + tự bật Auto lại {len(running)} cửa sổ.")
                    self._restart_app()
                    return   # đang re-exec, không lên lịch tiếp
                else:
                    self.log("📦 Gói code đang sync dở (zip chưa đủ) → thử lại lượt sau.")
        except Exception as e:
            try: self.log(f"📦 deploy-watch lỗi: {e}")
            except Exception: pass
        self.root.after(self.DEPLOY_POLL_MS, self._deploy_watch_tick)

    def _auto_resume_after_deploy(self):
        """Sau khi re-exec do cập nhật code: tự bật Auto lại các cửa sổ đang chạy trước đó (cờ resume)."""
        try:
            from core import deploy_sync as _D
            devs = _D.pop_resume()
        except Exception:
            devs = []
        if not devs:
            return
        self.log(f"📦 Sau cập nhật code: sẽ tự bật lại Auto {len(devs)} cửa sổ (chờ dò thiết bị)…")
        # RETRY tới khi MỖI thiết bị dò ra (tree.exists) mới bật — thiết bị dò chậm/không đều khác nhau, nếu chỉ
        # bật 1 phát lúc 6s thì cửa sổ chưa dò kịp sẽ KHÔNG tự tick (bug "cửa sổ tick, cửa sổ không").
        pending = set(devs)
        deadline = time.time() + 90
        def _tick():
            if not pending or time.time() > deadline:
                if pending:
                    self.log(f"📦 Hết giờ chờ — {len(pending)} cửa sổ chưa dò ra để tự bật: {sorted(pending)} "
                             f"(bấm Auto tay nếu cần).")
                return
            for d in list(pending):
                try:
                    if self.bots.get(d, {}).get('is_running'):
                        pending.discard(d); continue        # đã chạy (vd watchdog) → bỏ
                    if self.tree.exists(d):                  # CHỈ bật khi thiết bị ĐÃ dò ra
                        self._start_bot(d, force=True)
                        pending.discard(d)
                except Exception as e:
                    self.log(f"📦 tự bật {d} lỗi: {e}", d)
            if pending:
                self.root.after(3000, _tick)
        self.root.after(4000, _tick)   # bắt đầu sau 4s, retry mỗi 3s tới khi đủ hoặc 90s

    def _restart_app(self):
        """KHỞI ĐỘNG LẠI HẲN tiến trình app (re-exec) — GIỐNG pkill + chạy lại: Frida chết ở mức OS, frida-server
        nhả hết session; tiến trình mới attach SẠCH 100%. Dùng khi bot đứng/connect treo (nút 'toàn bộ' cũ
        detach trong-tiến-trình không đủ sạch). Sau khi mở lại, TICK vào cửa sổ để chạy. (mất state UI, phải tick lại.)"""
        import os, sys
        self.log("♻️ KHỞI ĐỘNG LẠI APP — đóng Frida + chạy lại tiến trình mới. Sau khi mở lại hãy TICK để auto chạy.")
        # best-effort: ra lệnh dừng + detach Frida cho gọn (execv sẽ nuke hết, nhưng nhả trước cho frida-server sạch).
        for dev, info in list(self.bots.items()):
            try:
                if isinstance(info, dict):
                    info['is_running'] = False
                    b = info.get('bot')
                    if b is not None:
                        setattr(b, '_run_active', False)
                        gb = getattr(b, 'game_bot', None)
                        if gb is not None:
                            gb.close()
            except Exception:
                pass

        def _reexec():
            try:
                self.root.destroy()
            except Exception:
                pass
            try:
                os.execv(sys.executable, [sys.executable] + sys.argv)   # thay tiến trình bằng bản mới (fresh)
            except Exception as e:
                print(f"[restart_app] execv lỗi: {e} — thử spawn mới")
                import subprocess
                subprocess.Popen([sys.executable] + sys.argv)
                os._exit(0)
        # chờ ~1.2s cho close() detach xong rồi re-exec
        self.root.after(1200, _reexec)

    def _restart_all_bots(self):
        """(GIỮ DỰ PHÒNG) Tắt+attach lại trong-tiến-trình (KHÔNG re-exec). Ít hiệu quả hơn _restart_app khi Frida treo."""
        running = [dev for dev, info in self.bots.items()
                   if isinstance(info, dict) and info.get('is_running')]
        if not running:
            self.log("🔁 Không có cửa sổ nào đang chạy để khởi động lại.")
            return
        self.log(f"🔁 KHỞI ĐỘNG LẠI {len(running)} cửa sổ: tắt sạch (detach Frida) → attach lại…")

        def _worker():
            # 1) TẮT tất cả (ra lệnh dừng + detach trong luồng cũ). _stop_bot set _run_active=False -> luồng
            #    cũ thoát + gb.close() (detach) trong finally.
            for dev in running:
                try:
                    self._stop_bot(dev, full=True)   # DỪNG HẲN (nhả Frida) — restart cần attach SẠCH, không pause
                except Exception as e:
                    self.log(f"(dừng {dev} lỗi: {e})", dev)
            time.sleep(1.5)   # nhịp để các luồng cũ kịp vào finally (detach); _start_bot còn join chờ tiếp
            # 2) BẬT LẠI từng cửa sổ (luồng mới CHỜ luồng cũ nhả Frida xong rồi mới connect — chống đua).
            for dev in running:
                try:
                    self.root.after(0, lambda d=dev: self._start_bot(d))
                    time.sleep(0.4)   # rải nhẹ, tránh dồn attach cùng lúc
                except Exception as e:
                    self.log(f"(bật lại {dev} lỗi: {e})", dev)
            self.log("🔁 Đã ra lệnh khởi động lại toàn bộ — các cửa sổ sẽ attach lại + chạy tiếp.")

        threading.Thread(target=_worker, daemon=True).start()

    def _refresh_devices(self):
        # Xoá list cũ (UI thread)
        for item in self.tree.get_children():
            if item not in self.bots or not self.bots[item]['is_running']:
                self.tree.delete(item)
        if getattr(self, "_scanning_devices", False):
            return
        self._scanning_devices = True
        self.log("Đang quét giả lập (chạy nền, KHÔNG đơ UI)...")

        # QUÉT adb chạy LUỒNG NỀN — trước đây quét ~29 cổng tuần tự trên luồng UI gây ĐƠ ~1 phút.
        def _scan():
            res = {"devices": None, "err": ""}
            try:
                from core.adb_helper import ADB_PATH
                from core.device_discovery import discover_devices
                _ignored = self._load_ignored_devices()
                _all = [d for d in discover_devices(ADB_PATH, package="vn.perfingame.jx1mobile")
                        if d not in _ignored]
                # Ưu tiên device TCP (127.0.0.1:port). Nếu KHÔNG có TCP nào (MuMu trên 1 số máy đăng ký
                # kiểu native 'emulator-5554') thì CHẤP NHẬN emulator-* — chúng đã được lọc theo game cài
                # trong discover_devices. Tránh vừa loại nhầm MuMu vừa không trùng device (TCP+emulator cùng máy).
                _tcp = [d for d in _all if not d.startswith("emulator-")]
                res["devices"] = _tcp if _tcp else _all
            except Exception as e:
                res["err"] = str(e)
            def _apply():
                self._scanning_devices = False
                if res["devices"] is None:
                    self.log(f"Lỗi tìm thiết bị: {res['err']}")
                    return
                for dev in res["devices"]:
                    if not self.tree.exists(dev):
                        self.tree.insert("", tk.END, iid=dev, values=("⬜", self._dev_label(dev), "-", "—"))
                try:
                    n = len(self.tree.get_children())
                    self.lbl_dev_count.config(text=f"🖥  {n} cửa sổ")
                except Exception:
                    pass
                self.log(f"Tìm thấy {len(res['devices'])} giả lập." if res["devices"]
                         else "Không tìm thấy giả lập nào đang chạy game!")
            self.root.after(0, _apply)
        threading.Thread(target=_scan, daemon=True).start()

    def _on_tree_click(self, event):
        # Xử lý click vào ô Checkbox (cột 'auto')
        region = self.tree.identify("region", event.x, event.y)
        if region == "cell":
            column = self.tree.identify_column(event.x)
            item_id = self.tree.identify_row(event.y)
            if column == '#1': # Cột Auto
                # PENDING (⏸▶) -> bấm = RESUME (chạy tiếp), KHÔNG tắt bot.
                if item_id in self.paused_devices:
                    self._resume_bot(item_id)
                    return
                current_values = list(self.tree.item(item_id, "values"))
                current_state = current_values[0]
                if current_state == "⬜":
                    current_values[0] = "✅"
                    self.tree.item(item_id, values=current_values)
                    self._start_bot(item_id)
                else:
                    current_values[0] = "⬜"
                    self.tree.item(item_id, values=current_values)
                    self._stop_bot(item_id)

    DEVICE_LABELS_PATH = "data/output/device_labels.json"

    def _load_device_labels(self):
        import json
        try:
            return json.load(open(self.DEVICE_LABELS_PATH, encoding="utf-8")) or {}
        except Exception:
            return {}

    def _mumu_names(self):
        """Map {adb_port(str): tên instance MuMu} qua `mumutool info all` (MuMuPlayer Pro). Cache 30s.
        → tự lấy tên cửa sổ user đặt trong MuMu (vd 'Cày Cấp 1', 'Thủ Quỹ') KHÔNG cần đặt tay."""
        import time as _t
        if getattr(self, '_mumu_ts', 0) and (_t.time() - self._mumu_ts) < 30:
            return getattr(self, '_mumu_cache', {})
        out = {}
        try:
            import subprocess, json
            tool = next((p for p in (
                "/Applications/MuMuPlayer Pro.app/Contents/MacOS/mumutool",
                "/Applications/MuMuPlayer.app/Contents/MacOS/mumutool") if os.path.exists(p)), None)
            if tool:
                r = subprocess.run([tool, "info", "all"], capture_output=True, text=True, timeout=5)
                for it in (json.loads(r.stdout).get("return", {}) or {}).get("results", []):
                    p, nm = it.get("adb_port"), it.get("name")
                    if p and nm:
                        out[str(p)] = nm
        except Exception:
            pass
        self._mumu_cache, self._mumu_ts = out, _t.time()
        return out

    def _dev_label(self, dev):
        """Nhãn TRƯỚC khi có tên nhân vật: tên user đặt tay > tên instance MuMu (mumutool) > cổng.
        Tên MuMu generic ('Android Device...') bỏ qua → dùng cổng cho gọn."""
        lb = (self.device_labels or {}).get(dev)
        if lb:
            return lb
        port = dev.split(":")[-1] if ":" in str(dev) else str(dev)
        nm = self._mumu_names().get(port)
        if nm and not nm.startswith("Android Device"):
            return nm
        return f"Cửa sổ {port}"

    def _set_device_label(self, dev):
        import json, os
        from tkinter import simpledialog
        cur = (self.device_labels or {}).get(dev, "")
        name = simpledialog.askstring("Đặt tên cửa sổ", f"Tên cho thiết bị {dev}:", initialvalue=cur, parent=self.root)
        if name is None:
            return
        name = name.strip()
        if name:
            self.device_labels[dev] = name
        else:
            self.device_labels.pop(dev, None)
        try:
            os.makedirs(os.path.dirname(self.DEVICE_LABELS_PATH), exist_ok=True)
            json.dump(self.device_labels, open(self.DEVICE_LABELS_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        except Exception as e:
            self.log(f"⚠️ Lưu tên cửa sổ lỗi: {e}")
        # cập nhật ngay ô tên nếu CHƯA có tên nhân vật (đang hiện nhãn cửa sổ)
        try:
            if self.tree.exists(dev):
                vals = list(self.tree.item(dev, "values"))
                if len(vals) >= 2 and (not vals[1] or vals[1].startswith("Cửa sổ ") or vals[1].startswith("Player_") or vals[1] == cur):
                    vals[1] = self._dev_label(dev); self.tree.item(dev, values=vals)
        except Exception:
            pass

    def _on_tree_right_click(self, event):
        region = self.tree.identify("region", event.x, event.y)
        if region != "cell":
            return
        column = self.tree.identify_column(event.x)
        item_id = self.tree.identify_row(event.y)
        if not item_id:
            return
        from tkinter import Menu
        menu = Menu(self.root, tearoff=0)
        # KHỞI ĐỘNG LẠI RIÊNG 1 cửa sổ (như "Khởi động lại toàn bộ" nhưng chỉ cửa sổ này).
        menu.add_command(label="♻️ Khởi động lại cửa sổ này",
                         command=lambda d=item_id: self._restart_one_window(d))
        menu.add_separator()
        # TẠM DỪNG/CHẠY TIẾP NHANH: giữ Frida attach, chỉ chặn vòng tick → ▶ chạy lại TỨC THÌ (không attach lại).
        _pl = getattr((self.bots.get(item_id) or {}).get('bot'), '_paused_loop', False)
        menu.add_command(label=("▶ Chạy tiếp (nhanh, giữ Frida)" if _pl else "⏸ Tạm dừng nhanh (giữ Frida)"),
                         command=lambda d=item_id: self._toggle_pause_loop(d))
        menu.add_separator()
        # QUÉT SẠP TOÀN MAP (1 vòng): cửa sổ này tự đi 7 thành + 10 thôn (Xa Phu) quét sạp → gom thư viện chung.
        menu.add_command(label="🛒 Quét sạp toàn map (1 vòng)",
                         command=lambda d=item_id: self._start_stall_scan(d))
        menu.add_separator()
        # ĐẶT TÊN cửa sổ (vd 'Dã Tẩu 1', 'Cày cấp 1') -> hiện thay 'Player_xxx' trước khi có tên nhân vật.
        menu.add_command(label="✏️ Đặt tên cửa sổ này",
                         command=lambda d=item_id: self._set_device_label(d))
        menu.add_separator()
        # THỦ QUỸ: đặt/bỏ cửa sổ này làm thủ quỹ (thay cho tính năng đổi tên cũ).
        if _treasurer.is_treasurer_device(item_id):
            menu.add_command(label="❌ Bỏ Thủ Quỹ (cửa sổ này)", command=lambda: self._set_treasurer_device(None))
        else:
            menu.add_command(label="💰 Đây là Thủ Quỹ", command=lambda d=item_id: self._set_treasurer_device(d))
        menu.add_separator()
        menu.add_command(label="🚫 Bỏ qua thiết bị này (không phải cửa sổ game)",
                         command=lambda d=item_id: self._ignore_device(d))
        menu.tk_popup(event.x_root, event.y_root)

    def _restart_one_window(self, device_id):
        """Chuột phải → khởi động lại RIÊNG cửa sổ này — ĂN NGAY (~3-5s, KHÔNG restart game): FORCE-DETACH session
        Frida cũ NGAY từ main thread (KHÔNG chờ luồng cũ tự đóng — nếu nó kẹt thì join timeout → 2 session/script
        cùng PID = 'không bắt được node' → đứng; đây là cái cách cũ thiếu) → tạo bot mới attach lại game ĐANG CHẠY
        (PID cũ còn sống, session cũ đã detach nên SẠCH). KHÔNG đụng cửa sổ khác."""
        self.paused_devices.discard(device_id)
        self.log("♻️ Khởi động lại cửa sổ (nhanh: detach Frida cũ + attach lại, KHÔNG restart game)…", device_id)
        ob = (self.bots.get(device_id) or {}).get('bot')
        if ob is not None:
            setattr(ob, '_run_active', False)   # ra lệnh luồng cũ dừng
            # ĐÓNG session Frida cũ NGAY (main thread) → device-side detach + script unload tức thì; RPC dở của
            # luồng cũ lỗi ra → luồng cũ thoát nhanh. Không còn 2-session-cùng-PID khi attach lại.
            try:
                gb = getattr(ob, 'game_bot', None)
                if gb is not None:
                    gb.close()
            except Exception as e:
                self.log(f"(đóng Frida cũ: {e})", device_id)
        # attach lại NGAY (game vẫn chạy, PID cũ): _start_bot(force) — luồng mới join luồng cũ (đã thoát nhanh
        # nhờ close ở trên) rồi connect SẠCH. 300ms để luồng cũ kịp thấy session đóng.
        self.root.after(300, lambda d=device_id: self._restart_bot_safe(d))

    def _restart_bot_safe(self, device_id):
        try:
            self._restart_bot(device_id)
        except Exception as e:
            self.log(f"❌ Khởi động lại cửa sổ lỗi: {e}", device_id)

    # (Đã bỏ UI chọn về-thành + dọn-túi — để MẶC ĐỊNH: recall='xaphu' (Biện Kinh), loot=bật.)

    def _on_tab_changed(self, event=None):
        """Log nay là 1 TAB riêng (không còn vùng log đáy) → notebook luôn expand lấp nửa dưới, không cần
        ẩn/hiện gì. Giữ hàm (đang bind) để tương thích; không thao tác layout nữa."""
        return

    def _toggle_manual_quest(self):
        """Nút "Để tôi làm NV này" ↔ "Tôi đã xong": PAUSE RIÊNG cửa sổ ĐANG CHỌN để user tự làm NV của char đó;
        bấm lại = ATTACH LẠI Frida HẲN cửa sổ đó (như bật Auto mới) + đọc lại NV Dã Tẩu. (CHỈ 1 cửa sổ,
        cửa sổ khác chạy bình thường.)"""
        if not self._manual_paused:
            dev = self.current_log_device
            if not dev or dev not in self.bots or not self.bots[dev].get('is_running'):
                self.log("⚠️ Chưa chọn cửa sổ đang chạy (bấm 1 dòng nhân vật ở bảng trên) để tự làm NV.")
                return
            b = self.bots[dev].get('bot')
            if b is not None:
                b.paused = True            # tick + vòng quét/rảo/cày đều dừng (đã check self.paused) — CHỈ cửa sổ này
            self._manual_paused = True
            self._manual_paused_dev = dev
            self.btn_manual.config(text="✅ Tôi đã xong", bg="#b9770e")
            self.log(f"🙋 ĐÃ TẠM DỪNG RIÊNG cửa sổ này để bạn tự làm NV. Xong bấm '✅ Tôi đã xong'.", dev)
        else:
            dev = getattr(self, '_manual_paused_dev', None)
            self._manual_paused = False
            self.btn_manual.config(text="🙋 Để tôi làm NV này", bg="#3b5168")
            self._manual_paused_dev = None
            if dev and dev in self.bots:
                self.paused_devices.discard(dev)
                self.log(f"✅ CHẠY LẠI cửa sổ này — attach Frida lại + đọc NV Dã Tẩu (như bật Auto mới).", dev)
                self._restart_one_window(dev)   # đóng session cũ + bot mới + connect SẠCH + READ_QUEST (CHỈ cửa sổ này)
            else:
                self.log("(cửa sổ đã tạm dừng không còn — bỏ qua)")

    def _on_buff_toggle(self):
        """Bật/tắt nhận buff Tân Thủ từ xa (cờ TOÀN CỤC, đồng bộ 2 tab). Bật -> nhận NGAY (reset mốc mọi bot)."""
        on = bool(self.var_buff.get())
        _buff_config.set_enabled(on)
        if on:
            for d, info in list(self.bots.items()):
                b = info.get('bot') if isinstance(info, dict) else None
                if b is not None:
                    try:
                        b._last_buff_ts = 0.0   # tick kế sẽ nhận ngay
                    except Exception:
                        pass
            self.log("🔆 BẬT nhận buff Tân Thủ từ xa: char <79 nhận NGAY + mỗi 1 giờ; char >=79 bỏ qua.")
        else:
            self.log("🔆 TẮT nhận buff Tân Thủ từ xa.")

    def _set_luyencong_device(self, dev, on):
        """BẬT/TẮT chế độ Luyện Công cho 1 cửa sổ -> lưu cờ + bật/tắt tab. Loại trừ lẫn nhau với Thủ Quỹ."""
        _luyencong.set_luyencong(dev, on)
        if on and _treasurer.is_treasurer_device(dev):
            # cửa sổ không thể vừa Luyện Công vừa Thủ Quỹ -> bỏ thủ quỹ
            cfg = _treasurer.load_config()
            _treasurer.save_config("", cfg.get("give_names"), pos=cfg.get("pos"), give_money=cfg.get("give_money"))
            self._refresh_treasurer_ui()
        try:
            self.current_log_device = dev
            self.tree.selection_set(dev)
        except Exception:
            pass
        self.log(f"🏋️ Cửa sổ {dev}: {'BẬT' if on else 'TẮT'} chế độ Luyện Công"
                 f"{' (chỉ bật tab Luyện công, ẩn tab Dã Tẩu)' if on else ' → trở lại Dã Tẩu'}.", dev)
        self._apply_tab_access()

    def _set_treasurer_device(self, dev):
        """Đặt (dev) hoặc BỎ (None) cửa sổ làm THỦ QUỸ -> lưu config + bật/tắt tab + cập nhật nhãn."""
        if dev and _luyencong.is_luyencong_device(dev):
            _luyencong.set_luyencong(dev, False)   # không thể vừa Thủ Quỹ vừa Luyện Công
        cfg = _treasurer.load_config()
        _treasurer.save_config(dev or "", cfg.get("give_names"), pos=cfg.get("pos"),
                               give_money=cfg.get("give_money"))
        if dev:
            try:
                self.current_log_device = dev
                self.tree.selection_set(dev)
            except Exception:
                pass
            self.log(f"💰 Đặt cửa sổ {dev} làm THỦ QUỸ (chỉ bật tab Thủ quỹ; các tab khác ẩn).", dev)
        else:
            self.log("Đã BỎ thủ quỹ — cửa sổ trở lại bình thường.")
        self._refresh_treasurer_ui()
        self._apply_tab_access()

    def _apply_tab_access(self):
        """Bật/tắt tab theo cửa sổ ĐANG CHỌN:
        - LUYỆN CÔNG  -> CHỈ tab 'Hỗ trợ luyện công'; mọi tab Dã Tẩu + Thủ quỹ ẩn.
        - THỦ QUỸ     -> chỉ tab Thủ quỹ.
        - Dã Tẩu (mặc định) -> mọi tab Dã Tẩu; ẩn tab Luyện công + Thủ quỹ."""
        try:
            sel = self.current_log_device
            if not sel:
                s = self.tree.selection(); sel = s[0] if s else None
            is_tr = bool(sel) and _treasurer.is_treasurer_device(sel)
            datau_tabs = [self.tab_datau, self.tab_rewards, self.tab_accounts]
            if is_tr:
                for t in datau_tabs:
                    self.notebook.tab(t, state='disabled')
                self.notebook.tab(self.tab_treasurer, state='normal')
                self.notebook.select(self.tab_treasurer)
            else:
                self.notebook.tab(self.tab_treasurer, state='disabled')
                for t in datau_tabs:
                    self.notebook.tab(t, state='normal')
            # SAU khi đổi state: nếu tab ĐANG CHỌN bị disable (hoặc rỗng) -> nhảy về tab enabled hợp lý.
            try:
                cur = self.notebook.select()
                if not cur or str(self.notebook.tab(cur, 'state')) == 'disabled':
                    self.notebook.select(self.tab_treasurer if is_tr else self.tab_datau)
            except Exception:
                pass
        except Exception:
            pass

    IGNORE_PATH = "data/output/device_ignore.json"

    def _load_ignored_devices(self):
        import json
        try:
            return set(json.load(open(self.IGNORE_PATH, encoding="utf-8")) or [])
        except Exception:
            return set()

    def _ignore_device(self, dev):
        import json, os
        ig = self._load_ignored_devices()
        ig.add(dev)
        try:
            os.makedirs(os.path.dirname(self.IGNORE_PATH), exist_ok=True)
            json.dump(sorted(ig), open(self.IGNORE_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        except Exception:
            pass
        # dừng bot nếu đang chạy + xoá khỏi tree
        info = self.bots.get(dev)
        if info:
            info['is_running'] = False
        if self.tree.exists(dev):
            self.tree.delete(dev)
        self.log(f"Đã bỏ qua thiết bị {dev} (sẽ không hiện/không quét lại). Bỏ lại: xoá khỏi {self.IGNORE_PATH}.")

    def _on_tree_select(self, event):
        selected = self.tree.selection()
        if selected:
            self.current_log_device = selected[0]
            self.lbl_view_dev.config(text=f"thiết bị: {self.current_log_device}")
            self._apply_tab_access()   # thủ quỹ -> chỉ tab Thủ quỹ; worker -> mọi tab trừ Thủ quỹ
            self._load_view(rebuild_log=True)
            # ĐỒNG BỘ tab "Tài khoản" theo cửa sổ đang chọn ở bảng trên (mỗi cửa sổ 1 danh sách riêng).
            try:
                self._load_account_queue_to_ui()
            except Exception:
                pass
            try:
                self._load_luyencong_queue_to_ui()
            except Exception:
                pass

    def _is_today(self):
        return (self.var_day.get() or tracker.today()) == tracker.today()

    def _refresh_day_list(self):
        """ĐÃ BỎ dropdown chọn ngày — luôn dùng HÔM NAY. Giữ hàm (vẫn được gọi) nhưng chỉ đảm bảo var_day=hôm nay."""
        today = tracker.today()
        # luôn ép về hôm nay (không còn xem ngày cũ); nếu còn combobox (phòng hờ) thì cập nhật values.
        if (self.var_day.get() or "") != today:
            self.var_day.set(today)
        if getattr(self, 'cmb_day', None) is not None:
            try:
                days = tracker.list_days()
                if today not in days:
                    days = [today] + days
                self.cmb_day['values'] = days
            except Exception:
                pass

    def _device_match(self, rec):
        """Lọc record theo thiết bị đang chọn (SYSTEM luôn hiện)."""
        if not self.current_log_device:
            return True
        return rec.get("device") in (self.current_log_device, "SYSTEM")

    def _current_char(self):
        """Tên nhân vật ĐANG chạy ở device đang xem (để lọc log THEO NHÂN VẬT). '' nếu không rõ."""
        b = self.bots.get(self.current_log_device) if self.current_log_device else None
        bot = b.get('bot') if isinstance(b, dict) else None
        return (getattr(bot, 'player_name', '') or '') if bot else ''

    def _char_match(self, rec, char):
        """Record thuộc nhân vật đang xem? Record cũ KHÔNG có 'char' -> vẫn hiện (tương thích)."""
        if not char:
            return True
        rc = rec.get("char")
        return (not rc) or (rc == char)

    def _load_view(self, rebuild_log=False):
        """ĐỌC LẠI dữ liệu của ngày đang chọn từ file log -> dựng lại toàn bộ panel.
        Đây là nguồn dữ liệu DUY NHẤT cho tracking (UI không bắt info trực tiếp từ game)."""
        day = self.var_day.get() or tracker.today()
        recs = [r for r in self._load_day_cached(day) if self._device_match(r)]
        char = self._current_char()
        # Panel 'phần thưởng hôm nay' + 'vật phẩm' + thống kê = THEO NHÂN VẬT đang chạy.
        recs = [r for r in recs if self._char_match(r, char)]
        try:
            self.lbl_view_dev.config(text=f"thiết bị: {self.current_log_device or '—'}"
                                          + (f"  |  nhân vật: {char}" if char else ""))
        except Exception:
            pass

        # Thống kê nhiệm vụ. Bot đếm quest_completed BỊ SÓT (đồ chí/một số turn-in không ghi) -> KHÔNG đáng tin.
        # NGUỒN CHUẨN = server báo "còn N nhiệm vụ" (remaining) trong gói nhận NV: đã LÀM hôm nay = 30 - N.
        # DAILY_CAP lấy từ hằng module (theo server, mặc định 20) — không hardcode 30 nữa.
        bot_done = len({r.get("qno") for r in recs if r.get("type") == "quest_completed"})
        cancelled = len({r.get("qno") for r in recs if r.get("type") == "quest_cancelled"})
        q_recv = [r for r in recs if r.get("type") == "quest_received"]
        milestone = q_recv[-1].get("qno") if q_recv else "—"
        # CAP CỐ ĐỊNH = 20 (server này 20 NV/ngày — user xác nhận; KHÔNG lấy động nữa).
        # ĐẾM CHÍNH XÁC: done = SỐ NV DISTINCT đã NHẬN trong ngày (đếm quest_received theo qno). Khớp
        # 'Nhiệm vụ thứ N' (N = số NV trong ngày) MÀ vẫn an toàn nếu qno là số tích luỹ (đếm SỰ KIỆN, không
        # lấy giá trị qno). Re-read cùng NV (resume) trùng qno -> dedup, không đếm 2 lần.
        cap = DAILY_CAP
        recv_qnos = {r.get("qno") for r in q_recv if r.get("qno") is not None}
        done = max(0, min(cap, len(recv_qnos)))
        if any(r.get("type") == "daily_limit" for r in recs):
            done = cap
        remaining = max(0, cap - done)
        total = cap
        # SỐ LẦN GẶP MỖI LOẠI NV HÔM NAY (distinct qno theo nhóm) — hiện trên tab Dã Tẩu.
        try:
            from core.quest_actions import classify_quest as _cq, GROUP_OF as _GO
            seen = {}   # group -> set(qno)
            for r in q_recv:
                qo = type("Q", (), {"item_name": r.get("item", "") or "",
                                    "clean_text": r.get("text", "") or "",
                                    "raw_text": r.get("text", "") or ""})()
                grp = _GO.get(_cq(qo), _cq(qo))
                seen.setdefault(grp, set()).add(r.get("qno"))
            for tkey, lbl in (self.lbl_type_count or {}).items():
                n = len(seen.get(tkey, ()))
                lbl.config(text=(f"×{n}" if n else "·"))
        except Exception:
            pass
        self._render_stats({"milestone": milestone, "total": total, "done": done,
                            "cancelled": cancelled, "remaining": remaining, "bot_done": bot_done}, today=self._is_today())
        # Cập nhật cột "NV hôm nay" trên header tree cho thiết bị đang xem.
        try:
            dev = self.current_log_device
            if dev and self.tree.exists(dev):
                vals = list(self.tree.item(dev, "values"))
                while len(vals) < 4:
                    vals.append("—")
                vals[3] = f"{done}/{cap}"
                self.tree.item(dev, values=vals)
        except Exception:
            pass
        # Nhiệm vụ gần nhất (label xanh) — rút gọn, không vỡ format
        if q_recv:
            last = q_recv[-1]
            it = (last.get('item') or '').strip()
            tx = self._clean_game_text(last.get('text') or '')[:90]
            self.lbl_quest.config(text=f"NV {last.get('qno')}: {it + ' — ' if it else ''}{tx}")
        else:
            self.lbl_quest.config(text="Chưa có dữ liệu nhiệm vụ ngày này")

        # Phần thưởng (event 'reward') — 1 panel merged + ĐẾM tổng theo loại.
        rewards = [r for r in recs if r.get("type") == "reward"]
        self._render_rewards(rewards)
        self._render_reward_counts(rewards)

        # LOG THỰC THI theo CỬA SỔ (device_id): đổi cửa sổ -> nạp lại log của cửa sổ đó (buffer khoá device_id).
        dev = self.current_log_device or ''
        if dev != getattr(self, "_log_view_dev", None):
            self._log_view_dev = dev
            self._reload_char_log(dev)
        # log_area do _live_log_append đổ trực tiếp từ bot._chat (lọc theo nhân vật đang xem).

    def _render_reward_counts(self, rewards):
        """TỔNG ngân lượng + kinh nghiệm THỰC NHẬN (quy đơn vị) cho nhân vật đang xem.
        Parse 'received': ngân lượng dạng 'X vạn Y lượng'; exp dạng 'X.XXX.XXX Điểm kinh nghiệm'."""
        import re
        total_luong = 0      # tổng lượng
        total_exp = 0        # tổng điểm kinh nghiệm
        tlh = 0              # số Thiết La Hán đã chọn/nhận
        for r in rewards:
            rec = r.get('received', '') or ''
            if "thiết la hán" in f"{r.get('chosen','')} {rec}".lower():
                tlh += 1
            # NGÂN LƯỢNG: ưu tiên 'X vạn Y lượng', rồi 'X vạn', rồi 'X lượng'
            m = re.search(r'(\d+)\s*vạn\s*(\d+)\s*lượng', rec)
            if m:
                total_luong += int(m.group(1)) * 10000 + int(m.group(2))
            else:
                m2 = re.search(r'(\d+)\s*vạn', rec)
                m3 = re.search(r'(\d[\d.,]*)\s*lượng', rec)
                if m2:
                    total_luong += int(m2.group(1)) * 10000
                elif m3:
                    total_luong += int(m3.group(1).replace('.', '').replace(',', ''))
            # KINH NGHIỆM: 'X.XXX.XXX Điểm kinh nghiệm'
            me = re.search(r'([\d.,]+)\s*Điểm kinh nghiệm', rec, re.IGNORECASE)
            if me:
                total_exp += int(me.group(1).replace('.', '').replace(',', ''))
        van, lng = divmod(total_luong, 10000)
        money_str = f"{van:,} vạn" + (f" {lng} lượng" if lng else "") if total_luong else "0"
        exp_str = f"{total_exp:,}" + (f" (~{total_exp/1_000_000:.0f} triệu)" if total_exp >= 1_000_000 else "") if total_exp else "0"
        self.lbl_cnt_summary.config(
            text=(f"💰 Ngân lượng: {money_str}\n"
                  f"⚔️ Kinh nghiệm: {exp_str}\n"
                  f"🟢 Thiết La Hán: {tlh}"))

    def _load_day_cached(self, day=None):
        """load_day CÓ CACHE theo (ngày, mtime, size): nhiều call site (_load_view + _update_all_today_counts
        + account progress) trong CÙNG nhịp poll chỉ parse file 1 LẦN thay vì 3 → giảm freeze/lag UI khi log lớn.
        File log đổi (bot ghi) -> sig đổi -> parse lại; không đổi -> trả cache."""
        import os
        day = day or tracker.today()
        fp = tracker.day_file(day)
        try:
            st = os.stat(fp); sig = (day, st.st_mtime, st.st_size)
        except Exception:
            sig = (day, 0, 0)
        if getattr(self, '_ldc_sig', None) == sig and getattr(self, '_ldc_recs', None) is not None:
            return self._ldc_recs
        recs = tracker.load_day(day)
        self._ldc_sig = sig; self._ldc_recs = recs
        return recs

    def _poll_tracking(self):
        """Mỗi 3s: CHỈ dựng lại panel khi file log ĐỔI (mtime/size) hoặc ĐỔI nhân vật — tránh parse lại
        toàn bộ file mỗi nhịp gây LAG UI khi log lớn."""
        try:
            if self._is_today():
                import os
                fp = tracker.day_file(self.var_day.get() or tracker.today())
                try:
                    st = os.stat(fp); sig = (st.st_mtime, st.st_size)
                except Exception:
                    sig = None
                cur_char = self._current_char()
                if sig != getattr(self, "_track_sig", None) or cur_char != getattr(self, "_track_char", None):
                    self._track_sig = sig
                    self._track_char = cur_char
                    self._refresh_day_list()
                    self._load_view(rebuild_log=False)
                    self._update_all_today_counts()   # cập nhật cột 'NV hôm nay' cho MỌI device (không chỉ đang xem)
                    try:
                        n = self._count_tlh_today()       # tổng Thiết La Hán MỌI nhân vật nhận hôm nay (từ log)
                        if hasattr(self, 'lbl_tlh_total'):
                            self.lbl_tlh_total.config(text=f"🟢 Thiết La Hán nhận hôm nay: {n} cái")
                    except Exception:
                        pass
            try:
                self._refresh_account_status()        # cập nhật bảng trạng thái account (tab Tài khoản)
            except Exception:
                pass
        except Exception:
            pass
        try:
            self._maybe_autosend_stats()      # tự gửi thống kê cuối ngày qua Zalo (nếu tới giờ + bật)
        except Exception:
            pass
        self.root.after(3000, self._poll_tracking)

    def _maybe_autosend_stats(self):
        """Tới giờ cấu hình (stats_hour) + chưa gửi hôm nay -> gửi thống kê ngày qua Zalo. 1 lần/ngày."""
        from core import notifier as _N
        cfg = _N.load_config()
        if not cfg or not (cfg.get("events") or {}).get("stats_daily", True):
            return
        hour = int(cfg.get("stats_hour", 21))
        now = time.localtime()
        today = time.strftime("%Y-%m-%d", now)
        if now.tm_hour < hour:
            return
        if getattr(self, '_stats_autosent_day', None) == today:
            return
        if _N.send_stats(today):
            self.log(f"📤 Đã tự gửi thống kê ngày {today} qua Zalo (giờ {hour}h).")
        self._stats_autosent_day = today   # đánh dấu đã gửi hôm nay (kể cả khi rỗng — tránh lặp)

    def _count_tlh_today(self):
        """Tổng 'Thiết La Hán' MỌI nhân vật nhận HÔM NAY — đọc từ tracker (event item_received, name chứa
        'thiết la hán'; mỗi event = 1 cái). Gộp toàn bộ device/nhân vật → đúng 'đọc từ log toàn bộ nhân vật'."""
        try:
            recs = self._load_day_cached(tracker.today())
        except Exception:
            return 0
        n = 0
        for r in recs:
            if r.get("type") == "item_received" and "thiết la hán" in (r.get("name") or "").lower():
                n += 1
        return n

    def _update_all_today_counts(self):
        """Cập nhật cột 'NV hôm nay /30' cho TẤT CẢ device trong tree (server-authoritative = 30 - còn lại).
        Trước đây chỉ device đang XEM mới cập nhật -> các device khác hiện sai/stale."""
        # DAILY_CAP lấy từ hằng module (theo server, mặc định 20) — không hardcode 30 nữa.
        try:
            recs = self._load_day_cached(tracker.today())
        except Exception:
            return
        # Nhân vật ĐANG chạy của từng device -> lọc record THEO NHÂN VẬT (giống _load_view). Account rotation:
        # daily_limit/quest của account CŨ trên cùng device KHÔNG được tính cho account mới (nếu không -> 30/30 sai).
        dev_char = {}
        for dev in self.tree.get_children():
            b = self.bots.get(dev)
            bot = b.get('bot') if isinstance(b, dict) else None
            dev_char[dev] = (getattr(bot, 'player_name', '') or '') if bot else ''
        by_dev = {}
        for r in recs:   # file theo THỨ TỰ thời gian -> bản ghi sau ghi đè bản trước (latest wins)
            d = r.get("device")
            if not d:
                continue
            ch = dev_char.get(d, '')          # record của account KHÁC trên cùng device -> bỏ (legacy không 'char' -> giữ)
            rc = r.get("char")
            if ch and rc and rc != ch:
                continue
            e = by_dev.setdefault(d, {"recv": set(), "hit": False})
            if r.get("type") == "daily_limit":
                e["hit"] = True
            # done = SỐ NV DISTINCT đã NHẬN trong ngày (khớp 'Nhiệm vụ thứ N', an toàn nếu qno tích luỹ).
            if r.get("type") == "quest_received" and r.get("qno") is not None:
                e["recv"].add(r.get("qno"))
        for dev in self.tree.get_children():
            e = by_dev.get(dev)
            if not e:
                continue
            cap = DAILY_CAP   # 20 cố định
            done = cap if e["hit"] else max(0, min(cap, len(e["recv"])))
            try:
                vals = list(self.tree.item(dev, "values"))
                while len(vals) < 4:
                    vals.append("—")
                vals[3] = f"{done}/{cap}"
                self.tree.item(dev, values=vals)
            except Exception:
                pass

    def _clear_log(self):
        # Chỉ xoá hiển thị; file log ngày vẫn giữ nguyên (dữ liệu lịch sử không mất).
        self.log_area.config(state='normal')
        self.log_area.delete(1.0, tk.END)
        self.log_area.config(state='disabled')

    def _copy_log(self):
        """Copy toàn bộ log thực thi vào clipboard để dễ gửi đi điều tra."""
        try:
            txt = self.log_area.get(1.0, tk.END)
            self.root.clipboard_clear()
            self.root.clipboard_append(txt)
            self.log(f"📋 Đã copy {txt.count(chr(10))} dòng log vào clipboard.")
        except Exception as e:
            self.log(f"⚠️ Copy log lỗi: {e}")

    def _char_key_of(self, device_id):
        """Khoá LOG THỰC THI = device_id (DUY NHẤT & ỔN ĐỊNH theo cửa sổ).
        KHÔNG khoá theo player_name: tên đọc TRỄ (~8s đầu / sau relogin reset '') hoặc 2 cửa sổ TRÙNG tên ->
        nhiều cửa sổ chung 1 buffer -> log bị TRỘN (vd cửa sổ A 'PENDING' lẫn cửa sổ B '⚔️ Mật chí 0/2'
        nhìn như 1 bot 'pause nhưng vẫn chạy'). device_id luôn riêng từng cửa sổ -> không bao giờ trộn."""
        return device_id or ''

    def _reload_char_log(self, char):
        """Nạp lại panel log thực thi = log RIÊNG của nhân vật `char` (đổi nhân vật -> đổi log)."""
        try:
            self.log_area.config(state='normal')
            self.log_area.delete(1.0, tk.END)
            for line in self.char_log_buf.get(char or (self.current_log_device or ''), [])[-400:]:
                self.log_area.insert(tk.END, line)
            self.log_area.see(tk.END)
            self.log_area.config(state='disabled')
        except Exception:
            pass

    def _live_log_append(self, device_id, msg):
        """Đổ live 1 dòng LOG THỰC THI: lưu vào buffer THEO NHÂN VẬT; chỉ hiện nếu là nhân vật đang xem."""
        def _append():
            ch = self._char_key_of(device_id)
            line = f"{time.strftime('%H:%M:%S')} - {msg}\n"
            buf = self.char_log_buf.setdefault(ch, [])
            buf.append(line)
            if len(buf) > 800:
                del buf[:200]
            # CHỈ hiển thị log của ĐÚNG cửa sổ đang xem (so khớp device_id). Chưa chọn cửa sổ nào (cur='')
            # -> KHÔNG đổ gì (tránh TRỘN log của mọi cửa sổ vào 1 panel — bug "pause nhưng vẫn chạy").
            cur = self.current_log_device or ''
            if ch != cur:
                return
            self.log_area.config(state='normal')
            self.log_area.insert(tk.END, line)
            if int(self.log_area.index('end-1c').split('.')[0]) > 600:
                self.log_area.delete(1.0, '200.0')
            self.log_area.see(tk.END)
            self.log_area.config(state='disabled')
        self.root.after(0, _append)

    def log(self, msg, device_id=None):
        """Thông báo cấp UI -> hiện live vào panel log thực thi + GHI VÀO FILE LOG (để Syncthing mang sang
        máy kia cho Claude đọc — nếu không, các thao tác UI như nút manual / 'Tôi đã xong' / restart / connect
        sẽ VÔ HÌNH trong log chia sẻ, không debug được)."""
        tag = f"[UI]{('['+device_id+']') if device_id else ''}"
        print(f"{tag} {msg}")
        self._live_log_append(device_id, msg)
        try:
            logging.getLogger().info(f"{tag} {msg}")
        except Exception:
            pass

    def _start_bot(self, device_id, force=False):
        # force=True: gọi từ watchdog/restart -> BỎ guard "đang chạy" + KHÔNG xoá log đang xem.
        if not force and device_id in self.bots and self.bots[device_id]['is_running']:
            self.log("Bot này đang chạy rồi!", device_id)
            return

        self.log(("♻️ Watchdog khởi động lại cửa sổ " if force else "Đã bật Auto cho ") + f"{device_id}.", device_id)
        adb = ADBHelper(device_id=device_id)
        bot = DaTauStateMachine(adb)
        
        # LOG THỰC THI live: bot._chat -> hiện thẳng lên panel (để điều tra lỗi). Cũng chặn spam chat in-game.
        bot.ui_log = lambda msg, d=device_id: self._live_log_append(d, msg)
        # Xoá log để "chạy lần nào load lần đấy" (KHÔNG xoá khi watchdog tự restart nền — giữ log đang xem).
        if not force:
            self.log_area.config(state='normal'); self.log_area.delete(1.0, tk.END); self.log_area.config(state='disabled')
        # Thông tin nhân vật (trạng thái hiện tại) vẫn cập nhật live lên bảng — đây là state, không phải tracking.
        bot.ui_update_player = lambda name, map_name, money: self.update_player_info(device_id, name, map_name, money)
        bot.ui_need_help = lambda reason, d=device_id: self.mark_need_help(d, reason)
        bot.ui_treasurer_log = lambda msg: self.treasurer_log(msg)   # log text thường
        bot.ui_treasurer_tx = lambda ev: self.treasurer_tx(ev)       # giao dịch có cấu trúc (Nhận xanh/Giao đỏ + đếm TLH)
        bot.buy_threshold_van = self._get_threshold()
        bot.quest_action_cfg = self._current_quest_actions()   # áp cấu hình phân loại NV hiện tại

        # CHỐNG ĐUA tắt→bật NHANH: luồng CŨ (nếu vừa tắt) có thể CHƯA kịp nhả Frida (gb.close trong finally).
        # Ra lệnh nó dừng (_run_active=False) + giữ ref để LUỒNG MỚI CHỜ nó detach xong rồi mới connect — nếu
        # không, 2 session Frida cùng PID -> double-hook recv -> "không bắt được node Dã Tẩu" + đứng.
        old = self.bots.get(device_id)
        old_thread = None
        if old:
            ob = old.get('bot')
            if ob is not None:
                setattr(ob, '_run_active', False)
            old_thread = old.get('thread')

        # Bắt đầu luồng
        bot._run_active = True
        thread = threading.Thread(target=self._run_bot_thread, args=(device_id, bot, old_thread), daemon=True)
        self.bots[device_id] = {'bot': bot, 'thread': thread, 'is_running': True}
        thread.start()

        # CHƯA chọn cửa sổ nào để xem -> tự chọn cửa sổ này (panel log luôn hiện ĐÚNG 1 cửa sổ, không trộn,
        # không để trống). User click cửa sổ khác để xem log cửa sổ đó.
        if not self.current_log_device:
            self.current_log_device = device_id
            try:
                self.tree.selection_set(device_id)
                self.lbl_view_dev.config(text=f"thiết bị: {device_id}")
            except Exception:
                pass

    def _restart_bot(self, device_id):
        """Khởi động lại RIÊNG 1 cửa sổ: tạo bot+luồng MỚI (force) — luồng mới TỰ CHỜ luồng cũ nhả Frida
        (cơ chế old_thread.join trong _run_bot_thread) rồi attach SẠCH. Dùng cho watchdog (cửa sổ treo) và
        nút khởi động lại 1 cửa sổ. KHÁC _restart_app (re-exec cả tiến trình) — cái này chỉ đụng 1 cửa sổ."""
        self._start_bot(device_id, force=True)

    # ---------------- WATCHDOG: tự khởi động lại CỬA SỔ TREO ----------------
    WATCHDOG_STALL_SEC = 5 * 60      # im (không nhúc nhích) quá ngần này = coi như treo -> restart (heartbeat bump
                                     # ở mỗi dòng log/đổi state/vòng cày nên 5' im là bất thường)
    WATCHDOG_POLL_MS = 30 * 1000     # nhịp quét watchdog
    WATCHDOG_COOLDOWN_SEC = 8 * 60   # đã restart 1 cửa sổ thì chờ ngần này mới restart lại nó (tránh loop)

    def _watchdog_tick(self):
        """Quét định kỳ: cửa sổ nào ĐANG chạy mà 'im' quá lâu (hb cũ) hoặc luồng đã chết -> tự restart RIÊNG
        cửa sổ đó. BỎ QUA: watchdog tắt; cửa sổ PENDING (chờ người chơi — restart vô ích); thủ quỹ (đứng yên
        chờ worker là BÌNH THƯỜNG, không có hb); vừa restart (cooldown)."""
        try:
            if not getattr(self, 'var_watchdog', None) or not self.var_watchdog.get():
                return
            now = time.time()
            stall = int(getattr(self, '_watchdog_stall_sec', self.WATCHDOG_STALL_SEC))
            last_restart = getattr(self, '_watchdog_last_restart', None)
            if last_restart is None:
                last_restart = self._watchdog_last_restart = {}
            for dev, info in list(self.bots.items()):
                bot = info.get('bot')
                thread = info.get('thread')
                if bot is None:
                    continue
                thread_dead = (thread is not None and not thread.is_alive())
                if not info.get('is_running'):
                    # is_running=False: PHÂN BIỆT crash vs user-tắt.
                    #  - LUỒNG CHẾT nhưng _run_active VẪN True = crash (tick lỗi 15 lần do game chết → luồng thoát,
                    #    finally set is_running=False) → PHẢI restart + relaunch game (trước đây bị 'continue' bỏ qua
                    #    → game nằm chết, "auto không bắt cửa sổ crash"). User tắt Auto = _stop_bot set _run_active=False
                    #    → KHÔNG restart.
                    crashed = thread_dead and getattr(bot, '_run_active', False)
                    if crashed and now - last_restart.get(dev, 0) >= self.WATCHDOG_COOLDOWN_SEC:
                        last_restart[dev] = now
                        self.log(f"🐕 Watchdog: cửa sổ {dev} LUỒNG CHẾT (crash game) → khởi động lại + relaunch game + login.", dev)
                        try:
                            from core import notifier as _N
                            _N.notify_stuck(dev, "luồng chết (game crash)", char=getattr(bot, 'player_name', '') or '')
                        except Exception:
                            pass
                        try: self._restart_bot(dev)
                        except Exception as e: self.log(f"🐕 Watchdog restart (crash) {dev} lỗi: {e}", dev)
                    continue
                # Thủ quỹ đứng yên chờ worker = bình thường (không có nhịp tim) -> KHÔNG restart vì stall/disconnect.
                # NHƯNG nếu LUỒNG thủ quỹ CHẾT (vd re-exec/build để rớt) thì PHẢI vớt — nếu không thủ quỹ nằm
                # im luôn, không ai trade (bug 2026-06-16: build re-exec làm thủ quỹ dừng, watchdog bỏ qua → mất gd).
                try:
                    from core import treasurer as _T
                    if _T.is_treasurer_device(dev):
                        thread_dead_t = (thread is not None and not thread.is_alive())
                        if thread_dead_t and now - last_restart.get(dev, 0) >= self.WATCHDOG_COOLDOWN_SEC:
                            last_restart[dev] = now
                            self.log(f"🐕 Watchdog: THỦ QUỸ {dev} LUỒNG CHẾT → khởi động lại (khôi phục giao dịch).", dev)
                            try: self._restart_bot(dev)
                            except Exception as e: self.log(f"🐕 Watchdog restart thủ quỹ {dev} lỗi: {e}", dev)
                        continue   # các trường hợp khác (stall/disconnect) của thủ quỹ = bình thường, bỏ qua
                except Exception:
                    pass
                # PENDING (chờ người chơi xử lý) HOẶC TẠM DỪNG NHANH (_paused_loop, giữ Frida) = cố ý dừng,
                # restart không giúp (và sẽ attach lại Frida vô ích) -> bỏ qua.
                if getattr(bot, 'paused', False) or getattr(bot, '_paused_loop', False):
                    continue
                # Cooldown: vừa restart cửa sổ này thì chưa restart lại.
                if now - last_restart.get(dev, 0) < self.WATCHDOG_COOLDOWN_SEC:
                    continue
                # CRASH GAME: process chết → Frida detached → game_bot_connected=False. State handler chỉ return
                # (KHÔNG tự về BOOTSTRAP relaunch) → cửa sổ kẹt mà hb có thể vẫn tươi → stall-check bỏ sót.
                # → Bắt MẤT-KẾT-NỐI KÉO DÀI (>90s, tránh false-positive lúc bot tự relaunch đổi account ~30-60s):
                # restart cửa sổ (→ BOOTSTRAP → _ensure_game_and_login tự mở game + đăng nhập lại).
                disc_since = getattr(self, '_watchdog_disc_since', None)
                if disc_since is None:
                    disc_since = self._watchdog_disc_since = {}
                connected = False
                try:
                    connected = bool(bot.game_bot_connected)
                except Exception:
                    connected = False
                if not connected:
                    t0 = disc_since.get(dev)
                    if t0 is None:
                        disc_since[dev] = now
                    elif now - t0 > 90:
                        disc_since.pop(dev, None)
                        last_restart[dev] = now
                        self.log(f"🐕 Watchdog: cửa sổ {dev} MẤT KẾT NỐI >90s (game crash/đóng) → khởi động lại + đăng nhập lại.", dev)
                        try:
                            from core import notifier as _N
                            _N.notify_stuck(dev, "game crash/mất kết nối", char=getattr(bot, 'player_name', '') or '')
                        except Exception:
                            pass
                        try:
                            self._restart_bot(dev)
                        except Exception as e:
                            self.log(f"🐕 Watchdog restart (crash) {dev} lỗi: {e}", dev)
                        continue
                else:
                    disc_since.pop(dev, None)
                hb = getattr(bot, '_hb_ts', None)
                thread_dead = (thread is not None and not thread.is_alive())
                stalled = (hb is not None and (now - hb) > stall)
                if thread_dead or stalled:
                    reason = "luồng chết" if thread_dead else f"im {int((now-hb)/60)} phút"
                    self.log(f"🐕 Watchdog: cửa sổ {dev} treo ({reason}) → tự khởi động lại.", dev)
                    last_restart[dev] = now
                    try:
                        from core import notifier as _N
                        _N.notify_stuck(dev, reason, char=getattr(bot, 'player_name', '') or '')  # kèm TÊN NV
                    except Exception:
                        pass
                    try:
                        self._restart_bot(dev)
                    except Exception as e:
                        self.log(f"🐕 Watchdog restart {dev} lỗi: {e}", dev)
        except Exception as e:
            try: self.log(f"🐕 Watchdog lỗi: {e}")
            except Exception: pass
        finally:
            try:
                self.root.after(self.WATCHDOG_POLL_MS, self._watchdog_tick)
            except Exception:
                pass

    def _stop_bot(self, device_id, full=True):
        """Tắt Auto = DỪNG HẲN: thoát luồng (_run_active=False) → finally gb.close() nhả Frida. (ĐÃ REVERT pause.)
        `full` giữ cho tương thích chữ ký nơi gọi cũ — luôn dừng hẳn."""
        self.log(f"Đã tắt Auto cho {device_id}. Đang chờ luồng dừng...", device_id)
        if device_id in self.bots:
            self.bots[device_id]['is_running'] = False
            bot = self.bots[device_id]['bot']
            setattr(bot, '_run_active', False)   # cờ dừng RIÊNG mỗi bot (không phụ thuộc dict bị thay khi bật lại)
            if hasattr(bot, 'stop'):
                bot.stop()

    def _run_bot_thread(self, device_id, bot, old_thread=None):
        try:
            LOG_DEVICE.dev = device_id   # gắn device cho luồng này → log ghi vào file RIÊNG cửa sổ (không trộn)
            # CHỜ luồng CŨ (cùng device) thoát + nhả Frida XONG rồi mới chạy (connect mới) — chống đua tắt/bật
            # nhanh = 2 session Frida cùng PID -> double-hook recv -> "không bắt được node Dã Tẩu" + đứng.
            if old_thread is not None and old_thread.is_alive():
                self.log("⏳ Đợi luồng Auto cũ nhả Frida trước khi attach lại...", device_id)
                old_thread.join(timeout=25)
                if old_thread.is_alive():
                    self.log("⚠️ Luồng cũ chưa dừng kịp sau 25s — vẫn chạy tiếp (nếu lỗi, tắt/bật lại).", device_id)
            # PER-TICK try/except: 1 tick lỗi (vd adb timeout, RPC hiccup) CHỈ log + chạy tiếp — KHÔNG giết bot.
            # (trước đây try bọc CẢ while → 1 lỗi = thoát loop = "Bot đã dừng hoàn toàn".) Đếm lỗi liên tiếp:
            # >15 lần liên tục mới dừng (lỗi dai = thật sự hỏng, để watchdog/đời restart).
            _errs = 0
            while getattr(bot, '_run_active', False):
                # TẠM DỪNG NHANH (giữ Frida): chỉ chặn tick, KHÔNG detach/không thoát luồng → ▶ Chạy tiếp tức thì
                # (không attach lại). Bump heartbeat để watchdog không tưởng treo.
                if getattr(bot, '_paused_loop', False):
                    try: bot._hb_ts = time.time()
                    except Exception: pass
                    time.sleep(0.3)
                    continue
                try:
                    bot.tick()
                    _errs = 0
                except Exception as e:
                    _errs += 1
                    self.log(f"⚠️ Lỗi tick (bỏ qua, chạy tiếp): {e}", device_id)
                    if _errs >= 15:
                        self.log(f"❌ {_errs} lỗi liên tiếp → dừng bot (bấm Auto/chuột phải Khởi động lại).", device_id)
                        break
                    time.sleep(1.0)
                time.sleep(0.2)
        except Exception as e:
            self.log(f"Lỗi hệ thống: {e}", device_id)
        finally:
            self.log("Bot đã dừng lại hoàn toàn.", device_id)
            # DETACH Frida khi dừng (unload script + detach session). TRƯỚC ĐÂY KHÔNG gọi (DaTauStateMachine
            # không có .stop() nên _stop_bot bỏ qua) -> script cũ DÍNH lại -> bật Auto lần 2 attach SESSION MỚI
            # vào CÙNG PID -> 2 script cùng hook recv/sendto -> gameFd nhiễu/double-send -> "không bắt được node".
            # Đóng ở đây (sau khi tick loop đã thoát) -> không đua rpc; bật lại = attach SẠCH.
            try:
                gb = getattr(bot, 'game_bot', None)
                if gb is not None:
                    gb.close()
            except Exception as e:
                self.log(f"(đóng Frida khi dừng: {e})", device_id)
            # CHỈ reset trạng thái/UI nếu entry HIỆN TẠI vẫn là bot NÀY. Khi tắt→bật nhanh, luồng cũ kết thúc
            # SAU khi entry đã thành bot MỚI -> KHÔNG được set is_running=False / uncheck đè lên luồng mới.
            if self.bots.get(device_id, {}).get('bot') is bot:
                self.bots[device_id]['is_running'] = False
                def _uncheck():
                    try:
                        if self.tree.exists(device_id):
                            vals = list(self.tree.item(device_id, "values"))
                            vals[0] = "⬜"
                            self.tree.item(device_id, values=vals)
                    except:
                        pass
                self.root.after(0, _uncheck)

    def _toggle_pause_loop(self, device_id):
        """⏸/▶ TẠM DỪNG / CHẠY TIẾP NHANH — chỉ chặn vòng tick, GIỮ Frida attach + luồng sống.
        ▶ Chạy tiếp = TỨC THÌ (không attach lại Frida). KHÁC 'Tắt Auto' (dừng hẳn + nhả Frida)."""
        ent = self.bots.get(device_id)
        if not ent or not ent.get('is_running'):
            self.log("Cửa sổ chưa bật Auto → không có gì để tạm dừng (bật Auto trước).", device_id)
            return
        bot = ent.get('bot')
        if bot is None:
            return
        paused = not getattr(bot, '_paused_loop', False)
        bot._paused_loop = paused
        self.log("⏸ ĐÃ TẠM DỪNG (giữ Frida) — chuột phải → ▶ Chạy tiếp để chạy lại NGAY." if paused
                 else "▶ CHẠY TIẾP — không cần attach lại Frida.", device_id)
        try:
            if self.tree.exists(device_id):
                vals = list(self.tree.item(device_id, "values"))
                vals[0] = "⏸" if paused else "✅"
                self.tree.item(device_id, values=vals)
        except Exception:
            pass

    def _start_stall_scan(self, device_id):
        """Chuột phải → QUÉT SẠP TOÀN MAP cho cửa sổ này (1 vòng): dừng bot hiện tại (nếu có), tạo bot mới,
        chạy thread scan_all_stalls() rồi dừng. Frida attach SẠCH (chờ luồng cũ nhả). KHÔNG đụng cửa sổ khác."""
        self.paused_devices.discard(device_id)
        self.log("🛒 Bắt đầu QUÉT SẠP TOÀN MAP (1 vòng) — đi 7 thành + 10 thôn (Xa Phu)…", device_id)
        adb = ADBHelper(device_id=device_id)
        bot = DaTauStateMachine(adb)
        bot.ui_log = lambda msg, d=device_id: self._live_log_append(d, msg)
        bot.ui_update_player = lambda name, map_name, money: self.update_player_info(device_id, name, map_name, money)
        # dừng luồng cũ + giữ ref để luồng quét CHỜ nó nhả Frida (chống 2-session-cùng-PID).
        old = self.bots.get(device_id)
        old_thread = None
        if old:
            ob = old.get('bot')
            if ob is not None:
                setattr(ob, '_run_active', False)
            old_thread = old.get('thread')
        bot._run_active = True
        thread = threading.Thread(target=self._run_scan_thread, args=(device_id, bot, old_thread), daemon=True)
        self.bots[device_id] = {'bot': bot, 'thread': thread, 'is_running': True}
        thread.start()
        if not self.current_log_device:
            self.current_log_device = device_id
            try:
                self.tree.selection_set(device_id)
                self.lbl_view_dev.config(text=f"thiết bị: {device_id}")
            except Exception:
                pass

    def _run_scan_thread(self, device_id, bot, old_thread=None):
        """Luồng QUÉT SẠP TOÀN MAP: chờ luồng cũ nhả Frida → connect → scan_all_stalls() (1 vòng) → dừng + detach.
        (Giống _run_bot_thread nhưng chạy scan_all_stalls thay vì vòng tick.)"""
        try:
            LOG_DEVICE.dev = device_id
            if old_thread is not None and old_thread.is_alive():
                self.log("⏳ Đợi luồng cũ nhả Frida trước khi quét…", device_id)
                old_thread.join(timeout=25)
            # CONNECT Frida (giống probe): attach + dò fd theo traffic (game đã connect trước attach → miss hook).
            if not bot.game_bot.connect():
                self.log("❌ Quét sạp: KHÔNG connect được Frida (game chạy chưa? cửa sổ khác đang attach?).", device_id)
                return
            for _ in range(6):
                try: bot.game_bot.poll_recv()
                except Exception: pass
                time.sleep(0.3)
            try: bot.game_bot.redetect_fd_by_traffic()
            except Exception: pass
            if getattr(bot, '_run_active', False):
                bot.scan_all_stalls()
        except Exception as e:
            self.log(f"🛒 Quét sạp lỗi hệ thống: {e}", device_id)
        finally:
            self.log("🛒 Quét sạp toàn map: KẾT THÚC.", device_id)
            try:
                gb = getattr(bot, 'game_bot', None)
                if gb is not None:
                    gb.close()
            except Exception:
                pass
            if self.bots.get(device_id, {}).get('bot') is bot:
                self.bots[device_id]['is_running'] = False
                def _uncheck():
                    try:
                        if self.tree.exists(device_id):
                            vals = list(self.tree.item(device_id, "values"))
                            vals[0] = "⬜"
                            self.tree.item(device_id, values=vals)
                    except:
                        pass
                self.root.after(0, _uncheck)

    def _render_stats(self, st, today=True):
        if not st:
            self.lbl_stat_milestone.config(text="Mốc hiện tại: —")
            self.lbl_stat_total.config(text="Hạn mức ngày: 30")
            self.lbl_stat_done.config(text="Đã làm hôm nay: 0/30")
            self.lbl_stat_cancelled.config(text="Đã huỷ: 0")
            self.lbl_stat_remain.config(text="Còn lại: —")
            return
        suffix = "hôm nay" if today else "ngày này"
        self.lbl_stat_milestone.config(text=f"Mốc gần nhất: Nhiệm vụ thứ {st.get('milestone', '—')}")
        self.lbl_stat_total.config(text=f"Hạn mức {suffix}: {st.get('total', 30)} (server)")
        # ĐÃ LÀM = theo server (30 - còn lại). Kèm số bot tự ghi nhận để đối chiếu.
        bd = st.get('bot_done')
        bd_txt = f"  (bot ghi nhận hoàn thành: {bd})" if bd is not None and bd != st.get('done') else ""
        self.lbl_stat_done.config(text=f"Đã làm {suffix}: {st.get('done', 0)}/{st.get('total', 30)}{bd_txt}")
        self.lbl_stat_cancelled.config(text=f"Trong đó đã huỷ ({suffix}): {st.get('cancelled', 0)}")
        self.lbl_stat_remain.config(text=f"Còn lại (server báo): {st.get('remaining', '—')}")

    def _current_quest_actions(self):
        """Đọc cấu hình hành động/loại hiện trên UI -> dict {type_key: action_key}."""
        return {tkey: self._act_key_by_label.get(var.get(), "auto")
                for tkey, var in self.action_vars.items()}

    def _save_quest_actions(self):
        """Lưu cấu hình + đẩy động vào mọi bot đang chạy."""
        cfg = self._current_quest_actions()
        quest_actions.save_config(cfg)
        for info in self.bots.values():
            b = info.get('bot')
            if b is not None:
                b.quest_action_cfg = cfg

    def _get_threshold(self):
        try:
            return max(0, int(float(self.var_threshold.get())))
        except Exception:
            return 50

    def _apply_threshold(self):
        """Đẩy ngưỡng giá mới vào tất cả bot đang chạy (động)."""
        v = self._get_threshold()
        for info in self.bots.values():
            b = info.get('bot')
            if b is not None:
                b.buy_threshold_van = v

    # ===== THUỐC mua trước khi cày đồ chí/mật chí =====
    POTION_CATALOG_PATH = "data/output/potion_shop_catalog.json"
    POTION_CFG_PATH = "data/output/potion_buy_config.json"

    def _load_potion_catalog(self):
        """Đọc danh sách thuốc trong hiệu thuốc (idx + tên) cho Combobox."""
        import json
        try:
            cat = json.load(open(self.POTION_CATALOG_PATH, encoding="utf-8"))
            self._potion_shopkey = cat.get("shopkey", "hieu.thuoc.thanh.thi")
            return cat.get("items", [])
        except Exception:
            self._potion_shopkey = "hieu.thuoc.thanh.thi"
            return []

    def _load_potion_selection(self):
        """Nạp lựa chọn thuốc đã lưu (potion_buy_config.json) lên UI."""
        import json
        try:
            cfg = json.load(open(self.POTION_CFG_PATH, encoding="utf-8"))
            idx = cfg.get("itemindex"); qty = cfg.get("qty", 0)
            for it in self._potion_catalog:
                if it["idx"] == idx:
                    self.var_potion.set(f"{it['idx']:>2} · {it['name']}")
                    break
            self.var_potion_qty.set(str(qty))
            if qty and idx is not None:
                self.lbl_potion.config(text=f"✓ {cfg.get('name','?')} ×{qty}", fg="green")
        except Exception:
            pass

    def _apply_potion(self):
        """Ghi lựa chọn thuốc (loại + số lượng) ra config để bot mua trước khi cày đồ chí."""
        import json, os
        sel = self.var_potion.get().strip()
        try:
            qty = int(self.var_potion_qty.get() or 0)
        except Exception:
            qty = 0
        if not sel:
            self.lbl_potion.config(text="Chưa chọn loại thuốc.", fg="red")
            return
        idx = int(sel.split("·")[0].strip())
        name = sel.split("·", 1)[1].strip() if "·" in sel else sel
        # particular (file id) từ catalog -> bot ĐẾM đúng 'have' để mua BÙ (qty - have), không vượt qty.
        part = None
        for it in getattr(self, "_potion_catalog", []):
            if it.get("idx") == idx:
                part = it.get("particular"); break
        cfg = {"name": name, "shopkey": getattr(self, "_potion_shopkey", "hieu.thuoc.thanh.thi"),
               "itemindex": idx, "qty": qty, "particular": part}
        try:
            os.makedirs(os.path.dirname(self.POTION_CFG_PATH), exist_ok=True)
            json.dump(cfg, open(self.POTION_CFG_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
            if qty > 0:
                self.lbl_potion.config(text=f"✓ Sẽ mua {name} ×{qty} trước khi cày", fg="green")
            else:
                self.lbl_potion.config(text="Đã lưu (×0 = không mua)", fg="gray")
        except Exception as e:
            self.lbl_potion.config(text=f"Lưu lỗi: {e}", fg="red")

    @staticmethod
    def _clean_game_text(s):
        """Bỏ tag màu game '<color=#..>..</color>' + đuôi '... từ Dã Tẩu' + gộp khoảng trắng (log sạch)."""
        import re
        s = str(s or "")
        s = re.sub(r"</?color[^>]*>", "", s)        # bỏ tag màu
        s = re.sub(r"\s*từ Dã Tẩu\s*$", "", s, flags=re.IGNORECASE)
        s = re.sub(r"\s+", " ", s).strip(" |")
        return s

    def _render_items(self, lst):
        """(ĐÃ MERGE vào panel phần thưởng) — giữ để tương thích, no-op nếu không còn panel riêng."""
        if not getattr(self, 'txt_items', None):
            return
        self.txt_items.config(state='normal')
        self.txt_items.delete(1.0, tk.END)
        if lst:
            for r in lst:
                qno = r.get("qno", "?")
                name = self._clean_game_text(r.get("name", "?"))
                self.txt_items.insert(tk.END, f"NV {qno}:  {name}\n")
        else:
            self.txt_items.insert(tk.END, "(chưa có)")
        self.txt_items.see(tk.END)
        self.txt_items.config(state='disabled')

    def _render_rewards(self, lst):
        self.txt_rewards.config(state='normal')
        self.txt_rewards.delete(1.0, tk.END)
        # tag màu: TLH = xanh đậm (nổi bật khi chọn Thiết La Hán); phần 'nhận' = xám nhạt cho gọn.
        self.txt_rewards.tag_configure("tlh", foreground="#1a7f37", font=("Helvetica", 10, "bold"))
        self.txt_rewards.tag_configure("recv", foreground="#555")
        self.txt_rewards.tag_configure("qno", foreground="#1565c0", font=("Helvetica", 10, "bold"))
        if lst:
            for rw in lst:
                if not isinstance(rw, dict):
                    try:
                        qno, r = rw
                        self.txt_rewards.insert(tk.END, f"NV {qno}: {r}\n")
                    except Exception:
                        self.txt_rewards.insert(tk.END, f"{rw}\n")
                    continue
                qno = rw.get("qno")
                chosen = self._clean_game_text(rw.get("chosen"))
                recv = self._clean_game_text(rw.get("received"))
                is_tlh = "thiết la hán" in f"{chosen} {recv}".lower()
                # Dòng 1: "NV xxx │ <đã chọn>"  (thẳng hàng cột NV rộng 3)
                self.txt_rewards.insert(tk.END, f"NV {str(qno):>3} ", ("qno",))
                self.txt_rewards.insert(tk.END, "│ ", ("recv",))
                self.txt_rewards.insert(tk.END, chosen + "\n", ("tlh",) if is_tlh else ())
                # Dòng 2 (thụt lề): nhận được gì
                if is_tlh:
                    self.txt_rewards.insert(tk.END, "        └→ ✓ Nhận được 1 Thiết La Hán\n", ("tlh",))
                elif recv and recv.lower() != chosen.lower():
                    self.txt_rewards.insert(tk.END, f"        └→ {recv}\n", ("recv",))
        else:
            self.txt_rewards.insert(tk.END, "(chưa có)")
        self.txt_rewards.see(tk.END)
        self.txt_rewards.config(state='disabled')

    def update_player_info(self, device_id, name, map_name, money):
        # (map_name giữ trong chữ ký cho tương thích nhưng KHÔNG hiển thị — đã bỏ cột Bản đồ.)
        def _update():
            if self.tree.exists(device_id):
                current_values = list(self.tree.item(device_id, "values"))
                while len(current_values) < 4:
                    current_values.append("—")
                if name: current_values[1] = name
                if money: current_values[2] = money
                self.tree.item(device_id, values=current_values)
        self.root.after(0, _update)

    def mark_need_help(self, device_id, reason):
        """reason=str -> bot PENDING (cần trợ giúp): tô ĐỎ tên + cột Auto thành '⏸▶' (bấm = Resume) + chuông.
        reason=None -> hết PENDING: bỏ đỏ, cột Auto về '✅' (đang chạy)."""
        def _update():
            if not self.tree.exists(device_id):
                return
            vals = list(self.tree.item(device_id, "values"))
            while len(vals) < 4:
                vals.append("—")
            if reason:
                self.paused_devices.add(device_id)
                self.tree.item(device_id, tags=("need_help",))
                if not str(vals[1]).startswith("🆘"):
                    vals[1] = f"🆘 {vals[1]}"
                vals[0] = "⏸▶"   # PENDING -> bấm ô này = Resume
                self.tree.item(device_id, values=vals)
                try: self.root.bell()
                except Exception: pass
                try:
                    from core import notifier as _N
                    _b = (self.bots.get(device_id) or {}).get('bot')
                    _ch = getattr(_b, 'player_name', '') if _b else ''
                    _N.notify_pending(device_id, reason, char=_ch)   # bắn Zalo kèm TÊN NV (dedup 10' — không spam)
                except Exception:
                    pass
            else:
                self.paused_devices.discard(device_id)
                self.tree.item(device_id, tags=())
                vals[1] = str(vals[1]).replace("🆘 ", "")
                vals[0] = "✅"   # chạy lại
                self.tree.item(device_id, values=vals)
        self.root.after(0, _update)

    # ==================== WEB AGENT: publish status + nhận lệnh (qua kênh file Syncthing) ====================
    WEB_TICK_MS = 3000   # nhịp publish status + poll lệnh

    def _web_build_status(self):
        """Gom trạng thái MỌI cửa sổ máy này -> dict cho web (cây Máy→Cửa sổ)."""
        wins = []
        try:
            for dev in self.tree.get_children():
                info = self.bots.get(dev) or {}
                bot = info.get('bot')
                try: vals = list(self.tree.item(dev, 'values'))
                except Exception: vals = []
                st = ''
                try: st = getattr(getattr(bot, 'state', None), 'name', '') or ''
                except Exception: pass
                # TÀI KHOẢN cửa sổ: trạng thái NV (X/N) + đã nộp thủ quỹ — GIỐNG bảng UI app (KHÔNG kèm mật khẩu).
                accts = []
                try:
                    accts = self._account_status_rows(dev)
                except Exception:
                    pass
                _is_tre = False
                try:
                    from core import treasurer as _TRE
                    _is_tre = _TRE.is_treasurer_device(dev)
                except Exception: pass
                _qlabel = ''
                try:
                    q = getattr(bot, 'current_quest', None)
                    if q is not None:
                        from core import quest_actions as _QA
                        _qlabel = _QA.display_label(_QA.classify_quest(q), q)
                except Exception: pass
                # SỨC KHOẺ cửa sổ → web hiện cờ để biết cửa sổ nào CRASH/treo mà vào cứu.
                _health = 'ok'; _hmsg = ''
                try:
                    _thr = info.get('thread')
                    _dead = (_thr is not None and not _thr.is_alive())
                    _runact = bool(getattr(bot, '_run_active', False)) if bot else False
                    _conn = bool(getattr(bot, 'game_bot_connected', False)) if bot else False
                    _hb = getattr(bot, '_hb_ts', 0) if bot else 0
                    _isrun = bool(info.get('is_running'))
                    if _dead and _runact:
                        _health = 'crash'; _hmsg = 'Luồng chết (game crash)'
                    elif _isrun and not _conn:
                        _health = 'disconnect'; _hmsg = 'Mất kết nối Frida'
                    elif _isrun and not _is_tre and _hb and (time.time() - _hb) > self.WATCHDOG_STALL_SEC:
                        _health = 'stuck'; _hmsg = f'Treo ~{int((time.time()-_hb)/60)} phút'
                    elif dev in self.paused_devices:
                        _health = 'pending'; _hmsg = 'Cần trợ giúp (PENDING)'
                except Exception: pass
                # LOG LIVE (giống hệt app, realtime qua status nhỏ sync nhanh — KHÔNG đọc file log lớn 20p trễ)
                _logtail = []
                try:
                    _ch = self._char_key_of(dev)
                    _logtail = list(self.char_log_buf.get(_ch, []))[-80:]
                except Exception: pass
                wins.append({
                    'device': dev,
                    'is_treasurer': _is_tre,
                    'quest_label': _qlabel,
                    'health': _health,
                    'health_msg': _hmsg,
                    'log_tail': _logtail,
                    'label': self._dev_label(dev),
                    'char': (getattr(bot, 'player_name', '') or '') if bot else '',
                    'running': bool(info.get('is_running')),
                    'paused_loop': bool(getattr(bot, '_paused_loop', False)) if bot else False,
                    'pending': dev in self.paused_devices,
                    'state': st,
                    'money': vals[2] if len(vals) > 2 else '',
                    'today': vals[3] if len(vals) > 3 else '',
                    'auto_icon': vals[0] if vals else '',
                    'accounts': accts,
                })
        except Exception:
            pass
        _host = ''
        try: _host = _socket.gethostname()
        except Exception: pass
        cfgs = {}
        try:
            from core import web_config as _WC
            cfgs = _WC.snapshot_machine_configs()   # CHỈ config non-sensitive (không rò mật khẩu/cookies qua Syncthing)
        except Exception: pass
        thr = 5
        try: thr = self._get_threshold()
        except Exception: pass
        # THỐNG KÊ HÔM NAY của MÁY NÀY (NV hoàn thành + vật phẩm) — publish để web GỘP mọi máy.
        stats_today = {}
        try:
            from core import tracker as _T
            from collections import Counter as _C
            import re as _re2
            qc = _C(); hiem = _C(); thiet = 0; lac = 0
            for r in _T.load_day():
                ty = r.get('type')
                if ty == 'quest_completed':
                    qc[r.get('device', '?')] += 1
                elif ty == 'tlh_gain':                        # bot ghi MỖI lần TLH vào túi (mọi nguồn) — từ đây đếm ĐỦ
                    thiet += int(r.get('qty', 1) or 1)
                elif ty == 'item_received':
                    nm = (r.get('name') or '').strip(); low = nm.lower()
                    if not nm: continue
                    if ('ngẫu nhiên' in low or 'điểm kinh nghiệm' in low or 'ngân lượng' in low
                            or 'hoàn thành liên tiếp' in low or 'hoàn thành chuỗi' in low or low == 'vật phẩm mới'
                            or 'thiết la hán' in low):
                        continue                              # TLH đếm qua 'tlh_gain' (đủ mọi nguồn) — bỏ ở đây tránh trùng
                    if '(tống kim)' in low or low == 'lắc' or ' lắc' in low:
                        m = _re2.search(r'x\s*(\d+)', low); lac += int(m.group(1)) if m else 1; continue
                    clean = nm.split('|')[-1].replace('Nhận được', '').replace('từ Dã Tẩu', '').strip()
                    hiem[clean or nm] += 1
            by_window = [{'label': (self._dev_label(d) or d), 'quests': n} for d, n in qc.most_common()]
            stats_today = {'quests_total': sum(qc.values()), 'by_window': by_window,
                           'thiet_la_han': thiet, 'lac': lac,
                           'hiem': [{'name': k, 'count': v} for k, v in hiem.most_common(20)]}
        except Exception: pass
        return {'windows': wins, 'count': len(wins), 'hostname': _host, 'configs': cfgs,
                'buy_threshold_van': thr, 'stats_today': stats_today}

    def _reload_config_after_web(self, name):
        """Áp config vừa web-sửa LÊN bot đang chạy (config đọc-live-từ-file thì tự áp; cái nạp-lúc-start cần đẩy lại)."""
        try:
            if name == 'device_labels':
                self.device_labels = self._load_device_labels()
                self._refresh_devices()
            elif name == 'quest_actions':
                from core import quest_actions as _QA
                cfg = _QA.load_config()
                for info in list(self.bots.values()):
                    b = info.get('bot')
                    if b is not None:
                        b.quest_action_cfg = cfg     # áp NGAY cho mọi bot đang chạy (khỏi restart)
        except Exception:
            pass

    def _web_execute(self, cmd):
        """Thực thi 1 lệnh từ web (đang ở Tk thread → gọi method trực tiếp an toàn). Trả mô tả ngắn.
        AN TOÀN: validate device thuộc máy này; KHÔNG gọi việc CHẶN Tk (gb.close) — restart đi qua _start_bot(force)."""
        act = cmd.get('action'); dev = cmd.get('device'); args = cmd.get('args') or {}
        try:
            if act == 'rescan':
                self._refresh_devices(); return "rescan"
            # các lệnh theo cửa sổ: device PHẢI là cửa sổ máy này (có trong cây) — chống lệnh rác/máy khác
            if dev:
                try:
                    if not self.tree.exists(dev):
                        self.log(f"(web: bỏ lệnh '{act}' — device lạ {dev})"); return f"unknown_device:{dev}"
                except Exception:
                    pass
            running = bool((self.bots.get(dev) or {}).get('is_running')) if dev else False
            if act == 'start' and dev:
                if running:
                    return f"already_running {dev}"
                self._start_bot(dev); return f"start {dev}"
            if act == 'stop' and dev:
                self._stop_bot(dev); return f"stop {dev}"
            if act == 'resume' and dev:
                if dev not in self.paused_devices:
                    self.log("(web: resume bỏ qua — cửa sổ không PENDING)", dev); return f"not_pending {dev}"
                self._resume_bot(dev); return f"resume {dev}"
            if act == 'restart' and dev:
                # KHÔNG dùng _restart_one_window (gb.close CHẶN Tk thread = đơ UI). Dùng _start_bot(force):
                # luồng MỚI tự join+detach luồng cũ Ở WORKER THREAD → Tk không bị chặn.
                self._start_bot(dev, force=True); return f"restart {dev}"
            if act == 'scan_stalls' and dev:
                if not running:
                    self.log("(web: quét sạp cần bật Auto trước)", dev); return f"not_running {dev}"
                self._start_stall_scan(dev); return f"scan_stalls {dev}"
            if act == 'set_treasurer' and dev:
                self._set_treasurer_device(dev); return f"set_treasurer {dev}"
            if act == 'unset_treasurer':
                self._set_treasurer_device(None); return "unset_treasurer"
            if act == 'set_accounts' and dev:
                import json as _json, os as _os
                incoming = args.get('accounts') or []      # [{acc, pass?}] — pass trống = GIỮ mật khẩu cũ
                try:
                    data = _json.load(open(self.ACCOUNT_QUEUE_PATH, encoding="utf-8"))
                except Exception:
                    data = {}
                old = {a.get('acc'): a.get('pass', '') for a in (data.get(dev) or [])}
                newlist = []
                for it in incoming:
                    acc = (str(it.get('acc') or '')).strip()
                    if not acc:
                        continue
                    pw = (str(it.get('pass') or '')).strip() or old.get(acc, '')
                    newlist.append({"acc": acc, "pass": pw})
                data[dev] = newlist
                _os.makedirs(_os.path.dirname(self.ACCOUNT_QUEUE_PATH), exist_ok=True)
                _json.dump(data, open(self.ACCOUNT_QUEUE_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
                b = (self.bots.get(dev) or {}).get('bot')
                if b is not None and hasattr(b, '_load_account_queue'):
                    try: b._load_account_queue()
                    except Exception: pass
                self.log(f"👤 Cập nhật {len(newlist)} tài khoản (lệnh web; mật khẩu trống = giữ cũ).", dev)
                return f"set_accounts {dev} ({len(newlist)})"
            if act in ('pause', 'unpause') and dev:
                if not running:
                    self.log("(web: pause/unpause bỏ qua — cửa sổ chưa bật Auto)", dev); return f"not_running {dev}"
                b = (self.bots.get(dev) or {}).get('bot')
                if b is not None:
                    b._paused_loop = (act == 'pause')
                    self.log(f"{'⏸ Tạm dừng' if act=='pause' else '▶ Chạy tiếp'} (lệnh web).", dev)
                return f"{act} {dev}"
            if act == 'set_config' and args.get('name') is not None:
                from core import web_config as _WC
                cname = args.get('name'); content = args.get('content')
                # PHÒNG VỆ: quest_actions = MERGE (giữ key cũ) → push thiếu key KHÔNG làm mất do_chi_combat
                # (mất key → load_config lấp default huy_do_chi = HỦY ĐỒ CHÍ oan). Chống lỗi auto-hủy.
                if cname == 'quest_actions' and isinstance(content, dict):
                    try:
                        cur = dict(_WC.read_config(cname) or {})
                        cur.update(content); content = cur
                    except Exception: pass
                if _WC.write_config(cname, content):
                    self.log(f"⚙️ Đã cập nhật config '{cname}' (lệnh web) → áp dụng.")
                    self._reload_config_after_web(cname)
                    return f"set_config {cname}"
                self.log(f"⚙️ set_config '{cname}' THẤT BẠI (name lạ / lỗi ghi).")
                return f"set_config_fail:{cname}"
            if act == 'set_threshold':
                try:
                    van = max(0, min(int(args.get('van')), 999))
                except Exception:
                    return "set_threshold_bad"
                try: self.var_threshold.set(van)      # cập nhật ô UI -> bot MỚI cũng đọc đúng (qua _get_threshold)
                except Exception: pass
                self._apply_threshold()               # đẩy vào mọi bot đang chạy + auto-resume nếu nâng ngưỡng
                self.log(f"💰 Ngưỡng giá mua = {van} vạn (lệnh web, áp mọi cửa sổ).")
                return f"set_threshold {van}"
            if act == 'set_label' and dev and args.get('label') is not None:
                self.device_labels[dev] = str(args['label']).strip()
                try:
                    import json as _j
                    _j.dump(self.device_labels, open(self.DEVICE_LABELS_PATH, "w", encoding="utf-8"),
                            ensure_ascii=False, indent=2)
                except Exception: pass
                self._refresh_devices(); return f"set_label {dev}"
        except Exception as e:
            self.log(f"(web lệnh '{act}' lỗi: {e})", dev or None)
            return f"err:{e}"
        return f"unknown:{act}"

    def _web_tick(self):
        """Định kỳ: publish trạng thái máy này + đọc lệnh web CHƯA áp → thực thi → đánh dấu áp."""
        try:
            from core import webbridge as _WB
            mid = _WB.web_machine_id()   # id theo hostname (duy nhất mỗi máy) — KHÔNG dùng machine_id.txt (dễ trùng → LinhDL ẩn)
            if not getattr(self, '_web_seeded', False):
                # KHỞI ĐỘNG: đánh dấu mọi lệnh ĐANG có = đã-áp → chỉ lệnh GỬI SAU mới chạy (chống replay phá bot).
                try: _WB.seed_applied_from_jsonl(mid)
                except Exception: pass
                self._web_seeded = True
            # PUBLISH ~9s/lần (giảm bão xung đột Syncthing do ghi 3s/lần); POLL lệnh mỗi tick (3s) cho nhạy.
            self._web_pub_n = getattr(self, '_web_pub_n', 0) + 1
            if self._web_pub_n % 3 == 1:
                ok = _WB.publish_status(mid, self._web_build_status())
                if ok and not getattr(self, '_web_pub_logged', False):
                    self.log(f"📡 Web-agent: đã publish status máy '{mid}' → web sẽ thấy máy này.")
                    self._web_pub_logged = True
            cmds = _WB.read_pending_commands(mid)
            done = []
            for c in cmds:
                res = self._web_execute(c)
                if isinstance(res, str) and res.startswith('unknown'):
                    self.log(f"(web: lệnh không xử lý: {c.get('action')} {c.get('device') or ''} → {res})")
                done.append(c.get('id'))   # vẫn mark applied để KHÔNG lặp; đã LOG nếu không xử lý
            if done:
                _WB.mark_applied(done)
        except Exception as e:
            try: logging.getLogger().info(f"[web_tick] {e}")
            except Exception: pass
        finally:
            self.root.after(self.WEB_TICK_MS, self._web_tick)

    def _start_zalo_listener(self):
        """Bật NGHE LỆNH Zalo (resume từ xa) nếu notify bật. An toàn: nuốt lỗi, không sập UI."""
        try:
            from core import notifier as _N
            if not _N.is_enabled():
                return
            _N.set_command_handler(self._on_zalo_command)
            _N.start_listener()
            self.log("📨 Đang nghe lệnh Zalo (trả lời: resume <tên> | resume all | tt).")
        except Exception as e:
            try: self.log(f"(nghe lệnh Zalo lỗi, bỏ qua: {e})")
            except Exception: pass

    def _device_by_name(self, name):
        """Khớp TÊN (từ Zalo) → device_id của MÁY NÀY. Ưu tiên: player_name khớp đúng → nhãn cửa sổ khớp đúng →
        chứa (player_name/nhãn/device_id). None nếu không thấy."""
        q = (name or "").strip().lower()
        if not q:
            return None
        bots = list(self.bots.items())
        for dev, info in bots:                         # 1) player_name khớp đúng
            nm = (getattr(info.get('bot'), 'player_name', '') or '').strip().lower()
            if nm and nm == q:
                return dev
        for dev, lb in list((self.device_labels or {}).items()):   # 2) nhãn cửa sổ khớp đúng
            if (lb or '').strip().lower() == q and dev in self.bots:
                return dev
        for dev, info in bots:                         # 3) chứa
            nm = (getattr(info.get('bot'), 'player_name', '') or '').strip().lower()
            lb = ((self.device_labels or {}).get(dev, '') or '').strip().lower()
            if (nm and q in nm) or (lb and q in lb) or q in dev.lower():
                return dev
        return None

    def _on_zalo_command(self, message, author_id, thread_id):
        """Xử lý lệnh nhận từ Zalo. CHẠY Ở LUỒNG LISTENER → mọi thao tác Tk phải qua root.after.
        Lệnh: 'resume <tên>' | 'resume all' | 'tt'/'status'. Chỉ đụng cửa sổ MÁY NÀY sở hữu."""
        from core import notifier as _N
        msg = (message or "").strip()
        low = msg.lower()
        def _reply(t):
            try: _N.reply(t, thread_id)
            except Exception: pass
        # TRẠNG THÁI: liệt kê cửa sổ PENDING của máy này
        if low in ("tt", "status", "trang thai", "trạng thái"):
            items = []
            for dev in list(self.paused_devices):
                b = (self.bots.get(dev) or {}).get('bot')
                nm = (getattr(b, 'player_name', '') or '') if b else ''
                items.append(f"• {nm or (self.device_labels or {}).get(dev) or dev}")
            _reply("🆘 Đang PENDING (máy này):\n" + ("\n".join(items) if items else "(không có)"))
            return
        # RESUME
        if low.startswith("resume") or low.startswith("tiep") or low.startswith("tiếp"):
            parts = msg.split(None, 1)
            arg = parts[1].strip() if len(parts) > 1 else ""
            if arg.lower() in ("all", "hết", "het", "tat ca", "tất cả", "*"):
                devs = list(self.paused_devices)
                if not devs:
                    _reply("(Máy này không có cửa sổ nào đang PENDING.)"); return
                for d in devs:
                    self.root.after(0, lambda dd=d: self._resume_bot(dd))
                _reply(f"▶️ Đã resume {len(devs)} cửa sổ PENDING.")
                return
            if not arg:
                _reply("Cú pháp: resume <tên nhân vật/cửa sổ> | resume all | tt"); return
            dev = self._device_by_name(arg)
            if not dev:
                _reply(f"❓ Không thấy cửa sổ khớp '{arg}' trên máy này."); return
            if dev not in self.paused_devices:
                _reply(f"ℹ️ '{arg}' không ở trạng thái PENDING (đang chạy / hoặc ở máy khác)."); return
            self.root.after(0, lambda: self._resume_bot(dev))
            _reply(f"▶️ Đã resume: {arg}")
            return
        # lệnh lạ → im lặng (tránh nhiễu)

    def _resume_bot(self, device_id):
        """Người chơi bấm Resume trên dòng PENDING -> bot chạy tiếp (đọc lại NV)."""
        info = self.bots.get(device_id)
        if info and info.get('bot') and hasattr(info['bot'], 'resume'):
            self.log("▶️ Resume — bot chạy tiếp.", device_id)
            try:
                info['bot'].resume()   # bot tự gọi ui_need_help(None) -> trả màu + cột Auto
            except Exception as e:
                self.log(f"Resume lỗi: {e}", device_id)
        else:
            self.paused_devices.discard(device_id)

if __name__ == "__main__":
    root = tk.Tk()
    # LƯỚI AN TOÀN TOÀN CỤC: tắt 1 cửa sổ giả lập → device biến mất → 1 callback Tk (watchdog/web_tick/_load_view…)
    # có thể ném exception CHƯA BẮT → mặc định Tk in ra rồi GIẾT mainloop = "sập cả app/auto crash luôn".
    # Ghi traceback vào log thay vì để chết → app SỐNG TIẾP + ta biết đúng chỗ lỗi để vá tận gốc.
    import traceback as _tb, sys as _sys
    def _tk_cb_exc(exc, val, tbk):
        msg = "".join(_tb.format_exception(exc, val, tbk))
        try: logging.getLogger().error(f"[Tk callback bắt lỗi — KHÔNG sập app]\n{msg}")
        except Exception: pass
        print(f"[Tk callback EXC]\n{msg}", file=_sys.stderr)
    root.report_callback_exception = _tk_cb_exc
    def _sys_exc(exc, val, tbk):
        msg = "".join(_tb.format_exception(exc, val, tbk))
        try: logging.getLogger().error(f"[excepthook nền — luồng lỗi]\n{msg}")
        except Exception: pass
        print(f"[excepthook]\n{msg}", file=_sys.stderr)
    _sys.excepthook = _sys_exc
    # Thêm theme cho giống ứng dụng native
    style = ttk.Style(root)
    style.theme_use('clam')
    app = BotUIApp(root)
    root.protocol("WM_DELETE_WINDOW", root.quit)
    root.mainloop()
