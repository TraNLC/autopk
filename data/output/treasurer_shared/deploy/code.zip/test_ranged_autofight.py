# -*- coding: utf-8 -*-
"""test_ranged_autofight.py — TEST phái TAY DÀI: bạn DI CHUYỂN tay, code TỰ ĐÁNH quái trong tầm.

Khác test_spam_attack (spam đổi target loạn -> huỷ đòn): script này FOCUS 1 mục tiêu, bắn theo NHỊP
(~mỗi 0.9s) tới khi nó chết/ra-tầm rồi mới đổi con khác — đúng cơ chế đòn (server cần ~1-2s/đòn).

Pha 1 (học skill): nếu KHÔNG truyền skillId -> bạn đánh 1 con bằng tay ~12s, script bắt skillId tầm xa.
Pha 2 (auto): focus con hp% thấp nhất (>0), bắn eDoSkillTargetNpc(skill, id) mỗi ~0.9s; bạn cứ chạy.

Dùng: (TẮT UI)  venv/bin/python -u test_ranged_autofight.py [secs] [device] [skillId]
  vd:  venv/bin/python -u test_ranged_autofight.py 60 127.0.0.1:26624 5     (skillId=5, bỏ pha học)
"""
import sys, time
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

_args = sys.argv[1:]
DEV = next((a for a in _args if (":" in a or a.startswith("emulator"))), "127.0.0.1:26624")
_nums = [int(a) for a in _args if a.isdigit()]
SKILL = next((n for n in _nums if n >= 100), None)   # số ≥100 = skillId (vd 362); <100 = giây
SECS = next((n for n in _nums if n < 100), 60)        # số <100 = thời lượng giây


def varints(body):
    out = {}; i = 0
    while i < len(body):
        tag = body[i]; i += 1; fno = tag >> 3; wt = tag & 7
        if wt == 0:
            v = 0; sh = 0
            while i < len(body):
                b = body[i]; i += 1; v |= (b & 0x7F) << sh; sh += 7
                if not b & 0x80: break
            out[fno] = v
        elif wt == 2:
            ln = body[i]; i += 1; out[fno] = body[i:i+ln]; i += ln
        else:
            break
    return out


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect():
        print("connect FAIL (UI còn attach?)"); return
    bot.capture_sent = True
    for _ in range(8):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.4)
    bot.redetect_fd_by_traffic()
    p = bot.rpc.ping()
    print(f"gameFd={p.get('gameFd')} recvAny={p.get('recvAny')}")
    if not p.get("recvAny"):
        print("recvAny=0 — chưa vào thế giới."); return

    def mobs():
        try:
            r = bot.rpc.get_near_npcs_detail() or {}
        except Exception:
            return []
        return [n for n in (r.get("npcs") or []) if (n.get("hpMax", 0) or 0) > 0]

    def hp_of(mid):
        for n in mobs():
            if str(n.get("id")) == str(mid):
                return n.get("hp")
        return None

    skill = SKILL
    if skill is None:
        print("\n==> PHA 1: ĐÁNH 1 con quái bằng SKILL TAY DÀI ~12s để học skillId...\n")
        bot.sent_buffer = []
        t0 = time.time(); casts = []
        while time.time() - t0 < 12:
            try: bot.poll_recv()
            except: pass
            for pp in list(getattr(bot, "sent_buffer", [])):
                op = pp.get("opcode")
                if op in (40, 239, 240):
                    try: casts.append((op, varints(bytes.fromhex(pp.get("hex", ""))[6:])))
                    except Exception: pass
            bot.sent_buffer = []
            time.sleep(0.1)
        for op, d in casts:
            if op == 239 and 1 in d: skill = d[1]; break
            if op == 40 and 7 in d: skill = d[7]; break
        if skill is None:
            print(f"Chưa học được skillId (bắt {len(casts)} gói). Truyền tay: ... <skillId>. Mẫu:")
            for op, d in casts[:5]:
                print(f"  op{op} {({k:(v if isinstance(v,int) else v.hex()) for k,v in d.items()})}")
            return
        print(f">>> Học được skillId tầm xa = {skill}")

    print(f"\n==> PHA 2 ({SECS}s): TỰ ĐÁNH bằng skill {skill} — BẠN CỨ DI CHUYỂN. Focus 1 con tới chết rồi đổi.\n")
    t0 = time.time(); target = None; tgt_name = ""; kills = 0; sent = 0; last_report = 0
    while time.time() - t0 < SECS:
        ms = mobs()
        # chọn/giữ target: nếu target cũ còn trong tầm + còn máu -> giữ; không thì chọn con hp% thấp nhất
        cur_ids = {str(n.get("id")): n for n in ms}
        if target not in cur_ids or (cur_ids.get(target, {}).get("hp", 0) or 0) <= 0:
            if target is not None:
                # target cũ biến mất sau khi mình đánh = nghi đã chết
                kills += 1
                print(f"  ☠️ '{tgt_name}' (id={target}) chết/ra-tầm → đổi con khác. (tổng hạ ~{kills})")
            alive = [n for n in ms if (n.get("hp", 0) or 0) > 0]
            if alive:
                alive.sort(key=lambda n: (n.get("hp", 100) or 100))   # con yếu máu nhất trước (finish off)
                target = str(alive[0].get("id")); tgt_name = alive[0].get("name") or "?"
                print(f"  🎯 Focus mới: '{tgt_name}' id={target} hp%={alive[0].get('hp')}")
            else:
                target = None
        if target:
            bot.send_gs('eDoSkillTargetNpc', skillid=int(skill), nid=str(target)); sent += 1
        if time.time() - last_report > 5:
            last_report = time.time()
            print(f"  --- t+{int(time.time()-t0)}s | quái quanh={len(ms)} | đã bắn={sent} | hạ~{kills} "
                  f"| target hp%={cur_ids.get(target,{}).get('hp') if target else '-'} ---")
        time.sleep(0.9)   # NHỊP đòn ~0.9s (không spam) — server cần thời gian/đòn
    print(f"\n=== KẾT QUẢ {SECS}s: bắn {sent} đòn skill {skill} | hạ ~{kills} con (vừa di chuyển vừa đánh) ===")
    print("Nếu hạ được nhiều con khi bạn đang chạy -> auto-đánh-tay-dài-bằng-packet KHẢ THI.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[*] Dừng.")
