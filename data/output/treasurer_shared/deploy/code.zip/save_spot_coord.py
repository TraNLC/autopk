# -*- coding: utf-8 -*-
"""save_spot_coord.py — Nhận toạ độ TRONG GAME (minimap, 3 số) -> convert WORLD = game*256 -> lưu bảng bãi
quái luyện công + (tuỳ chọn) ĐI THỬ tới đó để verify (GotoFindingPath dùng WORLD).

WORLD = game*256 (codebase: WORLD//256 = minimap, da_tau_state_machine:3238). TẮT ui_bot_app.py trước.
  venv/bin/python save_spot_coord.py --gx 214 --gy 190 [--map 53] [--note "Tân Thủ Thôn X"] [--go]
  --go : đi thử tới toạ độ vừa convert (xác minh char tới đúng chỗ bạn đứng).
"""
import sys, time, json, os
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

DEV = "127.0.0.1:26624"; GX = GY = None; MAP = None; NOTE = ""; GO = False
a = sys.argv
if "--device" in a: DEV = a[a.index("--device") + 1]
if "--gx" in a: GX = int(a[a.index("--gx") + 1])
if "--gy" in a: GY = int(a[a.index("--gy") + 1])
if "--map" in a: MAP = int(a[a.index("--map") + 1])
if "--note" in a: NOTE = a[a.index("--note") + 1]
if "--go" in a: GO = True
OUT = "data/output/luyencong_spawn_spots.json"

if GX is None or GY is None:
    print("Thiếu --gx --gy (toạ độ trong game)."); sys.exit(1)

WX, WY = GX * 256, GY * 256   # convert game(minimap) -> WORLD

bot = VLTK1Bot(device_id=DEV)
if not bot.connect():
    print("connect fail"); sys.exit(1)

mid = MAP if MAP is not None else (bot.rpc.get_player_info() or {}).get("mapId")
print(f"[*] map={mid} | game=({GX},{GY}) -> WORLD=({WX},{WY})")

try:
    table = json.load(open(OUT, encoding="utf-8"))
except Exception:
    table = {}
table[str(mid)] = {"x": WX, "y": WY, "game": [GX, GY], "note": NOTE or table.get(str(mid), {}).get("note", "")}
os.makedirs(os.path.dirname(OUT), exist_ok=True)
json.dump(table, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print(f"💾 Lưu {OUT}[{mid}] = WORLD({WX},{WY}) game({GX},{GY}) note={NOTE!r}")
print(f"   → Tổng {len(table)} thôn: " + ", ".join(f"{k}:{v.get('note') or v.get('game')}" for k, v in table.items()))

if GO:
    print(f"[*] ĐI THỬ: walk_to(game {GX},{GY}) -> world({WX},{WY}) (main-thread, re-issue mỗi 2s)…")
    for i in range(6):
        try:
            ok = bot.walk_to(GX, GY, 90)   # nhận game coords, tự *256
            print(f"   lần {i+1}: walk_to ok={ok}")
        except Exception as e:
            print(f"   walk_to lỗi: {e}")
        time.sleep(2)
    print("   → Nhìn trong game: char có tới đúng bãi quái (chỗ bạn đứng) không?")
