# -*- coding: utf-8 -*-
"""test_melee_vs_ranged.py — So replay op239 skill MELEE (1, đánh thường) vs RANGED (362, Thiên Ngoại).
Giả thuyết user: melee replay TRÚNG, ranged replay TRƯỢT. Chỉ tính dame khi HP% GIẢM.
⚠️ TẮT autoplay + KHÔNG đánh tay. Có pre-check 5s chống nhiễm. Đứng SÁT quái (skill 1 tầm ngắn).
Dùng: venv/bin/python -u test_melee_vs_ranged.py [device]
"""
import sys, time
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

DEV = next((x for x in sys.argv[1:] if (":" in x or x.startswith("emulator"))), "127.0.0.1:26624")


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect(): print("connect FAIL"); return
    bot.capture_sent = True
    for _ in range(6):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.3)
    try: bot.redetect_fd_by_traffic()
    except Exception as e: print("redetect:", e)
    try:
        pi = bot.rpc.get_player_info() or {}; print(f"CHAR={pi.get('name')!r}")
    except Exception: pass

    def snap():
        try: r = bot.rpc.get_near_npcs_detail() or {}
        except Exception: return {}
        return {str(n.get("id")): {"name": n.get("name") or "?", "hp": n.get("hp")}
                for n in (r.get("npcs") or []) if (n.get("hpMax",0) or 0) > 0}

    s0 = snap()
    if not s0: print("❌ Không thấy quái. Đứng SÁT quái rồi chạy lại."); return
    print("Quái: " + ", ".join(f"{v['name']}#{k}={v['hp']}" for k,v in s0.items()))

    def hp(t): return (snap().get(t,{}) or {}).get("hp")

    def run_skill(skill, label):
        # chọn target HP cao nhất CÒN trong list mỗi lần chạy (đầy máu, dễ thấy tụt)
        cur = snap()
        if not cur: return None
        t = sorted(cur.items(), key=lambda kv: -(kv[1]["hp"] or 0))[0][0]
        tn = cur[t]["name"]
        # pre-check 4s chống nhiễm trên target này
        ha = hp(t); time.sleep(4); hb = hp(t)
        if t not in snap() or (ha is not None and hb is not None and hb < ha):
            print(f"   [{label}] ⚠️ target {tn}#{t} tự đổi {ha}->{hb} khi 0 gói → autoplay còn bật → BỎ."); return "DIRTY"
        before = hp(t)
        for _ in range(15):
            bot.send_gs('eDoSkillTargetNpc', skillid=skill, nid=t)
            t1=time.time()
            while time.time()-t1<0.4:
                try: bot.poll_recv()
                except: pass
                time.sleep(0.04)
        after = hp(t); gone = t not in snap()
        dmg = (before is not None and after is not None and after < before)
        print(f"   [{label}] skill {skill} vào {tn}#{t}: HP {before} -> {('mất' if gone else after)}   " +
              ("💥 TỤT MÁU = REPLAY TRÚNG" if dmg else "(không tụt — mất khỏi list chưa chắc chết)" if gone else "KHÔNG đổi = trượt"))
        return dmg

    print("\n=== A) MELEE: skill 1 (đánh thường) — đứng SÁT quái ===")
    run_skill(1, "MELEE")
    print("\n=== B) RANGED: skill 362 (Thiên Ngoại Lưu Tinh) ===")
    run_skill(362, "RANGED")
    print("\n→ Nếu A tụt máu, B không = XÁC NHẬN: melee replay trúng, ranged replay trượt (server phân biệt theo skillId).")


if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: print("\n[*] Dừng.")
