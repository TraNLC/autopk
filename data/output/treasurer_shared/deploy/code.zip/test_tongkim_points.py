# -*- coding: utf-8 -*-
"""test_tongkim_points.py — Probe NV "nâng điểm tích luỹ Tống Kim".

Mục tiêu (chốt 3 ẩn số trước khi code luồng worker dùng-item-trả-NV):
  1. Chữ ký item "điểm tích luỹ Tống Kim" = genre/detail/particular nào (để worker + thủ quỹ nhận đúng).
  2. use_item (ePlayerUserItem) có TIÊU item + NÂNG điểm tích luỹ không (so túi + bắt gói server).
  3. Gói server nào báo điểm tích luỹ (để đọc tiến độ NV).

CÁCH DÙNG (acc TEST, đã TẮT UI):
  venv/bin/python test_tongkim_points.py             # liệt kê item Tống Kim trong túi
  venv/bin/python test_tongkim_points.py --use <index>  # DÙNG 1 item ở ô <index> + bắt gói/so túi
"""
import sys
import time
import subprocess
import platform

sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot
from core.adb_helper import ADB_PATH

PACKAGE = "vn.perfingame.jx1mobile"
NOISE = {7, 8, 9, 16, 17, 18, 19, 20, 23, 63, 66}   # op16 eSyncPlayerItem là noise nhưng GIỮ để thấy item đổi


def detect_device():
    if platform.system() == "Darwin":
        for p in [26624, 26656, 26688, 16384, 22471, 5555]:
            subprocess.run(f"{ADB_PATH} connect 127.0.0.1:{p}", shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3)
    try:
        out = subprocess.check_output(f"{ADB_PATH} devices", shell=True).decode().strip().split("\n")
    except Exception as e:
        print(f"[-] adb devices lỗi: {e}"); return None
    for line in out[1:]:
        if "device" in line and "offline" not in line:
            dev = line.split("\t")[0]
            if dev.startswith("emulator-"):
                continue
            try:
                pid = subprocess.check_output(f"{ADB_PATH} -s {dev} shell pidof {PACKAGE}",
                                              shell=True, stderr=subprocess.DEVNULL).decode().strip()
                if pid:
                    return dev
            except Exception:
                pass
    return None


def bag_tongkim(bot):
    """Liệt kê item nghi Tống Kim trong túi (g6 + tên/particular gợi ý)."""
    dump = bot.dump_bag_items() or {}
    items = [it for it in dump.get('items', []) if it.get('location') == 2]
    out = []
    for it in items:
        nm = (it.get('name') or '').lower()
        if it.get('genre') == 6 or 'tống kim' in nm or 'tong kim' in nm or 'tích lu' in nm or 'tich lu' in nm:
            out.append(it)
    return items, out


def main():
    use_idx = None
    if "--use" in sys.argv:
        i = sys.argv.index("--use")
        use_idx = int(sys.argv[i + 1]) if i + 1 < len(sys.argv) else None

    dev = detect_device()
    if not dev:
        print("[-] Không thấy giả lập đang chạy game."); return
    print(f"[*] Device: {dev}")
    bot = VLTK1Bot(device_id=dev)
    if not bot.connect():
        print("[-] connect() FAIL."); return
    try:
        print(f"[*] recvAny={bot.rpc.ping().get('recvAny')}")
    except Exception:
        pass

    all_items, cands = bag_tongkim(bot)
    print(f"\n=== {len(cands)} item nghi Tống Kim / g6 trong túi ===")
    for it in cands:
        print(f"  index={it.get('index')}  name={it.get('name')!r}  "
              f"g{it.get('genre')}/d{it.get('detail')}/p{it.get('particular')}  stack={it.get('stack')}")
    if not cands:
        print("  (không có — đứng ở chỗ có item Tống Kim / nhận item trước)")

    if use_idx is None:
        print("\n[i] Chọn 1 index ở trên rồi chạy lại:  venv/bin/python test_tongkim_points.py --use <index>")
        print("    -> sẽ DÙNG item đó + bắt gói server + so túi trước/sau để biết có nâng điểm + tiêu item không.")
        return

    # --use: dùng item + bắt gói
    target = next((it for it in all_items if it.get('index') == use_idx), None)
    print(f"\n[*] item ô {use_idx}: {target.get('name') if target else '??'} "
          f"(p{target.get('particular') if target else '?'}, stack {target.get('stack') if target else '?'})")
    bot.recv_buffer = []
    try:
        bot.poll_recv()
    except Exception:
        pass
    bot.recv_buffer = []
    stack0 = target.get('stack') if target else None
    print(f"[*] >>> use_item({use_idx}) — quan sát điểm tích luỹ trong game + panel NV.")
    bot.use_item(use_idx)

    got = []
    for _ in range(10):
        time.sleep(0.5)
        try:
            bot.poll_recv()
        except Exception:
            pass
        if getattr(bot, 'recv_buffer', None):
            got.extend(bot.recv_buffer); bot.recv_buffer = []
    print(f"\n=== gói server sau use_item ({len(got)}) ===")
    for p in got:
        if p.get('opcode') in (7, 8, 20):       # bỏ move/sync ồn nhất
            continue
        print(f"  ← op{p.get('opcode')} ({p.get('name')})  {(p.get('hex') or '')[:80]}")

    # so stack item sau
    _, cands2 = bag_tongkim(bot)
    t2 = next((it for it in cands2 if it.get('index') == use_idx), None)
    stack1 = t2.get('stack') if t2 else 0
    print(f"\n[*] stack item ô {use_idx}: {stack0} -> {stack1} "
          f"({'ĐÃ TIÊU 1' if (stack0 and stack1 is not None and stack1 < stack0) else 'KHÔNG đổi'})")
    print("[KẾT LUẬN] Gửi tôi output. Tôi xác định: chữ ký item, gói nào mang 'điểm tích luỹ' (đọc tiến độ),"
          " và xác nhận use_item nâng điểm + tiêu item -> ráp luồng worker tự dùng + trả NV.")


if __name__ == "__main__":
    main()
