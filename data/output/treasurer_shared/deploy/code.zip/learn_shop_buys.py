"""
learn_shop_buys.py — Học itemindex shop NPC từ chính cú MUA TAY của bạn.

Vì (genre,detail,particular) KHÔNG phân biệt được model vũ khí (17 đao đều (0,0,1)),
cách chắc chắn nhất: bạn mua tay món quest cần -> tool bắt eShopBuyItem(148) = (shopkey, itemindex, qty),
bạn nhắn tên món -> lưu vào data/output/shop_item_index.json: { "<tên lower>": {shopkey, itemindex} }.
Bot (npc_shop.find_itemindex) tra map học này TRƯỚC, khớp tên shop_index sau.

    venv/bin/python -u learn_shop_buys.py [giây]    # mặc định 240s
"""
import sys, time, json, os, subprocess, platform
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot
from core.adb_helper import ADB_PATH

PKG = "vn.perfingame.jx1mobile"
FEED_PATH = "data/output/shop_buy_feed.txt"
RAW_PATH = "data/output/shop_buy_raw.jsonl"


def _feed(line):
    print(line, flush=True)
    try:
        with open(FEED_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def detect():
    if platform.system() == "Darwin":
        for p in [26624, 26656, 26688, 16384, 22471, 5555]:
            subprocess.run(f"{ADB_PATH} connect 127.0.0.1:{p}", shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3)
    for l in subprocess.check_output(f"{ADB_PATH} devices", shell=True).decode().split("\n")[1:]:
        if "device" in l and "offline" not in l:
            d = l.split("\t")[0]
            if not d.startswith("emulator-"):
                try:
                    if subprocess.check_output(f"{ADB_PATH} -s {d} shell pidof {PKG}", shell=True,
                                               stderr=subprocess.DEVNULL).decode().strip():
                        return d
                except Exception:
                    pass
    return None


def _decode_buy(body):
    """eShopBuyItem body: f1=shopkey(string), f2=itemindex(varint), f3=qty(varint)."""
    shopkey, itemindex, qty = "", None, 1
    pos = 0
    while pos < len(body):
        tag = body[pos]; pos += 1
        fnum = tag >> 3; wt = tag & 7
        if wt == 2:
            ln = body[pos]; pos += 1
            v = body[pos:pos+ln]; pos += ln
            if fnum == 1:
                shopkey = v.decode("utf-8", "replace")
        elif wt == 0:
            val = 0; shift = 0
            while pos < len(body):
                b = body[pos]; pos += 1
                val |= (b & 0x7f) << shift
                if not (b & 0x80):
                    break
                shift += 7
            if fnum == 2:
                itemindex = val
            elif fnum == 3:
                qty = val
        else:
            break
    return shopkey, itemindex, qty


def main():
    secs = int(sys.argv[1]) if len(sys.argv) > 1 else 240
    dev = detect()
    if not dev:
        print("[-] no device"); return
    b = VLTK1Bot(device_id=dev)
    if not b.connect():
        print("[-] connect fail"); return
    time.sleep(1)
    try:
        os.makedirs("data/output", exist_ok=True)
        open(FEED_PATH, "w", encoding="utf-8").close()
    except Exception:
        pass

    def on_msg(message, data):
        if message.get("type") != "send":
            return
        p = message.get("payload", {})
        if not isinstance(p, dict) or p.get("type") != "send_out":
            return
        if p.get("opcode") != 148:   # eShopBuyItem
            return
        try:
            hx = p.get("hex", "")
            body = bytes.fromhex(hx)[6:]
            shopkey, itemindex, qty = _decode_buy(body)
            _feed(f"🛒 [{time.strftime('%H:%M:%S')}] MUA: shopkey={shopkey!r} itemindex={itemindex} qty={qty} "
                  f"| (nhắn tôi TÊN món vừa mua để lưu)")
            try:
                with open(RAW_PATH, "a", encoding="utf-8") as f:
                    f.write(json.dumps({"ts": time.strftime('%H:%M:%S'), "shopkey": shopkey,
                                        "itemindex": itemindex, "qty": qty, "hex": hx},
                                       ensure_ascii=False) + "\n")
            except Exception:
                pass
            # Thử đọc túi để gợi ý tên món mới (best-effort)
            try:
                dump = b.dump_bag_items()
                items = dump.get("items", []) if dump and dump.get("ok") else []
                if items:
                    last = sorted(items, key=lambda x: x.get("slot", 0))[-3:]
                    names = [f"ô{it.get('slot')}:{it.get('name','?')}" for it in last]
                    _feed(f"    túi (3 ô cuối): {names}")
            except Exception:
                pass
        except Exception as e:
            _feed(f"   parse err: {e}")

    b.script.on("message", on_msg)
    _feed(f"🟢 HỌC MUA SHOP {secs}s — mở shop NPC, MUA TAY món quest cần (vd Đơn Đao hệ Thổ). "
          f"Mỗi lần mua tôi bắt shopkey+itemindex; bạn nhắn tên món để tôi lưu.")
    t0 = time.time()
    while time.time() - t0 < secs:
        time.sleep(0.3)
    _feed("🏁 HẾT GIỜ học mua shop.")
    b.close()


if __name__ == "__main__":
    main()
