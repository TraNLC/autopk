# -*- coding: utf-8 -*-
"""test_capture_huyhoang.py — LISTENER hái "Quả Huy Hoàng": vừa QUÉT object quả xung quanh vừa BẮT GÓI live.

Hái quả là tương tác CÓ KÊNH (~10s) chứ không nhặt-tức-thì. Script KHÔNG đoán opcode mà:
  (A) QUÉT object gần (getNearNpcsSafe + getNearPlayers) liên tục -> liệt kê quả (id+tên), và phát hiện
      quả nào XUẤT HIỆN/BIẾN MẤT (quả biến mất = quả vừa bị hái).
  (B) GHI MỌI gói OUT (client gửi) + IN (server trả) theo thời gian.
-> Ghép objectId trong gói "bắt đầu hái" với npcId quả vừa biến mất => ra cơ chế (có remote/auto được không).

CÁCH DÙNG:
  1. TẮT hẳn UI Auto (Frida attach 1 lần).
  2. Tới bãi quả, ĐỢI 1 quả CHÍN (hái được).
  3. Chạy:  venv/bin/python test_capture_huyhoang.py        (mặc định 40s; đổi: ... 60)
  4. Khi thấy "==> CLICK QUẢ CHÍN NGAY BÂY GIỜ", CLICK quả + đứng im cho hái xong.
  5. Copy TOÀN BỘ output gửi lại.
"""
import sys
import time
import subprocess
import platform

sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot
from core.adb_helper import ADB_PATH

PACKAGE = "vn.perfingame.jx1mobile"

# Opcode "ồn" lúc cày/di chuyển — gộp đếm thay vì in từng cái (giữ timeline sạch để thấy gói hái).
NOISE_OPS = {7, 8, 9, 16, 17, 18, 19, 20, 23, 63, 66}


def detect_device():
    if platform.system() == "Darwin":
        for p in [26624, 26656, 26688, 26720, 26880, 16384, 22471, 5555]:
            subprocess.run(f"{ADB_PATH} connect 127.0.0.1:{p}", shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3)
    try:
        out = subprocess.check_output(f"{ADB_PATH} devices", shell=True).decode().strip().split("\n")
    except Exception as e:
        print(f"[-] adb devices lỗi: {e}")
        return None
    for line in out[1:]:
        if "device" in line and "offline" not in line:
            dev = line.split("\t")[0]
            if dev.startswith("emulator-"):
                continue
            try:
                pid = subprocess.check_output(f"{ADB_PATH} -s {dev} shell pidof {PACKAGE}",
                                              shell=True, stderr=subprocess.DEVNULL).decode().strip()
                if pid:
                    return dev
            except Exception:
                pass
    return None


def scan_objs(bot):
    """Quét object gần: NPC (node hái quả thường là NPC) + player/sạp. Trả {id: name}."""
    objs = {}
    try:
        r = bot.rpc.get_near_npcs_safe() or {}
        for n in (r.get("npcs") or []):
            objs[str(n.get("id"))] = (n.get("name") or "").strip()
    except Exception:
        pass
    try:
        r = bot.rpc.get_near_players() or {}
        for n in (r.get("players") or []):
            objs.setdefault(str(n.get("id")), "(player)")
    except Exception:
        pass
    return objs


def main():
    secs = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 40
    dev = detect_device()
    if not dev:
        print("[-] Không thấy giả lập đang chạy game. Mở game trước.")
        return
    print(f"[*] Device: {dev}")
    bot = VLTK1Bot(device_id=dev)
    if not bot.connect():
        print("[-] connect() FAIL — UI Auto còn attach Frida? Tắt UI rồi chạy lại. (Frida attach 1 lần)")
        return
    bot.capture_sent = True   # bật bắt gói GỬI (sendto); mặc định off -> sent_buffer rỗng
    # game đã connect trước attach -> hook connect() miss -> dò lại fd theo traffic (nếu recvAny=0)
    try:
        if not (bot.rpc.ping() or {}).get("recvAny"):
            for _ in range(8):
                bot.poll_recv(); time.sleep(0.4)
            bot.redetect_fd_by_traffic()
    except Exception:
        pass
    try:
        print(f"[*] recvAny={bot.rpc.ping().get('recvAny')} (phải >0).")
    except Exception:
        pass

    # Snapshot object gần TRƯỚC khi hái (để biết quả nào có sẵn + tên).
    base = scan_objs(bot)
    print(f"\n=== OBJECT GẦN TRƯỚC KHI HÁI ({len(base)}) — tìm 'Quả'/'Huy Hoàng' ===")
    for oid, nm in base.items():
        print(f"  id={oid}  name={nm!r}")

    # Xả buffer cũ
    bot.sent_buffer = []
    bot.recv_buffer = []
    try:
        bot.poll_recv()
    except Exception:
        pass
    bot.sent_buffer = []
    bot.recv_buffer = []

    print("\n" + "=" * 56)
    print("==> CLICK QUẢ CHÍN NGAY BÂY GIỜ + đứng im cho hái xong!")
    print(f"    (đang bắt gói + quét object {secs}s...)")
    print("=" * 56 + "\n")

    t0 = time.time()
    timeline = []      # (elapsed, kind, ...) — kind: OUT/IN/OBJ+/OBJ-
    noise = {}
    seen_sent = 0
    prev = dict(base)
    last_scan = 0.0
    while time.time() - t0 < secs:
        try:
            bot.poll_recv()
        except Exception:
            pass
        now = time.time()
        # OUT (client gửi)
        sb = list(getattr(bot, "sent_buffer", []))
        for p in sb[seen_sent:]:
            op = p.get("opcode")
            if op in NOISE_OPS:
                noise[("OUT", op)] = noise.get(("OUT", op), 0) + 1
            else:
                timeline.append((round(now - t0, 1), "OUT", op, p.get("name") or "?", (p.get("hex") or "")[:96]))
        seen_sent = len(sb)
        # IN (server trả)
        rb = list(getattr(bot, "recv_buffer", []))
        if rb:
            bot.recv_buffer = []
            for p in rb:
                op = p.get("opcode")
                if op in NOISE_OPS:
                    noise[("IN", op)] = noise.get(("IN", op), 0) + 1
                else:
                    timeline.append((round(now - t0, 1), "IN", op, p.get("name") or "?", (p.get("hex") or "")[:96]))
        # QUÉT object mỗi ~1s -> phát hiện quả XUẤT HIỆN / BIẾN MẤT (biến mất = vừa bị hái)
        if now - last_scan >= 1.0:
            last_scan = now
            cur = scan_objs(bot)
            for oid, nm in cur.items():
                if oid not in prev:
                    timeline.append((round(now - t0, 1), "OBJ+", oid, nm, ""))
            for oid, nm in prev.items():
                if oid not in cur:
                    timeline.append((round(now - t0, 1), "OBJ-", oid, nm, ""))
            prev = cur
        time.sleep(0.12)

    print(f"\n=== TIMELINE (bỏ {sum(noise.values())} gói ồn di-chuyển/sync) ===")
    if not timeline:
        print("  (KHÔNG bắt được gì — click chưa trúng / recvAny=0 / quá xa?)")
    for row in timeline:
        t, kind = row[0], row[1]
        if kind in ("OUT", "IN"):
            _, _, op, nm, hx = row
            arrow = "→ OUT" if kind == "OUT" else "← IN "
            print(f"  t+{t:>4}s {arrow} op{op} ({nm})  {hx}")
        else:  # OBJ+ / OBJ-
            _, _, oid, nm, _ = row
            tag = "OBJ XUẤT HIỆN" if kind == "OBJ+" else "OBJ BIẾN MẤT "
            print(f"  t+{t:>4}s [{tag}] id={oid} name={nm!r}")

    print("\n=== gói ồn (gộp) ===")
    for (d, op), c in sorted(noise.items(), key=lambda x: -x[1]):
        print(f"  {d} op{op}: {c} lần")
    print("\n[i] Gửi tôi toàn bộ output. Tôi sẽ chỉ ra: gói CLICK hái (objectId = id quả vừa biến mất?), "
          "gói server đếm/giữ kênh 10s, gói cấp item lúc xong => có auto/remote được không.")


if __name__ == "__main__":
    main()
