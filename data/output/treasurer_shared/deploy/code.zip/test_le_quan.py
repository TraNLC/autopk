# -*- coding: utf-8 -*-
"""test_le_quan.py — Test REMOTE CALL tới NPC "Lễ Quan" (mở NPC bằng packet từ xa, không đi tới).

Cơ chế: mở NPC = eNpcDialogue(op33){npcId}. Server KHÔNG check khoảng cách khi mở NPC (như Dã Tẩu/shop) →
gọi npcId từ xa là server trả dialog (op34 lời chào / op124 nội dung / op126 givebox...).

Vướng: chưa biết npcId của Lễ Quan → HỌC bằng cách bạn CLICK Lễ Quan 1 lần (bot bắt op33 gửi đi).

CÁCH DÙNG (acc test, đã TẮT UI hoặc dùng device không chạy):
  1. venv/bin/python test_le_quan.py            # HỌC: bạn click Lễ Quan trong game → in ra npcId
  2. venv/bin/python test_le_quan.py --call <npcId>   # REMOTE-CALL: gửi mở Lễ Quan từ xa + xem server trả gì
"""
import sys
import time
import subprocess
import platform

sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot
from core.adb_helper import ADB_PATH

PACKAGE = "vn.perfingame.jx1mobile"
NOISE = {7, 8, 9, 16, 17, 18, 19, 20, 23, 63, 66}


def detect_device():
    if platform.system() == "Darwin":
        for p in [26624, 26656, 26688, 16384, 22471, 5555]:
            subprocess.run(f"{ADB_PATH} connect 127.0.0.1:{p}", shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3)
    try:
        out = subprocess.check_output(f"{ADB_PATH} devices", shell=True).decode().strip().split("\n")
    except Exception as e:
        print(f"[-] adb devices lỗi: {e}"); return None
    for line in out[1:]:
        if "device" in line and "offline" not in line:
            dev = line.split("\t")[0]
            if dev.startswith("emulator-"):
                continue
            try:
                pid = subprocess.check_output(f"{ADB_PATH} -s {dev} shell pidof {PACKAGE}",
                                              shell=True, stderr=subprocess.DEVNULL).decode().strip()
                if pid:
                    return dev
            except Exception:
                pass
    return None


def _npcid_from_op33(hexstr):
    try:
        body = bytes.fromhex(hexstr or "")[6:]
        if body and body[0] == 0x0a:
            ln = body[1]
            return body[2:2 + ln].decode("utf-8", "ignore")
    except Exception:
        pass
    return None


def main():
    call_id = None
    if "--call" in sys.argv:
        i = sys.argv.index("--call")
        call_id = sys.argv[i + 1] if i + 1 < len(sys.argv) else None

    dev = detect_device()
    if not dev:
        print("[-] Không thấy giả lập đang chạy game."); return
    print(f"[*] Device: {dev}")
    bot = VLTK1Bot(device_id=dev)
    if not bot.connect():
        print("[-] connect() FAIL."); return
    try:
        print(f"[*] recvAny={bot.rpc.ping().get('recvAny')}")
    except Exception:
        pass

    if call_id:
        # ===== REMOTE-CALL =====
        bot.recv_buffer = []
        try:
            bot.poll_recv()
        except Exception:
            pass
        bot.recv_buffer = []
        print(f"[*] >>> talk_npc('{call_id}') — mở Lễ Quan TỪ XA (eNpcDialogue op33). KHÔNG di chuyển.")
        bot.talk_npc(str(call_id))
        got = []
        for _ in range(10):
            time.sleep(0.5)
            try:
                bot.poll_recv()
            except Exception:
                pass
            if getattr(bot, "recv_buffer", None):
                got.extend(bot.recv_buffer); bot.recv_buffer = []
        notable = [p for p in got if p.get("opcode") not in NOISE]
        print(f"\n=== server trả ({len(got)} gói, đáng chú ý {len(notable)}) ===")
        for p in notable[:30]:
            hx = (p.get("hex") or "")
            txt = ""
            try:
                txt = bytes.fromhex(hx)[6:].decode("utf-8", "ignore")
                txt = "".join(c for c in txt if c.isprintable())[:60]
            except Exception:
                pass
            print(f"  ← op{p.get('opcode')} ({p.get('name')})  {txt!r}")
        if any(p.get("opcode") in (34, 124, 166, 126, 245) for p in notable):
            print("\n✅ Server CÓ trả dialog/nội dung → REMOTE-CALL Lễ Quan từ xa ĐƯỢC.")
        else:
            print("\n❓ Không thấy gói dialog rõ ràng — có thể npcId sai, hoặc Lễ Quan cần điều kiện/khoảng cách. "
                  "Gửi tôi output để xem.")
        return

    # ===== HỌC npcId =====
    print("\n" + "=" * 52)
    print("==> Trong game, CLICK vào NPC 'Lễ Quan' NGAY BÂY GIỜ (đang nghe 20s)…")
    print("=" * 52 + "\n")
    bot.sent_buffer = []
    t0 = time.time()
    seen = 0
    found = []
    _secs = 60
    if "--secs" in sys.argv:
        try: _secs = int(sys.argv[sys.argv.index("--secs") + 1])
        except Exception: pass
    while time.time() - t0 < _secs:
        try:
            bot.poll_recv()
        except Exception:
            pass
        sb = list(getattr(bot, "sent_buffer", []))
        for p in sb[seen:]:
            if p.get("opcode") == 33:
                nid = _npcid_from_op33(p.get("hex", ""))
                if nid and nid not in found:
                    found.append(nid)
                    print(f"  → eNpcDialogue npcId = {nid}")
        seen = len(sb)
        lid = getattr(bot, "last_npc_dialogue_id", None)
        if lid and lid not in found:
            found.append(lid)
            print(f"  → (auto-learn) npcId = {lid}")
        time.sleep(0.2)
    if found:
        print(f"\n[i] npcId Lễ Quan (nghi) = {found}. Test remote-call: "
              f"venv/bin/python test_le_quan.py --call {found[-1]}")
    else:
        print("\n[-] Chưa bắt được op33 — bạn click trúng NPC chưa? Thử lại + click đúng Lễ Quan.")


if __name__ == "__main__":
    main()
