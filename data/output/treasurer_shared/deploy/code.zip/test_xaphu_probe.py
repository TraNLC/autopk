# -*- coding: utf-8 -*-
"""test_xaphu_probe.py — TEST AN TOÀN prober Xa Phu (KHÔNG travel, KHÔNG mất đồ).

Đứng char trong 1 ĐỘNG (nhất là 8 động sót: map 79/129/130/181/198/53/76/996) rồi chạy:
  venv/bin/python test_xaphu_probe.py [--device 127.0.0.1:26624]
Script chỉ DÒ npc Xa Phu nào MỞ được menu từ vị trí hiện tại (eNpcDialogue) → in ra.
TẮT ui_bot_app.py trước (Frida attach 1 lần).
"""
import sys, time
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

DEV = "127.0.0.1:26624"
a = sys.argv
if "--device" in a:
    DEV = a[a.index("--device") + 1]

bot = VLTK1Bot(device_id=DEV)
if not bot.connect():
    print("connect fail"); sys.exit(1)

mid = (bot.rpc.get_player_info() or {}).get("mapId")
print(f"[*] Đang ở map {mid}. Dò 7 Xa Phu npc xem cái nào mở menu (same-region)…", flush=True)

# in từng npc thử (không cache để thấy hết)
MENU = (34, 124, 166, 167)
opened = []
for npc in bot._all_known_xaphu_npcs():
    try: bot.recv_buffer = []
    except Exception: pass
    bot.talk_npc(npc)
    ok = bool(bot.wait_for_packet(MENU, timeout=1.3))
    print(f"   npc {npc:>5}: {'✅ MỞ MENU' if ok else '— (vùng khác, bỏ qua)'}", flush=True)
    if ok: opened.append(npc)
    time.sleep(0.2)

print(f"\n=== KẾT QUẢ map {mid}: npc mở được = {opened or 'KHÔNG CÓ (vùng lạ, vd Ba Lăng → cần học id)'} ===")
if opened:
    print(f"→ xaphu_travel sẽ tự dùng npc {opened[0]} để về thành/đi NV từ động này. ✅")
else:
    print("→ Vùng này CHƯA có Xa Phu npc trong 7 thành. Bot sẽ về thành bằng TDP (tốn 1 phù, không treo).")
    print("  Học id: đứng ở THÀNH vùng này click Xa Phu, mình bắt op33 npcId rồi thêm vào xaphu_town_npc.json.")
