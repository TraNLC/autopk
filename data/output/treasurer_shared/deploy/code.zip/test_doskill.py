# -*- coding: utf-8 -*-
"""test_doskill.py — Invoke PlayerMain.DoSkill(id) trên MAIN THREAD (client tự cast đúng bài) thay vì bơm op239.
Đo HP quái GIẢM = client cast có dame. ⚠️ KHÔNG giữ nút skill, KHÔNG đánh tay. Pre-check chống nhiễm.
Dùng: venv/bin/python -u test_doskill.py [device] [skillId]
"""
import sys, time
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot
DEV = next((x for x in sys.argv[1:] if (":" in x or x.startswith("emulator"))), "127.0.0.1:26624")
SKILL = next((int(x) for x in sys.argv[1:] if x.isdigit() and int(x) > 50), 362)

def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect(): print("connect FAIL"); return
    for _ in range(6):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.3)
    try: bot.redetect_fd_by_traffic()
    except Exception as e: print("redetect:", e)
    try: pi=bot.rpc.get_player_info() or {}; print(f"CHAR={pi.get('name')!r}")
    except Exception: pass
    def snap():
        try: r=bot.rpc.get_near_npcs_detail() or {}
        except Exception: return {}
        return {str(n.get("id")):{"name":n.get("name") or "?","hp":n.get("hp")} for n in (r.get("npcs") or []) if (n.get("hpMax",0) or 0)>0}
    s0=snap()
    if not s0: print("❌ không thấy quái, đứng cạnh quái rồi chạy lại."); return
    print("Quái trước: "+", ".join(f"{v['name']}#{k}={v['hp']}" for k,v in s0.items()))
    # pre-check 5s (KHÔNG invoke) — HP phải đứng yên
    print("\n[pre-check 5s, KHÔNG invoke] HP phải đứng yên:")
    a={k:v["hp"] for k,v in snap().items()}; time.sleep(5); b={k:v["hp"] for k,v in snap().items()}
    drift=[k for k in a if k not in b or (a[k] is not None and b.get(k) is not None and b[k]<a[k])]
    if drift: print(f"⚠️ {len(drift)} con tự tụt/mất khi 0 invoke ({drift[:3]}) → bạn còn GIỮ nút skill / auto → BỎ. Thả hết rồi chạy lại."); return
    print(f"   ✓ {len(b)} con đứng yên = sạch.\n")
    before={k:v["hp"] for k,v in snap().items()}
    print(f"==> INVOKE DoSkill({SKILL}) main-thread ~20 phát (client tự cast). ĐỪNG giữ nút/đánh tay.")
    for i in range(20):
        r=bot.rpc.do_skill_hooked(SKILL)
        t1=time.time()
        while time.time()-t1<0.8:
            try: bot.poll_recv()
            except: pass
            time.sleep(0.05)
        if (i+1)%5==0:
            try: lf=bot.rpc.skill_last_fire()
            except Exception: lf={}
            print(f"   ...{i+1}/20 | lastFire={lf.get('fire')!r}")
    after=snap()
    print("\n=== KẾT QUẢ (HP% trước→sau) ===")
    drop=0
    for k,hpb in before.items():
        gone=k not in after; ha=after.get(k,{}).get("hp")
        d=(hpb is not None and ha is not None and ha<hpb)
        if d: drop+=1
        print(f"   #{k} {hpb} -> {('mất' if gone else ha)}{'  💥 TỤT' if d else ('  ☠️mất' if gone else '')}")
    print(f"\n----- {drop} con TỤT MÁU. " + ("✅ INVOKE DoSkill GÂY DAME → tự đánh được!" if drop else "❌ không con nào tụt — DoSkill chưa ăn (xem lastFire: lỗi? cần SetTarget trước?)."))
    try: print("lastFire cuối:", bot.rpc.skill_last_fire())
    except Exception: pass

if __name__=="__main__":
    try: main()
    except KeyboardInterrupt: print("\n[*] Dừng.")
