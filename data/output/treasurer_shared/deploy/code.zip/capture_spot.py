# -*- coding: utf-8 -*-
"""capture_spot.py — Bắt toạ độ WORLD bãi quái lv1 theo thôn, bằng cách HOOK GotoFindingPath:
bạn TAP vào bãi quái để char đi tới -> hook bắt (x,y) ĐÍCH = đúng toạ độ WORLD cần (đơn vị chuẩn cho
GotoFindingPath, KHÔNG phải minimap). Lưu {mapId thôn -> (x,y)}.

(readPositionFromMemory hỏng offset 32-bit; op9/_lastPosition không parse được trong probe -> dùng hook tap.)
TẮT ui_bot_app.py trước.
  venv/bin/python capture_spot.py [--device 127.0.0.1:26624] [--note "Tân Thủ Thôn X"]
"""
import sys, time, json, os
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

DEV = "127.0.0.1:26624"
NOTE = ""
a = sys.argv
if "--device" in a: DEV = a[a.index("--device") + 1]
if "--note" in a: NOTE = a[a.index("--note") + 1]
OUT = "data/output/luyencong_spawn_spots.json"

bot = VLTK1Bot(device_id=DEV)
if not bot.connect():
    print("connect fail"); sys.exit(1)

# bật hook bắt args GotoFindingPath
r = bot.rpc.capture_goto()
print(f"[*] captureGoto: {r}", flush=True)
# xoá log cũ
base = len((bot.rpc.last_goto_args() or {}).get("log", []))

mid = (bot.rpc.get_player_info() or {}).get("mapId")
print(f"👉 ĐANG Ở map {mid}. TAP vào BÃI QUÁI để char đi tới đó (trong ~30s)…", flush=True)

target = None
t0 = time.time()
while time.time() - t0 < 30:
    log = (bot.rpc.last_goto_args() or {}).get("log", [])
    # lấy bản ghi GotoFindingPath MỚI nhất sau 'base'
    for rec in log[base:]:
        if str(rec.get("m", "")).startswith("GotoFindingPath/6"):
            args = rec.get("args", [])
            if len(args) >= 2 and isinstance(args[0], int) and isinstance(args[1], int) and args[0] > 0 and args[1] > 0:
                target = (args[0], args[1])
                print(f"   🎯 TAP đi tới WORLD=({args[0]},{args[1]})", flush=True)
    if target:
        break
    time.sleep(0.5)

if not target:
    print("⚠️ Chưa bắt được cú TAP đi (hãy TAP vào bãi quái để char DI CHUYỂN tới đó). KHÔNG lưu.")
    sys.exit(1)

mid = (bot.rpc.get_player_info() or {}).get("mapId")   # đọc lại map (phòng đổi)
x, y = target
try:
    table = json.load(open(OUT, encoding="utf-8"))
except Exception:
    table = {}
table[str(mid)] = {"x": x, "y": y, "note": NOTE or table.get(str(mid), {}).get("note", "")}
os.makedirs(os.path.dirname(OUT), exist_ok=True)
json.dump(table, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print(f"💾 Đã lưu {OUT}[{mid}] = (x={x}, y={y}) note={NOTE!r}")
print(f"   → Tổng {len(table)} thôn: {[(k, v.get('note'), (v.get('x'), v.get('y'))) for k, v in table.items()]}")
