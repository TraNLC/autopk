# -*- coding: utf-8 -*-
"""listen_lequan.py — LISTENER bắt npcId Lễ Quan khi user CLICK TAY ở từng thành. Log REALTIME + lưu ngay.

Cách dùng: TẮT ui_bot_app.py trước (Frida attach 1 lần). Chạy script này → nó đứng nghe.
Bạn DI CHUYỂN char tới từng thành → CLICK vào NPC Lễ Quan. Mỗi cú click, script in:
   🏛️ [thành <tên> map <id>] click npcId=<X> → dialog: '<text>'  (✅ NGHI LỄ QUAN / npc khác?)
và LƯU vào data/output/lequan_town_npc.json (mapId -> npcId).

Xem realtime: tail -f data/output/lequan_live.log   (hoặc nhìn ngay console này)
  venv/bin/python listen_lequan.py [--device 127.0.0.1:26624]
Dừng: Ctrl-C.
"""
import sys, time, json, os
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

DEV = "127.0.0.1:26624"
a = sys.argv
if "--device" in a:
    DEV = a[a.index("--device") + 1]

LIVE_PATH = "data/output/lequan_live.log"
OUT_PATH = "data/output/lequan_town_npc.json"
_LIVE = open(LIVE_PATH, "w", encoding="utf-8")
def log(m):
    print(m, flush=True)
    try: _LIVE.write(m + "\n"); _LIVE.flush()
    except Exception: pass

TOWN = {1: "Phượng Tường", 11: "Thành Đô", 37: "Biện Kinh", 78: "Tương Dương",
        80: "Dương Châu", 162: "Đại Lý", 176: "Lâm An", 53: "Ba Lăng Huyện"}
# tra tên map từ maplist (cho map lạ)
try:
    _ML = {str(m["id"]): m.get("name") for m in json.load(open("data/output/json/maplist.json", encoding="utf-8"))}
except Exception:
    _ML = {}
def town_name(mid):
    return TOWN.get(mid) or _ML.get(str(mid)) or f"map {mid}"

# Lễ Quan = NPC chức quan/lễ phẩm/Tống Kim → keyword nhận diện (chỉ GỢI Ý, vẫn lưu mọi click).
LQ_KW = ("lễ quan", "lễ phẩm", "chức quan", "hoạt động", "tống kim", "tích lũy", "tích luỹ",
         "tân thủ", "luyện công", "vinh dự", "vinh hàm", "huân chương")

def decode_select_index(hexstr):
    """eNpcSelect(op35) body: 0x08 <varint selectIndex>. Trả index hoặc None."""
    try:
        b = bytes.fromhex(hexstr)[6:]
        if b and b[0] == 0x08:
            val = 0; shift = 0; i = 1
            while i < len(b):
                c = b[i]; i += 1
                val |= (c & 0x7f) << shift
                if not (c & 0x80): break
                shift += 7
            return val
    except Exception:
        pass
    return None

def load_out():
    try: return json.load(open(OUT_PATH, encoding="utf-8"))
    except Exception: return {}
def save_out(d):
    try: json.dump(d, open(OUT_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    except Exception as e: log(f"  ⚠️ lưu lỗi: {e}")

bot = VLTK1Bot(device_id=DEV)
if not bot.connect():
    log("connect fail"); sys.exit(1)
bot.capture_sent = True   # BẮT BUỘC: nếu không sent_buffer rỗng -> không bắt được op35/option chọn

log("=" * 60)
log("👂 LISTENER LỄ QUAN đang nghe. Di chuyển char tới từng thành rồi CLICK Lễ Quan.")
log("   Mỗi click sẽ log ở đây + lưu vào " + OUT_PATH)
log("   Dừng: Ctrl-C.")
log("=" * 60)

out = load_out()
last_t = bot.last_npc_dialogue_t
seen_recent = {}     # npcId -> ts (chống log trùng 1 click nhiều lần)
cur_npc = None       # npc đang mở dialog (để gắn option chọn vào đúng npc/thành)
cur_mid = None
sent_seen = len(getattr(bot, "sent_buffer", []) or [])   # mốc sent_buffer -> bắt op35 MỚI

try:
    while True:
        # incoming op34 (menu) — parse FULL option theo thứ tự (index)
        menu_opts = None
        for p in (bot.poll_recv() or []):
            if p.get("opcode") in (34, 124):
                opts = bot.parse_npc_menu(p.get("hex", ""))
                if opts and len(opts) >= 1:
                    menu_opts = opts
        # phát hiện CLICK NPC tay MỚI (op33)
        if bot.last_npc_dialogue_t != last_t and bot.last_npc_dialogue_id:
            last_t = bot.last_npc_dialogue_t
            nid = bot.last_npc_dialogue_id
            time.sleep(0.6)
            for p in (bot.poll_recv() or []):
                if p.get("opcode") in (34, 124):
                    opts = bot.parse_npc_menu(p.get("hex", ""))
                    if opts: menu_opts = opts
            try: mid = (bot.rpc.get_player_info() or {}).get("mapId")
            except Exception: mid = None
            cur_npc, cur_mid = nid, mid
            if not (seen_recent.get(nid, 0) and (time.time() - seen_recent[nid]) < 3):
                seen_recent[nid] = time.time()
                question = menu_opts[0] if menu_opts else ""
                is_lq = any(k in (question + " " + " ".join(menu_opts or [])).lower() for k in LQ_KW)
                flag = "✅ NGHI LÀ LỄ QUAN" if is_lq else "❓ (npc khác? kiểm text)"
                log(f"\n🏛️ [{town_name(mid)} | map {mid}] click npcId={nid}  {flag}")
                if menu_opts:
                    log(f"     ❓ câu hỏi: {question!r}")
                    log(f"     📋 MENU (option ⇄ index eNpcSelect):")
                    # opts[0]=câu hỏi -> các lựa chọn từ opts[1], index eNpcSelect thường 0-based theo thứ tự lựa chọn
                    for i, o in enumerate(menu_opts[1:]):
                        log(f"         [{i}] {o}")
                # LƯU npc + menu. GUARD: nếu đã có record Lễ Quan ở map này mà click mới KHÔNG phải Lễ Quan
                # (vd lỡ click Xa Phu) -> KHÔNG ghi đè (giữ Lễ Quan).
                rec = out.get(str(mid), {})
                if rec.get("is_lequan_guess") and not is_lq:
                    log(f"     ⏭️ (npc {nid} không phải Lễ Quan — giữ record Lễ Quan {rec.get('npcId')} cũ, không ghi đè)")
                else:
                    rec.update({"npcId": str(nid), "town": town_name(mid),
                                "question": question, "menu": menu_opts[1:] if menu_opts else [],
                                "is_lequan_guess": is_lq, "actions": rec.get("actions", {})})
                    out[str(mid)] = rec
                    save_out(out)
                    log(f"     💾 đã lưu {OUT_PATH}[{mid}] = npc {nid} (+menu)")
        # bắt MỌI gói gửi bạn bấm sau khi mở dialog (op35 eNpcSelect / 167 context / 245 award...) -> ghi lại
        sb = getattr(bot, "sent_buffer", []) or []
        if len(sb) > sent_seen:
            for p in sb[sent_seen:]:
                op = p.get("opcode")
                if op in (35, 167, 245) and cur_mid is not None:   # các op chọn-trong-dialog
                    idx = decode_select_index(p.get("hex", ""))
                    rec = out.get(str(cur_mid), {})
                    menu = rec.get("menu", [])
                    oname = menu[idx] if (idx is not None and 0 <= idx < len(menu)) else "(sub-menu/?)"
                    log(f"     ➡️  GỬI {p.get('name') or op}(idx={idx}) → {oname!r}  (npc {cur_npc} @ {town_name(cur_mid)})")
                    acts = rec.get("actions", {})
                    acts[str(idx)] = {"name": oname, "opcode": op, "hex": p.get("hex")}
                    rec["actions"] = acts
                    out[str(cur_mid)] = rec
                    save_out(out)
            sent_seen = len(sb)
        time.sleep(0.25)
except KeyboardInterrupt:
    log("\n=== DỪNG listener. Đã lưu: " + ", ".join(f"{v.get('town')}→{v.get('npcId')}" for v in out.values()))
