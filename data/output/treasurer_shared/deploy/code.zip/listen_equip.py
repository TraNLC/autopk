# -*- coding: utf-8 -*-
"""listen_equip.py — BẮT gói gửi đi khi user DOUBLE-TAP mặc vũ khí trong túi (để biết equip dùng opcode/payload gì).

TẮT ui_bot_app/luyencong_tool trước. Chạy script → vào game, mở túi → DOUBLE-TAP vũ khí để mặc.
Mỗi gói gửi đi sẽ log (opcode/name/hex). Tìm gói xuất hiện ĐÚNG LÚC mặc.
  venv/bin/python listen_equip.py [--device 127.0.0.1:26624]
Dừng: Ctrl-C.
"""
import sys, time
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

DEV = "127.0.0.1:26624"
a = sys.argv
if "--device" in a:
    DEV = a[a.index("--device") + 1]

bot = VLTK1Bot(device_id=DEV)
if not bot.connect():          # FULL connect (dò fd) -> hook gửi gói trong-world mới bắt được
    print("connect fail"); sys.exit(1)
try:
    bot.redetect_fd_by_traffic()
except Exception:
    pass
bot.capture_sent = True

print("=" * 60, flush=True)
print("👂 LISTENER MẶC VŨ KHÍ. Mở túi → DOUBLE-TAP vũ khí để mặc.", flush=True)
print("   Mỗi gói gửi đi sẽ log. Dừng: Ctrl-C.", flush=True)
print("=" * 60, flush=True)

# bỏ qua gói nhiễu thường gặp (di chuyển/skill/chat) để dễ thấy gói equip
NOISE = {9, 23, 48, 132, 133, 140, 56, 68, 83, 87, 90, 94, 116, 120, 248}
seen = len(getattr(bot, "sent_buffer", []) or [])
try:
    while True:
        sb = getattr(bot, "sent_buffer", []) or []
        if len(sb) > seen:
            for p in sb[seen:]:
                op = p.get("opcode")
                tag = "  ⭐" if op not in NOISE else ""
                print(f"📤 op{op} {p.get('name') or ''} | hex={p.get('hex')}{tag}", flush=True)
            seen = len(sb)
        time.sleep(0.2)
except KeyboardInterrupt:
    print("\n=== DỪNG listener mặc vũ khí. ===", flush=True)
