# -*- coding: utf-8 -*-
"""test_qua_fields.py — SOI memory object Quả Huy Hoàng để tìm field 'đã chín / timer / state'.
Mục tiêu: biết quả chín mà KHÔNG cần click-thử (để chỉ click ĐÚNG 1 LẦN lúc chín).

Dump cho quả id>=10000:
  - getNearNpcsDetail: name/level/hp/hpMax/npcKind/npcType/series (đọc qua data/identify).
  - getNearObjects: id/name/cls + DANH SÁCH TÊN FIELD của class object (diag.fields) -> soi field lạ (timer/state).

Dùng: (TẮT UI)  venv/bin/python -u test_qua_fields.py [device]
"""
import sys, time, json
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

DEV = next((x for x in sys.argv[1:] if (":" in x or x.startswith("emulator"))), "127.0.0.1:26624")
QUA_MIN_ID = 10000


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect():
        print("connect FAIL (UI còn attach? tắt rồi chạy lại)"); return
    for _ in range(5):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.3)
    try: bot.redetect_fd_by_traffic()
    except Exception: pass
    try: print(f"recvAny={bot.rpc.ping().get('recvAny')}")
    except Exception as e: print(f"ping: {e}")

    print("\n===== getNearNpcsDetail (lọc id>=10000) =====")
    try:
        r = bot.rpc.get_near_npcs_detail() or {}
        npcs = r.get("npcs") or []
        hi = [n for n in npcs if str(n.get("id")).isdigit() and int(n.get("id")) >= QUA_MIN_ID]
        print(f"tổng {len(npcs)} npc, {len(hi)} quả(id>=10000). diag={r.get('diag')}")
        for n in hi[:6]:
            print("  " + json.dumps(n, ensure_ascii=False))
    except Exception as e:
        print(f"detail lỗi: {e}")

    print("\n===== getNearObjects (id/name/cls + diag.fields) =====")
    try:
        r = bot.rpc.get_near_objects() or {}
        objs = r.get("objs") or []
        print(f"tổng {len(objs)} object. diag.nodes={(r.get('diag') or {}).get('nodes')} errors={(r.get('diag') or {}).get('errors')}")
        print(f"  >>> FIELD của class object value: {(r.get('diag') or {}).get('fields')}")
        hi = [o for o in objs if str(o.get("id")).isdigit() and int(o.get("id")) >= QUA_MIN_ID]
        print(f"  {len(hi)} object id>=10000:")
        for o in hi[:8]:
            print("    " + json.dumps(o, ensure_ascii=False))
        # in vài object thường để so sánh cls
        print("  vài object id<10000 (so sánh cls):")
        for o in [o for o in objs if str(o.get('id')).isdigit() and int(o.get('id')) < QUA_MIN_ID][:4]:
            print("    " + json.dumps(o, ensure_ascii=False))
    except Exception as e:
        print(f"objects lỗi: {e}")


if __name__ == "__main__":
    main()
