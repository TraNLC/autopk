# -*- coding: utf-8 -*-
"""listen_createchar.py — BẮT luồng TẠO NHÂN VẬT (+ ra thành/auto/trainoff) khi user làm TAY 1 lần.

Mục tiêu: lấy gói opcode 5 UnityCreateCharacterRequest {data(tạo hình), factionId(phái), name, sex} để
REPLAY tạo char hàng loạt (chỉ đổi name). Đồng thời log mọi gói gửi (Xa Phu op33/35, autoplay 140,
trainoff 136/138, chọn server/role) để dựng cả dây chuyền.

Cách dùng: TẮT ui_bot_app.py. Chạy script. Trên giả lập: login 1 acc MỚI → tạo nhân vật bằng tay
(chọn phái/giới/tạo hình + nhập tên) → vào game → (tuỳ chọn) ra thành bằng Xa Phu + bật auto + trainoff.
Mỗi gói sẽ log + gói op5 được LƯU template vào data/output/createchar_template.json.
  venv/bin/python listen_createchar.py [--device 127.0.0.1:26624]
Dừng: Ctrl-C.
"""
import sys, time, json
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

DEV = "127.0.0.1:26624"
a = sys.argv
if "--device" in a:
    DEV = a[a.index("--device") + 1]

LIVE = open("data/output/createchar_live.log", "w", encoding="utf-8")
def log(m):
    print(m, flush=True)
    try: LIVE.write(m + "\n"); LIVE.flush()
    except Exception: pass

# opcode đáng chú ý trong dây chuyền (để log nổi bật)
KEY = {5: "UnityCreateCharacterRequest (TẠO CHAR)", 1: "select server?", 3: "select role?",
       33: "eNpcDialogue (Xa Phu/NPC)", 35: "eNpcSelect (chọn menu)",
       140: "eApplyAutoplayProfile (bật auto)", 136: "eTrainoffCheckRequet",
       138: "eTrainoffStart (treo offline)", 248: "eGotoPosition (di chuyển)"}

def decode_create(hexstr):
    """Giải gói op5 -> {data, factionId, name, sex}."""
    try:
        from features.bot.shop_parser import _decode_protobuf
        fb = _decode_protobuf(bytes.fromhex(hexstr)[6:])
        def s(x): return x.decode("utf-8", "ignore") if isinstance(x, (bytes, bytearray)) else x
        return {"data": s(fb.get(1)), "factionId": fb.get(2), "name": s(fb.get(3)), "sex": fb.get(4)}
    except Exception as e:
        return {"_decode_err": str(e)}

bot = VLTK1Bot(device_id=DEV)
if not bot.connect():
    log("connect fail"); sys.exit(1)
bot.capture_sent = True

log("=" * 64)
log("👂 LISTENER TẠO CHAR. Trên giả lập: login acc MỚI → tạo nhân vật tay → vào game →")
log("   (tuỳ chọn) Xa Phu ra bãi train + bật auto + trainoff. Tôi bắt hết.")
log("   Gói op5 (tạo char) sẽ LƯU template. Dừng: Ctrl-C.")
log("=" * 64)

sent_seen = len(getattr(bot, "sent_buffer", []) or [])
try:
    while True:
        sb = getattr(bot, "sent_buffer", []) or []
        if len(sb) > sent_seen:
            for p in sb[sent_seen:]:
                op = p.get("opcode")
                nm = p.get("name") or ""
                hexs = p.get("hex", "")
                if op in KEY:
                    log(f"\n📤 op{op} {KEY[op]}  | hex={hexs}")
                    if op == 5:
                        info = decode_create(hexs)
                        log(f"   🎯 TẠO CHAR: factionId={info.get('factionId')} sex={info.get('sex')} "
                            f"name={info.get('name')!r}")
                        log(f"      data(tạo hình)={str(info.get('data'))[:80]!r}…")
                        try:
                            json.dump(info, open("data/output/createchar_template.json", "w", encoding="utf-8"),
                                      ensure_ascii=False, indent=2)
                            log("   💾 Đã lưu data/output/createchar_template.json (replay đổi name là tạo được).")
                        except Exception as e:
                            log(f"   ⚠️ lưu lỗi: {e}")
                else:
                    # gói khác: log gọn (chỉ opcode) để thấy thứ tự, không spam hex
                    log(f"   · op{op} {nm}")
            sent_seen = len(sb)
        time.sleep(0.25)
except KeyboardInterrupt:
    log("\n=== DỪNG listener tạo char. ===")
