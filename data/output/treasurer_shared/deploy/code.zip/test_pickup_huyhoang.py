# -*- coding: utf-8 -*-
"""test_pickup_huyhoang.py — Probe TEST remote nhặt "Quả Huy Hoàng" (hoặc bất kỳ đồ dưới đất).

Ý tưởng (đã RE): server báo đồ rơi dưới đất qua gói op54 `eAddMapObject`
  {objectId, dataId, mapId, mapX, mapY, name, ...}. Nhặt = op56 `eObjectPickup{objectId}`.
Giới hạn: op54 CHỈ bắn cho đồ trong AOI (gần nhân vật) -> "remote" = nhặt KHÔNG cần đi nốt
mấy bước tới đè lên, chứ KHÔNG phải nhặt khắp map. Test này KHÔNG di chuyển nhân vật.

CÁCH DÙNG:
  1. TẮT hẳn UI Auto (Frida chỉ attach 1 lần).
  2. Mở game, đứng gần (cùng màn) chỗ có "Quả Huy Hoàng" rơi dưới đất.
  3. venv/bin/python test_pickup_huyhoang.py            # tự tìm tên chứa "huy hoàng"
     venv/bin/python test_pickup_huyhoang.py "tên khác"  # lọc theo tên khác
     venv/bin/python test_pickup_huyhoang.py --id <objectId>  # nhặt thẳng objectId
  4. Copy toàn bộ output gửi lại.
"""
import sys
import time
import subprocess
import platform
import unicodedata

sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot
from core.adb_helper import ADB_PATH
from proto.vltk1_protocol import decode_message_fields

PACKAGE = "vn.perfingame.jx1mobile"


def detect_device():
    if platform.system() == "Darwin":
        for p in [26624, 26656, 26688, 16384, 22471, 5555]:
            subprocess.run(f"{ADB_PATH} connect 127.0.0.1:{p}", shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3)
    try:
        out = subprocess.check_output(f"{ADB_PATH} devices", shell=True).decode().strip().split("\n")
    except Exception as e:
        print(f"[-] adb devices lỗi: {e}")
        return None
    for line in out[1:]:
        if "device" in line and "offline" not in line:
            dev = line.split("\t")[0]
            if dev.startswith("emulator-"):
                continue
            try:
                pid = subprocess.check_output(f"{ADB_PATH} -s {dev} shell pidof {PACKAGE}",
                                              shell=True, stderr=subprocess.DEVNULL).decode().strip()
                if pid:
                    return dev
            except Exception:
                pass
    return None


def _norm(s):
    """bỏ dấu + lowercase để so tên không phụ thuộc dấu."""
    s = unicodedata.normalize("NFD", s or "")
    return "".join(c for c in s if unicodedata.category(c) != "Mn").lower()


def scan_ground(bot, seconds=6):
    """Quét recv_buffer gom MỌI op54 (đồ dưới đất) trong `seconds`. Trả dict objectId -> info."""
    found = {}
    t0 = time.time()
    while time.time() - t0 < seconds:
        try:
            bot.poll_recv()
        except Exception:
            pass
        for p in list(getattr(bot, "recv_buffer", []) or []):
            if p.get("opcode") != 54:
                continue
            try:
                body = bytes.fromhex(p.get("hex", ""))[6:]
                f = decode_message_fields("AddMapObject", body) or {}
                oid = f.get("objectId") or f.get(1)
                if not oid:
                    continue
                found[str(oid)] = {
                    "objectId": str(oid),
                    "dataId": f.get("dataId") or f.get(2),
                    "mapId": f.get("mapId") or f.get(3),
                    "x": f.get("mapX") or f.get(4),
                    "y": f.get("mapY") or f.get(5),
                    "name": f.get("name") or f.get(7) or "",
                    "type": f.get("type") or f.get(9),
                }
            except Exception:
                pass
        time.sleep(0.3)
    return found


def bag_count(bot):
    try:
        d = bot.dump_bag_items() or {}
        items = [it for it in d.get("items", []) if it.get("location") == 2]
        return len(items), {it.get("index"): (it.get("particular"), it.get("stack")) for it in items}
    except Exception:
        return -1, {}


def main():
    args = sys.argv[1:]
    force_id = None
    name_filter = "huy hoang"
    if "--id" in args:
        i = args.index("--id")
        force_id = args[i + 1] if i + 1 < len(args) else None
    elif args:
        name_filter = _norm(args[0])

    dev = detect_device()
    if not dev:
        print("[-] Không thấy giả lập nào đang chạy game. Mở game trước.")
        return
    print(f"[*] Device: {dev}")
    bot = VLTK1Bot(device_id=dev)
    if not bot.connect():
        print("[-] connect() FAIL — kiểm tra Frida/Root/ABI.")
        return

    try:
        ping = bot.rpc.ping()
        print(f"[*] recvAny={ping.get('recvAny')} (phải >0 thì mới bắt được gói op54).")
    except Exception:
        pass

    if force_id:
        target = {"objectId": force_id, "name": "(--id)"}
        print(f"[*] Nhặt thẳng objectId={force_id}")
    else:
        print(f"[*] Quét đồ dưới đất (op54) ~6s, tìm tên chứa: {name_filter!r} ...")
        ground = scan_ground(bot, seconds=6)
        if not ground:
            print("[-] KHÔNG bắt được op54 nào. Đồ có thể đã rơi TRƯỚC khi probe chạy, hoặc nhân vật quá xa "
                  "(ngoài AOI). Thử: đứng sát hơn / để đồ rơi MỚI trong lúc probe chạy / di chuyển nhẹ.")
            return
        print(f"\n=== {len(ground)} đồ dưới đất bắt được ===")
        for o in ground.values():
            print(f"  objId={o['objectId']}  name={o['name']!r}  dataId={o['dataId']}  "
                  f"map={o['mapId']} ({o['x']},{o['y']}) type={o['type']}")
        cand = [o for o in ground.values() if name_filter in _norm(o["name"])]
        if not cand:
            print(f"\n[-] Không thấy đồ nào tên chứa {name_filter!r}. "
                  f"Chạy lại với tên khác hoặc --id <objectId> ở trên.")
            return
        target = cand[0]
        print(f"\n[*] CHỌN: objId={target['objectId']} name={target['name']!r}")

    n_before, sig_before = bag_count(bot)
    print(f"[*] Túi TRƯỚC: {n_before} ô.")
    print(f"[*] >>> Gửi eObjectPickup(objectId={target['objectId']}) — KHÔNG di chuyển nhân vật.")
    bot.pickup(str(target["objectId"]))

    # chờ + đọc lại túi
    for _ in range(8):
        time.sleep(0.5)
        try:
            bot.poll_recv()
        except Exception:
            pass
    n_after, sig_after = bag_count(bot)
    print(f"[*] Túi SAU: {n_after} ô.")

    if n_after > n_before:
        print("\n✅ NHẶT ĐƯỢC TỪ XA — túi tăng ô (remote pickup OK, server KHÔNG chặn khoảng cách).")
    elif sig_after != sig_before:
        print("\n✅ Túi CÓ THAY ĐỔI (có thể gộp stack) — khả năng nhặt được. Kiểm tra trong game.")
    else:
        print("\n❌ Túi KHÔNG đổi — có thể server CHẶN khoảng cách (phải tới gần), hoặc objectId hết hạn, "
              "hoặc cần đứng sát hơn. Xem có gói server phản hồi nào ở recv không (chạy lại + đứng sát test).")


if __name__ == "__main__":
    main()
