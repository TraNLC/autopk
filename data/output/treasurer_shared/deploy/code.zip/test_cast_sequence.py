# -*- coding: utf-8 -*-
"""test_cast_sequence.py — ĐIỀU TRA "khoá mục tiêu": BẮT TRỌN chuỗi gói OUT theo THỨ TỰ khi đánh CHIÊU TAY.

Mục tiêu: chiêu caster (vd Thiên Ngoại Lưu Tinh) ra chiêu + tốn mana NHƯNG 0 dame khi replay op239.
Nghi: client khoá mục tiêu bằng gói KHÁC (op40 eCastSkill có launchType/targetType/targetId, hoặc 1 gói
select-target) mà replay đang thiếu. Script GHI MỌI gói OUT theo thứ tự + giải mã field op40/238/239/240/262
→ thấy ĐÚNG client gửi gì để khoá target.

Cách dùng: TẮT UI cửa sổ acc Thiên Nhẫn → venv/bin/python -u test_cast_sequence.py [device] [secs]
  Trong lúc chạy: ĐỨNG CẠNH 1 con quái, đánh CHIÊU (caster) vào nó bằng tay vài lần. Script đọc HP% con
  trước/sau để biết cú tay CÓ dame (capture sạch), rồi in chuỗi gói để soi gói khoá-target.
"""
import sys, time, os
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

_a = sys.argv[1:]
DEV = next((x for x in _a if (":" in x or x.startswith("emulator"))), "127.0.0.1:26624")
SECS = next((int(x) for x in _a if x.isdigit() and int(x) > 5), 30)
LOG = "data/output/test_cast_sequence.log"
os.makedirs("data/output", exist_ok=True)
_lf = open(LOG, "w", encoding="utf-8")
def emit(s): print(s, flush=True); _lf.write(s + "\n"); _lf.flush()

# field name cho các gói skill (từ proto/vltk1_protocol.py) — để đọc hiểu ngay
FIELDS = {
    40:  {1: "launchType", 2: "launchId", 3: "targetType", 4: "targetId", 5: "tgtPosX", 6: "tgtPosY", 7: "skillId", 8: "skillLevel", 9: "isNoAction"},
    238: {1: "skillid", 2: "cid(player)"},
    239: {1: "skillid", 2: "nid(npc)"},
    240: {1: "skillid", 2: "posX", 3: "posY"},
    262: {1: "f1", 2: "f2", 3: "f3"},
}
SKILL_OPS = (40, 238, 239, 240, 262)


def decode(body):
    """protobuf top-level -> {fno: int | bytes}."""
    out = {}; i = 0
    while i < len(body):
        tag = body[i]; i += 1; fno = tag >> 3; wt = tag & 7
        if wt == 0:
            v = 0; sh = 0
            while i < len(body):
                b = body[i]; i += 1; v |= (b & 0x7F) << sh; sh += 7
                if not b & 0x80: break
            out[fno] = v
        elif wt == 2:
            if i >= len(body): break
            ln = body[i]; i += 1; out[fno] = body[i:i+ln]; i += ln
        elif wt == 5: i += 4
        elif wt == 1: i += 8
        else: break
    return out


def fmt(op, d):
    """Giải mã field theo tên; bytes -> thử utf-8 + hex."""
    names = FIELDS.get(op, {})
    parts = []
    for k in sorted(d):
        nm = names.get(k, f"f{k}")
        v = d[k]
        if isinstance(v, (bytes, bytearray)):
            try: s = bytes(v).decode("utf-8", "ignore")
            except Exception: s = ""
            shown = repr(s) if s and all(32 <= ord(c) < 127 or ord(c) > 127 for c in s) else bytes(v).hex()
            parts.append(f"{nm}={shown}")
        else:
            parts.append(f"{nm}={v}")
    return ", ".join(parts)


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect():
        emit("connect FAIL (UI bot còn attach? tắt rồi chạy lại)"); return
    bot.capture_sent = True
    for _ in range(6):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.3)
    try: bot.redetect_fd_by_traffic()
    except Exception as e: emit(f"redetect: {e}")
    # KHÔNG bật captureAllSends: nó đọc cả socket khác → rác op0/op-1 (7916 gói) + dễ segfault. gameFd (vd 5)
    # recv & send DÙNG CHUNG → đã bắt được op239 plaintext. Nếu lần này 0 gói skill → mới cân nhắc bật lại.
    try:
        p = bot.rpc.ping(); emit(f"gameFd={p.get('gameFd')} recvAny={p.get('recvAny')}")
    except Exception as e: emit(f"ping: {e}")
    try:
        pi = bot.rpc.get_player_info() or {}
        emit(f"CHAR = {pi.get('name')!r}  (xác nhận đúng acc Thiên Nhẫn 'Láo Là Bem'?)")
    except Exception as e: emit(f"get_player_info: {e}")

    def mobs():
        try: r = bot.rpc.get_near_npcs_detail() or {}
        except Exception: return {}
        return {str(n.get("id")): {"name": n.get("name") or "?", "hp": n.get("hp")} for n in (r.get("npcs") or []) if (n.get("hpMax", 0) or 0) > 0}

    before = mobs()
    emit(f"\n[*] BẮT chuỗi gói OUT {SECS}s | {DEV}. ĐÁNH CHIÊU caster vào 1 con quái cạnh bạn bằng TAY vài lần.")
    emit(f"   Quái quanh (HP% trước): " + ", ".join(f"{v['name']}#{k}={v['hp']}" for k, v in before.items()) + "\n")

    bot.sent_buffer = []
    t0 = time.time()
    seq = []                       # (t, op, fields) — CHỈ gói skill, theo thứ tự
    others = {}                    # opcode khác -> đếm
    last_print = 0.0
    while time.time() - t0 < SECS:
        try: bot.poll_recv()
        except: pass
        for pp in list(getattr(bot, "sent_buffer", [])):
            op = pp.get("opcode")
            try: d = decode(bytes.fromhex(pp.get("hex", ""))[6:])
            except Exception: d = {}
            if op in SKILL_OPS:
                nm = {40: 'eCastSkill', 238: 'DoSkillTgtPlayer', 239: 'DoSkillTgtNpc', 240: 'DoSkillTgtPos', 262: 'eTargetToPlayerSpecial'}.get(op, '')
                seq.append((time.time() - t0, op, fmt(op, d)))
                emit(f"  t+{seq[-1][0]:.2f}s  →OUT op{op} ({nm})  {seq[-1][2]}  | RAWHEX={pp.get('hex','')}")
            else:
                others[op] = others.get(op, 0) + 1
        bot.sent_buffer = []
        time.sleep(0.04)

    after = mobs()
    emit("\n=== TÓM TẮT ===")
    emit(f"Tổng gói skill bắt được: {len(seq)} (op gặp: {sorted(set(op for _,op,_ in seq))})")
    emit(f"Opcode OUT KHÁC (đếm): {dict(sorted(others.items()))}")
    emit("\nHP% quái trước→sau (xem cú TAY có dame = capture sạch):")
    for k, v in before.items():
        ha = after.get(k, {}).get("hp")
        drop = (v["hp"] is not None and ha is not None and ha < v["hp"])
        emit(f"   {v['name']}#{k}: {v['hp']} → {('mất' if k not in after else ha)}{'  💥' if drop else ''}")
    emit("\n→ Soi: nếu có op40 eCastSkill (targetType/targetId) HOẶC 1 gói lạ TRƯỚC op239 = gói KHOÁ MỤC TIÊU đang thiếu.")
    emit(f"Log: {LOG}")


if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: emit("\n[*] Dừng.")
    finally: _lf.close()
