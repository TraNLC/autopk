# -*- coding: utf-8 -*-
"""listen_skills.py — LISTENER LIÊN TỤC bắt gói GỬI (skill) — chạy nền, KHÔNG tự tắt.
Ghi mọi gói OUT không-ồn vào data/output/skill_listen.log + stdout. Ép gameFd=SEND fd (mặc định 120,
vì game tách recv/send fd) để bắt được skill (op239/240/40...). Ctrl+C / kill để dừng.

Dùng: venv/bin/python -u listen_skills.py [secs] [device] [sendfd]
"""
import sys, time, os
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

_a = sys.argv[1:]
SECS = next((int(x) for x in _a if x.isdigit() and int(x) > 200), 600)
DEV = next((x for x in _a if (":" in x or x.startswith("emulator"))), "127.0.0.1:26624")
SENDFD = next((int(x) for x in _a if x.isdigit() and int(x) <= 200), 120)
NOISE = {7, 8, 9, 16, 17, 18, 19, 20, 23, 63, 66, 69, 251, 70}
LOG = "data/output/skill_listen.log"
os.makedirs("data/output", exist_ok=True)
_lf = open(LOG, "w", encoding="utf-8")


def emit(s):
    print(s, flush=True); _lf.write(s + "\n"); _lf.flush()


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect():
        emit("connect FAIL"); return
    bot.capture_sent = True
    for _ in range(4):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.3)
    # ÉP gameFd = fd GỬI (game tách recv/send). KHÔNG redetect (redetect chọn theo recv -> mất fd gửi).
    try: bot.set_game_fd(SENDFD)
    except Exception as e: emit(f"set_game_fd lỗi: {e}")
    emit(f"[*] LISTEN skills {SECS}s | gameFd(ép)={SENDFD} | log={LOG}. CAST THOẢI MÁI.\n")
    t0 = time.time(); seen = 0; last_beat = 0
    while time.time() - t0 < SECS:
        try: bot.poll_recv()
        except: pass
        sb = list(getattr(bot, "sent_buffer", []))
        for p in sb[seen:]:
            op = p.get("opcode")
            if op in NOISE:
                continue
            hx = p.get("hex") or ""
            extra = ""
            # decode skillId cho op239/240 (field1 varint) + target
            if op in (239, 240):
                try:
                    body = bytes.fromhex(hx)[6:]
                    if body and body[0] == 0x08:
                        v = 0; sh = 0; i = 1
                        while i < len(body):
                            b = body[i]; i += 1; v |= (b & 0x7F) << sh; sh += 7
                            if not b & 0x80: break
                        extra = f"  skillId={v}"
                except Exception:
                    pass
            emit(f"  t+{round(time.time()-t0,1):>6}s op{op}: {hx[:120]}{extra}")
        seen = len(sb)
        if time.time() - last_beat > 20:
            last_beat = time.time()
            emit(f"  --- t+{int(time.time()-t0)}s: đã bắt {seen} gói OUT (đang nghe) ---")
        time.sleep(0.05)
    emit(f"\n[xong] {SECS}s. Tổng {seen} gói OUT. Log: {LOG}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        emit("\n[*] Dừng.")
    finally:
        _lf.close()
