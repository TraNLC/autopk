"""
scan_here.py — QUÉT SẠP TẠI CHỖ (đứng im, không di chuyển) → gom vào THƯ VIỆN CHUNG 2 máy.

Quy trình phối hợp (theo yêu cầu user):
  1. TẮT cửa sổ UI Auto của giả lập sẽ quét (Frida chỉ attach 1 lần/PID).
  2. Tự tay điều khiển nhân vật (radar) tới chỗ ĐÔNG SẠP nhất.
  3. Mỗi lần muốn quét:  venv/bin/python scan_here.py  [device]
     → script attach, đọc TẤT CẢ sạp trong tầm client đã load (phạm vi rộng nhất có thể tại chỗ),
       gộp vào stall_catalog.json + PUBLISH ra treasurer_shared/stall_catalog/<máy>.json (Syncthing → 2 máy),
       in: quét được bao nhiêu sạp + thêm bao nhiêu món mới vào thư viện.
  4. Đứng yên quét lại vài lần (sạp trả lời lai rai) hoặc đi chỗ khác rồi quét tiếp — đều cộng dồn.

KHÔNG di chuyển bằng code (user tự di chuyển tay để tránh lỗi pathing).
"""
import sys
import time
import subprocess
import platform

sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot
from core.adb_helper import ADB_PATH
from core.stall_shopper import (
    scan_stalls, load_catalog, save_catalog, publish_catalog,
    catalog_counts, CATALOG_PATH,
)

PACKAGE = "vn.perfingame.jx1mobile"
MAX_STALLS = 400   # mở rộng cap: gom HẾT sạp client đã load quanh chỗ đứng (đừng để 80 cắt bớt)


def detect_device():
    if platform.system() == "Darwin":
        for p in (26624, 26656, 26688, 26720, 26752, 26784, 16384, 22471, 5555):
            subprocess.run(f"{ADB_PATH} connect 127.0.0.1:{p}", shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3)
    try:
        out = subprocess.check_output(f"{ADB_PATH} devices", shell=True).decode().strip().split("\n")
    except Exception as e:
        print(f"[-] adb devices lỗi: {e}")
        return None
    for line in out[1:]:
        if "device" in line and "offline" not in line:
            dev = line.split("\t")[0]
            if dev.startswith("emulator-"):
                continue
            try:
                pid = subprocess.check_output(
                    f"{ADB_PATH} -s {dev} shell pidof {PACKAGE}", shell=True,
                    stderr=subprocess.DEVNULL).decode().strip()
                if pid:
                    return dev
            except Exception:
                pass
    return None


def main():
    dev = sys.argv[1] if len(sys.argv) > 1 else detect_device()
    if not dev:
        print("[-] Không thấy giả lập nào đang chạy game. Mở game + TẮT UI Auto cửa sổ đó trước.")
        return
    print(f"[*] Device: {dev}  — đang attach Frida…")
    bot = VLTK1Bot(device_id=dev)
    if not bot.connect():
        print("[-] Không attach được Frida (đang chạy UI Auto cửa sổ này? game chưa vào nhân vật?).")
        return
    # Khởi động fd theo traffic (giống luồng quét trong UI) — để gửi/nhận packet ổn định.
    for _ in range(6):
        try: bot.poll_recv()
        except Exception: pass
        time.sleep(0.3)
    try: bot.redetect_fd_by_traffic()
    except Exception: pass

    # ĐẾM thư viện TRƯỚC khi quét (để báo "thêm bao nhiêu MỚI").
    before_items, before_stalls = catalog_counts(load_catalog())

    # QUÉT NHIỀU LƯỢT TẠI CHỖ: 1 lượt server chỉ trả ~6/45 sạp (đồ về lai rai). Lặp tới khi 2 lượt liên tiếp
    # KHÔNG thêm sạp mới (hoặc tối đa MAX_PASS) → vét gần hết sạp trong tầm. Không di chuyển, không đụng lõi.
    MAX_PASS = 8
    session = {}            # gom catalog của CẢ phiên quét này (mọi lượt)
    dry = 0
    for _p in range(MAX_PASS):
        scanned = scan_stalls(bot, max_players=MAX_STALLS, merge=False, log=print) or {}
        new = sum(1 for cid in scanned if cid not in session)
        session.update(scanned)
        print(f"  → lượt {_p+1}: {len(scanned)} sạp trả lời, +{new} sạp mới (phiên: {len(session)} sạp).")
        if new == 0:
            dry += 1
            if dry >= 2:
                break       # 2 lượt liền không thêm sạp → coi như đã vét hết tầm
        else:
            dry = 0
        time.sleep(0.8)
    si, ss = catalog_counts(session)

    # GỘP vào thư viện local + PUBLISH ra shared (2 máy dùng chung).
    lib = load_catalog()
    lib.update(session)
    save_catalog(lib)
    publish_catalog()
    after_items, after_stalls = catalog_counts(lib)

    print("\n========== KẾT QUẢ QUÉT ==========")
    print(f"📡 Phiên này ({_p+1} lượt): {ss} sạp có hàng, {si} món.")
    print(f"📚 Thư viện chung: +{after_stalls - before_stalls} sạp mới / +{after_items - before_items} món mới "
          f"→ tổng {after_stalls} sạp / {after_items} món (đã publish cho 2 máy, đã lọc KNB).")
    print("==================================")
    try: bot.close()
    except Exception: pass


if __name__ == "__main__":
    main()
