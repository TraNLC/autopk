# -*- coding: utf-8 -*-
"""brute_datau_node.py — "Call mù" tìm node Dã Tẩu của VÙNG chưa biết: đứng trong 1 động vùng đó, gửi
eNpcDialogue(id) cho id trong range, DỪNG khi 1 id trả về DIALOG DÃ TẨU (text 'thiếu hiệp'+'nhiệm vụ').

Tìm được → lưu vào datau_town_nodes.json (scan list) + datau_nodes.json[mapId] → re-run learner học cả vùng.
Chạy: venv/bin/python brute_datau_node.py [--lo 1 --hi 4200]
"""
import sys, time, json, os
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

DEV = "127.0.0.1:26624"
LO, HI = 1, 4200
a = sys.argv
if "--lo" in a: LO = int(a[a.index("--lo")+1])
if "--hi" in a: HI = int(a[a.index("--hi")+1])
LIVE = open("data/output/brute_datau_live.log", "w", encoding="utf-8")
def log(m):
    print(m, flush=True)
    try: LIVE.write(m+"\n"); LIVE.flush()
    except Exception: pass

bot = VLTK1Bot(device_id=DEV)
if not bot.connect(): log("connect fail"); sys.exit()
mid = (bot.rpc.get_player_info() or {}).get('mapId')
log(f"[*] Brute node Dã Tẩu tại map {mid}, range {LO}-{HI} …")

KNOWN = set()  # bỏ qua node đã biết (đã scan trượt rồi)
try: KNOWN = set(json.load(open('data/output/datau_nodes.json')).values()) | {"714","716","396","8746","3447"}
except Exception: pass

def is_datau(txt):
    t = txt.lower()
    return ("dã tẩu" in t) or ("thiếu hiệp" in t and ("nhiệm vụ" in t or "hoàn thành" in t))

found = None
t0 = time.time()
for npc in range(LO, HI+1):
    if str(npc) in KNOWN:
        continue
    bot.recv_buffer = []; bot.poll_recv(); bot.recv_buffer = []
    bot.talk_npc(str(npc))
    hit = False
    e0 = time.time()
    while time.time() - e0 < 0.3:
        for p in (bot.poll_recv() or []):
            op = p.get('opcode')
            if op in (34, 124, 245):
                try:
                    txt = bytes.fromhex(p.get('hex', ''))[6:].decode('utf-8', 'ignore')
                except Exception:
                    txt = ""
                snip = ''.join(c for c in txt if c.isprintable())[:55]
                # op124 (quest info) / op245 (award) = DIALOG DÃ TẨU (NPC quest); op34 = chào thường → cần keyword.
                if op in (124, 245) or is_datau(txt):
                    found = npc
                    log(f"🎯 TÌM THẤY node Dã Tẩu = {npc} (op{op}) tại map {mid}! text={snip!r}")
                    hit = True; break
                elif op == 34 and snip:
                    log(f"   · id {npc} mở dialog op34: {snip!r}")   # ứng viên (npc thường) — để soi tay nếu cần
        if hit: break
    if hit: break
    if npc % 200 == 0:
        log(f"   … đã thử tới id {npc} ({round(time.time()-t0)}s)")

if found:
    # lưu: thêm vào scan list + map->node
    try:
        with open('data/output/datau_town_nodes.json', encoding='utf-8') as f: cfg = json.load(f)
        lst = [str(x) for x in (cfg.get('town_datau_nodes') or [])]
        if str(found) not in lst:
            lst.insert(0, str(found)); cfg['town_datau_nodes'] = lst
            json.dump(cfg, open('data/output/datau_town_nodes.json','w',encoding='utf-8'), ensure_ascii=False, indent=2)
        nodes = json.load(open('data/output/datau_nodes.json'))
        nodes[str(mid)] = str(found)
        json.dump(nodes, open('data/output/datau_nodes.json','w',encoding='utf-8'), ensure_ascii=False, indent=2)
        log(f"✅ Đã lưu: datau_town_nodes += {found}; datau_nodes[{mid}]={found}. Re-run learner sẽ học cả vùng.")
    except Exception as e:
        log(f"lưu lỗi: {e}")
else:
    log(f"❌ Hết range {LO}-{HI} không thấy node Dã Tẩu. Thử range cao hơn (--lo {HI+1} --hi {HI+4000}).")
