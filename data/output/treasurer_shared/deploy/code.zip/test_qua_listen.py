# -*- coding: utf-8 -*-
"""test_qua_listen.py — LISTENER THUẦN (KHÔNG click gì) tìm gói server BÁO-CHÍN của bãi Quả Huy Hoàng.

Tất cả quả chín CÙNG LÚC -> server gần như chắc gửi 1 gói broadcast lúc chín. Script:
  - KHÔNG gửi gói nào (không click) -> mọi op48/op133/... thấy được là SERVER TỰ đẩy.
  - Mỗi 0.5s đọc danh sách quả (id>=10000): log lúc quả XUẤT HIỆN / BIẾN MẤT (biến mất hàng loạt = sóng chín, bị hái).
  - Log mọi gói IN không-ồn, kèm mốc thời gian -> đối chiếu: gói nào tới NGAY TRƯỚC đợt biến-mất = gói báo-chín.

Dùng: (TẮT UI)  venv/bin/python -u test_qua_listen.py [secs] [device]   (mặc định 360s)
"""
import sys, time, os
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

_a = sys.argv[1:]
SECS = next((int(x) for x in _a if x.isdigit() and int(x) > 30), 360)
DEV = next((x for x in _a if (":" in x or x.startswith("emulator"))), "127.0.0.1:26624")
QUA_MIN_ID = 10000
NOISE = {7, 8, 9, 16, 17, 18, 19, 20, 23, 40, 54, 63, 66, 68, 69, 70, 83, 87, 90, 94, 117, 120, 251}
LOG = "data/output/qua_listen.log"
os.makedirs("data/output", exist_ok=True)
_lf = open(LOG, "w", encoding="utf-8")
def emit(s): print(s, flush=True); _lf.write(s + "\n"); _lf.flush()


def main():
    bot = VLTK1Bot(device_id=DEV)
    if not bot.connect():
        emit("connect FAIL (UI còn attach? tắt rồi chạy lại)"); return
    for _ in range(5):
        try: bot.poll_recv()
        except: pass
        time.sleep(0.3)
    try: bot.redetect_fd_by_traffic()
    except Exception: pass
    try: emit(f"recvAny={bot.rpc.ping().get('recvAny')}")
    except Exception as e: emit(f"ping: {e}")

    def qua_ids():
        try:
            r = bot.rpc.get_near_npcs_safe() or {}
            return sorted(int(n.get("id")) for n in (r.get("npcs") or [])
                          if str(n.get("id")).isdigit() and int(n.get("id")) >= QUA_MIN_ID)
        except Exception:
            return []

    emit(f"[*] LISTEN THUẦN {SECS}s | {DEV} | KHÔNG click. Tìm gói báo-chín. log={LOG}\n")
    t0 = time.time()
    try: bot.recv_buffer = []
    except Exception: pass
    prev = set(qua_ids()); seen = len(getattr(bot, "recv_buffer", []) or [])
    emit(f"  t+0s: bắt đầu với {len(prev)} quả: {sorted(prev)[:8]}{'...' if len(prev)>8 else ''}")
    last_beat = 0.0; last_scan = 0.0

    while time.time() - t0 < SECS:
        try: bot.poll_recv()
        except: pass
        now = time.time()
        buf = list(getattr(bot, "recv_buffer", []) or [])
        for pk in buf[seen:]:
            op = pk.get("opcode")
            if op not in NOISE:
                emit(f"  t+{now-t0:6.1f}s ←IN op{op} ({pk.get('name')}) {(pk.get('hex') or '')[:150]}")
        seen = len(buf)
        if now - last_scan >= 0.5:
            last_scan = now
            cur = set(qua_ids())
            app = cur - prev; gone = prev - cur
            if app:  emit(f"  t+{now-t0:6.1f}s 🌱 +{len(app)} quả XUẤT HIỆN: {sorted(app)[:8]}")
            if gone: emit(f"  t+{now-t0:6.1f}s 💥 -{len(gone)} quả BIẾN MẤT: {sorted(gone)[:8]} (còn {len(cur)})")
            prev = cur
        if now - last_beat > 20:
            last_beat = now
            emit(f"  --- t+{int(now-t0)}s: {len(prev)} quả quanh (đang nghe, chưa click) ---")
        time.sleep(0.1)
    emit(f"\n[xong] {SECS}s. Log: {LOG}")


if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: emit("\n[*] Dừng.")
    finally: _lf.close()
