# -*- coding: utf-8 -*-
"""test_balang_xaphu.py — TEST: từ Ba Lăng (map 53/76) có gọi được Xa Phu Tương Dương (1222) không?
User báo Ba Lăng <-> Tương Dương 'thông nhau' → nếu 1222 mở menu từ Ba Lăng thì prober đã tự xử 53/76.

AN TOÀN: chỉ THP tới Ba Lăng + mở menu npc (KHÔNG travel/mất đồ). TẮT ui_bot_app.py trước.
  venv/bin/python test_balang_xaphu.py [--device 127.0.0.1:26624] [--no-thp]
"""
import sys, time
sys.path.insert(0, ".")
from features.bot.game_bot import VLTK1Bot

DEV = "127.0.0.1:26624"
a = sys.argv
if "--device" in a:
    DEV = a[a.index("--device") + 1]
NO_THP = "--no-thp" in a   # nếu char đã đứng sẵn trong Ba Lăng thì khỏi THP

BALANG_MAPS = {53, 76, 54, 55, 56, 70, 71, 72, 73, 74, 75, 77, 199}  # vùng Ba Lăng (prefix maplist)

bot = VLTK1Bot(device_id=DEV)
if not bot.connect():
    print("connect fail"); sys.exit(1)

def cur_map():
    try: return (bot.rpc.get_player_info() or {}).get("mapId")
    except Exception: return None

mid = cur_map()
print(f"[*] Map hiện tại: {mid}", flush=True)
if mid not in BALANG_MAPS and not NO_THP:
    print("[*] Chưa ở vùng Ba Lăng -> Xa Phu tới 'Ba Lăng Huyện' (cat Thôn Trấn)…", flush=True)
    ok = bot.xaphu_travel("ba lăng huyện", wait=3.5, attempts=3)
    time.sleep(1.0)
    mid = cur_map()
    print(f"[*] Map sau Xa Phu: {mid} (travel ok={ok})", flush=True)

if mid not in BALANG_MAPS:
    print(f"⚠️ Không tới được Ba Lăng (map {mid}). Lái char tới Ba Lăng (53/76) rồi chạy lại với --no-thp.")
    sys.exit(1)

print(f"[*] Đang ở Ba Lăng map {mid}. Dò 7 Xa Phu npc xem cái nào mở menu…", flush=True)
MENU = (34, 124, 166, 167)
opened = []
for npc in ["1222", "1312", "879", "1058", "1386", "4159", "3363"]:  # 1222 (TD) thử TRƯỚC
    try: bot.recv_buffer = []
    except Exception: pass
    bot.talk_npc(npc)
    ok = bool(bot.wait_for_packet(MENU, timeout=1.3))
    tag = " (Tương Dương)" if npc == "1222" else ""
    print(f"   npc {npc:>5}{tag}: {'✅ MỞ MENU' if ok else '— (không mở)'}", flush=True)
    if ok: opened.append(npc)
    time.sleep(0.2)

print(f"\n=== KẾT QUẢ Ba Lăng map {mid}: npc mở được = {opened or 'KHÔNG CÓ'} ===")
if "1222" in opened:
    print("🎯 ĐÚNG GIẢ THUYẾT: Ba Lăng gọi được Xa Phu Tương Dương (1222) → prober ĐÃ tự xử 53/76, KHỎI TDP/id mới. ✅")
elif opened:
    print(f"→ Ba Lăng mở được npc {opened[0]} (không phải 1222) → prober vẫn xử được (npc này đã trong 7 ứng viên).")
else:
    print("→ Không npc nào trong 7 mở được → Ba Lăng là vùng riêng, cần học id Xa Phu Ba Lăng.")
