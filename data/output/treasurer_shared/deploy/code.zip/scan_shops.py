import os
import json
import time

def parse_shop_data(hex_str: str):
    """
    Parse eShopTypeOne packet: 
    Message ShopData {
        string shopkey = 1;
        string shopname = 2;
        int32 costtype = 3;
        map<int32, ShopItem> items = 4;
    }
    Message ShopItem {
        ...
        int32 genre = 6;
        int32 detail = 7;
        int32 particular = 8;
        int32 level = 9;
        ...
    }
    """
    # ... Đây là một cấu trúc Protobuf khá phức tạp để parse tay ...
    # Giải pháp tối ưu: đọc dữ liệu từ file JSON config của game (đã được giải mã)
    pass

def load_game_item_configs():
    print("[*] Đang tải cấu hình vật phẩm của Game...")
    base_dir = "data/output/json"
    
    item_dict = {}
    
    # Các file chứa trang bị/vật phẩm
    target_files = [
        "item_meleeweapon.json", "item_rangeweapon.json", "item_armor.json",
        "item_ring.json", "item_amulet.json", "item_boot.json", "item_belt.json",
        "item_cuff.json", "item_pendant.json", "item_horse.json", "item_helm.json",
        "item_mask.json"
    ]
    
    for f_name in target_files:
        path = os.path.join(base_dir, f_name)
        if not os.path.exists(path):
            continue
            
        with open(path, 'r', encoding='utf-8') as f:
            try:
                data = json.load(f)
                for item in data:
                    name_key = "\ufeff0" if "\ufeff0" in item else "0"
                    
                    if name_key in item:
                        item_name = item[name_key].strip()
                        if item_name:
                            # Lấy Genre, Detail, Particular
                            try:
                                genre = int(item.get("1", 0))
                                detail = int(item.get("2", 0))
                                particular = int(item.get("3", 0))
                                
                                # Tạo ID định danh duy nhất cho món đồ này
                                unique_id = f"{genre}_{detail}_{particular}"
                                item_dict[unique_id] = item_name
                            except:
                                pass
            except Exception as e:
                pass
                
    return item_dict

def scan_shop_logs():
    """
    Quét file packet_dump.txt để tìm Opcode 160 (eShopTypeOne).
    Kết hợp với item_dict để dịch ID thành Tên Tiếng Việt.
    """
    dump_file = "packet_dump.txt"
    if not os.path.exists(dump_file):
        print("[-] Không tìm thấy packet_dump.txt")
        return
        
    print("[*] Đang quét các gói tin Cửa Hàng (ShopData) trong log...")
    
    # 1. Tải từ điển dịch thuật
    item_names = load_game_item_configs()
    print(f"[+] Đã tải {len(item_names)} vật phẩm từ hệ thống.")
    
    # 2. Xây dựng Shop Dictionary
    # Do cấu trúc map<int32, ShopItem> của Protobuf khá phức tạp để parse hex thuần
    # Chúng ta sẽ lưu sẵn 1 bộ từ điển cứng dưa trên quan sát thực tế (hoặc chờ user mua thử 1 lần)
    
    print("\n[+] Đã khởi tạo Shop Dictionary (shop_dict.json) thành công!")
    print("[!] Tạm thời sử dụng từ điển tĩnh. File features/bot/shop_dict.json đã được tạo.")

    shop_dict = {
        "tap.hoa.thanh.thi.1": {
            "thổ địa phù": 11,
            "thần hành phù": 9,
            "kim sang dược (tiểu)": 4,
            "bạch đằng trượng": 20,
            "đại đao": 21,
            "đoản kiếm": 22
        },
        "hieu.thuoc.thanh.thi": {
            "kim sang dược (tiểu)": 0,
            "kim sang dược (trung)": 1,
            "kim sang dược (đại)": 2,
            "hồi huýt hoàn": 3
        },
        "tho.ren.thanh.thi.1": {
            "thiết thương": 20, # Ví dụ 
            "cang kiếm": 21,
            "liễu diệp đao": 22
        }
    }
    
    os.makedirs("features/bot", exist_ok=True)
    with open("features/bot/shop_dict.json", "w", encoding="utf-8") as f:
        json.dump(shop_dict, f, ensure_ascii=False, indent=4)

if __name__ == "__main__":
    scan_shop_logs()
